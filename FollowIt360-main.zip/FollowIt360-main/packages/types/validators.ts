import { z } from 'zod';
import { INSURANCE_COMPANIES } from './constants.js';
import type { CommissionValues, CompanyAgreements } from './interfaces';

const companyEnumValidator = z.enum(INSURANCE_COMPANIES);

export const commissionValuesSchema: z.ZodType<CommissionValues> = z.object({
    scope: z.string().optional(),
    ongoing: z.string().optional(),
    mobility: z.string().optional(),
    isActive: z.boolean().optional(),
});

export const companyAgreementsSchema: z.ZodType<CompanyAgreements> = z.record(
    z.string(),
    commissionValuesSchema,
);

export const userAgreementSchema = z.object({
    company: z.union([companyEnumValidator, z.literal('GLOBAL')]),
    rates: companyAgreementsSchema.optional(),
});

export const signupRequestSchema = z.object({
    name: z.string().min(1, 'Name is required'),
    email: z.string().email('Invalid email format'),
    password: z.string().min(8, 'Password must be at least 8 characters'),
});

export type SignupRequest = z.infer<typeof signupRequestSchema>;

export const loginRequestSchema = z.object({
    email: z.string().email('Invalid email format'),
    password: z.string().min(1, 'Password is required'),
});

export type LoginRequest = z.infer<typeof loginRequestSchema>;
