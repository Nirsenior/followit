import { InsuranceType } from './constants.js';

export interface User {
    id: string;
    name: string;
    email: string;
    phone?: string;
}

export interface CommissionValues {
    scope?: string;
    ongoing?: string;
    mobility?: string;
    isActive?: boolean;
}

export type CompanyAgreements = Partial<Record<InsuranceType, CommissionValues>>;

export interface UserProfile {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone?: string;
    isAdmin?: boolean;
    password?: string;
    selectedCompanies: string[];
    agreements: Record<string, CompanyAgreements>;
    paymentMethod?: {
        cardNumber: string;
        expiry: string;
        cvv: string;
    };
    isSetupComplete?: boolean;
}

export interface PremiumScheduleItem {
    age: number;
    premium: number;
}

export interface InvestmentTrackAllocation {
    trackName: string;
    weight: number; // 0-100 percentage
}

export interface Policy {
    id: string;
    type: InsuranceType;
    company: string;
    isAgentAppointmentOnly: boolean;
    monthlyCost: number;
    premiumSchedule?: PremiumScheduleItem[];
    excelColumns?: string[];
    details: {
        subPolicies?: Record<string, number>;
        accumulation?: number;
        deposit?: number;
        mobility?: number;
        redemptions?: number;
        subType?: string;
        monthlyDeposit?: number;
        lumpSumDeposit?: number;
        investmentTracks?: InvestmentTrackAllocation[];
        establishmentDate?: string;
        isRecommended?: boolean;
        recommendationReason?: string;
    };
    issueDate: string;
    status: 'active' | 'inactive';
    fixedCommissionRate?: string;
    currentAccumulation?: string;
    initialAccumulation?: string;
    systemEntryDate?: string;
    lastCalculatedDate?: string;
}

export type Relationship = 'spouse' | 'child' | 'other';

export interface FamilyMember {
    id: string;
    firstName: string;
    lastName: string;
    dateOfBirth: string;
    relationship: Relationship;
    policies: Policy[];
    isPremiumSharedWithPrimary?: boolean;
}

export interface Customer {
    id: string; // governmentId
    dbId?: string; // actual database UUID
    firstName: string;
    lastName: string;
    dateOfBirth?: string;
    issueDate: string;
    policies: Policy[];
    familyMembers?: FamilyMember[];
    createdAt?: string;
    creationType?: 'existing' | 'new_production';
}
