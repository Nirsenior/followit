import { InsuranceType } from './constants.js';

export * from './constants.js';
export * from './interfaces.js';

export type FinancialSubType =
    | 'קרן השתלמות'
    | 'קופת גמל'
    | 'קופת גמל להשקעה'
    | 'חיסכון ארוך טווח'
    | 'קרן פנסיה';

export interface CommissionValues {
    scope?: string;
    ongoing?: string;
    mobility?: string;
    isActive?: boolean;
}

export type CompanyAgreements = Partial<Record<InsuranceType, CommissionValues>>;

export interface UserProfile {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone?: string;
    password?: string;
    agreements: Record<string, CompanyAgreements>;
    paymentMethod: {
        cardNumber: string;
        expiry: string;
        cvv: string;
    };
    isAdmin?: boolean;
    isSetupComplete?: boolean;
}

export interface PremiumScheduleItem {
    age: number;
    premium: number;
}

export interface InvestmentTrackAllocation {
    trackName: string;
    weight: number; // 0-100 percentage
}

export interface Policy {
    id: string;
    type: InsuranceType;
    company: string;
    isAgentAppointmentOnly: boolean;
    monthlyCost: number; // Manual cost or fallback
    premiumSchedule?: PremiumScheduleItem[]; // From Excel
    excelColumns?: string[]; // Metadata from Excel if uploaded
    details: {
        subPolicies?: Record<string, number>;
        accumulation?: number;
        deposit?: number; // Legacy — use for backward compat
        mobility?: number;
        redemptions?: number;
        subType?: string;
        monthlyDeposit?: number;
        lumpSumDeposit?: number;
        investmentTracks?: InvestmentTrackAllocation[];
        establishmentDate?: string;
        manualElementaryScope?: number;
        manualElementaryOngoing?: number;
    };
    issueDate: string;
    status: 'active' | 'inactive';
    fixedCommissionRate?: string; // Locked rate for "New Only" updates
}

export type Relationship = 'spouse' | 'child' | 'other';

export interface FamilyMember {
    id: string; // T.Z or ID
    firstName: string;
    lastName: string;
    issueDate: string;
    relationship: Relationship;
    policies: Policy[];
    isPremiumSharedWithPrimary?: boolean; // For children < 18
}

export interface Customer {
    id: string; // T.Z
    firstName: string;
    lastName: string;
    issueDate: string; // Mandatory for Excel-based premium (was birthdate)
    policies: Policy[];
    familyMembers?: FamilyMember[];
    createdAt: string;
    creationType?: 'existing' | 'new_production';
}

export * from './validators.js';
