export const INSURANCE_COMPANIES = [
    'הראל',
    'מגדל',
    'מנורה',
    'הפניקס',
    'כלל',
    'איילון',
    'שומרה',
    'שלמה חברה לביטוח',
    'הכשרה',
    'פספורטקארד',
    'אלטשולר שחם',
    'אינפיניטי',
    'מור',
    'פסגות',
    'אנליסט',
    'IBI',
    'ילין לפידות',
    'מיטב',
] as const;

export type InsuranceCompany = (typeof INSURANCE_COMPANIES)[number];

export const INSURANCE_TYPES = [
    'health',
    'life',
    'critical_illness',
    'pension',
    'gemel',
    'hishtalmut',
    'gemel_invest',
    'long_term_savings',
    'elementary',
    'abroad',
] as const;

export type InsuranceType = (typeof INSURANCE_TYPES)[number];

export const INDIVIDUAL_POLICY_COMPANIES = [
    'הפניקס',
    'הראל',
    'כלל',
    'מגדל',
    'מנורה',
    'איילון',
    'הכשרה',
];

export const FINANCIAL_ONLY_COMPANIES = [
    'אלטשולר שחם',
    'אינפיניטי',
    'מור',
    'פסגות',
    'אנליסט',
    'IBI',
    'ילין לפידות',
    'מיטב',
];

export const PENSION_COMPANIES = [
    'מגדל',
    'מנורה',
    'אלטשולר שחם',
    'הראל',
    'מור',
    'מיטב',
    'הפניקס',
    'כלל',
    'אינפיניטי',
];

export const GEMEL_COMPANIES = [
    'הפניקס',
    'מנורה',
    'אלטשולר שחם',
    'מיטב',
    'ילין לפידות',
    'מגדל',
    'הראל',
    'מור',
    'כלל',
    'אנליסט',
    'אינפיניטי',
];

export const HISHTALMUT_COMPANIES = [
    'ילין לפידות',
    'מור',
    'כלל',
    'מגדל',
    'אינפיניטי',
    'מיטב',
    'אנליסט',
    'מנורה',
    'הפניקס',
    'הראל',
    'אלטשולר שחם',
];

export const GEMEL_INVEST_COMPANIES = [
    'הפניקס',
    'מנורה',
    'הראל',
    'ילין לפידות',
    'אינפיניטי',
    'מור',
    'אלטשולר שחם',
    'אנליסט',
    'מגדל',
    'כלל',
    'מיטב',
];

export const POLIS_COMPANIES = [
    'מגדל',
    'הכשרה',
    'הראל',
    'מנורה',
    'הפניקס',
    'כלל',
    'איילון',
];

export const ELEMENTARY_COMPANIES = ['שומרה', 'שלמה חברה לביטוח'];

export const INSURANCE_TYPE_LABELS: Record<InsuranceType, string> = {
    health: 'בריאות',
    life: 'חיים',
    critical_illness: 'מחלות קשות',
    pension: 'פנסיה',
    gemel: 'קופת גמל',
    hishtalmut: 'קרן השתלמות',
    gemel_invest: 'קופת גמל להשקעה',
    long_term_savings: 'חיסכון ארוך טווח',
    elementary: 'אלמנטרי',
    abroad: 'חו״ל',
};

export const FINANCIAL_TYPES = [
    'pension',
    'gemel',
    'hishtalmut',
    'gemel_invest',
    'long_term_savings',
] as const;

export type FinancialType = (typeof FINANCIAL_TYPES)[number];

/**
 * Type guard to check if an insurance type is a financial type.
 */
export function isFinancialType(type: InsuranceType): type is FinancialType {
    return (FINANCIAL_TYPES as readonly InsuranceType[]).includes(type);
}

export const INDIVIDUAL_TYPES = ['health', 'life', 'critical_illness'] as const;
export type IndividualType = (typeof INDIVIDUAL_TYPES)[number];

/**
 * Type guard to check if an insurance type is an individual type (health, life, critical illness).
 */
export function isIndividualType(type: InsuranceType): type is IndividualType {
    return (INDIVIDUAL_TYPES as readonly InsuranceType[]).includes(type);
}

/**
 * Checks if a given insurance type should show the mobility commission field.
 * Currently, all financial types except long-term savings show this field.
 */
export function isMobilityType(type: InsuranceType): boolean {
    return isFinancialType(type) && type !== 'long_term_savings';
}

export const PRIVATE_SUB_POLICIES = [
    'ניתוחים בחו״ל',
    'השתלות בחו״ל',
    'תרופות מחוץ לסל',
    'ניתוחים משלים שב״ן עם השתתפות עצמית',
    'ניתוחים משלים שב״ן ללא השתתפות עצמית',
    'ניתוחים שקל ראשון',
    'ייעוץ ובדיקות בסיסי',
    'ייעוץ ובדיקות מורחב',
    'אבחון מהיר',
    'טיפולים בטכנולוגיות מתקדמות ואביזרים',
    'ליווי רפואי וטיפולים אגב אירוע רפואי',
    'רפואה משלימה',
    'ייעוץ אונליין',
    'ביקור רופא עד הבית',
    'טיפולים בהתפתחות הילד',
    'מחלות קשות',
    'מחלות קשות – כיסוי לסרטן',
    'תאונות אישיות',
];

export const ELEMENTARY_OPTIONS = {
    רכב: ['מקיף', 'חובה', "צד ג'"],
    דירה: ['תכולה', "צד ג'", 'מבנה'],
    עסק: ['אחריות מקצועית', 'תכולה', "צד ג'", 'מבנה'],
} as const;

export const PRODUCT_GROUP_LABELS = {
    pension: INSURANCE_TYPE_LABELS.pension,
    financial: 'פיננסי',
    individual: 'פרט',
    elementary: INSURANCE_TYPE_LABELS.elementary,
    abroad: INSURANCE_TYPE_LABELS.abroad,
} as const;

/**
 * Maps an internal insurance type to its primary product group label.
 */
export function getProductGroupLabel(type: InsuranceType): string {
    if (type === 'pension') return PRODUCT_GROUP_LABELS.pension;
    if (isFinancialType(type)) return PRODUCT_GROUP_LABELS.financial;
    if (isIndividualType(type)) return PRODUCT_GROUP_LABELS.individual;
    if (type === 'elementary') return PRODUCT_GROUP_LABELS.elementary;
    if (type === 'abroad') return PRODUCT_GROUP_LABELS.abroad;
    return INSURANCE_TYPE_LABELS[type] || type;
}

export const POLICY_STATUS = {
    ACTIVE: 'active',
} as const;

export const INSURANCE_TYPE = {
    PENSION: 'pension',
    ELEMENTARY: 'elementary',
    ABROAD: 'abroad',
    GEMEL: 'gemel',
    HISHTALMUT: 'hishtalmut',
    GEMEL_INVEST: 'gemel_invest',
    HEALTH: 'health',
    LIFE: 'life',
    CRITICAL_ILLNESS: 'critical_illness',
    LONG_TERM_SAVINGS: 'long_term_savings',
} as const;

export const GEMELNET_COMPANY_MAP: Record<string, string> = {
    'הראל': 'הראל פנסיה וגמל בע"מ',
    'מגדל': 'מגדל מקפת קרנות פנסיה וקופות גמל בע"מ',
    'מנורה': 'מנורה מבטחים פנסיה וגמל בע"מ',
    'הפניקס': 'הפניקס פנסיה וגמל בע"מ ',
    'כלל': 'כלל פנסיה וגמל בע"מ',
    'אלטשולר שחם': 'אלטשולר שחם גמל ופנסיה בע"מ',
    'מור': 'מור גמל ופנסיה בע"מ',
    'מיטב': 'מיטב גמל ופנסיה בע"מ',
    'ילין לפידות': 'ילין לפידות ניהול קופות גמל בע"מ',
    'פסגות': 'פסגות קופות גמל ופנסיה בע"מ', // Note: largely acquired by Altshuler
    'אנליסט': 'אנליסט קופות גמל בע"מ',
    'אינפיניטי': 'אינפיניטי השתלמות, גמל ופנסיה בע"מ',
    'IBI': 'אי.בי.אי. השתלמות בע"מ',
    'הכשרה': 'הכשרה חברה לביטוח בע"מ',
    'איילון': 'איילון פנסיה וגמל בע"מ',
};

export const POLIS_COMPANY_MAP: Record<string, string> = {
    'מגדל': 'מגדל חברה לביטוח בע"מ',
    'הכשרה': 'הכשרה חברה לביטוח בע"מ',
    'הראל': 'הראל חברה לביטוח בע"מ',
    'מנורה': 'מנורה מבטחים חברה לביטוח בע"מ',
    'הפניקס': 'הפניקס חברה לביטוח בע"מ',
    'כלל': 'כלל חברה לביטוח בע"מ',
    'איילון': 'איילון חברה לביטוח בע"מ',
};
