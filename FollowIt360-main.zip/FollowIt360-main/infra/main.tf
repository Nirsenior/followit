terraform {
  backend "gcs" {
    bucket = "followit360-tfstate-prod"
    prefix = "terraform/state"
  }
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = ">= 4.0.0"
    }
    google-beta = {
      source  = "hashicorp/google-beta"
      version = ">= 4.0.0"
    }
  }
}

provider "google" {
  # Credentials can be set via GOOGLE_APPLICATION_CREDENTIALS env var
}

provider "google-beta" {
  # Credentials can be set via GOOGLE_APPLICATION_CREDENTIALS env var
}

locals {
  environments = {
    staging = "stg"
    prod    = "prod"
  }
}

resource "google_project" "follow_it" {
  for_each        = local.environments
  name            = "${var.project_name}-${each.value}"
  project_id      = "${var.project_name}-${each.value}"
  billing_account = var.billing_account_id
  org_id          = var.org_id

  labels = {
    env     = each.key
    project = var.project_name
    owner   = var.owner
  }
}

resource "google_project_service" "cloudbilling" {
  for_each           = google_project.follow_it
  project            = each.value.project_id
  service            = "cloudbilling.googleapis.com"
  disable_on_destroy = false
}

resource "google_project_service" "run" {
  for_each           = google_project.follow_it
  project            = each.value.project_id
  service            = "run.googleapis.com"
  disable_on_destroy = false
}

resource "google_project_service" "sqladmin" {
  for_each           = google_project.follow_it
  project            = each.value.project_id
  service            = "sqladmin.googleapis.com"
  disable_on_destroy = false
}

resource "google_project_service" "iam" {
  for_each           = google_project.follow_it
  project            = each.value.project_id
  service            = "iam.googleapis.com"
  disable_on_destroy = false
}

resource "google_project_service" "iamcredentials" {
  for_each           = google_project.follow_it
  project            = each.value.project_id
  service            = "iamcredentials.googleapis.com"
  disable_on_destroy = false
}

resource "google_project_service" "artifactregistry" {
  for_each           = google_project.follow_it
  project            = each.value.project_id
  service            = "artifactregistry.googleapis.com"
  disable_on_destroy = false
}

resource "google_project_service" "dns" {
  for_each           = google_project.follow_it
  project            = each.value.project_id
  service            = "dns.googleapis.com"
  disable_on_destroy = false
}

resource "google_project_service" "firebase" {
  for_each           = google_project.follow_it
  project            = each.value.project_id
  service            = "firebase.googleapis.com"
  disable_on_destroy = false
}

resource "google_project_service" "appengine" {
  for_each           = google_project.follow_it
  project            = each.value.project_id
  service            = "appengine.googleapis.com"
  disable_on_destroy = false
}

resource "google_project_service" "compute" {
  for_each           = google_project.follow_it
  project            = each.value.project_id
  service            = "compute.googleapis.com"
  disable_on_destroy = false
}

resource "google_project_service" "servicenetworking" {
  for_each           = google_project.follow_it
  project            = each.value.project_id
  service            = "servicenetworking.googleapis.com"
  disable_on_destroy = false
}


resource "google_project_service" "secretmanager" {
  for_each           = google_project.follow_it
  project            = each.value.project_id
  service            = "secretmanager.googleapis.com"
  disable_on_destroy = false
}

resource "google_project_service" "cloudscheduler" {
  for_each           = google_project.follow_it
  project            = each.value.project_id
  service            = "cloudscheduler.googleapis.com"
  disable_on_destroy = false
}

resource "google_storage_bucket" "tf_state" {
  provider                    = google
  project                     = google_project.follow_it["prod"].project_id
  name                        = "followit360-tfstate-prod"
  location                    = "me-west1"
  force_destroy               = false
  uniform_bucket_level_access = true
  versioning {
    enabled = true
  }
}
