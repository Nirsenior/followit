locals {
  domain_map = {
    staging = google_firebase_hosting_custom_domain.staging.custom_domain
    prod    = google_firebase_hosting_custom_domain.prod_www.custom_domain
  }
}

data "google_secret_manager_secret_version" "cron_secret_version" {
  for_each = google_project.follow_it
  secret   = data.google_secret_manager_secret.cron_secret[each.key].id
  project  = each.value.project_id
}

resource "google_cloud_scheduler_job" "yield_catch_up" {
  for_each         = google_project.follow_it
  project          = each.value.project_id
  region           = var.region
  name             = "yield-catch-up-job"
  description      = "Nightly job to calculate yield catch-ups for policies"
  schedule         = "0 2 * * *"
  time_zone        = "Asia/Jerusalem"
  attempt_deadline = "320s"

  http_target {
    http_method = "POST"
    uri         = "https://${local.domain_map[each.key]}/api/yields/catch-up"

    headers = {
      "x-cron-secret" = data.google_secret_manager_secret_version.cron_secret_version[each.key].secret_data
    }
  }

  depends_on = [
    google_project_service.cloudscheduler
  ]
}
