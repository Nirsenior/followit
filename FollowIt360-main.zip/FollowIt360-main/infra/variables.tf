variable "project_name" {
  description = "The base name of the project"
  type        = string
  default     = "followit360"
}

variable "billing_account_id" {
  description = "The ID of the billing account to associate with the project"
  type        = string
}

variable "org_id" {
  description = "The ID of the organization or folder to create the project in"
  type        = string
}

variable "owner" {
  description = "The owner of the resources (for tagging)"
  type        = string
  default     = "user"
}

variable "region" {
  description = "The region to deploy resources in"
  type        = string
  default     = "me-west1"
}
