resource "google_service_account" "app_sa" {
  for_each     = google_project.follow_it
  project      = each.value.project_id
  account_id   = "${var.project_name}-app-sa"
  display_name = "Application Service Account for ${each.key}"
}

resource "google_project_iam_member" "run_invoker" {
  for_each = google_project.follow_it
  project  = each.value.project_id
  role     = "roles/run.invoker"
  member   = "serviceAccount:${google_service_account.app_sa[each.key].email}"
}

resource "google_project_iam_member" "cloudsql_client" {
  for_each = google_project.follow_it
  project  = google_project.follow_it["prod"].project_id # Shared instance is in prod
  role     = "roles/cloudsql.client"
  member   = "serviceAccount:${google_service_account.app_sa[each.key].email}"
}

resource "google_project_iam_member" "run_admin" {
  for_each = google_project.follow_it
  project  = each.value.project_id
  role     = "roles/run.admin"
  member   = "serviceAccount:${google_service_account.app_sa[each.key].email}"
}

resource "google_project_iam_member" "sa_user" {
  for_each = google_project.follow_it
  project  = each.value.project_id
  role     = "roles/iam.serviceAccountUser"
  member   = "serviceAccount:${google_service_account.app_sa[each.key].email}"
}

resource "google_project_iam_member" "firebase_admin" {
  for_each = google_project.follow_it
  project  = each.value.project_id
  role     = "roles/firebasehosting.admin"
  member   = "serviceAccount:${google_service_account.app_sa[each.key].email}"
}

# Cloud Run Service Agent needs VPC Access User role on PROD project (where connectors live)
resource "google_project_iam_member" "vpc_access_user" {
  for_each = google_project.follow_it
  project  = google_project.follow_it["prod"].project_id
  role     = "roles/vpcaccess.user"
  member   = "serviceAccount:service-${google_project.follow_it[each.key].number}@serverless-robot-prod.iam.gserviceaccount.com"
}

# Cloud Run Service Agent needs Compute Network User role on PROD project to use connector there
resource "google_project_iam_member" "cloud_run_network_user" {
  for_each = google_project.follow_it
  project  = google_project.follow_it["prod"].project_id
  role     = "roles/compute.networkUser"
  member   = "serviceAccount:service-${google_project.follow_it[each.key].number}@serverless-robot-prod.iam.gserviceaccount.com"
}

# Cloud Run Service Agent needs Viewer role on PROD project to "see" the cross-project connector
resource "google_project_iam_member" "cloud_run_viewer" {
  for_each = google_project.follow_it
  project  = google_project.follow_it["prod"].project_id
  role     = "roles/viewer"
  member   = "serviceAccount:service-${google_project.follow_it[each.key].number}@serverless-robot-prod.iam.gserviceaccount.com"
}

# Grant production service account owner permissions on the staging project
resource "google_project_iam_member" "prod_sa_staging_owner" {
  project = google_project.follow_it["staging"].project_id
  role    = "roles/owner"
  member  = "serviceAccount:${google_service_account.app_sa["prod"].email}"
}

# Grant production service account owner role on production project as well
resource "google_project_iam_member" "prod_sa_prod_owner" {
  project = google_project.follow_it["prod"].project_id
  role    = "roles/owner"
  member  = "serviceAccount:${google_service_account.app_sa["prod"].email}"
}
