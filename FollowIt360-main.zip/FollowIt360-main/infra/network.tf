# VPC Network in each project
resource "google_compute_network" "main" {
  for_each                = google_project.follow_it
  name                    = "follow-it-vpc-${each.key}"
  project                 = each.value.project_id
  auto_create_subnetworks = false

  depends_on = [google_project_service.compute]
}

# Subnet for Cloud Run connectors
resource "google_compute_subnetwork" "connector_subnet" {
  for_each      = google_project.follow_it
  name          = "connector-subnet-${each.key}"
  project       = each.value.project_id
  region        = var.region
  network       = google_compute_network.main[each.key].id
  ip_cidr_range = each.key == "prod" ? "10.1.1.0/24" : "10.1.2.0/24"
}

# Reserved IP range for Cloud SQL Private Service Access (only in prod where instance lives)
resource "google_compute_global_address" "private_ip_address" {
  name          = "google-managed-services-prod"
  purpose       = "VPC_PEERING"
  address_type  = "INTERNAL"
  prefix_length = 16
  network       = google_compute_network.main["prod"].id
  project       = google_project.follow_it["prod"].project_id

  depends_on = [google_project_service.compute]
}

# Create the VPC Peering for Private Service Access
resource "google_service_networking_connection" "private_vpc_connection" {
  network                 = google_compute_network.main["prod"].id
  service                 = "servicenetworking.googleapis.com"
  reserved_peering_ranges = [google_compute_global_address.private_ip_address.name]

  depends_on = [google_project_service.servicenetworking]
}


# PSC Endpoint for Cloud SQL in staging VPC to reach prod instance
resource "google_compute_address" "sql_psc_endpoint" {
  name         = "sql-psc-endpoint"
  project      = google_project.follow_it["staging"].project_id
  region       = var.region
  subnetwork   = google_compute_subnetwork.connector_subnet["staging"].id
  address_type = "INTERNAL"
  purpose      = "GCE_ENDPOINT"
}

resource "google_compute_forwarding_rule" "sql_psc_rule" {
  name                  = "sql-psc-rule"
  project               = google_project.follow_it["staging"].project_id
  region                = var.region
  network               = google_compute_network.main["staging"].id
  target                = google_sql_database_instance.cluster.psc_service_attachment_link
  load_balancing_scheme = ""
  ip_address            = google_compute_address.sql_psc_endpoint.id
}

# Cloud DNS Private Zone in staging to resolve the PSC endpoint
resource "google_dns_managed_zone" "sql_psc_zone" {
  name        = "sql-psc-zone"
  project     = google_project.follow_it["staging"].project_id
  dns_name    = "sql.goog."
  description = "Private zone to resolve Cloud SQL PSC endpoint"
  visibility  = "private"

  private_visibility_config {
    networks {
      network_url = google_compute_network.main["staging"].id
    }
  }

  depends_on = [google_project_service.dns]
}

resource "google_dns_record_set" "sql_psc_record" {
  name         = "e1cfa342fb4d.2q1z4vmhb3e66.me-west1.sql.goog."
  project      = google_project.follow_it["staging"].project_id
  type         = "A"
  ttl          = 300
  managed_zone = google_dns_managed_zone.sql_psc_zone.name
  rrdatas      = [google_compute_address.sql_psc_endpoint.address]
}
