# Grant access to manually created JWT_SECRET
data "google_secret_manager_secret" "jwt_secret" {
  secret_id = "JWT_SECRET"
  project   = google_project.follow_it["prod"].project_id
}

resource "google_secret_manager_secret_iam_member" "jwt_secret_access" {
  for_each  = google_project.follow_it
  project   = google_project.follow_it["prod"].project_id
  secret_id = data.google_secret_manager_secret.jwt_secret.id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${google_service_account.app_sa[each.key].email}"
}

# Grant access to manually created GOOGLE_CLIENT_ID
data "google_secret_manager_secret" "google_client_id" {
  for_each  = google_project.follow_it
  secret_id = "GOOGLE_CLIENT_ID"
  project   = each.value.project_id
}

resource "google_secret_manager_secret_iam_member" "google_client_id_access" {
  for_each  = google_project.follow_it
  project   = each.value.project_id
  secret_id = data.google_secret_manager_secret.google_client_id[each.key].id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${google_service_account.app_sa[each.key].email}"
}

# Grant access to manually created GOOGLE_CLIENT_SECRET
data "google_secret_manager_secret" "google_client_secret" {
  for_each  = google_project.follow_it
  secret_id = "GOOGLE_CLIENT_SECRET"
  project   = each.value.project_id
}

resource "google_secret_manager_secret_iam_member" "google_client_secret_access" {
  for_each  = google_project.follow_it
  project   = each.value.project_id
  secret_id = data.google_secret_manager_secret.google_client_secret[each.key].id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${google_service_account.app_sa[each.key].email}"
}

# Grant access to manually created CRON_SECRET
data "google_secret_manager_secret" "cron_secret" {
  for_each  = google_project.follow_it
  secret_id = "CRON_SECRET"
  project   = each.value.project_id
}

resource "google_secret_manager_secret_iam_member" "cron_secret_access" {
  for_each  = google_project.follow_it
  project   = each.value.project_id
  secret_id = data.google_secret_manager_secret.cron_secret[each.key].id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${google_service_account.app_sa[each.key].email}"
}
