# Enable Firebase on the projects
resource "google_firebase_project" "follow_it" {
  provider = google-beta
  for_each = google_project.follow_it
  project  = each.value.project_id

  depends_on = [google_project_service.firebase]
}

# Add Firebase Hosting site
resource "google_firebase_hosting_site" "staging" {
  provider = google-beta
  project  = google_project.follow_it["staging"].project_id
  site_id  = "followit360-stg" # This must be unique in Firebase

  depends_on = [google_firebase_project.follow_it]
}

# Add Custom Domain
resource "google_firebase_hosting_custom_domain" "staging" {
  provider      = google-beta
  project       = google_project.follow_it["staging"].project_id
  site_id       = google_firebase_hosting_site.staging.site_id
  custom_domain = "staging.followit360.com"
}

output "staging_dns_records" {
  value = google_firebase_hosting_custom_domain.staging.required_dns_updates
}

resource "google_firebase_hosting_custom_domain" "prod" {
  provider        = google-beta
  project         = google_project.follow_it["prod"].project_id
  site_id         = google_project.follow_it["prod"].project_id
  custom_domain   = "followit360.com"
  redirect_target = google_firebase_hosting_custom_domain.prod_www.custom_domain
}

resource "google_firebase_hosting_custom_domain" "prod_www" {
  provider      = google-beta
  project       = google_project.follow_it["prod"].project_id
  site_id       = google_project.follow_it["prod"].project_id
  custom_domain = "www.followit360.com"
}

output "prod_dns_records" {
  value = google_firebase_hosting_custom_domain.prod.required_dns_updates
}

output "prod_www_dns_records" {
  value = google_firebase_hosting_custom_domain.prod_www.required_dns_updates
}

