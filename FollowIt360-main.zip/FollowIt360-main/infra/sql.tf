resource "google_sql_database_instance" "cluster" {
  name             = "follow-it-cluster"
  project          = google_project.follow_it["prod"].project_id
  region           = var.region
  database_version = "POSTGRES_15"

  settings {
    tier = "db-f1-micro"

    ip_configuration {
      ipv4_enabled                                  = false
      private_network                               = google_compute_network.main["prod"].id
      enable_private_path_for_google_cloud_services = true

      psc_config {
        psc_enabled               = true
        allowed_consumer_projects = [for p in google_project.follow_it : p.project_id]
      }
    }

    database_flags {
      name  = "cloudsql.iam_authentication"
      value = "on"
    }

    user_labels = {
      project     = "followit360"
      cost-center = "investor-funded"
    }
  }

  depends_on = [
    google_service_networking_connection.private_vpc_connection,
    google_project_service.sqladmin
  ]
}

resource "google_sql_database" "follow_it_staging" {
  name     = "follow_it_staging"
  instance = google_sql_database_instance.cluster.name
  project  = google_project.follow_it["prod"].project_id
}

resource "google_sql_database" "follow_it_prod" {
  name     = "follow_it_prod"
  instance = google_sql_database_instance.cluster.name
  project  = google_project.follow_it["prod"].project_id
}

# Create IAM Users for Database Authentication
resource "google_sql_user" "iam_user" {
  for_each = google_project.follow_it
  name     = trimsuffix(google_service_account.app_sa[each.key].email, ".gserviceaccount.com")
  instance = google_sql_database_instance.cluster.name
  project  = google_project.follow_it["prod"].project_id
  type     = "CLOUD_IAM_SERVICE_ACCOUNT"
}

# Grant Cloud SQL Instance User role to the service accounts
resource "google_project_iam_member" "sql_instance_user" {
  for_each = google_project.follow_it
  project  = google_project.follow_it["prod"].project_id # Instance is in prod project
  role     = "roles/cloudsql.instanceUser"
  member   = "serviceAccount:${google_service_account.app_sa[each.key].email}"
}
