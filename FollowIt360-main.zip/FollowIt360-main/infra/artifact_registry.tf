resource "google_artifact_registry_repository" "app_images" {
  provider = google
  for_each = google_project.follow_it

  location      = "me-west1"
  repository_id = "app-images"
  description   = "Docker repository for application images"
  format        = "DOCKER"
  project       = each.value.project_id

  cleanup_policy_dry_run = false

  cleanup_policies {
    id     = "keep-recent-3"
    action = "KEEP"
    most_recent_versions {
      keep_count = 3
    }
  }

  cleanup_policies {
    id     = "delete-others"
    action = "DELETE"
    condition {
      tag_state = "ANY"
    }
  }
}

resource "google_artifact_registry_repository_iam_member" "writer" {
  provider = google
  for_each = google_project.follow_it

  project    = each.value.project_id
  location   = google_artifact_registry_repository.app_images[each.key].location
  repository = google_artifact_registry_repository.app_images[each.key].name
  role       = "roles/artifactregistry.writer"
  member     = "serviceAccount:${google_service_account.app_sa[each.key].email}"
}
