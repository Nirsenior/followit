resource "google_iam_workload_identity_pool" "github_pool" {
  provider = google
  for_each = google_project.follow_it

  workload_identity_pool_id = "github-pool"
  display_name              = "GitHub Actions Pool"
  description               = "Identity pool for GitHub Actions"
  project                   = each.value.project_id
}

resource "google_iam_workload_identity_pool_provider" "github" {
  provider = google
  for_each = google_project.follow_it

  workload_identity_pool_id          = google_iam_workload_identity_pool.github_pool[each.key].workload_identity_pool_id
  workload_identity_pool_provider_id = "github-provider"
  display_name                       = "GitHub Actions Provider"
  description                        = "OIDC identity provider for GitHub Actions"
  project                            = each.value.project_id

  attribute_mapping = {
    "google.subject"       = "assertion.sub"
    "attribute.actor"      = "assertion.actor"
    "attribute.repository" = "assertion.repository"
  }

  attribute_condition = "assertion.repository == 'GalTenne/FollowIt360'"

  oidc {
    issuer_uri = "https://token.actions.githubusercontent.com"
  }
}

resource "google_service_account_iam_member" "wif_user" {
  provider = google
  for_each = google_project.follow_it

  service_account_id = google_service_account.app_sa[each.key].name
  role               = "roles/iam.workloadIdentityUser"
  member             = "principalSet://iam.googleapis.com/${google_iam_workload_identity_pool.github_pool[each.key].name}/attribute.repository/GalTenne/FollowIt360"
}
