output "project_ids" {
  value = {
    for k, v in google_project.follow_it : k => v.project_id
  }
}

output "service_account_emails" {
  value = {
    for k, v in google_service_account.app_sa : k => v.email
  }
}
