/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        slate: {
          50: '#f8fafc',
          100: '#f1f5f9',
          200: '#e2e8f0',
          300: '#cbd5e1',
          400: '#94a3b8',
          500: '#64748b',
          600: '#475569',
          700: '#334155',
          800: '#1e293b',
          900: '#0f172a',
          950: '#020617',
        },
        sky: {
          50: '#eff6ff',   
          100: '#dbeafe',
          200: '#bfdbfe',
          300: '#93c5fd',
          400: '#60a5fa',
          500: '#3b82f6',
          600: '#2563eb',
          700: '#1d4ed8',
          800: '#1e40af',
          900: '#1e3a8a',
        },
        emerald: {
          400: '#34D399',
          500: '#059669',
        },
        rose: {
          400: '#FB7185',
          500: '#E11D48',
        },
        amber: {
          500: '#D97706',
        }
      },
      boxShadow: {
        'sm': '0 2px 8px -2px rgba(24, 24, 27, 0.04)',
        'DEFAULT': '0 4px 16px -4px rgba(24, 24, 27, 0.06), 0 2px 8px -2px rgba(24, 24, 27, 0.04)',
        'md': '0 8px 24px -4px rgba(24, 24, 27, 0.06), 0 4px 12px -2px rgba(24, 24, 27, 0.04)',
        'lg': '0 12px 32px -4px rgba(24, 24, 27, 0.08), 0 6px 16px -2px rgba(24, 24, 27, 0.04)',
        'xl': '0 20px 48px -8px rgba(24, 24, 27, 0.1), 0 8px 24px -4px rgba(24, 24, 27, 0.04)',
        '2xl': '0 32px 64px -12px rgba(24, 24, 27, 0.14), 0 16px 32px -8px rgba(24, 24, 27, 0.04)',
      }
    }
  },
  plugins: [],
}
