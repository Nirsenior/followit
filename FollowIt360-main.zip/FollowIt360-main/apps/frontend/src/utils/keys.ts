/**
 * Named keyboard key values from the UI Events spec.
 * https://www.w3.org/TR/uievents-key/#named-key-attribute-values
 *
 * Use instead of raw string literals when comparing `KeyboardEvent.key`
 * so that key names are refactor-safe and self-documenting.
 */
export const Keys = {
    Escape: 'Escape',
    Enter: 'Enter',
    Space: ' ',
    Tab: 'Tab',
    ArrowUp: 'ArrowUp',
    ArrowDown: 'ArrowDown',
    ArrowLeft: 'ArrowLeft',
    ArrowRight: 'ArrowRight',
    Home: 'Home',
    End: 'End',
} as const;

export type Key = (typeof Keys)[keyof typeof Keys];
