/**
 * Commission Calculation Engine for Financial & Pension Products
 *
 * Formulas:
 * - Scope (היקף):
 *   • Mobility: mobility × scope%
 *   • Lump-sum deposit: lumpSum × scope%
 *   • Monthly deposit: monthly × 12 × scope%
 *   • Accumulation only (no mobility): NO scope commission
 *
 * - Ongoing (נפרעים):
 *   • Formula: ((monthlyDeposit * 12) + accumulation) * ongoingRate / 12
 *   • Note: This combines the annualized deposit with the existing accumulation/mobility value.
 */

export interface FinancialInputs {
    accumulation: number; // סכום צבירה
    mobility: number; // סכום ניוד
    monthlyDeposit: number; // הפקדה חודשית
    lumpSumDeposit: number; // הפקדה חד פעמית
}

export interface CommissionRates {
    scope: number; // היקף % (as decimal, e.g. 0.5 = 0.5%)
    ongoing: number; // נפרעים % (as decimal, e.g. 0.2 = 0.2%)
    mobility: number; // ניוד % (as decimal)
}

/**
 * Calculate total one-time scope (היקף) commission
 */
export function calcFinancialScope(
    inputs: FinancialInputs,
    rates: CommissionRates,
    type?: string,
): number {
    const scopeRate = rates.scope / 100;
    const mobilityRate = rates.mobility / 100 || scopeRate; // fallback to scope

    let total = 0;

    // Special Case: Long Term Savings (חסכון ארוך טווח) - Scope is calculated from EVERYTHING (including accumulation)
    if (type === 'long_term_savings') {
        const totalBase =
            inputs.monthlyDeposit * 12 + (inputs.lumpSumDeposit || 0) + (inputs.accumulation || 0);
        return totalBase * scopeRate;
    }

    // Standard Case for other financial products:
    // 1. Mobility scope
    if (inputs.mobility > 0) {
        total += inputs.mobility * mobilityRate;
    }

    // 2. Lump-sum deposit scope
    if (inputs.lumpSumDeposit > 0) {
        total += inputs.lumpSumDeposit * scopeRate;
    }

    // 3. Monthly deposit annualized scope
    if (inputs.monthlyDeposit > 0) {
        total += inputs.monthlyDeposit * 12 * scopeRate;
    }

    return total;
}

/**
 * Calculate monthly ongoing (נפרעים) commission
 *
 * For Financial products (Gemel/Hishtalmut/etc.):
 *   Monthly Fee = ((EOM Accumulation + (Monthly Deposit × 12)) × Fee %) / 12
 *
 * For Pension:
 *   Monthly Fee = Monthly Deposit × Fee %   (exception — no accumulation component)
 */
export function calcFinancialOngoing(
    inputs: FinancialInputs,
    rates: CommissionRates,
    type?: string,
): number {
    const ongoingRate = rates.ongoing / 100;

    // Pension ongoing is calculated ONLY from the monthly deposit (confirmed business rule)
    if (type === 'pension') {
        return (inputs.monthlyDeposit || 0) * ongoingRate;
    }

    // For Financial types: use end-of-month accumulation as the base, including lump-sum deposits and mobility
    const eomAccumulation = inputs.accumulation || 0;
    const baseAccumulation = Math.max(eomAccumulation, inputs.mobility || 0);
    const lumpSum = inputs.lumpSumDeposit || 0;
    const annualizedDeposits = (inputs.monthlyDeposit || 0) * 12;

    return ((baseAccumulation + lumpSum + annualizedDeposits) * ongoingRate) / 12;
}

/**
 * Calculate the total accumulated balance for a given month index using
 * the COMPOUND growth formula:
 *
 *   EOM = (SOM + monthly_deposit) × (1 + yield)
 *
 * This correctly mirrors the Gemel-Net accumulation model.
 * Negative yields are fully supported — they reduce the balance accordingly.
 *
 * @param inputs      - initial financial inputs (accumulation = starting balance)
 * @param monthIndex  - months elapsed since establishment (0 = end of first month)
 * @param monthlyYieldDecimal - average monthly yield as a decimal (e.g. 0.0123 = 1.23%)
 *                              Pass 0 for deposit-only accumulation (no tracks mapped).
 */
export function calcAccumulatedBalance(
    inputs: FinancialInputs,
    monthIndex: number,
    monthlyYieldDecimal: number = 0,
): number {
    const yieldMultiplier = 1 + monthlyYieldDecimal;

    // SOM balance in month 0: existing accumulation + mobility + lump sum deposit
    let balance =
        (inputs.accumulation || 0) + (inputs.mobility || 0) + (inputs.lumpSumDeposit || 0);

    // Apply compound growth for each month (0 = first month of activity)
    for (let m = 0; m <= monthIndex; m++) {
        // EOM = (SOM + monthly_deposit) × (1 + yield)
        balance = (balance + (inputs.monthlyDeposit || 0)) * yieldMultiplier;
    }

    return balance;
}

/**
 * Calculate the weighted monthly yield from multiple investment tracks.
 *
 * Accepts the normalized PolicyTrack format (sharePercentage as 0..1 decimal)
 * and a map of fundId → monthly yield (also as decimal, e.g. 0.0123 = 1.23%).
 *
 * @param tracks       - array of { fundId, sharePercentage } from policy_tracks DB
 * @param yieldByFund  - map of fundId → monthly yield decimal fetched from the API
 * @returns blended yield decimal
 */
export function calcWeightedYield(
    tracks: { fundId: number; sharePercentage: number }[],
    yieldByFund: Record<number, number>, // fundId → monthly yield decimal
): number {
    let weightedYield = 0;
    for (const track of tracks) {
        const yld = yieldByFund[track.fundId] ?? 0;
        weightedYield += track.sharePercentage * yld;
    }
    return weightedYield;
}

/**
 * @deprecated Use calcWeightedYield with PolicyTrack objects instead.
 * Kept for backward compatibility with any existing callers.
 */
export function calcWeightedReturn(
    tracks: { trackName: string; weight: number }[],
    trackReturns: Record<string, number>, // trackName -> monthly return %
): number {
    let weightedReturn = 0;
    tracks.forEach((track) => {
        const returnRate = trackReturns[track.trackName] || 0;
        weightedReturn += (track.weight / 100) * returnRate;
    });
    return weightedReturn;
}
