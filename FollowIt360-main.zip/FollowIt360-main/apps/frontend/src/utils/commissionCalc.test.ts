// @vitest-environment node
import { describe, it, expect } from 'vitest';
import {
    calcFinancialScope,
    calcFinancialOngoing,
    calcAccumulatedBalance,
    calcWeightedReturn,
    calcWeightedYield,
    type FinancialInputs,
    type CommissionRates
} from './commissionCalc.js';

describe('Commission Calculation Engine', () => {

    describe('calcFinancialScope', () => {
        const rates: CommissionRates = { scope: 1, ongoing: 0, mobility: 0.5 };

        it('calculates default financial scope correctly', () => {
            const inputs: FinancialInputs = {
                accumulation: 100000,
                mobility: 50000,
                monthlyDeposit: 1000,
                lumpSumDeposit: 20000
            };
            
            // Scope formula: mobility*(0.5%) + lumpSum*(1%) + monthly*12*(1%)
            // 50000 * 0.005 = 250
            // 20000 * 0.01 = 200
            // 1000 * 12 * 0.01 = 120
            // Total = 570
            const result = calcFinancialScope(inputs, rates);
            expect(result).toBe(570);
        });

        it('uses scope rate as fallback if mobility rate is missing', () => {
            const fallbackRates: CommissionRates = { scope: 1, ongoing: 0, mobility: 0 };
            const inputs: FinancialInputs = { accumulation: 0, mobility: 50000, monthlyDeposit: 0, lumpSumDeposit: 0 };
            
            // 50000 * 0.01 = 500
            const result = calcFinancialScope(inputs, fallbackRates);
            expect(result).toBe(500);
        });

        it('calculates long_term_savings scale strictly on total base including accumulation', () => {
            const inputs: FinancialInputs = {
                accumulation: 100000,
                mobility: 0, // Mobility is usually converted to accumulation in long_term_savings conceptually, but calculation uses input fields
                monthlyDeposit: 1000,
                lumpSumDeposit: 20000
            };
            // (100000 + 20000 + 1000*12) * 1% = 132000 * 0.01 = 1320
            const result = calcFinancialScope(inputs, rates, 'long_term_savings');
            expect(result).toBe(1320);
        });
    });

    describe('calcFinancialOngoing', () => {
        const rates: CommissionRates = { scope: 0, ongoing: 0.6, mobility: 0 };

        it('calculates pension ongoing correctly (only on monthly deposit)', () => {
            const inputs: FinancialInputs = {
                accumulation: 100000,
                mobility: 50000,
                monthlyDeposit: 1000,
                lumpSumDeposit: 20000
            };
            
            // For pension: monthlyDeposit * ongoingRate = 1000 * 0.6% = 6
            const result = calcFinancialOngoing(inputs, rates, 'pension');
            expect(result).toBeCloseTo(6);
        });

        it('calculates standard ongoing using base accumulation (MAX of accumulation/mobility), lump-sum deposit, and annualized deposits', () => {
             const inputs: FinancialInputs = {
                accumulation: 100000,
                mobility: 50000,
                monthlyDeposit: 1000,
                lumpSumDeposit: 20000
            };
            // Formula: ((MAX(accumulation, mobility) + lumpSumDeposit + monthly * 12) * ongoingRate) / 12
            // base = MAX(100000, 50000) = 100000
            // lumpSum = 20000
            // annualizedDeposits = 1000 * 12 = 12000
            // Total base = 100000 + 20000 + 12000 = 132000
            // ((132000) * 0.006) / 12 = 792 / 12 = 66
            const result = calcFinancialOngoing(inputs, rates);
            expect(result).toBeCloseTo(66);
        });

        it('calculates ongoing with only lump-sum deposit correctly', () => {
            const inputs: FinancialInputs = {
                accumulation: 0,
                mobility: 0,
                monthlyDeposit: 0,
                lumpSumDeposit: 50000
            };
            // Formula: (lumpSumDeposit * ongoingRate) / 12 = (50000 * 0.006) / 12 = 300 / 12 = 25
            const result = calcFinancialOngoing(inputs, rates);
            expect(result).toBeCloseTo(25);
        });

        it('calculates ongoing with only mobility correctly', () => {
            const inputs: FinancialInputs = {
                accumulation: 0,
                mobility: 50000,
                monthlyDeposit: 0,
                lumpSumDeposit: 0
            };
            // Formula: (mobility * ongoingRate) / 12 = (50000 * 0.006) / 12 = 300 / 12 = 25
            const result = calcFinancialOngoing(inputs, rates);
            expect(result).toBeCloseTo(25);
        });
    });

    describe('calcAccumulatedBalance', () => {
        it('calculates static accumulated balance at month 0 (initial conditions)', () => {
             const inputs: FinancialInputs = {
                accumulation: 100000,
                mobility: 50000,
                monthlyDeposit: 1000,
                lumpSumDeposit: 20000
            };
            const result = calcAccumulatedBalance(inputs, 0);
            // With inclusive loop (m <= 0), it adds one deposit then multiplies by yield (1.0 in this test)
            expect(result).toBe(170000 + 1000); // 171000
        });

        it('calculates accumulated balance dynamically over months without returns', () => {
            const inputs: FinancialInputs = {
                accumulation: 100000,
                mobility: 50000,
                monthlyDeposit: 1000,
                lumpSumDeposit: 20000 // Total base: 170000
            };
            const result = calcAccumulatedBalance(inputs, 5); // 5 months (inclusive = 6 deposits)
            // 170000 + (1000 * 6) = 176000
            expect(result).toBe(176000);
        });

        it('calculates accumulated balance dynamically over months with returns (decimal yield)', () => {
             const inputs: FinancialInputs = {
                accumulation: 100000,
                mobility: 0,
                monthlyDeposit: 1000,
                lumpSumDeposit: 0 // Total base: 100000
            };
            // yield is now a decimal: 0.005 = 0.5%
            const result = calcAccumulatedBalance(inputs, 2, 0.005);
            // EOM month 0: (100000 + 1000) * 1.005 = 101505
            // EOM month 1: (101505 + 1000) * 1.005 = 103017.525
            // EOM month 2: (103017.525 + 1000) * 1.005 = 104537.612625
            expect(result).toBeCloseTo(104537.612625);
        });
    });

    describe('calcWeightedYield', () => {
        it('calculates proper multi-track weighted sum using decimals', () => {
            const tracks = [
                { fundId: 1, sharePercentage: 0.4 },
                { fundId: 2, sharePercentage: 0.6 },
            ];
            const returns = {
                1: 0.015, // 1.5%
                2: 0.005, // 0.5%
            };
            // 0.4 * 0.015 + 0.6 * 0.005 = 0.006 + 0.003 = 0.009
            const result = calcWeightedYield(tracks, returns);
            expect(result).toBeCloseTo(0.009);
        });

        it('returns zero safely if track returns are missing for fundId', () => {
            const tracks = [
                { fundId: 1, sharePercentage: 1.0 },
            ];
            const returns = {};
            const result = calcWeightedYield(tracks, returns);
            expect(result).toBe(0);
        });
    });

    describe('calcWeightedReturn', () => {
        it('calculates a proper multi-track weighted sum', () => {
            const tracks = [
                { trackName: 'high_risk', weight: 40 },
                { trackName: 'low_risk', weight: 60 },
            ];
            const returns = {
                'high_risk': 1.5,
                'low_risk': 0.5,
            };
            // (40/100) * 1.5 + (60/100) * 0.5 = 0.6 + 0.3 = 0.9
            const result = calcWeightedReturn(tracks, returns);
            expect(result).toBeCloseTo(0.9);
        });

        it('returns zero safely if track returns are missing', () => {
             const tracks = [
                { trackName: 'high_risk', weight: 100 },
            ];
            const returns = {};
            const result = calcWeightedReturn(tracks, returns);
            expect(result).toBe(0);
        });
    });
});
