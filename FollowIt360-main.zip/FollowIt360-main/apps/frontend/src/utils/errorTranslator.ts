const ERROR_TRANSLATIONS: Record<string, string> = {
    // Auth & Login
    'HTTPS is required': 'נדרש חיבור מאובטח (HTTPS)',
    'Database not ready': 'מסד הנתונים אינו זמין זמנית. אנא נסה שוב מאוחר יותר.',
    'Invalid email or password': 'כתובת אימייל או סיסמה שגויים',
    "This account uses Google sign-in. Please click 'Continue with Google'": "חשבון זה מחובר באמצעות Google. אנא לחץ על 'המשך באמצעות Google'",
    
    // Auth & Signup
    'Email already exists': 'כתובת דוא״ל זו כבר רשומה במערכת',
    
    // General Operational & JWT
    'Validation Error: Invalid Input Data': 'שגיאת אימות: נתוני הקלט אינם תקינים',
    'Invalid token. Please log in again.': 'פג תוקף החיבור. אנא התחבר שוב.',
    'Your token has expired! Please log in again.': 'פג תוקף החיבור שלך! אנא התחבר שוב.',
    'Unauthorized': 'גישה לא מורשית',
    'Forbidden: Admins only': 'גישה חסומה: למנהלים בלבד',
    'User not found': 'המשתמש לא נמצא',
    
    // Postgres Constraints Mapping
    'Duplicate field value entered. Please use another value.': 'ערך כפול הוזן. אנא השתמש בערך אחר.',
    'Invalid reference. The related record does not exist.': 'קישור לא חוקי. הרשומה המקושרת אינה קיימת.',
    'Missing required field.': 'שדה חובה חסר.',
    'Invalid input format.': 'פורמט קלט לא חוקי.',
    'Input value is too long.': 'ערך הקלט ארוך מדי.',
    
    // Fallback/Generic
    'Something went very wrong!': 'משהו השתבש! אנא נסה שוב מאוחר יותר.',
};

/**
 * Translates an English backend error message to Hebrew.
 * If no translation is matched, it returns the original message.
 */
export function translateError(message: string): string {
    if (!message) return 'שגיאה לא ידועה. אנא נסה שוב.';
    
    const trimmed = message.trim();
    if (ERROR_TRANSLATIONS[trimmed]) {
        return ERROR_TRANSLATIONS[trimmed];
    }
    
    // Fallback substring mapping
    for (const [key, translation] of Object.entries(ERROR_TRANSLATIONS)) {
        if (trimmed.toLowerCase().includes(key.toLowerCase())) {
            return translation;
        }
    }
    
    return trimmed;
}
