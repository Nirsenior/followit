import { CommissionValues, CompanyAgreements, InsuranceType, UserProfile } from '@repo/types';

/**
 * Returns a list of company names currently configured in the user's agreements,
 * excluding the internal fallback 'GLOBAL' settings object.
 */
export const getSelectedCompanies = (
    agreements: UserProfile['agreements'] | undefined | null,
): string[] => {
    if (!agreements) return [];
    return Object.keys(agreements).filter((company) => company !== 'GLOBAL');
};

/**
 * Removes empty string values from a single company's agreements object.
 * If a particular insurance type has no non-empty values, it is removed entirely.
 * Uses idiomatic functional patterns for better maintainability.
 */
export const sanitizeCompanyAgreements = (
    agreements: CompanyAgreements | undefined,
): CompanyAgreements => {
    if (!agreements) return {};

    return Object.entries(agreements).reduce<CompanyAgreements>((acc, [type, values]) => {
        if (!values) return acc;

        // Filter out keys with empty string values, keep booleans and non-empty strings
        const sanitizedValues = Object.fromEntries(
            Object.entries(values).filter(([_, value]) => value !== '' && value !== undefined),
        ) as CommissionValues;

        if (Object.keys(sanitizedValues).length > 0) {
            acc[type as InsuranceType] = sanitizedValues;
        }

        return acc;
    }, {});
};

/**
 * Sanitizes an entire record of company agreements.
 */
export const sanitizeAllAgreements = (
    agreements: Record<string, CompanyAgreements>,
): Record<string, CompanyAgreements> => {
    return Object.fromEntries(
        Object.entries(agreements).map(([company, companyAgreements]) => [
            company,
            sanitizeCompanyAgreements(companyAgreements),
        ]),
    );
};
