import { describe, expect, it } from 'vitest';
import { translateError } from './errorTranslator.js';

describe('errorTranslator utility', () => {
    it('translates login error messages to Hebrew', () => {
        expect(translateError('Invalid email or password')).toBe('כתובת אימייל או סיסמה שגויים');
        expect(translateError("This account uses Google sign-in. Please click 'Continue with Google'")).toBe(
            "חשבון זה מחובר באמצעות Google. אנא לחץ על 'המשך באמצעות Google'"
        );
        expect(translateError('HTTPS is required')).toBe('נדרש חיבור מאובטח (HTTPS)');
        expect(translateError('Database not ready')).toBe('מסד הנתונים אינו זמין זמנית. אנא נסה שוב מאוחר יותר.');
    });

    it('translates signup and general database messages to Hebrew', () => {
        expect(translateError('Email already exists')).toBe('כתובת דוא״ל זו כבר רשומה במערכת');
        expect(translateError('Duplicate field value entered. Please use another value.')).toBe(
            'ערך כפול הוזן. אנא השתמש בערך אחר.'
        );
    });

    it('falls back to the original message if translation is not found', () => {
        expect(translateError('Some unknown network error')).toBe('Some unknown network error');
    });

    it('returns default message if input is falsy', () => {
        expect(translateError('')).toBe('שגיאה לא ידועה. אנא נסה שוב.');
        expect(translateError(null as any)).toBe('שגיאה לא ידועה. אנא נסה שוב.');
    });

    it('handles fuzzy matching via substring search', () => {
        expect(translateError('Error: Invalid email or password!')).toBe('כתובת אימייל או סיסמה שגויים');
    });
});
