import { InsuranceType } from '@repo/types';

const getBaseUrl = () => import.meta.env.VITE_API_URL || '';

export const fetchYieldsTracks = async (
    insuranceType: InsuranceType,
    company: string,
): Promise<Array<{ trackName: string; fundId: number }>> => {
    const params = new URLSearchParams({ insuranceType, company });
    const res = await fetch(`${getBaseUrl()}/api/yields/tracks?${params.toString()}`, {
        credentials: 'include',
    });

    if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to fetch investment tracks');
    }

    return res.json();
};

/**
 * Fetches the weighted monthly yield (decimal) for a specific policy and report period.
 *
 * @param policyId - UUID of the policy
 * @returns decimal yield, e.g. 0.0123 = 1.23%
 */
export const fetchPolicyYield = async (policyId: string): Promise<number> => {
    const path = `/api/yields/${policyId}`;

    const res = await fetch(`${getBaseUrl()}${path}`, { credentials: 'include' });
    if (!res.ok) {
        console.warn(`[yields API] Failed for policy ${policyId}:`, res.status);
        return 0;
    }
    const data: { weightedYield: number } = await res.json();
    const yld = data.weightedYield ?? 0;
    return yld;
};

/**
 * Fetches yields for multiple policies in parallel.
 *
 * @param policyIds - array of policy UUIDs
 * @returns Record<policyId, monthlyYieldDecimal>
 */
export const fetchYieldsForPolicies = async (
    policyIds: string[],
): Promise<Record<string, number>> => {
    if (!policyIds.length) return {};

    const results = await Promise.allSettled(
        policyIds.map(async (id) => ({
            id,
            yield: await fetchPolicyYield(id),
        })),
    );

    const map: Record<string, number> = {};
    for (const r of results) {
        if (r.status === 'fulfilled') {
            map[r.value.id] = r.value.yield;
        }
    }
    return map;
};
