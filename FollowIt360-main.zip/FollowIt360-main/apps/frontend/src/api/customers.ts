import type { Customer } from '@repo/types';

// Omit 'createdAt', 'id' and other backend-generated details for the creation payload if needed,
// though the frontend currently constructs a custom payload. We use `any` or strict types.
export interface CreateCustomerPayload {
    customer: {
        firstName: string;
        surname: string;
        governmentId: string;
        issueDate: string;
    };
    policies: {
        company: string;
        insuranceType: string;
        issueDate: string;
        isAgentAppointmentOnly: boolean;
        details: any;
    }[];
    familyMembers?: any[];
}

const getBaseUrl = () => import.meta.env.VITE_API_URL || '';

export const fetchCustomers = async (): Promise<Customer[]> => {
    const res = await fetch(`${getBaseUrl()}/api/customers`, { credentials: 'include' });
    if (!res.ok) throw new Error('Failed to fetch customers');
    return res.json();
};

export const createCustomer = async (
    payload: CreateCustomerPayload,
): Promise<{ status: string; customerId: string }> => {
    const res = await fetch(`${getBaseUrl()}/api/customers`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        credentials: 'include',
    });

    if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to create customer');
    }

    return res.json();
};
export const updateCustomer = async (
    dbId: string,
    payload: CreateCustomerPayload,
): Promise<{ status: string }> => {
    const res = await fetch(`${getBaseUrl()}/api/customers/${dbId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        credentials: 'include',
    });

    if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to update customer');
    }

    return res.json();
};

export const deleteCustomer = async (dbId: string): Promise<{ status: string }> => {
    const res = await fetch(`${getBaseUrl()}/api/customers/${dbId}`, {
        method: 'DELETE',
        credentials: 'include',
    });

    if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to delete customer');
    }

    return res.json();
};
