import React from 'react';
import { Navigate } from 'react-router-dom';
import { ROUTES } from '../constants/routes';
import { useAuthStore } from '../store/authStore';

interface RouteGuardProps {
    children: React.ReactNode;
    /** Redirect target when the guard condition is NOT met. */
    redirectTo: string;
    /** Guard passes when this predicate returns true. */
    allow: (isAuthenticated: boolean) => boolean;
}

const RouteGuard: React.FC<RouteGuardProps> = ({ children, redirectTo, allow }) => {
    const { isAuthenticated } = useAuthStore();
    if (!allow(isAuthenticated)) return <Navigate to={redirectTo} replace />;
    return <>{children}</>;
};

/** Redirects unauthenticated users to /login. */
export const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <RouteGuard allow={(auth) => auth} redirectTo={ROUTES.HOME}>
        {children}
    </RouteGuard>
);

/**
 * Redirects already-authenticated users away from public pages (login/signup).
 * New users (isSetupComplete=false) are sent to /onboarding; existing users to /dashboard.
 * This prevents handleSignup's login() call from causing PublicRoute to override
 * the subsequent navigate(ROUTES.ONBOARDING).
 */
export const PublicRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { isAuthenticated } = useAuthStore();
    if (isAuthenticated) {
        return <Navigate to={ROUTES.DASHBOARD} replace />;
    }
    return <>{children}</>;
};
