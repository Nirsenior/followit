import {
    ArrowLeft,
    BarChart3,
    CalendarDays,
    Check,
    Clock,
    FileSignature,
    ShieldCheck,
    Star,
    TrendingUp,
} from 'lucide-react';
import React from 'react';
import ComparisonSection from '../components/ComparisonSection';
import HowItWorksSection from '../components/HowItWorksSection';
import InteractiveDashboardMockup from '../components/InteractiveDashboardMockup';
import Logo from '../components/Logo';

interface LandingPageProps {
    onRegister: () => void;
    onLogin: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onRegister, onLogin }) => {
    const handleScroll = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
        e.preventDefault();
        const element = document.getElementById(targetId);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    };

    const getVersionText = () => {
        const version = import.meta.env.APP_VERSION || '';
        const host = window.location.hostname;
        if (host === 'localhost' || host === '127.0.0.1') return `v${version} (localhost)`;
        if (host.includes('staging') || host.includes('run.app')) return `v${version} (dev)`;
        return `v${version}`;
    };

    return (
        <div
            className="bg-slate-50 min-h-screen selection:bg-sky-100 font-sans text-slate-900 overflow-x-hidden"
            dir="rtl"
        >
            <nav
                className="fixed top-0 inset-x-0 bg-[#0A1128]/95 backdrop-blur-md border-b border-white/10 z-50"
                aria-label="ניווט ראשי"
            >
                <div className="max-w-7xl mx-auto px-6 h-20 flex justify-between items-center">
                    <div className="flex-1 flex justify-start">
                        <Logo
                            variant="light"
                            showSubtitle={false}
                            className="scale-75 origin-right"
                        />
                    </div>
                    <div className="hidden md:flex gap-8 text-sm text-slate-300 font-medium justify-center">
                        <a
                            href="#how-it-works"
                            onClick={(e) => handleScroll(e, 'how-it-works')}
                            className="hover:text-white transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 rounded-sm"
                        >
                            איך זה עובד
                        </a>
                        <a
                            href="#features"
                            onClick={(e) => handleScroll(e, 'features')}
                            className="hover:text-white transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 rounded-sm"
                        >
                            יתרונות
                        </a>
                        <a
                            href="#testimonials"
                            onClick={(e) => handleScroll(e, 'testimonials')}
                            className="hover:text-white transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 rounded-sm"
                        >
                            לקוחות מספרים
                        </a>
                        <a
                            href="#pricing"
                            onClick={(e) => handleScroll(e, 'pricing')}
                            className="hover:text-white transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 rounded-sm"
                        >
                            עלות
                        </a>
                    </div>
                    <div className="flex-1 flex justify-end items-center gap-3 sm:gap-4">
                        <button
                            onClick={onLogin}
                            className="text-white hover:text-sky-300 font-medium text-xs sm:text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 rounded-sm"
                        >
                            התחבר
                        </button>
                        <button
                            onClick={onRegister}
                            className="bg-blue-600 text-white px-3 py-1.5 sm:px-5 sm:py-2.5 rounded-lg font-bold text-xs sm:text-sm hover:bg-blue-500 transition-colors shadow-lg shadow-blue-500/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-[#0A1128]"
                        >
                            הרשמה
                        </button>
                    </div>
                </div>
            </nav>

            {/* Hero Section */}
            <section
                className="relative pt-24 pb-20 lg:pt-32 lg:pb-32 bg-[#0A1128] text-white overflow-hidden"
                aria-labelledby="hero-heading"
            >
                <div className="absolute inset-0 opacity-40" aria-hidden="true">
                    <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-blue-600/20 rounded-full blur-[120px] -mr-[400px] -mt-[400px]" />
                    <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-[100px] -ml-[200px] -mb-[200px]" />
                    <svg
                        className="absolute w-full h-full object-cover opacity-20"
                        viewBox="0 0 1440 800"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                    >
                        <path
                            d="M0 400C240 400 480 200 720 200C960 200 1200 400 1440 400V800H0V400Z"
                            fill="url(#paint0_linear)"
                        />
                        <defs>
                            <linearGradient
                                id="paint0_linear"
                                x1="720"
                                y1="200"
                                x2="720"
                                y2="800"
                                gradientUnits="userSpaceOnUse"
                            >
                                <stop stopColor="#3B82F6" stopOpacity="0.2" />
                                <stop offset="1" stopColor="#0A1128" stopOpacity="0" />
                            </linearGradient>
                        </defs>
                    </svg>
                </div>

                <div className="max-w-[1536px] w-full mx-auto px-6 lg:px-12 relative z-10 grid lg:grid-cols-2 gap-12 xl:gap-20 items-center">
                    <div className="text-right">
                        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-white/10 bg-white/5 backdrop-blur-md mb-8">
                            <ShieldCheck className="w-4 h-4 text-sky-400" aria-hidden="true" />
                            <span className="text-sm font-medium text-slate-200">
                                המערכת המובילה לסוכני ביטוח
                            </span>
                        </div>

                        <h1
                            id="hero-heading"
                            className="text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold mb-6 leading-tight tracking-tight"
                        >
                            מערכת מעקב העמלות של סוכני הביטוח
                        </h1>
                        <p className="text-lg md:text-xl xl:text-2xl text-slate-300 mb-10 leading-relaxed max-w-2xl">
                            Followit360 מבצעת עדכון אוטומטי של התפתחות פרמיה, מעקב עמלות פשוט וניהול
                            שוטף חכם.
                        </p>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-10">
                            <div>
                                <div
                                    className="w-10 h-10 bg-sky-500/20 rounded-full flex items-center justify-center mb-3"
                                    aria-hidden="true"
                                >
                                    <Clock className="w-5 h-5 text-sky-400" />
                                </div>
                                <h4 className="font-bold text-white mb-1">פחות עבודה ידנית</h4>
                                <p className="text-sm text-slate-400">
                                    יותר זמן למכירות ופחות התעסקות באקסלים.
                                </p>
                            </div>
                            <div>
                                <div
                                    className="w-10 h-10 bg-emerald-500/20 rounded-full flex items-center justify-center mb-3"
                                    aria-hidden="true"
                                >
                                    <TrendingUp className="w-5 h-5 text-emerald-400" />
                                </div>
                                <h4 className="font-bold text-white mb-1">מעקב מדויק יותר</h4>
                                <p className="text-sm text-slate-400">נתונים עדכניים בזמן אמת.</p>
                            </div>
                            <div>
                                <div
                                    className="w-10 h-10 bg-indigo-500/20 rounded-full flex items-center justify-center mb-3"
                                    aria-hidden="true"
                                >
                                    <BarChart3 className="w-5 h-5 text-indigo-400" />
                                </div>
                                <h4 className="font-bold text-white mb-1">שליטה מלאה</h4>
                                <p className="text-sm text-slate-400">
                                    תמונה מלאה של העסק בכל רגע נתון.
                                </p>
                            </div>
                        </div>

                        <div className="flex flex-wrap items-center gap-4">
                            <button
                                onClick={onRegister}
                                className="bg-blue-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-blue-500 shadow-lg shadow-blue-600/30 transition-all flex items-center gap-2 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-[#0A1128]"
                            >
                                להרשמה עכשיו{' '}
                                <ArrowLeft
                                    className="w-5 h-5 group-hover:-translate-x-1 transition-transform"
                                    aria-hidden="true"
                                />
                            </button>
                        </div>
                    </div>

                    <div
                        className="relative mt-12 lg:mt-0 w-full max-w-3xl mx-auto"
                        aria-hidden="true"
                    >
                        <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-sky-400 rounded-3xl blur-3xl opacity-20" />
                        <div className="relative rounded-2xl overflow-hidden shadow-[0_30px_60px_-15px_rgba(0,0,0,0.5)] border border-white/10 bg-[#060A18] z-10 group">
                            <div className="bg-[#0c142e] px-4 py-3 flex items-center gap-1.5 border-b border-white/5 select-none">
                                <div className="w-3.5 h-3.5 rounded-full bg-[#ff5f56]" />
                                <div className="w-3.5 h-3.5 rounded-full bg-[#ffbd2e]" />
                                <div className="w-3.5 h-3.5 rounded-full bg-[#27c93f]" />
                                <div className="mx-auto text-[11px] text-slate-500 font-mono tracking-wider pl-8">
                                    followit360.com
                                </div>
                            </div>
                            <div className="overflow-hidden">
                                <InteractiveDashboardMockup
                                    simulatedVideo={true}
                                    className="w-full transform transition-transform duration-500"
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* VS Section */}
            <ComparisonSection />

            {/* How It Works Section */}
            <HowItWorksSection />

            {/* Features Section */}
            <section
                id="features"
                className="py-24 bg-slate-50 relative border-t border-slate-100"
                aria-labelledby="features-heading"
            >
                <div className="max-w-7xl mx-auto px-6">
                    <h2
                        id="features-heading"
                        className="text-3xl md:text-4xl font-bold text-center text-slate-900 mb-16"
                    >
                        יכולות שמגדילות רווחים ומקטינות התעסקות
                    </h2>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                        {[
                            {
                                icon: FileSignature,
                                color: 'bg-purple-50',
                                iconColor: 'text-purple-500',
                                title: 'ניהול הסכמים',
                                desc: 'שליטה מלאה על מבנה העמלות שלך.',
                            },
                            {
                                icon: CalendarDays,
                                color: 'bg-blue-50',
                                iconColor: 'text-blue-500',
                                title: 'יומן לקוחות מתקדם',
                                desc: 'מעקב אחר פוליסות בכל התחומים ובכל התצורות.',
                            },
                            {
                                icon: BarChart3,
                                color: 'bg-emerald-50',
                                iconColor: 'text-emerald-500',
                                title: 'חישוב עמלות חכם',
                                desc: 'חישוב אוטומטי לפי הסכמים, מוצרים וחברות.',
                            },
                            {
                                icon: TrendingUp,
                                color: 'bg-purple-50',
                                iconColor: 'text-purple-500',
                                title: 'מעקב התפתחות פרמיה',
                                desc: 'צפייה בשווי תיק הנפרעים בכל רגע נתון.',
                            },
                        ].map(({ icon: Icon, color, iconColor, title, desc }) => (
                            <div
                                key={title}
                                className="bg-white rounded-2xl p-6 text-center border border-slate-100 shadow-sm hover:shadow-lg transition-all hover:-translate-y-1 group"
                            >
                                <div
                                    className={`w-16 h-16 ${color} rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform`}
                                    aria-hidden="true"
                                >
                                    <Icon className={`w-8 h-8 ${iconColor}`} />
                                </div>
                                <h3 className="font-bold text-slate-900 mb-2 text-base">{title}</h3>
                                <p className="text-sm text-slate-500">{desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Testimonials Section */}
            <section
                id="testimonials"
                className="py-24 bg-[#0A1128] text-white relative overflow-hidden"
                aria-labelledby="testimonials-heading"
            >
                <div className="absolute inset-0 opacity-20" aria-hidden="true">
                    <div className="absolute -top-40 -right-40 w-96 h-96 bg-blue-600 rounded-full blur-[100px]" />
                    <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-sky-500/10 rounded-full blur-[100px]" />
                </div>

                <div className="max-w-7xl mx-auto px-6 relative z-10">
                    <div className="text-center max-w-3xl mx-auto mb-16">
                        <h2
                            id="testimonials-heading"
                            className="text-3xl md:text-4xl font-bold text-white mb-4"
                        >
                            לקוחות מספרים
                        </h2>
                        <p className="text-lg text-slate-400">
                            סוכני ביטוח שכבר עברו לניהול חכם עם Followit360 ומספרים על השינוי
                        </p>
                    </div>

                    <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
                        {[
                            {
                                img: 11,
                                name: 'רונן משה',
                                role: 'סוכן פנסיוני ופיננסי',
                                text: '"followit360 חסכה לי זמן יקר של התעסקות ידנית כל חודש, תיק הנפרעים שלי מעולם לא היה ברור יותר."',
                            },
                            {
                                img: 32,
                                name: 'מיכל לוי',
                                role: 'סוכנת ביטוח חיים ופנסיוני',
                                text: '"סוף סוף מערכת שמחשבת עמלות כמו שצריך! בלי כאבי ראש, בלי אקסלים מורכבים. מומלץ ביותר לכל סוכן."',
                            },
                            {
                                img: 68,
                                name: 'אלון רפאל',
                                role: 'סוכן פרט וסיכונים',
                                text: '"המערכת נוחה לשימוש באופן מפתיע, ניתן להעלות פוליסות משפחתיות, ניתן להזין רק מינוי סוכן ואף ניתן לערוך את הסכמי העמלות בצורה רטרואקטיבית-מומלץ בחום!"',
                            },
                            {
                                img: 47,
                                name: 'דנה אהרון',
                                role: 'סוכנת ביטוח אלמנטרי ופנסיוני',
                                text: '"המערכת פשוטה, אינטואיטיבית ועושה את העבודה בצורה מושלמת. \nאיזה כיף שלא לשלם המון כסף על בדיקות עמלות בסוף שנה!"',
                            },
                        ].map(({ img, name, role, text }) => (
                            <article
                                key={name}
                                className="bg-white/5 border border-white/10 rounded-3xl p-8 backdrop-blur-sm relative flex flex-col justify-between hover:border-white/20 transition-all"
                            >
                                <div>
                                    <div
                                        className="flex gap-1 mb-6 text-yellow-400"
                                        role="img"
                                        aria-label="דירוג: 5 כוכבים מתוך 5"
                                    >
                                        {[1, 2, 3, 4, 5].map((i) => (
                                            <Star
                                                key={i}
                                                className="w-4 h-4 fill-current"
                                                aria-hidden="true"
                                            />
                                        ))}
                                    </div>
                                    <p className="text-lg leading-relaxed mb-8 text-slate-200">
                                        {text}
                                    </p>
                                </div>
                                <div className="flex items-center gap-4">
                                    <img
                                        src={`https://i.pravatar.cc/100?img=${img}`}
                                        alt={`תמונת פרופיל של ${name}`}
                                        className="w-12 h-12 rounded-full border-2 border-sky-500"
                                        loading="lazy"
                                    />
                                    <div>
                                        <div className="font-bold text-white text-base">{name}</div>
                                        <div className="text-xs text-slate-400">{role}</div>
                                    </div>
                                </div>
                            </article>
                        ))}
                    </div>
                </div>
            </section>

            {/* Pricing Section */}
            <section
                id="pricing"
                className="py-24 bg-white relative border-t border-b border-slate-100"
                aria-labelledby="pricing-heading"
            >
                <div className="max-w-7xl mx-auto px-6">
                    <div className="text-center max-w-3xl mx-auto mb-16">
                        <h2
                            id="pricing-heading"
                            className="text-3xl md:text-4xl font-bold text-slate-900 mb-4"
                        >
                            עלות
                        </h2>
                    </div>

                    <div className="grid md:grid-cols-2 gap-12 max-w-4xl mx-auto items-center">
                        <div className="text-right">
                            <div className="text-slate-600 space-y-6 text-base leading-relaxed">
                                <p>כפי שהבנתם, Followit360 פותחה על ידי סוכנים עבור סוכנים.</p>
                                <p>
                                    אנחנו מכירים את הקושי שבמעקב אחר עמלות, ניהול נתונים באקסלים
                                    והעבודה עם מערכות יקרות ומורכבות.
                                </p>
                                <p>לכן בנינו מערכת פשוטה, חכמה ונגישה לכל סוכן ביטוח.</p>
                                <p className="font-bold text-slate-900 text-lg">
                                    המחיר הוא 129 ₪ בלבד לחודש.
                                </p>
                                <p>
                                    בנוסף, אנו מציעים חודש ראשון ללא עלות כדי לאפשר לכם להכיר את
                                    המערכת ולהתרגל לשיטת העבודה החדשה.
                                </p>
                            </div>
                        </div>

                        <div className="bg-[#0A1128] text-white rounded-3xl p-8 border-2 border-blue-500 shadow-2xl shadow-blue-900/20 relative hover:shadow-blue-900/30 transition-all duration-300">
                            <div
                                className="absolute top-4 left-4 bg-emerald-500 text-white text-xs font-bold px-3 py-1 rounded-full"
                                aria-hidden="true"
                            >
                                חודש ראשון חינם!
                            </div>
                            <div>
                                <h3 className="text-2xl font-bold mb-2">מנוי סוכן מלא</h3>
                                <p className="text-slate-400 text-sm mb-6">
                                    כל היכולות והתובנות של המערכת ללא הגבלה
                                </p>
                                <div className="flex items-baseline gap-2 mb-8">
                                    <span className="text-5xl font-black text-white">₪129</span>
                                    <span className="text-slate-400 text-sm">/ לחודש</span>
                                </div>
                                <ul className="space-y-4 mb-8">
                                    {[
                                        'ללא התחייבות',
                                        'ללא אותיות קטנות',
                                        'ללא הפתעות',
                                        'חודש ראשון חינם',
                                    ].map((item) => (
                                        <li
                                            key={item}
                                            className="flex items-center gap-3 text-slate-200"
                                        >
                                            <Check
                                                className="w-5 h-5 text-sky-400 shrink-0"
                                                aria-hidden="true"
                                            />
                                            <span>{item}</span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            <button
                                onClick={onRegister}
                                className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold hover:bg-blue-500 transition-colors shadow-lg shadow-blue-500/20 text-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-[#0A1128]"
                            >
                                להרשמה עכשיו
                            </button>
                        </div>
                    </div>
                </div>
            </section>

            <footer className="py-24 bg-[#060A18] text-white relative overflow-hidden border-t border-white/5">
                <div className="absolute inset-0" aria-hidden="true">
                    <div className="absolute top-10 left-10 w-2 h-2 bg-sky-400 rounded-full blur-[1px]" />
                    <div className="absolute bottom-20 right-20 w-3 h-3 bg-blue-500 rounded-full blur-[2px]" />
                    <div className="absolute top-1/2 left-1/4 w-1.5 h-1.5 bg-white rounded-full" />
                </div>

                <div className="max-w-7xl mx-auto px-6 relative z-10 flex flex-col-reverse md:flex-row items-center gap-12">
                    <div className="md:w-1/2 w-full mt-10 md:mt-0" aria-hidden="true">
                        <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10 bg-[#060A18] shadow-sky-500/10 group">
                            <div className="bg-[#0c142e] px-4 py-3 flex items-center gap-1.5 border-b border-white/5 select-none">
                                <div className="w-3.5 h-3.5 rounded-full bg-[#ff5f56]" />
                                <div className="w-3.5 h-3.5 rounded-full bg-[#ffbd2e]" />
                                <div className="w-3.5 h-3.5 rounded-full bg-[#27c93f]" />
                                <div className="mx-auto text-[11px] text-slate-500 font-mono tracking-wider pl-8">
                                    followit360.com
                                </div>
                            </div>
                            <div className="overflow-hidden">
                                <InteractiveDashboardMockup className="w-full transform group-hover:scale-[1.01] transition-transform duration-500" />
                            </div>
                        </div>
                    </div>

                    <div className="md:w-1/2 text-center md:text-right">
                        <h2 className="text-3xl md:text-5xl font-bold mb-6 leading-tight">
                            הגיע הזמן לשלוט בצורה מלאה בעסק שלך
                        </h2>
                        <p className="text-lg text-slate-400 mb-10">
                            Followit360 מקלה על שגרת העבודה שלך ומעניקה לך תמונה מלאה של העמלות,
                            הלקוחות והתפתחות הפרמיה.
                        </p>
                        <div className="flex flex-wrap items-center justify-center md:justify-start gap-4">
                            <button
                                onClick={onRegister}
                                className="bg-blue-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-blue-500 shadow-lg shadow-blue-600/30 transition-all flex items-center gap-2 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-[#060A18]"
                            >
                                להרשמה עכשיו{' '}
                                <ArrowLeft
                                    className="w-5 h-5 group-hover:-translate-x-1 transition-transform"
                                    aria-hidden="true"
                                />
                            </button>
                        </div>
                    </div>
                </div>

                <div className="max-w-7xl mx-auto px-6 mt-20 pt-8 border-t border-white/10 text-center text-slate-500 text-sm flex flex-col md:flex-row justify-between items-center gap-4">
                    <div className="flex items-center gap-3">
                        <span>
                            &copy; {new Date().getFullYear()} Followit360. פותח באהבה לסוכני ישראל.
                        </span>
                        <span className="text-[11px] text-slate-600 bg-white/5 border border-white/10 px-2 py-0.5 rounded font-mono select-none">
                            {getVersionText()}
                        </span>
                    </div>
                    <nav aria-label="קישורי תחתית">
                        <ul className="flex gap-6 list-none">
                            <li>
                                <a
                                    href="#"
                                    className="hover:text-slate-300 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 rounded-sm"
                                >
                                    תקנון האתר
                                </a>
                            </li>
                            <li>
                                <a
                                    href="#"
                                    className="hover:text-slate-300 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 rounded-sm"
                                >
                                    מדיניות פרטיות
                                </a>
                            </li>
                            <li>
                                <a
                                    href="#"
                                    className="hover:text-slate-300 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 rounded-sm"
                                >
                                    צור קשר
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </footer>
        </div>
    );
};

export default LandingPage;
