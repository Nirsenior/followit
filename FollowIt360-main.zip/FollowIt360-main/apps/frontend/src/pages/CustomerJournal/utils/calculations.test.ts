// @vitest-environment node
import { Customer, Policy, UserProfile } from '@repo/types';
import { describe, expect, it } from 'vitest';
import { EMPTY_USER_PROFILE } from '../../../constants/profile.js';
import {
    calculateAccumulationForCustomer,
    calculateAge,
    calculateCommissions,
    calculateCustomerPremiumSplit,
    calculateCustomerTotalPremium,
    getEffectivePremium,
    getLatestTimestamp
} from './calculations.js';

describe('Customer Journal Calculations', () => {
    describe('calculateAge', () => {
        it('calculates full years properly considering month differences', () => {
            // born in August 2000
            expect(calculateAge('2000-08-01', 9, 2025)).toBe(25); // Target: Oct 2025 -> Month 9. 9 >= 7 (August is 7, Wait, August is month index 7 in JS normally, but the function targetMonth is usually 0-indexed or 1-indexed? The function does `targetMonth - birthDate.getMonth()`. birthDate.getMonth() for August is 7. If targetMonth is 9, m = 2. 25 years.)
            expect(calculateAge('2000-08-01', 6, 2025)).toBe(24); // Target: July 2025 -> Month 6. 6 < 7, so 2025 - 2000 - 1 = 24.
        });

        it('returns zero safely if DOB is empty', () => {
            expect(calculateAge('', 1, 2025)).toBe(0);
        });

        it('defaults to current date when month is -1 or undefined', () => {
            const now = new Date();
            const birthStr = now.toISOString().split('T')[0];

            expect(calculateAge(birthStr, -1)).toBe(0);
            expect(calculateAge(birthStr, undefined)).toBe(0);
        });
    });

    describe('getEffectivePremium', () => {
        const dummyPolicy: Policy = {
            id: '1',
            company: 'הראל',
            type: 'life',
            status: 'active',
            monthlyCost: 100,
            details: {},
            premiumSchedule: [
                { year: 0, premium: 100 },
                { year: 1, premium: 120 },
                { year: 2, premium: 140 },
            ],
        };

        it('returns the premium from the policy schedule based on elapsed years', () => {
            // Customer issue date: Jan 2020. Target: Feb 2022. => 2 years elapsed.
            // Expected premium: array index 2 => 140.
            const premium = getEffectivePremium(dummyPolicy, '2020-01-01', 1, 2022);
            expect(premium).toBe(140);
        });

        it('falls back to default monthlyCost if schedule runs out or is missing', () => {
            // 5 years elapsed, index 5 is undefined
            const premium = getEffectivePremium(dummyPolicy, '2020-01-01', 1, 2025);
            expect(premium).toBe(100);
        });

        it('defaults to current premium when date is omitted', () => {
            const now = new Date();
            const issueStr = now.toISOString().split('T')[0];

            // Expected index 0 -> 100
            expect(getEffectivePremium(dummyPolicy, issueStr)).toBe(100);
        });
    });

    describe('calculateCommissions', () => {
        const profile: UserProfile = {
            ...EMPTY_USER_PROFILE,
            agreements: {
                הראל: {
                    life: { scope: '50', ongoing: '10' },
                    pension: { scope: '1', ongoing: '0.5', mobility: '0.8' },
                },
            },
        };

        it('calculates elementary commissions using manual fallback fields', () => {
            const policy: Policy = {
                id: '1',
                company: 'הראל',
                type: 'elementary',
                status: 'active',
                monthlyCost: 0,
                details: { manualElementaryScope: 500, manualElementaryOngoing: 50 },
            };
            const result = calculateCommissions(policy, 100, profile);
            expect(result.scope).toBe(500);
            expect(result.ongoing).toBe(50);
        });

        it('calculates life insurance scope and ongoing natively', () => {
            const policy: Policy = {
                id: '1',
                company: 'הראל',
                type: 'life',
                status: 'active',
                monthlyCost: 100,
                details: {},
            };
            // ongoing = premium * ongoingRate = 100 * 0.10 = 10
            // scope = premium * 12 * scopeRate = 100 * 12 * 0.50 = 600
            const result = calculateCommissions(policy, 100, profile);
            expect(result.ongoing).toBe(10);
            expect(result.scope).toBe(600);
        });

        it('does not calculate scope if policy is Agent Appointment Only (מינוי סוכן)', () => {
            const policy: Policy = {
                id: '1',
                company: 'הראל',
                type: 'life',
                status: 'active',
                monthlyCost: 100,
                isAgentAppointmentOnly: true,
                details: {},
            };
            const result = calculateCommissions(policy, 100, profile);
            expect(result.ongoing).toBe(10);
            expect(result.scope).toBe(0);
        });

        it('calculates financial commissions delegating to calcFinancial*', () => {
            const policy: Policy = {
                id: '1',
                company: 'הראל',
                type: 'pension',
                status: 'active',
                monthlyCost: 1000,
                details: {
                    accumulation: 100000,
                    mobility: 0,
                    monthlyDeposit: 1000,
                    lumpSumDeposit: 0,
                },
            };
            const result = calculateCommissions(policy, 1000, profile);
            // Pension scope: monthlyDeposit * 12 * scopeRate = 1000 * 12 * 0.01 = 120
            // Pension ongoing: monthlyDeposit * ongoingRate = 1000 * 0.005 = 5
            expect(result.scope).toBe(120);
            expect(result.ongoing).toBe(5);
        });
    });

    describe('calculateAccumulationForCustomer', () => {
        it('calculates accumulation accurately factoring existing accumulations and deposits', () => {
            const customer = {
                policies: [
                    {
                        type: 'pension',
                        issueDate: '2020-01-01',
                        details: { accumulation: 100000, monthlyDeposit: 1000 },
                    },
                ],
            } as unknown as Customer;

            // Current logic is static: it just returns the initial accumulation without projection.
            const acc = calculateAccumulationForCustomer(customer, {}, 0, 2021);
            expect(acc).toBe(100000);
        });

        it('safely handles non-financial policies and missing issueDates', () => {
            const customer = {
                policies: [
                    { type: 'life', details: {} }, // Handled and skipped natively
                    { type: 'gemel', details: { accumulation: 50000 } }, // No issue date
                ],
            } as unknown as Customer;

            const acc = calculateAccumulationForCustomer(customer, {}, 0, 2021);
            expect(acc).toBe(50000); // Only initial accumulation added
        });

        it('defaults to current accumulation when date is omitted', () => {
            const now = new Date();
            const customer = {
                policies: [
                    {
                        type: 'pension',
                        issueDate: now.toISOString(),
                        details: { accumulation: 100000, monthlyDeposit: 1000 },
                    },
                ],
            } as unknown as Customer;

            // Current logic is static: even at month 0, it only returns the initial accumulation.
            const acc = calculateAccumulationForCustomer(customer);
            expect(acc).toBe(100000);
        });
    });

    describe('calculateCustomerTotalPremium', () => {
        it('calculates total premium for all policies including family members', () => {
            const customer = {
                issueDate: '2020-01-01',
                policies: [{ type: 'life', monthlyCost: 100, details: {} }],
                familyMembers: [
                    {
                        issueDate: '2020-01-01',
                        policies: [{ type: 'life', monthlyCost: 50, details: {} }],
                    },
                ],
            } as unknown as Customer;

            expect(calculateCustomerTotalPremium(customer)).toBe(150);
        });

        it('shares premium schedule with primary when isPremiumSharedWithPrimary is true', () => {
            const customer = {
                issueDate: '2020-01-01',
                policies: [
                    { 
                        type: 'life', 
                        monthlyCost: 100, 
                        details: {},
                        premiumSchedule: [
                            { year: 0, premium: 100 },
                            { year: 1, premium: 120 },
                            { year: 2, premium: 140 }, // Target year 2 -> 140
                        ]
                    }
                ],
                familyMembers: [
                    {
                        issueDate: '2020-01-01',
                        isPremiumSharedWithPrimary: true,
                        policies: [
                            { type: 'life', monthlyCost: 50, details: {}, premiumSchedule: [] }
                        ],
                    },
                ],
            } as unknown as Customer;

            // Elapsed years = 2022 - 2020 = 2 years.
            // Both primary and family member should use the 140 premium.
            // Total = 140 + 140 = 280.
            expect(calculateCustomerTotalPremium(customer, 1, 2022)).toBe(280);
        });
    });

    describe('calculateAccumulationForCustomer - Family Members', () => {
        it('calculates accumulation for family member policies', () => {
            const customer = {
                policies: [],
                familyMembers: [
                    {
                        policies: [
                            {
                                type: 'gemel',
                                details: { accumulation: 20000 }
                            }
                        ]
                    }
                ]
            } as unknown as Customer;
            
            const acc = calculateAccumulationForCustomer(customer);
            expect(acc).toBe(20000);
        });
        
        it('safely handles family members without policies array', () => {
            const customer = {
                policies: [],
                familyMembers: [
                    {
                        name: 'Spouse'
                    }
                ]
            } as unknown as Customer;
            
            const acc = calculateAccumulationForCustomer(customer);
            expect(acc).toBe(0);
        });
    });

    describe('getLatestTimestamp', () => {

        it('returns 0 if no valid dates exist', () => {
            const customer = {
                policies: []
            } as unknown as Customer;
            expect(getLatestTimestamp(customer)).toBe(0);
        });

        it('returns issueDate timestamp as baseline', () => {
            const customer = {
                issueDate: '2020-01-01',
                policies: []
            } as unknown as Customer;
            // parseFlexibleDate creates a local Date(2020, 0, 1)
            expect(getLatestTimestamp(customer)).toBe(new Date(2020, 0, 1).getTime());
        });

        it('falls back to createdAt if issueDate is invalid', () => {
            const customer = {
                issueDate: 'invalid',
                createdAt: '2020-05-01T00:00:00Z',
                policies: []
            } as unknown as Customer;
            expect(getLatestTimestamp(customer)).toBe(new Date('2020-05-01T00:00:00Z').getTime());
        });

        it('finds the max issueDate among policies', () => {
            const customer = {
                issueDate: '2020-01-01',
                policies: [
                    { issueDate: '2021-01-01' },
                    { issueDate: '2022-01-01' },
                    { issueDate: '2019-01-01' }
                ]
            } as unknown as Customer;
            expect(getLatestTimestamp(customer)).toBe(new Date(2022, 0, 1).getTime());
        });
    });

    describe('calculateCustomerPremiumSplit', () => {
        it('correctly splits premium between private (non-financial) and financial policies including family members', () => {
            const customer = {
                issueDate: '2020-01-01',
                policies: [
                    { type: 'life', monthlyCost: 100, details: {} },        // Private
                    { type: 'pension', monthlyCost: 200, details: {} },     // Financial
                ],
                familyMembers: [
                    {
                        issueDate: '2020-01-01',
                        policies: [
                            { type: 'health', monthlyCost: 50, details: {} },       // Private
                            { type: 'gemel', monthlyCost: 300, details: {} },       // Financial
                        ],
                    },
                ],
            } as unknown as Customer;

            const split = calculateCustomerPremiumSplit(customer);
            expect(split.privatePremium).toBe(150);      // 100 + 50
            expect(split.financialPremium).toBe(500);    // 200 + 300
        });

        it('safely handles customer with only private or only financial policies', () => {
            const customerOnlyPrivate = {
                issueDate: '2020-01-01',
                policies: [{ type: 'life', monthlyCost: 100, details: {} }],
                familyMembers: [],
            } as unknown as Customer;

            const splitPrivate = calculateCustomerPremiumSplit(customerOnlyPrivate);
            expect(splitPrivate.privatePremium).toBe(100);
            expect(splitPrivate.financialPremium).toBe(0);

            const customerOnlyFinancial = {
                issueDate: '2020-01-01',
                policies: [{ type: 'gemel', monthlyCost: 250, details: {} }],
                familyMembers: [],
            } as unknown as Customer;

            const splitFinancial = calculateCustomerPremiumSplit(customerOnlyFinancial);
            expect(splitFinancial.privatePremium).toBe(0);
            expect(splitFinancial.financialPremium).toBe(250);
        });

        it('shares premium schedule with primary when isPremiumSharedWithPrimary is true', () => {
            const customer = {
                issueDate: '2020-01-01',
                policies: [
                    { 
                        type: 'life', // individual
                        monthlyCost: 100, 
                        details: {},
                        premiumSchedule: [
                            { year: 0, premium: 100 },
                            { year: 1, premium: 120 },
                            { year: 2, premium: 140 }, // Target year 2 -> 140
                        ]
                    }
                ],
                familyMembers: [
                    {
                        issueDate: '2020-01-01',
                        isPremiumSharedWithPrimary: true,
                        policies: [
                            { type: 'pension', monthlyCost: 50, details: {}, premiumSchedule: [] } // financial
                        ],
                    },
                ],
            } as unknown as Customer;

            // Target 2022 => index 2 => premium 140.
            // Primary is life -> privatePremium = 140
            // Family member is pension -> shared schedule -> financialPremium = 140
            const split = calculateCustomerPremiumSplit(customer, 1, 2022);
            expect(split.privatePremium).toBe(140);
            expect(split.financialPremium).toBe(140);
        });
    });
});

