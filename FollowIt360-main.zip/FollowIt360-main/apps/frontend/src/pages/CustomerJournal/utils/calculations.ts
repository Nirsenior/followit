/**
 * @fileoverview Frontend Commission & Accumulation Calculations
 *
 * SCOPE (היקף) FORMULAS:
 *
 * | Type                 | Formula                                                         |
 * |----------------------|-----------------------------------------------------------------|
 * | pension              | (mobility×mobilityRate%) + (lumpSum×scopeRate%) + (monthly×12×scopeRate%) |
 * | gemel/hishtalmut     | (mobility×mobilityRate%) + (lumpSum×scopeRate%) + (monthly×12×scopeRate%) |
 * | long_term_savings    | (accum + monthly×12 + lumpSum) × scopeRate%                    |
 * | health/life/critical | monthly × 12 × scopeRate%                                       |
 * | elementary/abroad    | manual ₪ entry                                                  |
 *
 * ⚠️  ACCUMULATION-ONLY = NO SCOPE: If only accumulation (no mobility, no deposits) → scope = ₪0.
 * ⚠️  EXISTING CUSTOMER (לקוח קיים): scope column stays EMPTY — never calculate scope for retro entries.
 *
 * ONGOING (נפרעים) FORMULAS:
 *
 * | Type                 | Formula                                                         |
 * |----------------------|-----------------------------------------------------------------|
 * | pension              | monthlyDeposit × ongoingRate%                                   |
 * | gemel/hishtalmut     | With lump-sum: (MAX(accum,mobility) + lumpSum) × ongoingRate% ÷ 12 |
 * |                      | With monthly:  (MAX(accum,mobility) × ongoingRate% ÷ 12) + (monthly × ongoingRate%) |
 * |                      | Both: sum both components                                       |
 * | long_term_savings    | (accum + monthly×12 + lumpSum) × ongoingRate% ÷ 12             |
 * | health/life/critical | monthlyPremium × ongoingRate%                                   |
 * | elementary/abroad    | manual ₪ entry                                                  |
 *
 * YIELD SYNC (מיי גמל נט — monthly):
 * ┌─────────────────────────┬─────────────────┬────────────────┬───────────────┐
 * │ Product                 │ → Accumulation  │ → Ongoing      │ → Scope       │
 * ├─────────────────────────┼─────────────────┼────────────────┼───────────────┤
 * │ pension                 │ ✅ display only  │ ❌ NEVER       │ ❌ NEVER      │
 * │ gemel/hishtalmut/invest │ ✅ yes           │ ✅ via accum   │ ❌ never      │
 * │ long_term_savings       │ ✅ yes           │ ✅ via accum   │ ❌ never      │
 * │ health/life/critical    │ ❌ no            │ ❌ no          │ ❌ no         │
 * └─────────────────────────┴─────────────────┴────────────────┴───────────────┘
 * ⚠️  PENSION: GemelNet ONLY feeds סכום צבירה for display. The נפרעים and היקף
 *     commission columns for pension are NEVER derived from GemelNet data.
 *
 * ACCUMULATION: Uses `currentAccumulation` (DB, yield-compounded by backend cron) when available,
 * falling back to form inputs (accumulation + mobility + lumpSumDeposit).
 * The DB value is authoritative — do not re-calculate yield in the frontend.
 *
 * Note: Remove `console.log` statements before committing.
 */
import { Customer, isFinancialType, isIndividualType, Policy, UserProfile } from '@repo/types';
import {
    calcFinancialOngoing,
    calcFinancialScope,
    CommissionRates,
    FinancialInputs,
} from '../../../utils/commissionCalc';

export const parseFlexibleDate = (dateStr: string): Date | null => {
    if (!dateStr || typeof dateStr !== 'string') return null;
    const clean = dateStr.trim();

    // Regex for YYYY-MM-DD or YYYY/MM/DD
    const isoMatch = clean.match(/^(\d{4})[/-](\d{1,2})[/-](\d{1,2})/);
    if (isoMatch) {
        return new Date(parseInt(isoMatch[1]), parseInt(isoMatch[2]) - 1, parseInt(isoMatch[3]));
    }

    // Regex for DD-MM-YYYY or DD/MM/YYYY
    const ilMatch = clean.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})/);
    if (ilMatch) {
        return new Date(parseInt(ilMatch[3]), parseInt(ilMatch[2]) - 1, parseInt(ilMatch[1]));
    }

    const d = new Date(clean);
    return isNaN(d.getTime()) ? null : d;
};

export const calculateAge = (dob: string, targetMonth?: number, targetYear?: number): number => {
    const birthDate = parseFlexibleDate(dob);
    if (!birthDate) return 0;

    const now = new Date();
    const effectiveMonth =
        targetMonth === undefined || targetMonth === -1 ? now.getMonth() : targetMonth;
    const effectiveYear =
        targetYear === undefined || targetYear === -1 ? now.getFullYear() : targetYear;

    let age = effectiveYear - birthDate.getFullYear();
    const m = effectiveMonth - birthDate.getMonth();
    if (m < 0) age--;
    return age;
};

export const getEffectivePremium = (
    policy: Policy,
    customerIssueDate: string,
    targetMonth?: number,
    targetYear?: number,
): number => {
    const birthDateForCalc = customerIssueDate;
    if (
        (isIndividualType(policy.type) ||
            policy.type === 'elementary' ||
            isFinancialType(policy.type)) &&
        policy.premiumSchedule &&
        policy.premiumSchedule.length > 0
    ) {
        const yearsPassed = calculateAge(birthDateForCalc, targetMonth, targetYear);
        // User logic: first row (index 0) is year 0, etc.
        const scheduleItem = policy.premiumSchedule[yearsPassed];
        return scheduleItem
            ? scheduleItem.premium
            : policy.monthlyCost || policy.details?.monthlyDeposit || 0;
    }
    return policy.monthlyCost || policy.details?.monthlyDeposit || 0;
};

export const calculateCustomerTotalPremium = (
    customer: Customer,
    targetMonth?: number,
    targetYear?: number,
): number => {
    let total = 0;

    // 1. Primary customer policies
    customer.policies.forEach((p) => {
        total += getEffectivePremium(p, customer.issueDate, targetMonth, targetYear);
    });

    // 2. Family members policies
    if (customer.familyMembers) {
        customer.familyMembers.forEach((fm) => {
            fm.policies.forEach((p) => {
                // Determine which schedule to use (shared or own)
                let policyToCalc = { ...p };
                if (
                    fm.isPremiumSharedWithPrimary &&
                    (!p.premiumSchedule || p.premiumSchedule.length === 0)
                ) {
                    const primarySchedule = customer.policies.find(
                        (pp) =>
                            isIndividualType(pp.type) &&
                            pp.premiumSchedule &&
                            pp.premiumSchedule.length > 0,
                    );
                    if (primarySchedule) {
                        policyToCalc.premiumSchedule = primarySchedule.premiumSchedule;
                    }
                }

                // Use the same centralized logic for fm too
                total += getEffectivePremium(
                    policyToCalc,
                    fm.issueDate || customer.issueDate,
                    targetMonth,
                    targetYear,
                );
            });
        });
    }

    return total;
};

export const calculateCustomerPremiumSplit = (
    customer: Customer,
    targetMonth?: number,
    targetYear?: number,
): { privatePremium: number; financialPremium: number } => {
    let privatePremium = 0;
    let financialPremium = 0;

    // 1. Primary customer policies
    customer.policies.forEach((p) => {
        const premium = getEffectivePremium(p, customer.issueDate, targetMonth, targetYear);
        if (isFinancialType(p.type)) {
            financialPremium += premium;
        } else {
            privatePremium += premium;
        }
    });

    // 2. Family members policies
    if (customer.familyMembers) {
        customer.familyMembers.forEach((fm) => {
            fm.policies.forEach((p) => {
                // Determine which schedule to use (shared or own)
                let policyToCalc = { ...p };
                if (
                    fm.isPremiumSharedWithPrimary &&
                    (!p.premiumSchedule || p.premiumSchedule.length === 0)
                ) {
                    const primarySchedule = customer.policies.find(
                        (pp) =>
                            isIndividualType(pp.type) &&
                            pp.premiumSchedule &&
                            pp.premiumSchedule.length > 0,
                    );
                    if (primarySchedule) {
                        policyToCalc.premiumSchedule = primarySchedule.premiumSchedule;
                    }
                }

                // Use the same centralized logic for fm too
                const premium = getEffectivePremium(
                    policyToCalc,
                    fm.issueDate || customer.issueDate,
                    targetMonth,
                    targetYear,
                );
                if (isFinancialType(p.type)) {
                    financialPremium += premium;
                } else {
                    privatePremium += premium;
                }
            });
        });
    }

    return { privatePremium, financialPremium };
};


/**
 * Calculate the total accumulated balance for all financial policies.
 *
 * @param customer       - the customer record (policies contain policyTracks)
 * @param targetMonth    - 0-indexed month (0-11)
 * @param targetYear     - e.g. 2025
 */
export const calculateAccumulationForCustomer = (
    customer: Customer,
    yieldByPolicy: Record<string, number> = {},
    targetMonth?: number,
    targetYear?: number,
): number => {
    let total = 0;

    const allPolicies = [
        ...customer.policies,
        ...(customer.familyMembers?.flatMap((fm) => fm.policies || []) || []),
    ];

    allPolicies.forEach((p) => {
        if (isFinancialType(p.type)) {
            const dbAccumulation = p.currentAccumulation
                ? parseFloat(p.currentAccumulation)
                : p.initialAccumulation
                  ? parseFloat(p.initialAccumulation)
                  : null;
            const formAccumulation =
                Math.max(p.details?.accumulation || 0, p.details?.mobility || 0) +
                (p.details?.lumpSumDeposit || 0);
            const initial =
                dbAccumulation !== null && !isNaN(dbAccumulation)
                    ? dbAccumulation
                    : formAccumulation;

            total += initial;
        }
    });
    return total;
};

export const calculateCommissions = (
    policy: Policy,
    premium: number,
    profile: UserProfile,
): { scope: number; ongoing: number } => {
    if (policy.type === 'elementary') {
        return {
            scope: policy.details?.manualElementaryScope || 0,
            ongoing: policy.details?.manualElementaryOngoing || 0,
        };
    }

    const agreement = profile.agreements[policy.company]?.[policy.type];
    if (!agreement) return { scope: 0, ongoing: 0 };

    if (isFinancialType(policy.type)) {
        const inputs: FinancialInputs = {
            // Pass EOM accumulation (may be yield-adjusted upstream) as the base for nifraim
            accumulation: policy.details?.accumulation || 0,
            mobility: policy.details?.mobility || 0,
            monthlyDeposit: policy.details?.monthlyDeposit || premium,
            lumpSumDeposit: policy.details?.lumpSumDeposit || 0,
        };
        const rates: CommissionRates = {
            scope: parseFloat(agreement.scope || '0'),
            ongoing: parseFloat(policy.fixedCommissionRate || agreement.ongoing || '0'),
            mobility: parseFloat(agreement.mobility || '0'),
        };
        const scope = policy.isAgentAppointmentOnly
            ? 0
            : calcFinancialScope(inputs, rates, policy.type);
        const ongoing = calcFinancialOngoing(inputs, rates, policy.type);
        return { scope, ongoing };
    }

    const scopeRate = parseFloat(agreement.scope || '0') / 100;
    const ongoingRate =
        parseFloat(policy.fixedCommissionRate || agreement.ongoing || '0') / 100;

    let scope = 0;
    let ongoing = 0;

    if (policy.status === 'active') {
        ongoing = premium * ongoingRate;

        if (!policy.isAgentAppointmentOnly) {
            scope = premium * 12 * scopeRate;
        }
    }
    return { scope, ongoing };
};

export const getLatestTimestamp = (cust: Customer): number => {
    // Check customer-level date first as a baseline
    let latest = parseFlexibleDate(cust.issueDate)?.getTime() || 0;

    // Fallback to createdAt if issueDate is missing/invalid
    if (latest === 0 && (cust as any).createdAt) {
        latest = new Date((cust as any).createdAt).getTime() || 0;
    }

    if (cust.policies && cust.policies.length > 0) {
        cust.policies.forEach((p) => {
            const ts = parseFlexibleDate(p.issueDate)?.getTime();
            if (ts && ts > latest) {
                latest = ts;
            }
        });
    }

    return latest;
};
