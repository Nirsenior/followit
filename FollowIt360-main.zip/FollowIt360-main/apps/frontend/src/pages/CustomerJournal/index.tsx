import { Customer, INSURANCE_COMPANIES, Policy, UserProfile } from '@repo/types';
import { useQueryClient } from '@tanstack/react-query';
import React, { useCallback, useMemo, useState } from 'react';
import { useCreateCustomer, useCustomers, useUpdateCustomer } from '../../hooks/useCustomers';
import { getSelectedCompanies } from '../../utils/profileUtils';
import { AddCustomerModal } from './components/AddCustomerModal';
import { AddFamilyMemberModal } from './components/AddFamilyMemberModal';
import { CustomerCreationTypeModal } from './components/CustomerCreationTypeModal';
import { CustomerHeader } from './components/CustomerHeader';
import { CustomerTable } from './components/CustomerTable';
import { parseFlexibleDate } from './utils/calculations';

interface CustomerJournalProps {
    profile: UserProfile;
    onLogout?: () => void;
    onNavigate?: (s: any) => void;
}

const CustomerJournal: React.FC<CustomerJournalProps> = ({ profile }) => {
    const queryClient = useQueryClient();
    const { data: customers = [], isLoading } = useCustomers();
    const createCustomerMutation = useCreateCustomer();
    const updateCustomerMutation = useUpdateCustomer();

    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [isTypeModalOpen, setIsTypeModalOpen] = useState(false);
    const [selectedCreationType, setSelectedCreationType] = useState<'existing' | 'new_production'>(
        'new_production',
    );
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedMonth, setSelectedMonth] = useState(-1);
    const [selectedYear, setSelectedYear] = useState(-1);
    const [viewingCustomer, setViewingCustomer] = useState<Customer | null>(null);
    const [viewingFamilyMember, setViewingFamilyMember] = useState<{
        fm: any;
        parent: Customer;
    } | null>(null);
    const [companyFilter, setCompanyFilter] = useState<string>('all');
    const [productFilter, setProductFilter] = useState<string>('all');

    const years = useMemo(() => {
        const currentYear = new Date().getFullYear();
        return Array.from({ length: 26 }, (_, i) => currentYear - i);
    }, []);

    const months = [
        'ינואר',
        'פברואר',
        'מרץ',
        'אפריל',
        'מאי',
        'יוני',
        'יולי',
        'אוגוסט',
        'ספטמבר',
        'אוקטובר',
        'נובמבר',
        'דצמבר',
    ];

    const filteredCustomers = useMemo(() => {
        return customers
            .filter((c: Customer) => {
                const fullSearchString = `${c.firstName} ${c.lastName} ${c.id}`.toLowerCase();
                const matchesSearch = fullSearchString.includes(searchQuery.toLowerCase());
                const matchesCompany =
                    companyFilter === 'all' ||
                    c.policies.some((p: Policy) => p.company === companyFilter);
                const matchesProduct =
                    productFilter === 'all' ||
                    c.policies.some((p: Policy) => p.type === productFilter);

                const matchesDate = c.policies.some((p: Policy) => {
                    if (!p.issueDate) return false;
                    const date = new Date(p.issueDate);
                    const monthMatch = selectedMonth === -1 || date.getMonth() === selectedMonth;
                    const yearMatch = selectedYear === -1 || date.getFullYear() === selectedYear;
                    return monthMatch && yearMatch;
                });

                return matchesSearch && matchesCompany && matchesProduct && matchesDate;
            })
            .sort((a: Customer, b: Customer) => {
                const getTs = (c: Customer) => {
                    const d = parseFlexibleDate(c.issueDate);
                    return d ? d.getTime() : 0;
                };
                return getTs(b) - getTs(a);
            });
    }, [customers, searchQuery, companyFilter, productFilter, selectedMonth, selectedYear]);

    const handleCloseAddModal = useCallback(() => setIsAddModalOpen(false), []);

    const handleAddCustomer = useCallback(
        async (newC: Customer) => {
            try {
                const payload = {
                    customer: {
                        firstName: newC.firstName,
                        surname: newC.lastName,
                        governmentId: newC.id,
                        issueDate: newC.issueDate,
                        creationType: newC.creationType || selectedCreationType,
                    },
                    policies: newC.policies.map((p) => ({
                        company: p.company,
                        insuranceType: p.type,
                        issueDate: p.issueDate,
                        isAgentAppointmentOnly: p.isAgentAppointmentOnly,
                        details: p.details,
                        status: p.status || 'active',
                    })),
                    familyMembers: newC.familyMembers,
                };

                await createCustomerMutation.mutateAsync(payload);
                setIsAddModalOpen(false);
            } catch (err) {
                console.error('Error adding customer:', err);
                alert(err instanceof Error ? err.message : 'שגיאה בהוספת לקוח. אנא נסה שוב.');
            }
        },
        [createCustomerMutation],
    );

    const profileCompanies = getSelectedCompanies(profile.agreements);
    const safeCompanies =
        profileCompanies.length > 0
            ? profileCompanies
            : [...(INSURANCE_COMPANIES as unknown as string[])];

    return (
        <div className="flex h-screen bg-slate-50 overflow-hidden text-slate-900" dir="rtl">
            <main className="flex-1 flex flex-col overflow-hidden relative">
                <CustomerHeader
                    setIsAddModalOpen={setIsTypeModalOpen}
                    selectedYear={selectedYear}
                    setSelectedYear={setSelectedYear}
                    selectedMonth={selectedMonth}
                    setSelectedMonth={setSelectedMonth}
                    years={years}
                    months={months}
                    companyFilter={companyFilter}
                    setCompanyFilter={setCompanyFilter}
                    productFilter={productFilter}
                    setProductFilter={setProductFilter}
                    availableCompanies={safeCompanies}
                    searchQuery={searchQuery}
                    setSearchQuery={setSearchQuery}
                />

                <div className="flex-1 overflow-hidden relative p-8">
                    {isLoading ? (
                        <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/50 backdrop-blur-sm z-10 transition-all opacity-100">
                            <div className="w-12 h-12 border-4 border-slate-100 border-t-emerald-500 rounded-full animate-spin"></div>
                            <p className="mt-4 text-slate-500 font-bold tracking-widest text-sm animate-pulse">
                                טוען לקוחות...
                            </p>
                        </div>
                    ) : null}
                    <div className="h-full w-full overflow-hidden">
                        <CustomerTable
                            filteredCustomers={filteredCustomers}
                            selectedMonth={selectedMonth}
                            selectedYear={selectedYear}
                            profile={profile}
                            setViewingCustomer={setViewingCustomer}
                            onViewFamilyMember={(fm, parent) =>
                                setViewingFamilyMember({ fm, parent })
                            }
                        />
                    </div>
                </div>
            </main>

            {isTypeModalOpen && (
                <CustomerCreationTypeModal
                    onClose={() => setIsTypeModalOpen(false)}
                    onContinue={(type) => {
                        setSelectedCreationType(type);
                        setIsTypeModalOpen(false);
                        setIsAddModalOpen(true);
                    }}
                />
            )}

            {isAddModalOpen && (
                <AddCustomerModal
                    onClose={handleCloseAddModal}
                    onSubmit={handleAddCustomer}
                    profile={profile}
                    isSubmitting={createCustomerMutation.isPending}
                    creationType={selectedCreationType}
                />
            )}

            {viewingCustomer && (
                <AddCustomerModal
                    onClose={() => setViewingCustomer(null)}
                    onSubmit={() => {}}
                    profile={profile}
                    initialCustomer={viewingCustomer}
                    onUpdate={(updated) => {
                        queryClient.setQueryData(['customers'], (old: Customer[] | undefined) => {
                            if (!old) return [];
                            return old.map((c) => (c.id === updated.id ? updated : c));
                        });
                        setViewingCustomer(null);
                    }}
                    onDelete={(deletedId) => {
                        queryClient.setQueryData(['customers'], (old: Customer[] | undefined) => {
                            if (!old) return [];
                            return old.filter((c) => c.id !== deletedId);
                        });
                        setViewingCustomer(null);
                    }}
                />
            )}

            {viewingFamilyMember && (
                <AddFamilyMemberModal
                    profile={profile}
                    initialLastName={viewingFamilyMember.parent.lastName}
                    initialFamilyMember={viewingFamilyMember.fm}
                    parentCreationType={viewingFamilyMember.parent.creationType}
                    onClose={() => setViewingFamilyMember(null)}
                    onSubmit={async (updatedFm) => {
                        const parent = viewingFamilyMember.parent;
                        const updatedFamilyMembers =
                            parent.familyMembers?.map((f: any) =>
                                f.id === updatedFm.id ? updatedFm : f,
                            ) ?? [];

                        try {
                            await updateCustomerMutation.mutateAsync({
                                dbId: (parent as any).dbId,
                                payload: {
                                    customer: {
                                        firstName: parent.firstName,
                                        surname: parent.lastName,
                                        governmentId: parent.id,
                                        issueDate: parent.issueDate || '',
                                        creationType: parent.creationType,
                                    },
                                    policies: parent.policies
                                        .filter((p) => p.status === 'active')
                                        .map((p) => ({
                                            company: p.company,
                                            insuranceType: p.type,
                                            issueDate: p.issueDate || '',
                                            isAgentAppointmentOnly: p.isAgentAppointmentOnly,
                                            details: p.details,
                                        })),
                                    familyMembers: updatedFamilyMembers,
                                },
                            });

                            // Update local cache
                            queryClient.setQueryData(
                                ['customers'],
                                (old: Customer[] | undefined) => {
                                    if (!old) return [];
                                    return old.map((c) =>
                                        c.id === parent.id
                                            ? { ...c, familyMembers: updatedFamilyMembers }
                                            : c,
                                    );
                                },
                            );
                            setViewingFamilyMember(null);
                        } catch (err) {
                            alert(
                                err instanceof Error ? err.message : 'שגיאה בשמירת נתוני בן המשפחה',
                            );
                        }
                    }}
                />
            )}
        </div>
    );
};

export default CustomerJournal;
