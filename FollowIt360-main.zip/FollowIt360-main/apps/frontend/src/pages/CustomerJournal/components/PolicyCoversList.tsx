import React, { useState } from 'react';

interface PolicyCoversListProps {
    subPolicies?: Record<string, number>;
    variant?: 'blue' | 'sky';
    size?: 'sm' | 'xs';
}

/**
 * PolicyCoversList displays the sub-policies (types of coverages) that a policy contains.
 * It abstracts the display logic using visual best practices, clean tags, and micro-interactions.
 * It supports toggle expand/collapse state locally to save sidebar vertical space.
 */
export const PolicyCoversList: React.FC<PolicyCoversListProps> = React.memo(({
    subPolicies,
    variant = 'blue',
    size = 'sm',
}) => {
    const [isExpanded, setIsExpanded] = useState(true);

    if (!subPolicies || Object.keys(subPolicies).length === 0) {
        return null;
    }

    const subNames = Object.keys(subPolicies);

    const containerClasses = size === 'xs' 
        ? 'flex flex-wrap gap-1 mt-1.5' 
        : 'mt-2 flex flex-wrap gap-1 max-w-[200px]';

    const badgeClasses = size === 'xs'
        ? `text-[9.5px] font-normal px-1 py-0.2 rounded border uppercase transition-all duration-200 hover:scale-[1.03] cursor-default
           ${variant === 'sky' 
               ? 'bg-sky-50 text-sky-600 border-sky-100/50 hover:bg-sky-100/50' 
               : 'bg-blue-50 text-blue-600 border-blue-100/50 hover:bg-blue-100/50'}`
        : `text-[10px] font-normal px-1.5 py-0.5 rounded border uppercase tracking-tighter transition-all duration-200 hover:scale-[1.03] cursor-default
           ${variant === 'sky' 
               ? 'bg-sky-50 text-sky-600 border-sky-100 hover:bg-sky-100/70 hover:border-sky-200' 
               : 'bg-blue-50 text-blue-600 border-blue-100 hover:bg-blue-100/70 hover:border-blue-200'}`;

    return (
        <div className="mt-1.5 text-right" dir="rtl">
            <button
                type="button"
                onClick={(e) => {
                    e.stopPropagation(); // Prevent triggering editing/actions on parent card container
                    setIsExpanded(prev => !prev);
                }}
                aria-expanded={isExpanded}
                className={`inline-flex items-center gap-1 text-[10.5px] font-normal transition-all cursor-pointer hover:underline outline-none border-none bg-transparent p-0 select-none focus-visible:ring-2 focus-visible:ring-blue-500/50 rounded px-1
                    ${variant === 'sky' ? 'text-sky-600 hover:text-sky-700' : 'text-blue-600 hover:text-blue-700'}`}
            >
                <span>{isExpanded ? 'הסתר כיסויים' : `הצג כיסויים (${subNames.length})`}</span>
                <span className={`text-[7px] transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} aria-hidden="true">
                    ▼
                </span>
            </button>

            {isExpanded && (
                <div className={`${containerClasses} animate-slideDown`}>
                    {subNames.map((name) => (
                        <span 
                            key={name} 
                            className={badgeClasses}
                            title={name}
                        >
                            {name}
                        </span>
                    ))}
                </div>
            )}
        </div>
    );
});

PolicyCoversList.displayName = 'PolicyCoversList';
