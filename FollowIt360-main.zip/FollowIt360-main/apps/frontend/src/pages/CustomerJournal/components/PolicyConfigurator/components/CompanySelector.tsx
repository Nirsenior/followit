import { InsuranceType, isIndividualType } from '@repo/types';
import React from 'react';

interface CompanySelectorProps {
    activeTab: InsuranceType;
    value: string;
    companies: string[];
    currentInputs: any;
    setCurrentInputs: (i: any) => void;
    size?: 'sm' | 'md';
}

export const CompanySelector: React.FC<CompanySelectorProps> = React.memo(
    ({ activeTab, value, companies, currentInputs, setCurrentInputs, size = 'md' }) => {
        const handleChange = (newCompany: string) => {
            if (isIndividualType(activeTab)) {
                setCurrentInputs({
                    ...currentInputs,
                    company: newCompany,
                    details: {
                        ...currentInputs.details,
                        subPolicies: {},
                    },
                });
            } else {
                setCurrentInputs({
                    ...currentInputs,
                    company: newCompany,
                });
            }
        };

        const baseClass = `w-full border-2 rounded-2xl outline-none bg-slate-50/50 text-slate-900 font-bold transition-all font-sans cursor-pointer appearance-none`;
        const sizeClass = size === 'sm' ? 'p-3 text-xs' : 'p-3.5 text-sm';
        const borderClass = !value
            ? 'border-blue-500/30 shadow-sm focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 focus:outline-none'
            : 'border-slate-100 focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-500/10 focus:outline-none';

        return (
            <div className="relative group">
                <select
                    value={value}
                    onChange={(e) => handleChange(e.target.value)}
                    className={`${baseClass} ${sizeClass} ${borderClass}`}
                    aria-label="בחר חברת ביטוח"
                >
                    <option value="" disabled>
                        בחר חברת ביטוח...
                    </option>
                    {companies.map((c) => (
                        <option key={c} value={c} className="font-bold py-2">
                            {c}
                        </option>
                    ))}
                </select>
                <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 group-hover:text-blue-500 transition-colors">
                    <svg
                        className="w-4 h-4"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        aria-hidden="true"
                    >
                        <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="3"
                            d="M19 9l-7 7-7-7"
                        />
                    </svg>
                </div>
                {companies.length === 0 && (
                    <div className="mt-2 p-3 bg-blue-50/30 border border-blue-100 rounded-xl text-center text-[10px] font-bold text-blue-400 italic">
                        אין חברות זמינות עבור כיסוי זה
                    </div>
                )}
            </div>
        );
    },
);

CompanySelector.displayName = 'CompanySelector';
