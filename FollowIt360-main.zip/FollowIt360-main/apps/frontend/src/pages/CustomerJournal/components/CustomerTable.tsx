import {
    Customer,
    getProductGroupLabel,
    InsuranceType,
    isFinancialType,
    isIndividualType,
    UserProfile,
} from '@repo/types';
import { ChevronDown, Heart } from 'lucide-react';
import React, { useEffect, useMemo, useState } from 'react';
import { getSelectedCompanies } from '../../../utils/profileUtils';
import {
    calculateAccumulationForCustomer,
    calculateCommissions,
    calculateCustomerPremiumSplit,
    getEffectivePremium,
    parseFlexibleDate,
} from '../utils/calculations';
import { TablePagination } from './TablePagination';

interface CustomerTableProps {
    filteredCustomers: Customer[];
    profile: UserProfile;
    selectedMonth: number;
    selectedYear: number;
    setViewingCustomer: (customer: Customer) => void;
    onViewFamilyMember?: (fm: any, parentCustomer: Customer) => void;
}

const ITEMS_PER_PAGE = 25;

const formatDate = (dateStr: string) => {
    const d = parseFlexibleDate(dateStr);
    if (!d) return dateStr;
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    return `${day}-${month}-${year}`;
};

export const CustomerTable: React.FC<CustomerTableProps> = React.memo(
    ({
        filteredCustomers,
        profile,
        selectedMonth,
        selectedYear,
        setViewingCustomer,
        onViewFamilyMember,
    }) => {
        const [expandedCustomers, setExpandedCustomers] = useState<Record<string, boolean>>({});
        const [currentPage, setCurrentPage] = useState(1);

        // Reset to first page when filters change
        useEffect(() => {
            setCurrentPage(1);
        }, [filteredCustomers]);

        const toggleExpand = (e: React.MouseEvent, customerId: string) => {
            e.stopPropagation();
            setExpandedCustomers((prev) => ({ ...prev, [customerId]: !prev[customerId] }));
        };

        const totalPages = Math.ceil(filteredCustomers.length / ITEMS_PER_PAGE);
        const paginatedCustomers = useMemo(() => {
            const startIdx = (currentPage - 1) * ITEMS_PER_PAGE;
            return filteredCustomers.slice(startIdx, startIdx + ITEMS_PER_PAGE);
        }, [filteredCustomers, currentPage]);

        return (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-full">
                <div className="flex-1 overflow-y-auto custom-scrollbar">
                    <table className="w-full text-right border-collapse" aria-label="יומן לקוחות ופוליסות">
                        <thead>
                            <tr className="border-b border-slate-200 text-slate-900 text-xs font-black uppercase tracking-widest leading-none">
                                <th className="sticky top-0 z-10 bg-slate-100 p-4 text-right border-l border-slate-200 w-[15%]">
                                    שם לקוח / ת״ז
                                </th>

                                <th className="sticky top-0 z-10 bg-slate-100 p-4 text-right border-l border-slate-200 w-[12%]">
                                    סוג מוצר
                                </th>
                                <th className="sticky top-0 z-10 bg-slate-100 p-4 text-right border-l border-slate-200 w-[10%]">
                                    חברה
                                </th>
                                <th className="sticky top-0 z-10 bg-slate-100 p-4 text-center border-l border-slate-200 w-[10%]">
                                    עלות ביטוח (פרט)
                                </th>
                                <th className="sticky top-0 z-10 bg-slate-100 p-4 text-center border-l border-slate-200 w-[10%]">
                                    הפקדה (פיננסי)
                                </th>
                                <th className="sticky top-0 z-10 bg-slate-100 p-4 text-center border-l border-slate-200 w-[10%]">
                                    נפרעים (סה״כ)
                                </th>
                                <th className="sticky top-0 z-10 bg-slate-100 p-4 text-center border-l border-slate-200 w-[10%]">
                                    היקף (סה״כ)
                                </th>
                                <th className="sticky top-0 z-10 bg-slate-100 p-4 text-center border-l border-slate-200 w-[11%]">
                                    סכום צבירה (פנסיוני/פיננסי)
                                </th>
                                <th className="sticky top-0 z-10 bg-slate-100 p-4 text-right border-l border-slate-200 w-[7%]">
                                    תאריך הפקה
                                </th>
                                <th className="sticky top-0 z-10 bg-slate-100 p-4 text-center w-[5%]">
                                    פוליסות
                                </th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {paginatedCustomers.length === 0 ? (
                                <tr>
                                    <td
                                        colSpan={10}
                                        className="p-24 text-center text-slate-400 italic font-medium"
                                    >
                                        לא נמצאו לקוחות מתאימים
                                    </td>
                                </tr>
                            ) : (
                                paginatedCustomers.map((customer) => {
                                    // Filter policies by selected companies
                                    const profileCompanies = getSelectedCompanies(
                                        profile.agreements,
                                    );
                                    const customerPolicies =
                                        profileCompanies.length > 0
                                            ? customer.policies.filter((p) =>
                                                  profileCompanies.includes(p.company),
                                              )
                                            : customer.policies;

                                    // Calculate Aggregates
                                    const companies = Array.from(
                                        new Set(customerPolicies.map((p) => p.company)),
                                    );
                                    const types = Array.from(
                                        new Set(
                                            customerPolicies.map((p) =>
                                                getProductGroupLabel(p.type as InsuranceType),
                                            ),
                                        ),
                                    );

                                    let totalComms = customerPolicies.reduce(
                                        (acc, p) => {
                                            const premium = getEffectivePremium(
                                                p,
                                                customer.issueDate,
                                            );
                                            const { scope, ongoing } = calculateCommissions(
                                                p,
                                                premium,
                                                profile,
                                            );
                                            return {
                                                scope: acc.scope + scope,
                                                ongoing:
                                                    acc.ongoing +
                                                    (p.status === 'active' ? ongoing : 0),
                                            };
                                        },
                                        { scope: 0, ongoing: 0 },
                                    );

                                    const { privatePremium, financialPremium } =
                                        calculateCustomerPremiumSplit(
                                            customer,
                                            selectedMonth,
                                            selectedYear,
                                        );

                                    let totalAccumulation =
                                        calculateAccumulationForCustomer(customer);
                                    let activeCount = customerPolicies.filter(
                                        (p) => p.status === 'active',
                                    ).length;
                                    let totalPoliciesCount = customerPolicies.length;

                                    const isExpanded = expandedCustomers[customer.id];

                                    if (
                                        !isExpanded &&
                                        customer.familyMembers &&
                                        customer.familyMembers.length > 0
                                    ) {
                                        customer.familyMembers.forEach((fm) => {
                                            const fmPoliciesRaw = fm.policies || [];
                                            const fmPolicies =
                                                profileCompanies.length > 0
                                                    ? fmPoliciesRaw.filter((p) =>
                                                          profileCompanies.includes(p.company),
                                                      )
                                                    : fmPoliciesRaw;

                                            totalPoliciesCount += fmPolicies.length;
                                            activeCount += fmPolicies.filter(
                                                (p) => p.status === 'active',
                                            ).length;

                                            fmPolicies.forEach((p) => {
                                                // Commissions
                                                const premium = getEffectivePremium(
                                                    p,
                                                    fm.issueDate || customer.issueDate,
                                                    selectedMonth,
                                                    selectedYear,
                                                );
                                                const { scope, ongoing } = calculateCommissions(
                                                    p,
                                                    premium,
                                                    profile,
                                                );
                                                totalComms.scope += scope;
                                                totalComms.ongoing +=
                                                    p.status === 'active' ? ongoing : 0;
                                            });
                                        });
                                    }

                                    return (
                                        <React.Fragment key={customer.id}>
                                            <tr
                                                onClick={() => setViewingCustomer(customer)}
                                                onKeyDown={(e) => {
                                                    if (e.key === 'Enter' || e.key === ' ') {
                                                        e.preventDefault();
                                                        setViewingCustomer(customer);
                                                    }
                                                }}
                                                tabIndex={0}
                                                role="button"
                                                aria-label={`הצג פרטים עבור ${customer.firstName} ${customer.lastName}`}
                                                className="hover:bg-indigo-50/50 transition-colors cursor-pointer group group-hover focus-visible:bg-indigo-50/50 focus-visible:outline-none"
                                            >
                                                <td className="p-4 font-bold text-slate-900 text-right border-l border-slate-100">
                                                    <div className="flex flex-col">
                                                        <span className="flex items-center gap-2 text-sm">
                                                            {customer.familyMembers &&
                                                                customer.familyMembers.length >
                                                                    0 && (
                                                                    <button
                                                                        onClick={(e) =>
                                                                            toggleExpand(
                                                                                e,
                                                                                customer.id,
                                                                            )
                                                                        }
                                                                        aria-expanded={isExpanded}
                                                                        aria-label={isExpanded ? "צמצם פוליסות משפחה" : "הרחב פוליסות משפחה"}
                                                                        className="p-0.5 hover:bg-slate-200 rounded text-slate-400 hover:text-slate-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500/50 transition-colors"
                                                                    >
                                                                        <ChevronDown
                                                                            className={`w-4 h-4 transition-transform duration-200 ${expandedCustomers[customer.id] ? 'rotate-180' : ''}`}
                                                                            aria-hidden="true"
                                                                        />
                                                                    </button>
                                                                )}
                                                            {customer.firstName} {customer.lastName}
                                                            {customer.familyMembers &&
                                                                customer.familyMembers.length >
                                                                    0 && (
                                                                    <span
                                                                        className="bg-indigo-100/50 text-indigo-600 px-1.5 py-0.5 rounded-md flex items-center gap-1 shadow-sm border border-indigo-200"
                                                                        title="ראש משפחה"
                                                                    >
                                                                        <Heart className="w-2.5 h-2.5 fill-current" aria-hidden="true" />
                                                                        <span className="text-[9px] uppercase tracking-widest font-bold">
                                                                            משפחה
                                                                        </span>
                                                                    </span>
                                                                )}
                                                        </span>
                                                        <span
                                                            className={`text-[11px] text-slate-400 font-medium ${customer.familyMembers && customer.familyMembers.length > 0 ? 'mr-6' : ''}`}
                                                        >
                                                            {customer.id}
                                                        </span>
                                                    </div>
                                                </td>
                                                <td className="p-4 text-slate-700 font-medium text-right border-l border-slate-100">
                                                    <div className="flex flex-wrap gap-1">
                                                        {types.join(', ')}
                                                    </div>
                                                </td>
                                                <td className="p-3 text-slate-700 font-medium text-right border-l border-slate-100">
                                                    <div className="flex flex-wrap gap-1">
                                                        {companies.map((c) => (
                                                            <span
                                                                key={c}
                                                                className="text-[10px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-600 font-bold"
                                                            >
                                                                {c}
                                                            </span>
                                                        ))}
                                                    </div>
                                                </td>
                                                <td className="p-4 text-center font-medium tabular-nums text-slate-600 text-sm border-l border-slate-100">
                                                    ₪{Math.round(privatePremium).toLocaleString()}
                                                </td>
                                                <td className="p-4 text-center font-medium tabular-nums text-slate-600 text-sm border-l border-slate-100">
                                                    ₪{Math.round(financialPremium).toLocaleString()}
                                                </td>
                                                <td className="p-4 text-center text-slate-600 font-medium tabular-nums text-sm border-l border-slate-100">
                                                    ₪
                                                    {totalComms.ongoing.toLocaleString(undefined, {
                                                        minimumFractionDigits: 2,
                                                        maximumFractionDigits: 2,
                                                    })}
                                                </td>
                                                <td className="p-4 text-center text-slate-600 font-medium tabular-nums text-sm border-l border-slate-100">
                                                    {customer.creationType === 'existing'
                                                        ? '₪0'
                                                        : `₪${Math.round(totalComms.scope).toLocaleString()}`}
                                                </td>
                                                <td className="p-4 text-center font-medium tabular-nums text-slate-600 text-sm border-l border-slate-100">
                                                    ₪
                                                    {Math.round(totalAccumulation).toLocaleString()}
                                                </td>
                                                <td className="p-4 text-slate-400 text-[11px] text-right font-bold border-l border-slate-100">
                                                    {(customer.issueDate || '').includes('-')
                                                        ? customer.issueDate
                                                              .split('-')
                                                              .reverse()
                                                              .join('/')
                                                        : customer.issueDate}
                                                </td>
                                                <td className="p-4 text-center">
                                                    <div className="inline-flex items-center justify-center w-8 h-8 bg-slate-50 border border-slate-100 rounded-lg">
                                                        <span className="text-[11px] font-bold text-slate-900">
                                                            {totalPoliciesCount}
                                                        </span>
                                                    </div>
                                                </td>
                                            </tr>

                                            {/* Sub-rows for family members */}
                                            {expandedCustomers[customer.id] &&
                                                customer.familyMembers &&
                                                customer.familyMembers.length > 0 &&
                                                customer.familyMembers.map((fm, idx) => {
                                                    const fmPoliciesRaw = fm.policies || [];
                                                    const fmPolicies =
                                                        profileCompanies.length > 0
                                                            ? fmPoliciesRaw.filter((p) =>
                                                                  profileCompanies.includes(
                                                                      p.company,
                                                                  ),
                                                              )
                                                            : fmPoliciesRaw;

                                                    const fmCompanies = Array.from(
                                                        new Set(fmPolicies.map((p) => p.company)),
                                                    );
                                                    const fmTypes = Array.from(
                                                        new Set(
                                                            fmPolicies.map((p) =>
                                                                getProductGroupLabel(
                                                                    p.type as InsuranceType,
                                                                ),
                                                            ),
                                                        ),
                                                    );
                                                    const isLast =
                                                        idx ===
                                                        (customer.familyMembers?.length || 0) - 1;

                                                    const fmTotalComms = fmPolicies.reduce(
                                                        (acc, p) => {
                                                            const premium = getEffectivePremium(
                                                                p,
                                                                fm.issueDate || customer.issueDate,
                                                                selectedMonth,
                                                                selectedYear,
                                                            );
                                                            const { scope, ongoing } =
                                                                calculateCommissions(
                                                                    p,
                                                                    premium,
                                                                    profile,
                                                                );
                                                            return {
                                                                scope: acc.scope + scope,
                                                                ongoing:
                                                                    acc.ongoing +
                                                                    (p.status === 'active'
                                                                        ? ongoing
                                                                        : 0),
                                                            };
                                                        },
                                                        { scope: 0, ongoing: 0 },
                                                    );

                                                    let fmTotalAccumulation = 0;
                                                    fmPolicies.forEach((p) => {
                                                        if (isFinancialType(p.type as any)) {
                                                            const initial =
                                                                Math.max(
                                                                    p.details?.accumulation || 0,
                                                                    p.details?.mobility || 0,
                                                                ) +
                                                                (p.details?.lumpSumDeposit || 0);
                                                            const monthly =
                                                                p.details?.monthlyDeposit || 0;
                                                            if (monthly === 0 || !p.issueDate)
                                                                fmTotalAccumulation += initial;
                                                            else {
                                                                let issue = (
                                                                    p.issueDate || ''
                                                                ).includes('/')
                                                                    ? new Date(
                                                                          parseInt(
                                                                              p.issueDate.split(
                                                                                  '/',
                                                                              )[2],
                                                                          ),
                                                                          parseInt(
                                                                              p.issueDate.split(
                                                                                  '/',
                                                                              )[1],
                                                                          ) - 1,
                                                                          parseInt(
                                                                              p.issueDate.split(
                                                                                  '/',
                                                                              )[0],
                                                                          ),
                                                                      )
                                                                    : new Date(p.issueDate || '');
                                                                const target = new Date(
                                                                    selectedYear === -1
                                                                        ? new Date().getFullYear()
                                                                        : selectedYear,
                                                                    selectedMonth === -1
                                                                        ? new Date().getMonth()
                                                                        : selectedMonth,
                                                                    1,
                                                                );
                                                                let diff =
                                                                    (target.getFullYear() -
                                                                        issue.getFullYear()) *
                                                                        12 +
                                                                    (target.getMonth() -
                                                                        issue.getMonth());
                                                                fmTotalAccumulation +=
                                                                    initial +
                                                                    monthly * Math.max(0, diff);
                                                            }
                                                        }
                                                    });

                                                    let fmPrivatePremium = 0;
                                                    let fmFinancialPremium = 0;
                                                    fmPolicies.forEach((p) => {
                                                        let policyToCalc = { ...p };
                                                        if (
                                                            fm.isPremiumSharedWithPrimary &&
                                                            (!p.premiumSchedule ||
                                                                p.premiumSchedule.length === 0)
                                                        ) {
                                                            const primarySchedule =
                                                                customer.policies.find(
                                                                    (pp) =>
                                                                        isIndividualType(pp.type) &&
                                                                        pp.premiumSchedule &&
                                                                        pp.premiumSchedule.length >
                                                                            0,
                                                                );
                                                            if (primarySchedule) {
                                                                policyToCalc.premiumSchedule =
                                                                    primarySchedule.premiumSchedule;
                                                            }
                                                        }
                                                        const premium = getEffectivePremium(
                                                            policyToCalc,
                                                            fm.issueDate || customer.issueDate,
                                                            selectedMonth,
                                                            selectedYear,
                                                        );
                                                        if (isFinancialType(p.type as any)) {
                                                            fmFinancialPremium += premium;
                                                        } else {
                                                            fmPrivatePremium += premium;
                                                        }
                                                    });

                                                    return (
                                                        <tr
                                                            key={fm.id}
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                if (onViewFamilyMember) {
                                                                    onViewFamilyMember(
                                                                        fm,
                                                                        customer,
                                                                    );
                                                                }
                                                            }}
                                                            onKeyDown={(e) => {
                                                                if (e.key === 'Enter' || e.key === ' ') {
                                                                    e.preventDefault();
                                                                    e.stopPropagation();
                                                                    if (onViewFamilyMember) {
                                                                        onViewFamilyMember(fm, customer);
                                                                    }
                                                                }
                                                            }}
                                                            tabIndex={0}
                                                            role="button"
                                                            aria-label={`הצג פרטים עבור ${fm.firstName} ${fm.lastName}`}
                                                            className="bg-slate-50/30 hover:bg-indigo-50/50 transition-colors cursor-pointer group focus-visible:bg-indigo-50/50 focus-visible:outline-none"
                                                        >
                                                            <td className="p-3 pr-10 text-right relative border-l border-slate-100">
                                                                {/* L-Shape Connector tree logic */}
                                                                <div
                                                                    className={`absolute right-4 w-px bg-slate-200 ${isLast ? 'top-0 h-1/2' : 'top-0 h-full'}`}
                                                                />
                                                                <div className="absolute right-4 top-1/2 w-4 border-t border-slate-200" />

                                                                <div className="flex flex-col ml-4">
                                                                    <span className="text-[11px] font-bold text-slate-700 flex items-center gap-1.5">
                                                                        <div className="w-1 h-1 rounded-full bg-slate-300" />
                                                                        {fm.firstName} {fm.lastName}
                                                                        <span className="text-[8px] bg-white border border-slate-200 text-slate-500 px-1 rounded uppercase font-bold tracking-wider">
                                                                            {fm.relationship ===
                                                                            'spouse'
                                                                                ? 'בן/בת זוג'
                                                                                : fm.relationship ===
                                                                                    'child'
                                                                                  ? 'ילד/ה'
                                                                                  : 'אחר'}
                                                                        </span>
                                                                    </span>
                                                                    <span className="text-[9px] text-slate-400 font-medium mr-3">
                                                                        {fm.id}
                                                                    </span>
                                                                </div>
                                                            </td>
                                                            <td className="p-3 text-slate-500 text-[10px] text-right font-medium border-l border-slate-100">
                                                                <div className="flex flex-wrap gap-1 leading-tight opacity-90">
                                                                    {fmTypes.join(', ')}
                                                                </div>
                                                            </td>
                                                            <td className="p-3 text-right border-l border-slate-100">
                                                                <div className="flex flex-wrap gap-1 opacity-80">
                                                                    {fmCompanies.map((c) => (
                                                                        <span
                                                                            key={c}
                                                                            className="text-[9px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-500 font-bold"
                                                                        >
                                                                            {c}
                                                                        </span>
                                                                    ))}
                                                                </div>
                                                            </td>
                                                            <td className="p-3 text-center font-medium tabular-nums text-slate-600 text-[11px] border-l border-slate-100">
                                                                ₪
                                                                {Math.round(
                                                                    fmPrivatePremium,
                                                                ).toLocaleString()}
                                                            </td>
                                                            <td className="p-3 text-center font-medium tabular-nums text-slate-600 text-[11px] border-l border-slate-100">
                                                                ₪
                                                                {Math.round(
                                                                    fmFinancialPremium,
                                                                ).toLocaleString()}
                                                            </td>
                                                            <td className="p-3 text-center text-slate-600/70 font-medium tabular-nums text-[11px] border-l border-slate-100">
                                                                ₪
                                                                {fmTotalComms.ongoing.toLocaleString(
                                                                    undefined,
                                                                    {
                                                                        minimumFractionDigits: 2,
                                                                        maximumFractionDigits: 2,
                                                                    },
                                                                )}
                                                            </td>
                                                            <td className="p-3 text-center text-slate-600/70 font-medium tabular-nums text-[11px] border-l border-slate-100">
                                                                {customer.creationType ===
                                                                'existing'
                                                                    ? '₪0'
                                                                    : `₪${Math.round(fmTotalComms.scope).toLocaleString()}`}
                                                            </td>
                                                            <td className="p-3 text-center font-medium tabular-nums text-slate-600/70 text-[11px] border-l border-slate-100">
                                                                ₪
                                                                {Math.round(
                                                                    fmTotalAccumulation,
                                                                ).toLocaleString()}
                                                            </td>
                                                            <td className="p-3 text-slate-400 text-[10px] text-right font-medium border-l border-slate-100">
                                                                {(
                                                                    fm.issueDate ||
                                                                    customer.issueDate ||
                                                                    ''
                                                                ).includes('-')
                                                                    ? (
                                                                          fm.issueDate ||
                                                                          customer.issueDate
                                                                      )
                                                                          .split('-')
                                                                          .reverse()
                                                                          .join('/')
                                                                    : fm.issueDate ||
                                                                      customer.issueDate}
                                                            </td>
                                                            <td className="p-3 text-center">
                                                                <div className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-white border border-slate-100 rounded-md shadow-sm opacity-80">
                                                                    <span className="text-[10px] font-medium text-slate-600">
                                                                        {fmPolicies.length}
                                                                    </span>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    );
                                                })}
                                        </React.Fragment>
                                    );
                                })
                            )}
                        </tbody>
                    </table>
                </div>

                <TablePagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    totalItems={filteredCustomers.length}
                    itemsPerPage={ITEMS_PER_PAGE}
                    onPageChange={setCurrentPage}
                />
            </div>
        );
    },
);
