import { InsuranceType, PremiumScheduleItem } from '@repo/types';
import {
    AlertCircle,
    Calendar,
    CheckCircle2,
    ChevronDown,
    Table as TableIcon,
    UploadCloud,
} from 'lucide-react';
import React, { useCallback, useRef, useState } from 'react';
import { useExcelParser } from '../hooks/useExcelParser';
import { PremiumScheduleBreakdown } from './PremiumScheduleBreakdown';

const TOTAL_PATTERNS = [
    'עלות ביטוח',
    'עלות חודשית',
    'עלות כוללת',
    'סה"כ',
    'סך הכל',
    'סה״כ',
    'total',
    'Total',
    'סכום לתשלום',
    'סיכום',
    'פרמיה',
    'לתשלום',
];

const EXCLUDE_PATTERNS = ['גיל', 'age', 'Age', 'סכום ביטוח', 'סכום כיסוי', 'סכום'];

interface ExcelPremiumUploaderProps {
    onScheduleParsed: (
        schedule: PremiumScheduleItem[],
        columns: string[],
        firstRawRow?: any,
    ) => void;
    onReset: () => void;
    hasData: boolean;
    company?: string;
    insuranceType?: InsuranceType;
    customerIssueDate?: string;
    targetMonth?: number;
    targetYear?: number;
    premiumSchedule?: PremiumScheduleItem[];
    subPolicies?: Record<string, number>;
    onDeleteSubPolicy?: (key: string) => void;
}

const FullTable: React.FC<{
    data: any[];
    mapping: any;
    currentAge: number;
    onHideFull: () => void;
}> = React.memo(({ data, mapping, currentAge, onHideFull }) => {
    return (
        <div className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-sm animate-fadeIn">
            <div className="p-3 border-b border-slate-100 flex justify-between items-center bg-slate-50 text-right">
                <span className="text-[10px] font-bold text-slate-500 uppercase">
                    מערך נתונים מלא ({data.length} שורות)
                </span>
                <button
                    onClick={onHideFull}
                    className="text-[10px] font-bold text-sky-600 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500/50 rounded p-1"
                >
                    חזרה לתצוגה ממוקדת
                </button>
            </div>
            <div className="overflow-x-auto">
                <table
                    className="w-full text-right text-[10px] min-w-[600px] border-collapse"
                    dir="rtl"
                >
                    <thead className="bg-slate-50 text-slate-400 font-bold border-b border-slate-100">
                        <tr>
                            {Object.keys(data[0]).map((col) => (
                                <th
                                    key={col}
                                    className={`p-2 px-4 whitespace-nowrap ${col === mapping.age ? 'text-slate-900 border-x border-slate-100 bg-slate-100/50' : ''}`}
                                >
                                    {col}
                                </th>
                            ))}
                            <th className="p-2 px-4 bg-sky-900 text-white sticky left-0 shadow-[-4px_0_10px_rgba(0,0,0,0.1)]">
                                סה״כ לתשלום (חודשי)
                            </th>
                        </tr>
                    </thead>
                    <tbody className="text-slate-700">
                        {data.slice(0, 15).map((row, i) => {
                            const ageCol = mapping.age;

                            let rowSum = 0;
                            // Priority 1: Use explicit cost column
                            const explicitTotal = Object.entries(row).find(([key, val]) => {
                                const k = key.trim();
                                return (
                                    (k === 'עלות ביטוח' ||
                                        k === 'עלות חודשית' ||
                                        k === 'עלות כוללת' ||
                                        k === 'סה"כ' ||
                                        k === 'סה״כ' ||
                                        k === 'סה"כ לתשלום' ||
                                        k.toLowerCase() === 'total') &&
                                    (parseFloat(String(val).replace(/[^\d.]/g, '')) || 0) > 0
                                );
                            });

                            if (explicitTotal) {
                                rowSum =
                                    parseFloat(String(explicitTotal[1]).replace(/[^\d.]/g, '')) ||
                                    0;
                            } else {
                                // Priority 2: Fallback sum
                                Object.entries(row).forEach(([key, val]) => {
                                    if (key === ageCol) return;
                                    if (TOTAL_PATTERNS.some((p) => key.includes(p))) return;
                                    if (EXCLUDE_PATTERNS.some((p) => key.includes(p))) return;
                                    const num = parseFloat(String(val).replace(/[^\d.]/g, '')) || 0;
                                    if (num > 0 && num < 10000) rowSum += num;
                                });
                            }

                            const monthlyResult = mapping.isAnnual ? rowSum / 12 : rowSum;
                            const isCurrentAge = parseInt(String(row[ageCol])) === currentAge;

                            return (
                                <tr
                                    key={i}
                                    className={`border-t border-slate-50 hover:bg-slate-50/50 transition-colors ${isCurrentAge ? 'bg-sky-50 ring-2 ring-sky-200 ring-inset relative z-10' : ''}`}
                                >
                                    {Object.keys(data[0]).map((col) => {
                                        const isAgeCol = col === mapping.age;
                                        return (
                                            <td
                                                key={col}
                                                className={`p-2 px-4 whitespace-nowrap font-medium ${isAgeCol ? 'font-black bg-slate-50/50 border-x border-slate-100 text-slate-900' : 'text-slate-500'}`}
                                            >
                                                {row[col] || '-'}
                                                {isAgeCol && isCurrentAge && (
                                                    <span className="sr-only"> (הגיל הנוכחי של הלקוח)</span>
                                                )}
                                            </td>
                                        );
                                    })}
                                    <td className="p-2 px-4 font-black text-sky-600 bg-sky-50 sticky left-0 shadow-[-4px_0_10px_rgba(0,0,0,0.1)]">
                                        ₪
                                        {monthlyResult.toLocaleString(undefined, {
                                            maximumFractionDigits: 1,
                                        })}
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
            {data.length > 15 && (
                <div className="p-2 text-center text-[9px] text-slate-400 font-bold bg-slate-50/80 border-t border-slate-100">
                    מציג 15 שורות ראשונות מתוך {data.length} שורות בקובץ
                </div>
            )}
        </div>
    );
});

export const ExcelPremiumUploader: React.FC<ExcelPremiumUploaderProps> = React.memo(
    ({
        onScheduleParsed,
        onReset,
        hasData,
        company,
        insuranceType,
        customerIssueDate,
        targetMonth,
        targetYear,
        premiumSchedule,
        subPolicies,
        onDeleteSubPolicy,
    }) => {
        const {
            data,
            mapping,
            setMapping,
            matches,
            validationError,
            currentAge,
            handleFile,
            resetParser,
        } = useExcelParser(company, insuranceType, customerIssueDate, targetMonth, targetYear);
        const [isDragging, setIsDragging] = useState(false);
        const [showFullTable, setShowFullTable] = useState(false);
        const fileInputRef = useRef<HTMLInputElement>(null);

        const onConfirm = useCallback(() => {
            if (!data) return;

            const schedule = data
                .map((row) => {
                    const ageCol = mapping.age;
                    let rowSum = 0;

                    // Priority 1: Use an explicit TOTAL or COST column
                    const explicitTotalEntry = Object.entries(row).find(([key, val]) => {
                        const k = key.trim();
                        return (
                            (k === 'עלות ביטוח' ||
                                k === 'עלות חודשית' ||
                                k === 'עלות כוללת' ||
                                k === 'סה"כ' ||
                                k === 'סה״כ' ||
                                k === 'סה"כ לתשלום' ||
                                k.toLowerCase() === 'total') &&
                            (parseFloat(String(val).replace(/[^\d.]/g, '')) || 0) > 0
                        );
                    });

                    if (explicitTotalEntry) {
                        rowSum =
                            parseFloat(String(explicitTotalEntry[1]).replace(/[^\d.]/g, '')) || 0;
                    } else {
                        // Priority 2: Match any total-like pattern
                        const totalLikeCol = Object.entries(row).find(
                            ([key, val]) =>
                                TOTAL_PATTERNS.some((p) => key.includes(p)) &&
                                (parseFloat(String(val).replace(/[^\d.]/g, '')) || 0) > 0,
                        );
                        if (totalLikeCol) {
                            rowSum =
                                parseFloat(String(totalLikeCol[1]).replace(/[^\d.]/g, '')) || 0;
                        } else {
                            // Priority 3: Fallback sum (excluding age and other totals/coverage amounts)
                            Object.entries(row).forEach(([key, val]) => {
                                if (key === ageCol) return;
                                if (TOTAL_PATTERNS.some((p) => key.includes(p))) return;
                                if (EXCLUDE_PATTERNS.some((p) => key.includes(p))) return;

                                const num = parseFloat(String(val).replace(/[^\d.]/g, '')) || 0;
                                if (num > 0 && num < 10000) rowSum += num; // Safety: avoid summing huge coverage amounts
                            });
                        }
                    }

                    const finalPremium = mapping.isAnnual ? rowSum / 12 : rowSum;
                    const parsedAge = parseInt(String(row[ageCol]));
                    return {
                        age: parsedAge,
                        premium: finalPremium,
                    };
                })
                .filter((i) => (mapping.age ? !isNaN(i.age) : true) && i.premium > 0);

            const columns = Object.keys(data[0]);
            onScheduleParsed(schedule, columns, data[0]);
            resetParser();
        }, [data, mapping, onScheduleParsed, resetParser]);

        return (
            <div className="space-y-3">
                {!data && !hasData && (
                    <div
                        onDragOver={(e) => {
                            e.preventDefault();
                            setIsDragging(true);
                        }}
                        onDragLeave={() => setIsDragging(false)}
                        onDrop={(e) => {
                            e.preventDefault();
                            setIsDragging(false);
                            const f = e.dataTransfer.files?.[0];
                            if (f) handleFile(f);
                        }}
                        onClick={() => fileInputRef.current?.click()}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                                e.preventDefault();
                                fileInputRef.current?.click();
                            }
                        }}
                        tabIndex={0}
                        role="button"
                        aria-label="טעינת טבלת התפתחות פרמיה מקובץ אקסל, לחץ לבחירת קובץ או גרור קובץ לכאן"
                        className={`
                            border-2 border-dashed rounded-xl p-6 transition-all cursor-pointer text-center outline-none focus-visible:ring-2 focus-visible:ring-sky-500/50 focus-visible:border-sky-500
                            ${isDragging ? 'border-sky-500 bg-sky-50' : 'border-slate-200 hover:border-sky-400 hover:bg-slate-50'}
                        `}
                    >
                        <UploadCloud
                            className={`w-10 h-10 mx-auto mb-3 ${isDragging ? 'text-sky-500' : 'text-slate-300'}`}
                            aria-hidden="true"
                        />
                        <div className="text-[13px] font-bold text-slate-700 mb-1">
                            גרור והשלך טבלת התפתחות פרמיה
                        </div>
                        <p className="text-[10px] text-slate-400 font-medium">
                            תומך בקבצי XLSX או XLS בלבד
                        </p>
                        <input
                            type="file"
                            ref={fileInputRef}
                            onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
                            accept=".xlsx, .xls"
                            className="hidden"
                        />
                    </div>
                )}

                {data && (
                    <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-4 animate-fadeIn">
                        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                            <h5 className="text-[11px] font-bold text-slate-900 flex items-center gap-2">
                                <TableIcon className="w-4 h-4 text-emerald-500" aria-hidden="true" /> וידוא ופענוח
                                נתונים
                            </h5>
                            <button
                                onClick={resetParser}
                                className="text-[10px] font-bold text-rose-500 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500/50 rounded px-1"
                            >
                                ביטול
                            </button>
                        </div>

                        {validationError && (
                            <div 
                                role="alert"
                                className="bg-amber-50 border border-amber-200 p-3 rounded-xl flex items-start gap-3 animate-shake"
                            >
                                <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" aria-hidden="true" />
                                <p className="text-[10px] font-bold text-amber-800 leading-relaxed">
                                    {validationError}
                                </p>
                            </div>
                        )}

                        {!showFullTable ? (
                            <div className="bg-sky-50/50 border border-sky-100 rounded-2xl p-5 animate-slideDown shadow-sm">
                                <div className="flex justify-between items-start mb-4 text-right border-b border-sky-100 pb-3">
                                    <div className="space-y-1">
                                        <div className="text-[10px] font-black text-sky-600 uppercase tracking-widest text-right">
                                            תצוגה ממוקדת: גיל {currentAge}
                                        </div>
                                        <h4 className="text-sm font-bold text-slate-900 text-right">
                                            פירוט כיסויים ופרמיה
                                        </h4>
                                    </div>
                                    <button
                                        onClick={() => setShowFullTable(true)}
                                        aria-expanded={showFullTable}
                                        className="bg-white px-3 py-1.5 rounded-lg border border-slate-200 text-[10px] font-bold text-slate-500 hover:text-sky-600 hover:border-sky-200 transition-all flex items-center gap-1.5 shadow-sm active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500/50"
                                    >
                                        הצג טבלה מלאה <ChevronDown className="w-3 h-3" aria-hidden="true" />
                                    </button>
                                </div>

                                {(() => {
                                    const ageCol = mapping.age;
                                    const relevantRow = ageCol
                                        ? data.find(
                                              (row) => parseInt(String(row[ageCol])) === currentAge,
                                          ) || data[0]
                                        : data[0];

                                    let rowSum = 0;
                                    const columnsToDisplay: [string, any][] = [];

                                    // 1. Collect all valid numeric breakdown columns
                                    const numericEntries = Object.entries(relevantRow).filter(
                                        ([key, val]) => {
                                            if (key === ageCol) return false;
                                            if (EXCLUDE_PATTERNS.some((p) => key.includes(p)))
                                                return false;
                                            const num =
                                                parseFloat(String(val).replace(/[^\d.]/g, '')) || 0;
                                            return num > 0 && num < 10000;
                                        },
                                    );

                                    // 2. Identify if there's an explicit total
                                    const explicitTotalEntry = numericEntries.find(([key]) => {
                                        const k = key.trim();
                                        return (
                                            k === 'עלות ביטוח' ||
                                            k === 'עלות חודשית' ||
                                            k === 'עלות כוללת' ||
                                            k === 'סה"כ' ||
                                            k === 'סה״כ' ||
                                            k === 'סה"כ לתשלום' ||
                                            k.toLowerCase() === 'total'
                                        );
                                    });

                                    if (explicitTotalEntry) {
                                        // Use the explicit total for calculations
                                        rowSum =
                                            parseFloat(
                                                String(explicitTotalEntry[1]).replace(
                                                    /[^\d.]/g,
                                                    '',
                                                ),
                                            ) || 0;

                                        // Add total to display first (highlighted)
                                        columnsToDisplay.push(explicitTotalEntry);
                                        // Add all other items as breakdown
                                        numericEntries.forEach((entry) => {
                                            if (
                                                entry[0] !== explicitTotalEntry[0] &&
                                                !TOTAL_PATTERNS.some((p) => entry[0].includes(p))
                                            ) {
                                                columnsToDisplay.push(entry);
                                            }
                                        });
                                    } else {
                                        // 2.5 Identify fallback total-like column
                                        const totalLikeEntry = numericEntries.find(([key]) => {
                                            return TOTAL_PATTERNS.some((p) => key.includes(p));
                                        });

                                        if (totalLikeEntry) {
                                            rowSum =
                                                parseFloat(
                                                    String(totalLikeEntry[1]).replace(
                                                        /[^\d.]/g,
                                                        '',
                                                    ),
                                                ) || 0;
                                            columnsToDisplay.push(totalLikeEntry);
                                            numericEntries.forEach((entry) => {
                                                if (
                                                    entry[0] !== totalLikeEntry[0] &&
                                                    !TOTAL_PATTERNS.some((p) =>
                                                        entry[0].includes(p),
                                                    )
                                                ) {
                                                    columnsToDisplay.push(entry);
                                                }
                                            });
                                        } else {
                                            // 3. Fallback: Sum up every individual component
                                            numericEntries.forEach((entry) => {
                                                const num =
                                                    parseFloat(
                                                        String(entry[1]).replace(/[^\d.]/g, ''),
                                                    ) || 0;
                                                rowSum += num;
                                                columnsToDisplay.push(entry);
                                            });
                                        }
                                    }

                                    const monthlyTotal = mapping.isAnnual ? rowSum / 12 : rowSum;

                                    return (
                                        <div className="space-y-4">
                                            <div className="bg-white rounded-xl border border-slate-100 divide-y divide-slate-50 shadow-sm overflow-hidden">
                                                {columnsToDisplay.map(([key, val]) => (
                                                    <div
                                                        key={key}
                                                        className="flex justify-between items-center p-3 hover:bg-slate-50/50 transition-colors"
                                                    >
                                                        <div className="flex flex-col gap-1">
                                                            <span className="text-xs font-bold text-slate-600">
                                                                {key}
                                                            </span>
                                                            {matches[key] && (
                                                                <div className="flex items-center gap-1.5">
                                                                    <CheckCircle2 className="w-3 h-3 text-emerald-500" aria-hidden="true" />
                                                                    <span className="text-[9px] font-black bg-emerald-50 text-emerald-600 px-1.5 py-0.5 rounded border border-emerald-100 uppercase tracking-tighter">
                                                                        זיהוי: {matches[key]}
                                                                    </span>
                                                                </div>
                                                            )}
                                                        </div>
                                                        <span className="text-xs font-black text-slate-900 tabular-nums">
                                                            ₪
                                                            {parseFloat(
                                                                String(val).replace(
                                                                    /[^\d.]/g,
                                                                    '',
                                                                ) || '0',
                                                            ).toLocaleString(undefined, {
                                                                maximumFractionDigits: 1,
                                                            })}
                                                        </span>
                                                    </div>
                                                ))}
                                            </div>

                                            <div className="bg-sky-600 rounded-xl p-4 text-white flex justify-between items-center shadow-lg shadow-sky-600/20">
                                                <div className="flex items-center gap-3">
                                                    <div className="bg-white/20 p-2 rounded-lg" aria-hidden="true">
                                                        <Calendar className="w-4 h-4 text-white" />
                                                    </div>
                                                    <div>
                                                        <div className="text-[10px] font-bold text-white/70 uppercase">
                                                            סה״כ חודשי (משוקלל)
                                                        </div>
                                                        <div className="text-[9px] text-white/50">
                                                            עדכון אוטומטי לגיל {currentAge + 1} בשנה
                                                            הבאה
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="text-xl font-black text-white tabular-nums leading-none">
                                                    ₪
                                                    {monthlyTotal.toLocaleString(undefined, {
                                                        maximumFractionDigits: 1,
                                                    })}
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })()}
                            </div>
                        ) : (
                            <FullTable
                                data={data}
                                mapping={mapping}
                                currentAge={currentAge}
                                onHideFull={() => setShowFullTable(false)}
                            />
                        )}

                        <button
                                                            className="w-full bg-slate-900 text-white py-3.5 rounded-xl font-bold text-sm shadow-xl shadow-slate-900/20 active:scale-95 transition-all flex items-center justify-center gap-3 hover:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-900/50"
                                                            onClick={onConfirm}
                                                        >
                                                            <CheckCircle2 className="w-5 h-5 text-emerald-400" aria-hidden="true" />
                                                            אישור וטעינת כל המידע לרקע
                        </button>
                    </div>
                )}

                {hasData && !data && (
                    <PremiumScheduleBreakdown
                        premiumSchedule={premiumSchedule}
                        subPolicies={subPolicies}
                        currentAge={currentAge}
                        onReset={onReset}
                        onDeleteSubPolicy={onDeleteSubPolicy}
                        insuranceType={insuranceType}
                    />
                )}
            </div>
        );
    },
);
