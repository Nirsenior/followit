import { InsuranceType, UserProfile } from '@repo/types';
import React from 'react';
import { AddPolicyButton } from './components/AddPolicyButton';
import { CompanySelector } from './components/CompanySelector';
import { InsuranceSidebar } from './components/InsuranceSidebar';
import { InsuranceTabBar } from './components/InsuranceTabBar';
import { PolicyContentArea } from './components/PolicyContentArea';
import { usePolicyConfigurator } from './hooks/usePolicyConfigurator';

export interface PolicyConfiguratorProps {
    activeTab: InsuranceType;
    setActiveTab: (t: InsuranceType) => void;
    profile: UserProfile;
    currentInputs: any;
    setCurrentInputs: (i: any) => void;
    onAddPolicy: () => void;
    buttonLabel: string;
    layout?: 'default' | 't-shape';
    customerIssueDate?: string;
    targetMonth?: number;
    targetYear?: number;
    allowedTabs?: InsuranceType[];
    creationType?: 'existing' | 'new_production';
}

const EMPTY_INPUTS = {
    company: '',
    monthlyCost: 0,
    isAgentAppointmentOnly: false,
    premiumSchedule: [],
    details: { subPolicies: {} },
    status: 'active',
};

export const PolicyConfigurator: React.FC<PolicyConfiguratorProps> = React.memo(
    ({
        activeTab,
        setActiveTab,
        profile,
        currentInputs,
        setCurrentInputs,
        onAddPolicy,
        buttonLabel,
        layout = 'default',
        customerIssueDate,
        targetMonth,
        targetYear,
        allowedTabs,
        creationType,
    }) => {
        const {
            elementaryCategory,
            setElementaryCategory,
            setIsCommsApproved,
            handleScheduleParsed,
            handleResetSchedule,
            handleUpdateSubPolicy,
            handleUpdateManualComm,
            handleUpdateDetail,
            handleUpdateTracks,
            handleDeleteSubPolicy,
            handleAdd,
            activeInsuranceTypes,
            filteredCompaniesUnderTab,
            shouldShowComms,
            fetchedTracks,
            isLoadingTracks,
        } = usePolicyConfigurator({
            activeTab,
            profile,
            currentInputs,
            setCurrentInputs,
            onAddPolicy,
            allowedTabs,
        });

        const handleSelectTab = (type: InsuranceType) => {
            setActiveTab(type);
            setIsCommsApproved(false);
            setCurrentInputs(EMPTY_INPUTS);
        };

        const contentAreaProps = {
            activeTab,
            currentInputs,
            setCurrentInputs,
            profile,
            shouldShowComms,
            elementaryCategory,
            setElementaryCategory,
            onUpdateSubPolicy: handleUpdateSubPolicy,
            onUpdateManualComm: handleUpdateManualComm,
            onUpdateDetail: handleUpdateDetail,
            onUpdateTracks: handleUpdateTracks,
            onScheduleParsed: handleScheduleParsed,
            onResetSchedule: handleResetSchedule,
            onDeleteSubPolicy: handleDeleteSubPolicy,
            customerIssueDate,
            targetMonth,
            targetYear,
            fetchedTracks,
            isLoadingTracks,
            creationType,
        };

        if (layout === 't-shape') {
            return (
                <div className="flex gap-6 h-full">
                    <InsuranceSidebar
                        activeTab={activeTab}
                        activeInsuranceTypes={activeInsuranceTypes}
                        onSelectTab={handleSelectTab}
                    />

                    <div className="flex-1 space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                            <div className="space-y-1.5">
                                <label htmlFor="config-company-select" className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block mr-1">
                                    חברת ביטוח
                                </label>
                                <CompanySelector
                                    activeTab={activeTab}
                                    value={currentInputs.company}
                                    companies={filteredCompaniesUnderTab}
                                    currentInputs={currentInputs}
                                    setCurrentInputs={setCurrentInputs}
                                    size="sm"
                                />
                            </div>
                            {activeTab !== 'elementary' && activeTab !== 'abroad' && (
                                <div className="h-full flex items-center pt-3.5 col-span-2">
                                    <label className="flex items-center gap-3 cursor-pointer group bg-white p-2.5 rounded-xl border border-slate-100 shadow-sm hover:border-sky-500 focus-within:ring-2 focus-within:ring-sky-500/50 transition-colors w-full md:max-w-max">
                                        <input
                                            type="checkbox"
                                            checked={currentInputs.isAgentAppointmentOnly}
                                            onChange={(e) =>
                                                setCurrentInputs({
                                                    ...currentInputs,
                                                    isAgentAppointmentOnly: e.target.checked,
                                                })
                                            }
                                            className="w-5 h-5 accent-sky-500 rounded-lg border-slate-200 focus-visible:outline-none"
                                        />
                                        <div className="text-right">
                                            <span className="text-xs font-bold text-slate-700 block group-hover:text-slate-900">
                                                מינוי סוכן בלבד
                                            </span>
                                            <span className="text-[9px] text-slate-400 font-medium">
                                                פוליסה קיימת (נפרעים בלבד)
                                            </span>
                                        </div>
                                    </label>
                                </div>
                            )}
                        </div>

                        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xl shadow-slate-200/50">
                            <PolicyContentArea {...contentAreaProps} />
                            <div className="pt-4 mt-4 border-t border-slate-100 flex justify-end">
                                <AddPolicyButton
                                    label={buttonLabel}
                                    disabled={!currentInputs.company}
                                    onClick={handleAdd}
                                    size="sm"
                                />
                            </div>
                        </div>
                    </div>
                </div>
            );
        }

        // default layout
        return (
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
                <InsuranceTabBar
                    activeTab={activeTab}
                    activeInsuranceTypes={activeInsuranceTypes}
                    onSelectTab={handleSelectTab}
                />

                <div className="p-8 space-y-8">
                    <div className="grid grid-cols-2 gap-6">
                        <div>
                            <label htmlFor="config-company-select" className="text-xs font-bold text-slate-500 mb-2 mr-1 uppercase">
                                חברת ביטוח
                            </label>
                            <CompanySelector
                                activeTab={activeTab}
                                value={currentInputs.company}
                                companies={filteredCompaniesUnderTab}
                                currentInputs={currentInputs}
                                setCurrentInputs={setCurrentInputs}
                                size="md"
                            />
                        </div>

                        <div className="space-y-1.5">
                            <label htmlFor="config-issue-date" className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block mr-1">
                                תאריך הפקה
                            </label>
                            <input
                                id="config-issue-date"
                                type="date"
                                value={currentInputs.issueDate || ''}
                                onChange={(e) =>
                                    setCurrentInputs({
                                        ...currentInputs,
                                        issueDate: e.target.value,
                                    })
                                }
                                className="w-full p-2.5 border rounded-xl border-slate-200 shadow-sm outline-none bg-white text-slate-900 font-bold text-xs transition-colors focus-visible:ring-2 focus-visible:ring-sky-500/50 focus-visible:border-sky-500 focus:border-sky-500"
                            />
                        </div>

                        {activeTab !== 'elementary' && activeTab !== 'abroad' && (
                            <div className="flex items-end pb-4">
                                <label className="flex items-center gap-4 cursor-pointer group focus-within:ring-2 focus-within:ring-sky-500/50 rounded p-1">
                                    <input
                                        type="checkbox"
                                        checked={currentInputs.isAgentAppointmentOnly}
                                        onChange={(e) =>
                                            setCurrentInputs({
                                                ...currentInputs,
                                                isAgentAppointmentOnly: e.target.checked,
                                            })
                                        }
                                        className="w-6 h-6 accent-sky-500 rounded-lg border-slate-200 focus-visible:outline-none"
                                    />
                                    <span className="text-base font-bold text-slate-600 group-hover:text-slate-900 transition-colors">
                                        מינוי סוכן בלבד (נפרעים בלבד)
                                    </span>
                                </label>
                            </div>
                        )}
                    </div>

                    <PolicyContentArea {...contentAreaProps} />

                    <div className="pt-8 border-t border-slate-100 flex justify-end">
                        <AddPolicyButton
                            label={buttonLabel}
                            disabled={!currentInputs.company}
                            onClick={handleAdd}
                            size="lg"
                        />
                    </div>
                </div>
            </div>
        );
    },
);

PolicyConfigurator.displayName = 'PolicyConfigurator';
