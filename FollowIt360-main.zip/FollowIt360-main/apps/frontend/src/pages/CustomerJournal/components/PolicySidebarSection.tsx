import {
    FamilyMember,
    INSURANCE_TYPE_LABELS,
    isFinancialType,
    Policy,
    INSURANCE_TYPE,
} from '@repo/types';
import { CheckCircle2, Pencil, ShieldCheck, Trash2 } from 'lucide-react';
import React from 'react';
import { PolicyCoversList } from './PolicyCoversList';

export interface PolicySidebarSectionProps {
    policies: Policy[];
    familyMembers?: FamilyMember[];
    onRemove: (idx: number) => void;
    onRemoveFamilyMember?: (idx: number) => void;
    onEditFamilyMember?: (idx: number) => void;
    onEdit: (idx: number) => void;
    editingIdx: number | null;
    totalCost: number;
    onSubmit: () => void;
    canSubmit: boolean;
    isSubmitting?: boolean;
    isEditMode?: boolean;
    saveStatus?: 'idle' | 'saving' | 'saved' | 'editing';
}

export const PolicySidebarSection: React.FC<PolicySidebarSectionProps & { isSubmitting?: boolean; isEditMode?: boolean; saveStatus?: 'idle' | 'saving' | 'saved' }> =
    React.memo(({ policies, familyMembers, onRemove, onRemoveFamilyMember, onEditFamilyMember, onEdit, editingIdx, totalCost, onSubmit, canSubmit, isSubmitting, isEditMode, saveStatus }) => {
        return (
            <aside aria-label="פוליסות ובני משפחה שנוספו" className="w-72 bg-white border-r border-slate-200 flex flex-col shrink-0">
                <div className="p-4 border-b border-slate-100">
                    <h3 className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                        פוליסות שנוספו ({policies.length})
                    </h3>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-2 custom-scrollbar">
                    {policies.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-center opacity-40 space-y-3">
                            <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center" aria-hidden="true">
                                <ShieldCheck className="w-6 h-6 text-slate-400" />
                            </div>
                            <p className="text-[10px] font-bold leading-relaxed text-slate-500">
                                טרם נוספו פוליסות
                                <br />
                                אנא בחר חברה וכיסוי משמאל
                            </p>
                        </div>
                    ) : (
                        policies.map((p, idx) => (
                            <div
                                key={p.id}
                                className={`p-3 rounded-2xl border flex justify-between items-center group animate-fadeIn transition-all ${
                                    editingIdx === idx
                                        ? 'bg-blue-50/50 border-blue-200 shadow-sm ring-2 ring-blue-500/5'
                                        : 'bg-slate-50/50 border-slate-100'
                                }`}
                            >
                                <div className="text-right">
                                    <div className="font-bold text-[11px] text-slate-900 leading-tight">
                                        {p.company}
                                    </div>
                                    <div className="text-[10px] text-blue-600 font-bold">
                                        {
                                            INSURANCE_TYPE_LABELS[
                                                p.type as keyof typeof INSURANCE_TYPE_LABELS
                                            ]
                                        }
                                    </div>
                                    <div className="text-[9px] text-slate-400 mt-0.5 font-medium">
                                        {(() => {
                                            if (isFinancialType(p.type)) {
                                                return `צבירה: ₪${(p.details?.accumulation || 0).toLocaleString()}`;
                                            }
                                            if (p.type === 'elementary') {
                                                const scope = p.details?.manualElementaryScope || 0;
                                                return `עמלה: ₪${scope.toLocaleString()}`;
                                            }
                                            if (p.type === 'abroad') {
                                                return `עמלה: ₪${p.monthlyCost.toLocaleString()}`;
                                            }
                                            return `₪${p.monthlyCost.toLocaleString()}`;
                                        })()}
                                    </div>
                                    {p.type === INSURANCE_TYPE.HEALTH && (
                                        <PolicyCoversList subPolicies={p.details?.subPolicies} variant="blue" />
                                    )}
                                </div>
                                <div className="flex flex-col gap-1">
                                    <button
                                        onClick={() => onEdit(idx)}
                                        aria-label={`ערוך פוליסת ${p.company} מסוג ${INSURANCE_TYPE_LABELS[p.type as keyof typeof INSURANCE_TYPE_LABELS] || p.type}`}
                                        className={`w-8 h-8 flex items-center justify-center rounded-xl transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 ${
                                            editingIdx === idx
                                                ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/20'
                                                : 'text-slate-300 hover:text-blue-500 hover:bg-blue-50'
                                        }`}
                                    >
                                        <Pencil className="w-3.5 h-3.5" aria-hidden="true" />
                                    </button>
                                    <button
                                        onClick={() => onRemove(idx)}
                                        aria-label={`מחק פוליסת ${p.company} מסוג ${INSURANCE_TYPE_LABELS[p.type as keyof typeof INSURANCE_TYPE_LABELS] || p.type}`}
                                        className="w-7 h-7 flex items-center justify-center text-slate-300 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500/50"
                                    >
                                        <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                                    </button>
                                </div>
                            </div>
                        ))
                    )}

                    {familyMembers && familyMembers.length > 0 && (
                        <div className="mt-6 pt-4 border-t border-slate-100">
                            <h3 className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-3">
                                בני משפחה ({familyMembers.length})
                            </h3>
                            <div className="space-y-2">
                                {familyMembers.map((fm, idx) => (
                                    <div key={fm.id} className="border border-slate-100 rounded-2xl bg-blue-50/30 overflow-hidden group">
                                        <div className="p-2 flex justify-between items-center">
                                            <div>
                                                <div className="text-[10px] font-black text-slate-900">{fm.firstName} {fm.lastName}</div>
                                                <div className="text-[8px] font-bold text-slate-400 flex items-center gap-1">
                                                    <ShieldCheck className="w-2.5 h-2.5" aria-hidden="true" />
                                                    {fm.policies.length} פוליסות
                                                </div>
                                            </div>
                                            <div className="flex gap-1 opacity-0 group-hover:opacity-100 focus-within:opacity-100 focus:opacity-100 transition-opacity">
                                                <button 
                                                    onClick={() => onEditFamilyMember?.(idx)}
                                                    aria-label={`ערוך פרטי בן משפחה ${fm.firstName} ${fm.lastName}`}
                                                    className="p-1.5 text-slate-300 hover:text-blue-500 hover:bg-blue-50 rounded-lg transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50"
                                                >
                                                    <Pencil className="w-3.5 h-3.5" aria-hidden="true" />
                                                </button>
                                                <button 
                                                    onClick={() => onRemoveFamilyMember?.(idx)}
                                                    aria-label={`מחק בן משפחה ${fm.firstName} ${fm.lastName}`}
                                                    className="p-1.5 text-slate-300 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500/50"
                                                >
                                                    <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                                                </button>
                                            </div>
                                        </div>
                                        {fm.policies.length > 0 && (
                                            <div className="bg-white/60 px-2 py-1.5 border-t border-slate-100/50 flex flex-col gap-1.5">
                                                {fm.policies.map((p, pIdx) => (
                                                    <div key={p.id || pIdx} className="flex flex-col gap-1 border-b border-slate-100/50 pb-1.5 last:border-0 last:pb-0">
                                                        <div className="flex justify-between items-center text-[9px]">
                                                            <div className="font-bold text-slate-700 truncate max-w-[120px]">{p.company} - {INSURANCE_TYPE_LABELS[p.type as keyof typeof INSURANCE_TYPE_LABELS]}</div>
                                                            <div className="text-sky-600 font-black shrink-0">
                                                                {(() => {
                                                                    if (isFinancialType(p.type)) {
                                                                        return `צבירה: ₪${(p.details?.accumulation || 0).toLocaleString()}`;
                                                                    }
                                                                    if (p.type === 'elementary') {
                                                                        const scope = p.details?.manualElementaryScope || 0;
                                                                        return `עמלה: ₪${scope.toLocaleString()}`;
                                                                    }
                                                                    if (p.type === 'abroad') {
                                                                        return `עמלה: ₪${(p.monthlyCost || 0).toLocaleString()}`;
                                                                    }
                                                                    return `₪${(p.monthlyCost || 0).toLocaleString()}`;
                                                                })()}
                                                            </div>
                                                        </div>
                                                        {p.type === INSURANCE_TYPE.HEALTH && (
                                                            <PolicyCoversList subPolicies={p.details?.subPolicies} variant="sky" size="xs" />
                                                        )}
                                                    </div>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
                <div className="p-6 border-t border-slate-100 bg-slate-50/50">
                    <div className="flex justify-between items-center mb-5">
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">סה״כ פרמיה:</span>
                        <span className="text-lg font-black text-slate-900 tabular-nums">
                            ₪{totalCost.toLocaleString()}
                        </span>
                    </div>
                    <button
                        disabled={!canSubmit || isSubmitting}
                        onClick={onSubmit}
                        className="w-full py-4 bg-slate-900 text-white font-bold rounded-2xl shadow-lg shadow-slate-900/20 hover:bg-blue-600 disabled:opacity-30 disabled:bg-slate-300 active:scale-[0.98] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-900/50 text-sm flex items-center justify-center gap-2"
                    >
                        {isSubmitting
                            ? 'שומר...'
                            : (saveStatus as any) === 'editing'
                              ? '⚠️ עדכן פוליסה תחילה'
                              : saveStatus === 'saved'
                                ? 'נשמר ✓'
                                : isEditMode
                                  ? 'שמור שינויים'
                                  : canSubmit && !policies.length && !(familyMembers?.length)
                                    ? 'הוסף פוליסות לפחות'
                                    : 'סיימתי והוספתי'}
                        {!isSubmitting && saveStatus !== 'saved' && <CheckCircle2 className="w-4 h-4" aria-hidden="true" />}
                    </button>
                </div>
            </aside>
        );
    });

PolicySidebarSection.displayName = 'PolicySidebarSection';
