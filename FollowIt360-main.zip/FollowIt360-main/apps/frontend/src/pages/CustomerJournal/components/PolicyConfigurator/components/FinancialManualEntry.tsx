import { InsuranceType, isFinancialType } from '@repo/types';
import { Check, ChevronDown } from 'lucide-react';
import React, { useMemo, useState } from 'react';
import { DebouncedInput } from '../../../../../components/ui/DebouncedInput';

interface FinancialManualEntryProps {
    currentInputs: any;
    activeTab: InsuranceType;
    onUpdateDetail: (field: string, val: any) => void;
    onUpdateTracks: (track: string, weight: number, fundId?: number) => void;
    fetchedTracks?: Array<{ trackName: string; fundId: number }>;
    isLoadingTracks?: boolean;
}

export const FinancialManualEntry: React.FC<FinancialManualEntryProps> = React.memo(
    ({
        currentInputs,
        activeTab,
        onUpdateDetail,
        onUpdateTracks,
        fetchedTracks,
        isLoadingTracks,
    }) => {
        const [isTracksExpanded, setIsTracksExpanded] = useState(true);

        const tracks = fetchedTracks || [];

        // Count occurrences of each track name to identify duplicates
        const nameCounts = useMemo(() => {
            const counts = new Map<string, number>();
            tracks.forEach((t) => {
                counts.set(t.trackName, (counts.get(t.trackName) || 0) + 1);
            });
            return counts;
        }, [tracks]);

        const totalWeight = (currentInputs.details.investmentTracks || []).reduce(
            (s: number, t: any) => s + (t.weight || 0),
            0,
        );

        return (
            <div className="space-y-6 animate-fadeIn">
                <div
                    role="note"
                    className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl flex items-start gap-3 shadow-sm"
                >
                    <span className="text-lg" aria-hidden="true">
                        ℹ️
                    </span>
                    <div>
                        <span className="text-slate-800 font-bold text-xs block mb-0.5">
                            יש להזין את סכום הקרן המעודכן נכון להיום.
                        </span>
                        <span className="text-slate-500 font-medium text-[11px]">
                            המערכת תבצע מכאן והלאה הצמדת תשואה עתידית בהתאם למסלול ההשקעה הנבחר.
                        </span>
                    </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                    {!isFinancialType(activeTab) && (
                        <div>
                            <label
                                htmlFor="financial-establishment-date"
                                className="text-[9px] font-bold text-slate-400 mb-1.5 block uppercase tracking-wider"
                            >
                                תאריך הקמה
                            </label>
                            <input
                                id="financial-establishment-date"
                                type="date"
                                className="w-full p-2.5 border border-slate-200 rounded-lg bg-white shadow-sm focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10 outline-none transition-colors font-bold text-xs"
                                value={currentInputs.details.establishmentDate || ''}
                                onChange={(e) =>
                                    onUpdateDetail('establishmentDate', e.target.value)
                                }
                            />
                        </div>
                    )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label
                            htmlFor="financial-accumulation"
                            className="text-[9px] font-bold text-slate-400 mb-1.5 block uppercase tracking-wider"
                        >
                            סכום צבירה (₪)
                        </label>
                        <DebouncedInput
                            id="financial-accumulation"
                            className="w-full p-2.5 border border-slate-200 rounded-lg bg-white shadow-sm focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10 outline-none transition-colors font-bold text-xs"
                            placeholder="0"
                            value={currentInputs.details.accumulation?.toString() || ''}
                            onCommit={(val) => onUpdateDetail('accumulation', parseFloat(val) || 0)}
                        />
                    </div>
                    {activeTab !== 'long_term_savings' &&
                        (isFinancialType(activeTab) ? (
                            <div className="flex items-end pb-1">
                                <label
                                    className={`
                  flex items-center gap-2.5 cursor-pointer group px-3 py-2 rounded-xl border transition-all duration-200 
                  focus-within:ring-2 focus-within:ring-sky-500/50 focus-within:border-sky-300 focus-within:outline-none
                  ${
                      currentInputs.details.mobilityPerformed
                          ? 'bg-sky-50/50 border-sky-300'
                          : 'bg-white border-slate-200 hover:border-sky-300'
                  }
              `}
                                >
                                    <div
                                        className={`
                   w-5 h-5 rounded border flex items-center justify-center transition-all duration-200
                   ${
                       currentInputs.details.mobilityPerformed
                           ? 'bg-sky-500 border-sky-500 text-white'
                           : 'bg-white border-slate-300 group-hover:border-sky-300'
                   }
                 `}
                                    >
                                        {!!currentInputs.details.mobilityPerformed && (
                                            <Check
                                                className="w-3 h-3 stroke-[3.5px]"
                                                aria-hidden="true"
                                            />
                                        )}
                                    </div>
                                    <input
                                        type="checkbox"
                                        className="sr-only"
                                        checked={!!currentInputs.details.mobilityPerformed}
                                        onChange={(e) =>
                                            onUpdateDetail('mobilityPerformed', e.target.checked)
                                        }
                                    />
                                    <span
                                        className={`text-[11px] font-bold transition-colors ${currentInputs.details.mobilityPerformed ? 'text-sky-900' : 'text-slate-600'}`}
                                    >
                                        בוצע ניוד
                                    </span>
                                </label>
                            </div>
                        ) : (
                            <div>
                                <label
                                    htmlFor="financial-mobility"
                                    className="text-[9px] font-bold text-slate-400 mb-1.5 block uppercase tracking-wider"
                                >
                                    סכום ניוד (₪)
                                </label>
                                <DebouncedInput
                                    id="financial-mobility"
                                    className="w-full p-2.5 border border-slate-200 rounded-lg bg-white shadow-sm focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10 outline-none transition-colors font-bold text-xs"
                                    placeholder="0"
                                    value={currentInputs.details.mobility?.toString() || ''}
                                    onCommit={(val) =>
                                        onUpdateDetail('mobility', parseFloat(val) || 0)
                                    }
                                />
                            </div>
                        ))}
                    <div>
                        <label
                            htmlFor="financial-monthly-deposit"
                            className="text-[9px] font-bold text-slate-400 mb-1.5 block uppercase tracking-wider"
                        >
                            הפקדה חודשית (₪)
                        </label>
                        <DebouncedInput
                            id="financial-monthly-deposit"
                            className="w-full p-2.5 border border-slate-200 rounded-lg bg-white shadow-sm focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10 outline-none transition-colors font-bold text-xs"
                            placeholder="0"
                            value={currentInputs.details.monthlyDeposit?.toString() || ''}
                            onCommit={(val) =>
                                onUpdateDetail('monthlyDeposit', parseFloat(val) || 0)
                            }
                        />
                    </div>
                    <div>
                        <label
                            htmlFor="financial-lump-sum-deposit"
                            className="text-[9px] font-bold text-slate-400 mb-1.5 block uppercase tracking-wider"
                        >
                            הפקדה חד פעמית (₪)
                        </label>
                        <DebouncedInput
                            id="financial-lump-sum-deposit"
                            className="w-full p-2.5 border border-slate-200 rounded-lg bg-white shadow-sm focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10 outline-none transition-colors font-bold text-xs"
                            placeholder="0"
                            value={currentInputs.details.lumpSumDeposit?.toString() || ''}
                            onCommit={(val) =>
                                onUpdateDetail('lumpSumDeposit', parseFloat(val) || 0)
                            }
                        />
                    </div>
                </div>

                {isLoadingTracks ? (
                    <div className="space-y-4 pt-4 border-t border-slate-100/60 animate-pulse">
                        <div className="flex items-center gap-2.5 px-2 py-1.5">
                            <div className="w-6 h-6 rounded-lg bg-slate-200"></div>
                            <div className="h-3 bg-slate-200 rounded w-24"></div>
                        </div>
                        <div className="space-y-2 bg-slate-50/30 p-4 rounded-2xl border border-slate-100/50 mt-1">
                            {[1, 2, 3].map((i) => (
                                <div key={i} className="flex items-center justify-between gap-4">
                                    <div className="h-3 bg-slate-200 rounded w-1/3"></div>
                                    <div className="w-24 h-8 bg-slate-200 rounded-xl shrink-0"></div>
                                </div>
                            ))}
                        </div>
                    </div>
                ) : tracks.length > 0 ? (
                    <div className="space-y-4 pt-4 border-t border-slate-100/60">
                        <button
                            type="button"
                            className="w-full flex items-center justify-between cursor-pointer group hover:bg-slate-50/50 -mx-2 px-2 py-1.5 rounded-xl transition-colors duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-500/50 text-right"
                            onClick={() => setIsTracksExpanded(!isTracksExpanded)}
                            aria-expanded={isTracksExpanded}
                            aria-controls="investment-tracks-panel"
                        >
                            <div className="flex items-center gap-2.5">
                                <div className="w-6 h-6 rounded-lg bg-slate-100 flex items-center justify-center group-hover:bg-sky-50 transition-colors">
                                    <ChevronDown
                                        className={`w-3.5 h-3.5 text-slate-400 group-hover:text-sky-500 transition-transform duration-500 cubic-bezier(0.4, 0, 0.2, 1) ${!isTracksExpanded ? '-rotate-90' : ''}`}
                                        aria-hidden="true"
                                    />
                                </div>
                                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest group-hover:text-slate-900 transition-colors">
                                    מסלולי השקעה
                                </span>
                            </div>
                            <span
                                className={`text-[9px] font-black px-2.5 py-1 rounded-full transition-all duration-300 ${totalWeight === 100 ? 'bg-emerald-50 text-emerald-600 ring-1 ring-emerald-100' : 'bg-amber-50 text-amber-600 ring-1 ring-amber-100'}`}
                            >
                                {totalWeight}% / 100%
                            </span>
                        </button>

                        <div
                            id="investment-tracks-panel"
                            className={`grid-transition ${isTracksExpanded ? 'grid-transition-open' : ''}`}
                        >
                            <div className="overflow-hidden">
                                <div className="space-y-2 bg-slate-50/30 p-4 rounded-2xl border border-slate-100/50 mt-1 animate-slideDown">
                                    {tracks.map(({ trackName, fundId }) => {
                                        const existing = (
                                            currentInputs.details.investmentTracks || []
                                        ).find((t: any) =>
                                            fundId && t.fundId
                                                ? t.fundId === fundId
                                                : t.trackName === trackName,
                                        );
                                        const trackInputId = `track-${fundId || trackName.replace(/\s+/g, '-')}`;
                                        return (
                                            <div
                                                key={trackName}
                                                className="flex items-center justify-between gap-4 group/item"
                                            >
                                                <label
                                                    htmlFor={trackInputId}
                                                    className="text-[11px] text-slate-600 font-bold flex-1 text-right group-hover/item:text-slate-900 transition-colors cursor-pointer"
                                                >
                                                    {nameCounts.get(trackName)! > 1
                                                        ? `${trackName} - ${fundId}`
                                                        : trackName}
                                                </label>
                                                <div className="relative w-24 shrink-0">
                                                    <DebouncedInput
                                                        id={trackInputId}
                                                        className="w-full p-2 pl-8 border border-slate-200 rounded-xl text-xs outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-50 bg-white shadow-sm transition-all font-black text-center"
                                                        placeholder="0"
                                                        value={existing?.weight?.toString() || ''}
                                                        onCommit={(val) =>
                                                            onUpdateTracks(
                                                                trackName,
                                                                Math.min(
                                                                    100,
                                                                    Math.max(
                                                                        0,
                                                                        parseFloat(val) || 0,
                                                                    ),
                                                                ),
                                                                fundId,
                                                            )
                                                        }
                                                    />
                                                    <span className="absolute left-2.5 top-2.5 text-[10px] text-slate-300 font-bold">
                                                        %
                                                    </span>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        </div>
                    </div>
                ) : null}
            </div>
        );
    },
);

FinancialManualEntry.displayName = 'FinancialManualEntry';
