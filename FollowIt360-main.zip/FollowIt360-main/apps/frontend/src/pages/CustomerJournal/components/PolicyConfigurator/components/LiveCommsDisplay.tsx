import { INSURANCE_TYPE_LABELS, InsuranceType, isFinancialType, UserProfile } from '@repo/types';
import { Calculator, Info } from 'lucide-react';
import React, { useMemo } from 'react';
import {
    calcFinancialOngoing,
    calcFinancialScope,
    CommissionRates,
    FinancialInputs,
} from '../../../../../utils/commissionCalc';
import { calculateCommissions, getEffectivePremium } from '../../../utils/calculations';

interface LiveCommsDisplayProps {
    activeTab: InsuranceType;
    currentInputs: any;
    profile: UserProfile;
    customerIssueDate?: string;
    targetMonth?: number;
    targetYear?: number;
    creationType?: 'existing' | 'new_production';
}

export const LiveCommsDisplay: React.FC<LiveCommsDisplayProps> = React.memo(
    ({
        activeTab,
        currentInputs,
        profile,
        customerIssueDate,
        targetMonth,
        targetYear,
        creationType,
    }) => {
        const liveComms = useMemo(() => {
            if (!currentInputs.company) return null;

            let comms: {
                scope: number;
                ongoing: number;
                rates?: CommissionRates;
                isManual?: boolean;
            } | null = null;
            const agreement = profile.agreements[currentInputs.company]?.[activeTab];

            if (activeTab === 'elementary') {
                const scope = currentInputs.details.manualElementaryScope || 0;
                const ongoing = currentInputs.details.manualElementaryOngoing || 0;
                if (scope !== 0 || ongoing !== 0) {
                    comms = { scope, ongoing, isManual: true };
                }
            } else if (isFinancialType(activeTab)) {
                const finInputs: FinancialInputs = {
                    accumulation: currentInputs.details.accumulation || 0,
                    mobility: currentInputs.details.mobility || 0,
                    monthlyDeposit: currentInputs.details.monthlyDeposit || 0,
                    lumpSumDeposit: currentInputs.details.lumpSumDeposit || 0,
                };
                if (agreement) {
                    const rates: CommissionRates = {
                        scope: parseFloat(agreement.scope || '0'),
                        ongoing: parseFloat(agreement.ongoing || '0'),
                        mobility: parseFloat(agreement.mobility || '0'),
                    };
                    comms = {
                        scope: currentInputs.isAgentAppointmentOnly
                            ? 0
                            : calcFinancialScope(finInputs, rates, activeTab as string),
                        ongoing: calcFinancialOngoing(finInputs, rates, activeTab as string),
                        rates,
                    };
                }
            } else {
                let premium = currentInputs.cost || 0;

                if (
                    (activeTab === 'health' ||
                        activeTab === 'life' ||
                        activeTab === 'critical_illness') &&
                    currentInputs.details?.subPolicies
                ) {
                    premium = Object.values(
                        currentInputs.details.subPolicies as Record<string, number>,
                    ).reduce((a: number, b) => a + (parseFloat(b as any) || 0), 0);
                }
                if (premium === 0 && currentInputs.premiumSchedule?.length > 0) {
                    premium = currentInputs.premiumSchedule[0].premium;
                }
                if (premium > 0 && agreement) {
                    const sRate = parseFloat(agreement.scope || '0');
                    const oRate = parseFloat(agreement.ongoing || '0');
                    comms = {
                        scope: currentInputs.isAgentAppointmentOnly
                            ? 0
                            : (premium * 12 * sRate) / 100,
                        ongoing: (premium * oRate) / 100,
                        rates: { scope: sRate, ongoing: oRate } as any,
                    };
                }
            }

            const monthlyCost = getEffectivePremium(
                { ...currentInputs, type: activeTab } as any,
                customerIssueDate || '',
                targetMonth || new Date().getMonth() + 1,
                targetYear || new Date().getFullYear(),
            );

            const { scope, ongoing } = calculateCommissions(
                { ...currentInputs, type: activeTab } as any,
                monthlyCost,
                profile,
            );

            const finalComms = comms || { scope, ongoing };
            return {
                ...finalComms,
                scope: creationType === 'existing' ? 0 : finalComms.scope,
            };
        }, [
            currentInputs,
            activeTab,
            profile,
            customerIssueDate,
            targetMonth,
            targetYear,
            creationType,
        ]);

        if (!liveComms) return null;

        return (
            <div
                role="status"
                aria-live="polite"
                className="mb-5 bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl p-4 text-white shadow-xl animate-fadeIn border border-white/5 relative overflow-hidden group"
            >
                <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/10 blur-2xl -mr-12 -mt-12 group-hover:bg-blue-500/15 transition-colors duration-700"></div>
                <div className="flex items-center justify-between mb-4 relative z-10">
                    <div className="flex items-center gap-2">
                        <div className="bg-blue-500/20 p-1.5 rounded-lg">
                            <Calculator className="w-4 h-4 text-blue-400" aria-hidden="true" />
                        </div>
                        <div className="text-[10px] font-black text-white uppercase tracking-[0.15em]">
                            תצוגת עמלות משוערת
                        </div>
                    </div>
                    {(liveComms as any).rates && (
                        <div className="text-[10px] text-slate-400 font-bold bg-white/5 px-2.5 py-1 rounded-full border border-white/10">
                            {(liveComms as any).rates.scope}% | {(liveComms as any).rates.ongoing}%
                        </div>
                    )}
                </div>
                <div className="grid grid-cols-2 gap-6 relative z-10">
                    <div className="space-y-0.5">
                        <div className="text-[9px] text-slate-400 font-bold uppercase tracking-widest flex items-center gap-1">
                            עמלת היקף <span className="text-[7px] opacity-40">(חד פעמי)</span>
                        </div>
                        <div className="text-2xl font-black tabular-nums transition-colors group-hover:text-blue-400">
                            ₪
                            {liveComms.scope.toLocaleString(undefined, {
                                maximumFractionDigits: 0,
                            })}
                        </div>
                    </div>
                    <div className="space-y-0.5">
                        <div className="text-[9px] text-slate-400 font-bold uppercase tracking-widest flex items-center gap-1">
                            עמלת נפרעים <span className="text-[7px] opacity-40">(חודשי)</span>
                        </div>
                        <div className="text-2xl font-black tabular-nums text-emerald-400 group-hover:text-emerald-300 transition-colors">
                            ₪
                            {liveComms.ongoing.toLocaleString(undefined, {
                                maximumFractionDigits: 1,
                            })}
                        </div>
                    </div>
                </div>
                <div className="mt-4 pt-3 border-t border-white/10 flex items-center gap-2 text-[8px] text-slate-500 font-medium relative z-10">
                    <Info className="w-3 h-3 text-blue-500/70" aria-hidden="true" />
                    <span className="leading-tight">
                        {activeTab === 'elementary'
                            ? 'מבוסס על סכום העמלה שהזנת ידנית'
                            : `מחושב לפי הסכם עם ${currentInputs.company} עבור ${INSURANCE_TYPE_LABELS[activeTab]}`}
                        {currentInputs.isAgentAppointmentOnly && ' (נפרעים בלבד - מינוי סוכן)'}
                    </span>
                </div>
            </div>
        );
    },
);

LiveCommsDisplay.displayName = 'LiveCommsDisplay';
