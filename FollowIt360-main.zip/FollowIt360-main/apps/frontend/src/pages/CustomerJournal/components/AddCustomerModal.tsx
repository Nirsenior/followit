import {
    Customer,
    INSURANCE_TYPE_LABELS,
    InsuranceType,
    isIndividualType,
    Policy,
    PremiumScheduleItem,
    UserProfile,
} from '@repo/types';
import { Edit3, Plus, Trash2, UserPlus, X } from 'lucide-react';
import React, { useCallback, useDeferredValue, useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { DeleteConfirmModal } from '../../../components/DeleteConfirmModal';
import { useDeleteCustomer, useUpdateCustomer } from '../../../hooks/useCustomers';
import { Keys } from '../../../utils/keys';
import { getSelectedCompanies } from '../../../utils/profileUtils';
import { AddFamilyMemberModal } from './AddFamilyMemberModal';
import { PersonalDetailsSection } from './PersonalDetailsSection';
import { PolicyConfigurator } from './PolicyConfigurator';
import { PolicySidebarSection } from './PolicySidebarSection';

export const AddCustomerModal: React.FC<{
    onClose: () => void;
    onSubmit: (c: Customer) => void;
    profile: UserProfile;
    isSubmitting?: boolean;
    initialCustomer?: Customer;
    onUpdate?: (c: Customer) => void;
    onDelete?: (id: string) => void;
    creationType?: 'existing' | 'new_production';
}> = React.memo(
    ({
        onClose,
        onSubmit,
        profile,
        isSubmitting,
        initialCustomer,
        onUpdate,
        onDelete,
        creationType,
    }) => {
        const isEditMode = !!initialCustomer;
        const updateCustomerMutation = useUpdateCustomer();
        const deleteCustomerMutation = useDeleteCustomer();
        const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
        const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
        const [showFamilyModal, setShowFamilyModal] = useState(false);
        const [editingFamilyMemberIdx, setEditingFamilyMemberIdx] = useState<number | null>(null);
        const [policyIdxToDelete, setPolicyIdxToDelete] = useState<number | null>(null);

        const [form, setForm] = useState<Omit<Customer, 'createdAt'>>(
            initialCustomer
                ? {
                      id: initialCustomer.id,
                      firstName: initialCustomer.firstName,
                      lastName: initialCustomer.lastName,
                      issueDate: initialCustomer.issueDate,
                      policies: initialCustomer.policies,
                      familyMembers: initialCustomer.familyMembers || [],
                      creationType: initialCustomer.creationType || 'existing',
                  }
                : {
                      id: '',
                      firstName: '',
                      lastName: '',
                      issueDate: '',
                      policies: [],
                      familyMembers: [],
                      creationType: creationType || 'new_production',
                  },
        );

        const totalCost = useMemo(() => {
            const primaryPremium = form.policies.reduce((sum, p) => sum + p.monthlyCost, 0);
            const familyPremium = (form.familyMembers || []).reduce(
                (sum, fm) => sum + fm.policies.reduce((pSum, p) => pSum + p.monthlyCost, 0),
                0,
            );
            return primaryPremium + familyPremium;
        }, [form.policies, form.familyMembers]);

        const activeInsuranceTypes = useMemo(() => {
            const types = new Set<InsuranceType>();
            getSelectedCompanies(profile.agreements).forEach((company: string) => {
                const companyAgreements = profile.agreements[company] || {};
                (Object.keys(companyAgreements) as InsuranceType[]).forEach((type) => {
                    const agreement = companyAgreements[type];
                    if (
                        agreement &&
                        (agreement.isActive ||
                            agreement.scope ||
                            agreement.ongoing ||
                            agreement.mobility)
                    ) {
                        types.add(type);
                    }
                });
            });
            return (Object.keys(INSURANCE_TYPE_LABELS) as InsuranceType[]).filter((t) =>
                types.has(t),
            );
        }, [profile]);

        const [activeTab, setActiveTab] = useState<InsuranceType>(
            activeInsuranceTypes[0] || 'health',
        );
        const [editingPolicyIdx, setEditingPolicyIdx] = useState<number | null>(null);

        const [currentInputs, setCurrentInputs] = useState<Partial<Policy>>({
            company: '',
            monthlyCost: 0,
            isAgentAppointmentOnly: false,
            premiumSchedule: [],
            details: { subPolicies: {} },
            status: 'active',
        });

        // Load an existing policy into the configurator for editing
        const handleEditPolicy = useCallback(
            (idx: number) => {
                if (editingPolicyIdx === idx) {
                    setEditingPolicyIdx(null);
                    setCurrentInputs({
                        company: '',
                        monthlyCost: 0,
                        isAgentAppointmentOnly: false,
                        premiumSchedule: [],
                        details: { subPolicies: {} },
                        status: 'active',
                    });
                    return;
                }
                const p = form.policies[idx];
                if (!p) return;
                setActiveTab(p.type as InsuranceType);
                setCurrentInputs({
                    company: p.company,
                    monthlyCost: p.monthlyCost,
                    isAgentAppointmentOnly: p.isAgentAppointmentOnly,
                    premiumSchedule: p.details?.premiumSchedule || p.premiumSchedule || [],
                    excelColumns: p.details?.excelColumns || p.excelColumns || [],
                    issueDate: p.issueDate,
                    details: p.details || { subPolicies: {} },
                    systemEntryDate: (p as any).systemEntryDate,
                    initialAccumulation: (p as any).initialAccumulation,
                    lastCalculatedDate: (p as any).lastCalculatedDate,
                    currentAccumulation: (p as any).currentAccumulation,
                });
                setEditingPolicyIdx(idx);
            },
            [form.policies, editingPolicyIdx],
        );

        const handleAddPolicyToForm = useCallback(() => {
            let monthlyCost = currentInputs.monthlyCost || 0;
            if (isIndividualType(activeTab) && currentInputs.details?.subPolicies) {
                monthlyCost = Object.values(
                    currentInputs.details.subPolicies as Record<string, number>,
                ).reduce((a: number, b) => a + (parseFloat(b as any) || 0), 0);
            }
            if (
                monthlyCost === 0 &&
                currentInputs.premiumSchedule &&
                currentInputs.premiumSchedule.length > 0
            ) {
                monthlyCost = currentInputs.premiumSchedule[0].premium;
            }
            if (!currentInputs.company) return;

            const updatedPolicy: Policy = {
                id:
                    editingPolicyIdx !== null
                        ? form.policies[editingPolicyIdx].id
                        : Math.random().toString(36).substring(2, 11),
                type: activeTab,
                company: currentInputs.company,
                monthlyCost,
                issueDate: form.issueDate || currentInputs.issueDate || new Date().toISOString(),
                premiumSchedule: currentInputs.premiumSchedule as PremiumScheduleItem[],
                excelColumns: currentInputs.excelColumns || [],
                isAgentAppointmentOnly: !!currentInputs.isAgentAppointmentOnly,
                details: {
                    ...(currentInputs.details || { subPolicies: {} }),
                    premiumSchedule: currentInputs.premiumSchedule || [],
                    excelColumns: currentInputs.excelColumns || [],
                },
                status: 'active',
                ...(currentInputs.systemEntryDate
                    ? { systemEntryDate: currentInputs.systemEntryDate }
                    : {}),
                ...(currentInputs.initialAccumulation
                    ? { initialAccumulation: currentInputs.initialAccumulation }
                    : {}),
                ...(currentInputs.lastCalculatedDate
                    ? { lastCalculatedDate: currentInputs.lastCalculatedDate }
                    : {}),
                ...(currentInputs.currentAccumulation
                    ? { currentAccumulation: currentInputs.currentAccumulation }
                    : {}),
            } as Policy;

            setForm((prev) => {
                const policies =
                    editingPolicyIdx !== null
                        ? prev.policies.map((p, i) => (i === editingPolicyIdx ? updatedPolicy : p))
                        : [...prev.policies, updatedPolicy];
                return { ...prev, policies };
            });

            setEditingPolicyIdx(null);
            setCurrentInputs({
                company: '',
                monthlyCost: 0,
                isAgentAppointmentOnly: false,
                premiumSchedule: [],
                details: { subPolicies: {} },
                status: 'active',
            });
        }, [activeTab, currentInputs, editingPolicyIdx, form.policies]);

        const deferredForm = useDeferredValue(form);

        const handleRemovePolicy = useCallback((idx: number) => {
            setPolicyIdxToDelete(idx);
        }, []);

        const handleConfirmRemovePolicy = useCallback(() => {
            if (policyIdxToDelete === null) return;
            const idx = policyIdxToDelete;
            if (editingPolicyIdx === idx) {
                setEditingPolicyIdx(null);
                setCurrentInputs({
                    company: '',
                    monthlyCost: 0,
                    isAgentAppointmentOnly: false,
                    premiumSchedule: [],
                    details: { subPolicies: {} },
                });
            }
            setForm((prev) => ({
                ...prev,
                policies: prev.policies.filter((_, i) => i !== idx),
            }));
            setPolicyIdxToDelete(null);
        }, [policyIdxToDelete, editingPolicyIdx]);

        const handleFullSubmit = useCallback(async () => {
            if (isEditMode && onUpdate) {
                setSaveStatus('saving');
                try {
                    if ((initialCustomer as any)?._isFamilyMember) {
                        const parent = (initialCustomer as any)._parentCustomer;
                        const fmIndex = parent.familyMembers.findIndex(
                            (f: any) => f.id === form.id,
                        );

                        const updatedFamilyMember = {
                            id: form.id,
                            firstName: form.firstName,
                            lastName: form.lastName,
                            issueDate: form.issueDate,
                            relationship: (initialCustomer as any).relationship,
                            isPremiumSharedWithPrimary: (initialCustomer as any)
                                .isPremiumSharedWithPrimary,
                            policies: form.policies
                                .filter((p) => p.status === 'active')
                                .map((p) => ({
                                    id: p.id,
                                    company: p.company,
                                    type: p.type,
                                    issueDate: p.issueDate,
                                    isAgentAppointmentOnly: p.isAgentAppointmentOnly,
                                    monthlyCost: p.monthlyCost,
                                    premiumSchedule: p.premiumSchedule,
                                    details: p.details,
                                    status: p.status,
                                })),
                        };

                        const updatedFamilyMembers = [...parent.familyMembers];
                        if (fmIndex >= 0) {
                            updatedFamilyMembers[fmIndex] = updatedFamilyMember;
                        }

                        const payload = {
                            customer: {
                                firstName: parent.firstName,
                                surname: parent.lastName,
                                governmentId: parent.id,
                                issueDate: parent.issueDate,
                                creationType: parent.creationType,
                            },
                            policies: parent.policies
                                .filter((p: any) => p.status === 'active')
                                .map((p: any) => ({
                                    company: p.company,
                                    insuranceType: p.type,
                                    issueDate: p.issueDate,
                                    isAgentAppointmentOnly: p.isAgentAppointmentOnly,
                                    details: p.details,
                                })),
                            familyMembers: updatedFamilyMembers,
                        };

                        await updateCustomerMutation.mutateAsync({
                            dbId: (parent as any).dbId,
                            payload,
                        });

                        onUpdate({ ...parent, familyMembers: updatedFamilyMembers });
                        setSaveStatus('saved');
                        setTimeout(() => {
                            setSaveStatus('idle');
                            onClose();
                        }, 800);
                        return;
                    }

                    const payload = {
                        customer: {
                            firstName: form.firstName,
                            surname: form.lastName,
                            governmentId: form.id,
                            issueDate: form.issueDate,
                            creationType: form.creationType,
                        },
                        policies: form.policies
                            .filter((p) => p.status === 'active')
                            .map((p) => ({
                                id: p.id,
                                company: p.company,
                                insuranceType: p.type,
                                issueDate: p.issueDate,
                                isAgentAppointmentOnly: p.isAgentAppointmentOnly,
                                details: p.details,
                                systemEntryDate: (p as any).systemEntryDate,
                                initialAccumulation: (p as any).initialAccumulation,
                                lastCalculatedDate: (p as any).lastCalculatedDate,
                                currentAccumulation: (p as any).currentAccumulation,
                            })),
                        familyMembers: form.familyMembers,
                    };
                    await updateCustomerMutation.mutateAsync({
                        dbId: (initialCustomer as any).dbId,
                        payload,
                    });
                    onUpdate({ ...form, createdAt: initialCustomer!.createdAt } as Customer);
                    setSaveStatus('saved');
                    setTimeout(() => {
                        setSaveStatus('idle');
                        onClose();
                    }, 800);
                } catch (e) {
                    setSaveStatus('idle');
                    alert(e instanceof Error ? e.message : 'שגיאה בשמירה');
                }
            } else {
                onSubmit({ ...form, createdAt: new Date().toISOString() });
            }
        }, [
            form,
            onSubmit,
            isEditMode,
            onUpdate,
            initialCustomer,
            onClose,
            updateCustomerMutation,
        ]);

        const targetDate = useMemo(
            () => ({
                month: new Date().getMonth() + 1,
                year: new Date().getFullYear(),
            }),
            [],
        );

        useEffect(() => {
            const handleKeyDown = (e: KeyboardEvent) => {
                if (e.key === 'Escape') {
                    if (!showDeleteConfirm && !showFamilyModal && policyIdxToDelete === null) {
                        onClose();
                    }
                }
            };
            window.addEventListener('keydown', handleKeyDown);
            return () => {
                window.removeEventListener('keydown', handleKeyDown);
            };
        }, [onClose, showDeleteConfirm, showFamilyModal, policyIdxToDelete]);

        if (typeof document === 'undefined') return null;

        const modalId = 'add-customer-modal-title';

        return createPortal(
            <div
                role="dialog"
                aria-modal="true"
                aria-labelledby={modalId}
                className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/60"
                dir="rtl"
                onKeyDown={(e) => e.key === Keys.Escape && onClose()}
            >
                <div
                    className="bg-slate-50 w-full max-w-7xl max-h-[92vh] rounded-3xl shadow-xl flex flex-col overflow-hidden border border-slate-200"
                    style={{ willChange: 'transform, opacity' }}
                >
                    {/* Modal Header */}
                    <div className="p-5 border-b border-slate-200 flex justify-between items-center bg-white shrink-0">
                        <h2
                            id={modalId}
                            className="text-xl font-black text-slate-900 flex items-center gap-3"
                        >
                            <span
                                aria-hidden="true"
                                className={`w-9 h-9 rounded-xl flex items-center justify-center shadow-sm ${isEditMode ? 'bg-cyan-700 shadow-cyan-700/20' : 'bg-cyan-700 shadow-cyan-700/20'}`}
                            >
                                {isEditMode ? (
                                    <Edit3 className="w-5 h-5 text-white" />
                                ) : (
                                    <Plus className="w-5 h-5 text-white" />
                                )}
                            </span>
                            {isEditMode
                                ? (initialCustomer as any)?._isFamilyMember
                                    ? `עריכת בן משפחה — ${form.firstName} ${form.lastName}`
                                    : `עריכת לקוח — ${form.firstName} ${form.lastName}`
                                : form.creationType === 'existing'
                                  ? 'לקוח קיים'
                                  : 'לקוח חדש'}
                        </h2>
                        <div className="flex items-center gap-2">
                            <div className="flex gap-2">
                                {!(initialCustomer as any)?._isFamilyMember && (
                                    <button
                                        type="button"
                                        onClick={() => setShowFamilyModal(true)}
                                        className="px-4 py-2.5 rounded-2xl text-blue-600 hover:bg-blue-50 border border-blue-100 font-bold text-xs transition-all flex items-center gap-2"
                                    >
                                        <UserPlus className="w-4 h-4" aria-hidden="true" />
                                        הוסף בן משפחה
                                    </button>
                                )}
                                {isEditMode && (
                                    <button
                                        onClick={() => setShowDeleteConfirm(true)}
                                        className="flex items-center gap-2 px-4 py-2.5 rounded-2xl text-rose-500 hover:bg-rose-50 border border-rose-100 font-bold text-xs transition-all"
                                    >
                                        <Trash2 className="w-4 h-4" aria-hidden="true" />
                                        {(initialCustomer as any)?._isFamilyMember
                                            ? 'מחק בן משפחה'
                                            : 'מחק לקוח'}
                                    </button>
                                )}
                            </div>
                            <button
                                onClick={onClose}
                                aria-label="סגור"
                                className="p-2 hover:bg-slate-100 rounded-full transition-standard text-slate-400"
                            >
                                <X className="w-5 h-5" aria-hidden="true" />
                            </button>
                        </div>
                    </div>

                    {/* Delete Customer / Family Member confirmation dialog */}
                    <DeleteConfirmModal
                        isOpen={showDeleteConfirm}
                        title={
                            (initialCustomer as any)?._isFamilyMember
                                ? 'מחיקת בן משפחה'
                                : 'מחיקת לקוח'
                        }
                        description={
                            <>
                                האם למחוק את{' '}
                                <span className="font-black text-slate-900">
                                    {form.firstName} {form.lastName}
                                </span>
                                ?
                                <br />
                                <span className="text-xs text-rose-400">פעולה זו בלתי הפיכה</span>
                            </>
                        }
                        isPending={
                            deleteCustomerMutation.isPending || updateCustomerMutation.isPending
                        }
                        onCancel={() => setShowDeleteConfirm(false)}
                        onConfirm={async () => {
                            try {
                                if ((initialCustomer as any)?._isFamilyMember) {
                                    const parent = (initialCustomer as any)._parentCustomer;
                                    const updatedFamilyMembers = parent.familyMembers.filter(
                                        (f: any) => f.id !== form.id,
                                    );

                                    const payload = {
                                        customer: {
                                            firstName: parent.firstName,
                                            surname: parent.lastName,
                                            governmentId: parent.id,
                                            issueDate: parent.issueDate,
                                        },
                                        policies: parent.policies
                                            .filter((p: any) => p.status === 'active')
                                            .map((p: any) => ({
                                                company: p.company,
                                                insuranceType: p.type,
                                                issueDate: p.issueDate,
                                                isAgentAppointmentOnly: p.isAgentAppointmentOnly,
                                                details: p.details,
                                            })),
                                        familyMembers: updatedFamilyMembers,
                                    };

                                    await updateCustomerMutation.mutateAsync({
                                        dbId: (parent as any).dbId,
                                        payload,
                                    });
                                    onUpdate?.({
                                        ...parent,
                                        familyMembers: updatedFamilyMembers,
                                    });
                                    onClose();
                                } else {
                                    await deleteCustomerMutation.mutateAsync(
                                        (initialCustomer as any).dbId,
                                    );
                                    onDelete ? onDelete(initialCustomer!.id) : onClose();
                                }
                            } catch (e) {
                                alert(e instanceof Error ? e.message : 'שגיאה במחיקה');
                            }
                        }}
                    />

                    {/* Delete Policy confirmation dialog */}
                    <DeleteConfirmModal
                        isOpen={policyIdxToDelete !== null}
                        title="מחיקת פוליסה"
                        description={
                            policyIdxToDelete !== null && form.policies[policyIdxToDelete] ? (
                                <>
                                    האם למחוק את פוליסת{' '}
                                    <span className="font-black text-slate-900">
                                        {
                                            INSURANCE_TYPE_LABELS[
                                                form.policies[policyIdxToDelete].type
                                            ]
                                        }
                                    </span>{' '}
                                    של חברת{' '}
                                    <span className="font-black text-slate-900">
                                        {form.policies[policyIdxToDelete].company}
                                    </span>
                                    ?
                                    <br />
                                    <span className="text-xs text-rose-400">
                                        פעולה זו תסיר את הפוליסה מהלקוח
                                    </span>
                                </>
                            ) : null
                        }
                        onCancel={() => setPolicyIdxToDelete(null)}
                        onConfirm={handleConfirmRemovePolicy}
                    />

                    {/* Top Bar - Personal Details */}
                    <PersonalDetailsSection form={form} setForm={setForm} />

                    <div className="flex-1 overflow-hidden flex">
                        {/* Main Content - Center/Left */}
                        <div className="flex-1 overflow-y-auto p-10 space-y-6 scroll-smooth">
                            {/* Editing banner */}
                            {editingPolicyIdx !== null && (
                                <div className="animate-fadeIn flex items-center gap-3 bg-amber-50 border border-amber-200 text-amber-800 rounded-2xl px-5 py-3.5 text-sm font-bold shadow-sm">
                                    <span className="text-lg" aria-hidden="true">
                                        ✏️
                                    </span>
                                    <div>
                                        <div className="font-black">מצב עריכת פוליסה פעיל</div>
                                        <div className="text-[11px] font-medium text-amber-600 mt-0.5">
                                            לאחר עדכון הנתונים, לחץ על{' '}
                                            <span className="bg-amber-200 px-1.5 py-0.5 rounded font-black">
                                                עדכן פוליסה ✓
                                            </span>{' '}
                                            כדי להחיל את השינויים
                                        </div>
                                    </div>
                                </div>
                            )}

                            <PolicyConfigurator
                                activeTab={activeTab}
                                setActiveTab={setActiveTab}
                                profile={profile}
                                currentInputs={currentInputs}
                                setCurrentInputs={setCurrentInputs}
                                onAddPolicy={handleAddPolicyToForm}
                                buttonLabel={
                                    editingPolicyIdx !== null
                                        ? 'עדכן פוליסה ✓'
                                        : 'הוסף פוליסה זו ללקוח'
                                }
                                layout="t-shape"
                                customerIssueDate={deferredForm.issueDate}
                                targetMonth={targetDate.month}
                                targetYear={targetDate.year}
                                creationType={form.creationType}
                            />
                        </div>

                        {/* Right Sidebar - Policies List */}
                        <PolicySidebarSection
                            policies={deferredForm.policies}
                            familyMembers={form.familyMembers}
                            onRemove={handleRemovePolicy}
                            onRemoveFamilyMember={(idx) => {
                                setForm((prev) => {
                                    const next = [...(prev.familyMembers || [])];
                                    next.splice(idx, 1);
                                    return { ...prev, familyMembers: next };
                                });
                            }}
                            onEditFamilyMember={(idx) => setEditingFamilyMemberIdx(idx)}
                            onEdit={handleEditPolicy}
                            editingIdx={editingPolicyIdx}
                            totalCost={totalCost}
                            onSubmit={handleFullSubmit}
                            canSubmit={
                                !!(deferredForm.id && deferredForm.firstName) &&
                                (isEditMode ||
                                    deferredForm.policies.length > 0 ||
                                    (form.familyMembers?.length || 0) > 0) &&
                                editingPolicyIdx === null
                            }
                            isSubmitting={saveStatus === 'saving' || isSubmitting}
                            isEditMode={isEditMode}
                            saveStatus={editingPolicyIdx !== null ? ('editing' as any) : saveStatus}
                        />
                    </div>
                    {(showFamilyModal || editingFamilyMemberIdx !== null) && (
                        <AddFamilyMemberModal
                            profile={profile}
                            initialLastName={form.lastName}
                            initialFamilyMember={
                                editingFamilyMemberIdx !== null
                                    ? form.familyMembers?.[editingFamilyMemberIdx]
                                    : undefined
                            }
                            parentCreationType={form.creationType}
                            onClose={() => {
                                setShowFamilyModal(false);
                                setEditingFamilyMemberIdx(null);
                            }}
                            onSubmit={(fm) => {
                                // Build updated family members list
                                const currentFamilyMembers = form.familyMembers || [];
                                const nextFamilyMembers = [...currentFamilyMembers];
                                if (editingFamilyMemberIdx !== null) {
                                    nextFamilyMembers[editingFamilyMemberIdx] = fm;
                                } else {
                                    nextFamilyMembers.push(fm);
                                }

                                // Update local state
                                setForm((prev) => ({ ...prev, familyMembers: nextFamilyMembers }));
                                setShowFamilyModal(false);
                                setEditingFamilyMemberIdx(null);
                            }}
                        />
                    )}
                </div>
            </div>,
            document.body,
        );
    },
);
