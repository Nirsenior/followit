import { INSURANCE_TYPE_LABELS, InsuranceType } from '@repo/types';
import React from 'react';

interface InsuranceTabBarProps {
    activeTab: InsuranceType;
    activeInsuranceTypes: InsuranceType[];
    onSelectTab: (type: InsuranceType) => void;
}

export const InsuranceTabBar: React.FC<InsuranceTabBarProps> = React.memo(
    ({ activeTab, activeInsuranceTypes, onSelectTab }) => {
        return (
            <div role="tablist" aria-label="סוגי כיסויים" className="flex bg-slate-50 border-b border-slate-200 p-1">
                {activeInsuranceTypes.map((type) => (
                    <button
                        key={type}
                        role="tab"
                        aria-selected={activeTab === type}
                        onClick={() => onSelectTab(type)}
                        className={`flex-1 py-3 px-2 rounded-xl text-xs font-bold transition-standard focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500/50 ${activeTab === type ? 'bg-white text-sky-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                    >
                        {INSURANCE_TYPE_LABELS[type]}
                    </button>
                ))}
                {activeInsuranceTypes.length === 0 && (
                    <div className="p-3 text-[10px] text-slate-400 font-bold italic w-full text-center">
                        אין הסכמים פעילים בפרופיל
                    </div>
                )}
            </div>
        );
    },
);

InsuranceTabBar.displayName = 'InsuranceTabBar';
