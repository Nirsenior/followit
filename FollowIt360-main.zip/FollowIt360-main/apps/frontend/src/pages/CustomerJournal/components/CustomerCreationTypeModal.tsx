import { CheckCircle2, FilePlus2, Info, UserPlus, X } from 'lucide-react';
import React, { useState } from 'react';
import { Keys } from '../../../utils/keys';

interface CustomerCreationTypeModalProps {
    onClose: () => void;
    onContinue: (type: 'existing' | 'new_production') => void;
}

export const CustomerCreationTypeModal: React.FC<CustomerCreationTypeModalProps> = ({
    onClose,
    onContinue,
}) => {
    const [selectedType, setSelectedType] = useState<'existing' | 'new_production' | null>(null);

    const modalId = 'customer-creation-type-modal-title';

    return (
        <div
            role="dialog"
            aria-modal="true"
            aria-labelledby={modalId}
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in duration-200"
            onKeyDown={(e) => e.key === Keys.Escape && onClose()}
        >
            <div className="bg-white rounded-3xl shadow-2xl w-full max-w-3xl overflow-hidden flex flex-col border border-slate-100 animate-in zoom-in-95 duration-200">
                {/* Header */}
                <div className="bg-slate-50 border-b border-slate-100 p-6 flex justify-between items-center shrink-0">
                    <h2
                        id={modalId}
                        className="text-xl font-bold text-slate-900 flex items-center gap-3"
                    >
                        <span
                            aria-hidden="true"
                            className="w-8 h-8 rounded-lg bg-cyan-700 flex items-center justify-center shadow-sm"
                        >
                            <UserPlus className="w-5 h-5 text-white" />
                        </span>
                        בחר סוג לקוח
                    </h2>
                    <button
                        onClick={onClose}
                        aria-label="סגור"
                        className="p-2 hover:bg-slate-200 rounded-full transition-colors text-slate-400 hover:text-slate-600"
                    >
                        <X className="w-5 h-5" aria-hidden="true" />
                    </button>
                </div>

                {/* Content */}
                <div className="p-8 flex flex-col sm:flex-row gap-6">
                    {/* Option 1: Existing Customer */}
                    <div className="flex-1 flex flex-col gap-3">
                        <button
                            onClick={() => setSelectedType('existing')}
                            aria-pressed={selectedType === 'existing'}
                            className={`text-right p-6 rounded-2xl border-2 transition-all flex flex-col items-start relative group h-full ${
                                selectedType === 'existing'
                                    ? 'border-emerald-500 bg-emerald-50/30 shadow-md ring-4 ring-emerald-500/10'
                                    : 'border-slate-200 hover:border-emerald-300 hover:bg-slate-50'
                            }`}
                        >
                            <div
                                aria-hidden="true"
                                className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-colors ${selectedType === 'existing' ? 'bg-emerald-500 text-white shadow-sm' : 'bg-slate-100 text-slate-500 group-hover:bg-emerald-100 group-hover:text-emerald-600'}`}
                            >
                                <UserPlus className="w-6 h-6" />
                            </div>
                            <h3 className="text-lg font-bold text-slate-900 mb-2">
                                הוסף לקוח קיים
                            </h3>
                            <p className="text-sm font-medium text-slate-500 leading-relaxed">
                                הזנת לקוח ופוליסות קיימות, כולל נתוני צבירה היסטוריים.
                            </p>

                            <div
                                aria-hidden="true"
                                className={`absolute top-6 left-6 transition-opacity ${selectedType === 'existing' ? 'opacity-100' : 'opacity-0'}`}
                            >
                                <CheckCircle2 className="w-6 h-6 text-emerald-500" />
                            </div>
                        </button>

                        <div className="flex items-start gap-2 text-slate-400 bg-slate-50/50 p-3.5 rounded-xl border border-slate-100">
                            <Info className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
                            <p className="text-xs leading-relaxed font-medium">
                                המערכת תעקוב אחר התפתחות הפרמיה והנפרעים בלבד (ללא חישוב עמלת היקף).
                            </p>
                        </div>
                    </div>

                    {/* Option 2: New Production */}
                    <div className="flex-1 flex flex-col gap-3">
                        <button
                            onClick={() => setSelectedType('new_production')}
                            aria-pressed={selectedType === 'new_production'}
                            className={`text-right p-6 rounded-2xl border-2 transition-all flex flex-col items-start relative group h-full ${
                                selectedType === 'new_production'
                                    ? 'border-indigo-500 bg-indigo-50/30 shadow-md ring-4 ring-indigo-500/10'
                                    : 'border-slate-200 hover:border-indigo-300 hover:bg-slate-50'
                            }`}
                        >
                            <div
                                aria-hidden="true"
                                className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-colors ${selectedType === 'new_production' ? 'bg-indigo-500 text-white shadow-sm' : 'bg-slate-100 text-slate-500 group-hover:bg-indigo-100 group-hover:text-indigo-600'}`}
                            >
                                <FilePlus2 className="w-6 h-6" />
                            </div>
                            <h3 className="text-lg font-bold text-slate-900 mb-2">
                                הוסף הפקה חדשה
                            </h3>
                            <p className="text-sm font-medium text-slate-500 leading-relaxed">
                                הקמת לקוח חדש והזנת פוליסות חדשות שהופקו כעת.
                            </p>

                            <div
                                aria-hidden="true"
                                className={`absolute top-6 left-6 transition-opacity ${selectedType === 'new_production' ? 'opacity-100' : 'opacity-0'}`}
                            >
                                <CheckCircle2 className="w-6 h-6 text-indigo-500" />
                            </div>
                        </button>

                        <div className="flex items-start gap-2 text-slate-400 bg-slate-50/50 p-3.5 rounded-xl border border-slate-100">
                            <Info className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
                            <p className="text-xs leading-relaxed font-medium">
                                המערכת תחשב עמלות היקף, נפרעים ומעקב פרמיה מלא בהתאם להסכמים שהוזנו.
                            </p>
                        </div>
                    </div>
                </div>

                {/* Footer */}
                <div className="p-6 bg-slate-50 border-t border-slate-100">
                    <button
                        disabled={!selectedType}
                        onClick={() => selectedType && onContinue(selectedType)}
                        className="w-full py-3.5 bg-sky-500 text-white font-bold rounded-xl shadow-lg shadow-sky-500/20 hover:bg-sky-600 disabled:opacity-30 disabled:bg-slate-300 disabled:shadow-none active:scale-[0.98] transition-all text-sm flex items-center justify-center gap-2"
                    >
                        המשך ליצירת הלקוח
                    </button>
                </div>
            </div>
        </div>
    );
};
