import { INSURANCE_TYPE_LABELS, InsuranceType } from '@repo/types';
import { CheckCircle2 } from 'lucide-react';
import React from 'react';

interface InsuranceSidebarProps {
    activeTab: InsuranceType;
    activeInsuranceTypes: InsuranceType[];
    onSelectTab: (type: InsuranceType) => void;
}

export const InsuranceSidebar: React.FC<InsuranceSidebarProps> = React.memo(
    ({ activeTab, activeInsuranceTypes, onSelectTab }) => {
        return (
            <div role="tablist" aria-label="בחירת סוג כיסוי" className="w-52 shrink-0 space-y-2">
                <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block mb-2 mr-1">
                    סוג כיסוי
                </label>
                {activeInsuranceTypes.map((type) => (
                    <button
                        key={type}
                        role="tab"
                        aria-selected={activeTab === type}
                        onClick={() => onSelectTab(type)}
                        className={`w-full flex items-center justify-between p-3 rounded-xl border-2 transition-all font-bold text-xs font-sans focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 ${
                            activeTab === type 
                                ? 'bg-blue-50/70 border-blue-500 text-blue-700 shadow-sm' 
                                : 'bg-white border-slate-100 text-slate-400 hover:text-slate-600 hover:border-slate-200'
                        }`}
                    >
                        <span>{INSURANCE_TYPE_LABELS[type]}</span>
                        {activeTab === type && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-blue-500" aria-hidden="true" />
                        )}
                    </button>
                ))}
            </div>
        );
    },
);

InsuranceSidebar.displayName = 'InsuranceSidebar';
