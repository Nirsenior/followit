import {
    FamilyMember,
    INSURANCE_TYPE,
    INSURANCE_TYPE_LABELS,
    InsuranceType,
    isFinancialType,
    isIndividualType,
    Policy,
    Relationship,
    UserProfile,
} from '@repo/types';
import { CheckCircle2, HeartHandshake, Pencil, ShieldCheck, Trash2, X } from 'lucide-react';
import React, { useCallback, useDeferredValue, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { Keys } from '../../../utils/keys';
import { getSelectedCompanies } from '../../../utils/profileUtils';
import { PolicyConfigurator } from './PolicyConfigurator';
import { PolicyCoversList } from './PolicyCoversList';

// Mimics the exact layout of PersonalDetailsSection from AddCustomerModal
const FamilyDetailsSection: React.FC<{
    form: FamilyMember;
    setForm: (f: FamilyMember) => void;
}> = React.memo(({ form, setForm }) => {
    return (
        <div className="px-10 py-8 bg-white border-b border-slate-100 shrink-0 font-sans">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div className="space-y-1.5">
                    <label
                        htmlFor="fm-firstName"
                        className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mr-1"
                    >
                        שם פרטי
                    </label>
                    <input
                        id="fm-firstName"
                        type="text"
                        value={form.firstName}
                        onChange={(e) => setForm({ ...form, firstName: e.target.value })}
                        className="w-full p-3.5 border border-slate-200 rounded-2xl outline-none text-slate-900 font-bold bg-slate-50/50 focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/5 transition-all text-sm"
                        placeholder="שם בן המשפחה"
                    />
                </div>
                <div className="space-y-1.5">
                    <label
                        htmlFor="fm-lastName"
                        className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mr-1"
                    >
                        שם משפחה
                    </label>
                    <input
                        id="fm-lastName"
                        type="text"
                        value={form.lastName}
                        onChange={(e) => setForm({ ...form, lastName: e.target.value })}
                        className="w-full p-3.5 border border-slate-200 rounded-2xl outline-none text-slate-900 font-bold bg-slate-50/50 focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/5 transition-all text-sm"
                        placeholder="ישראלי"
                    />
                </div>
                <div className="space-y-1.5">
                    <label
                        htmlFor="fm-id"
                        className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mr-1"
                    >
                        תעודת זהות
                    </label>
                    <input
                        id="fm-id"
                        type="text"
                        value={form.id}
                        onChange={(e) => setForm({ ...form, id: e.target.value })}
                        className="w-full p-3.5 border border-slate-200 rounded-2xl outline-none text-slate-900 font-bold bg-slate-50/50 focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/5 transition-all text-sm"
                        placeholder="000000000"
                    />
                </div>
                <div className="space-y-1.5">
                    <label
                        htmlFor="fm-issueDate"
                        className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mr-1"
                    >
                        תאריך הפקה/לידה
                    </label>
                    <input
                        id="fm-issueDate"
                        type="date"
                        value={form.issueDate || ''}
                        onChange={(e) => {
                            const newDate = e.target.value;
                            setForm({
                                ...form,
                                issueDate: newDate,
                                policies: form.policies.map((p) => ({ ...p, issueDate: newDate })),
                            });
                        }}
                        className="w-full p-3.5 border border-slate-200 rounded-2xl outline-none text-slate-900 font-bold bg-slate-50/50 focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/5 transition-all text-sm"
                    />
                </div>
                <div className="space-y-1.5">
                    <label
                        htmlFor="fm-relationship"
                        className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mr-1"
                    >
                        קשר ללקוח הראשי
                    </label>
                    <select
                        id="fm-relationship"
                        value={form.relationship}
                        onChange={(e) =>
                            setForm({ ...form, relationship: e.target.value as Relationship })
                        }
                        className="w-full p-3.5 border border-slate-200 rounded-2xl outline-none text-slate-900 font-bold bg-slate-50/50 focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/5 transition-all text-sm appearance-none cursor-pointer"
                    >
                        <option value="child">בן/בת</option>
                        <option value="spouse">בן/בת זוג</option>
                        <option value="other">אחר</option>
                    </select>
                </div>
            </div>
        </div>
    );
});

// Mimics the exact layout of PolicySidebarSection from AddCustomerModal
interface FamilySidebarSectionProps {
    policies: Policy[];
    onRemove: (idx: number) => void;
    onEdit: (idx: number) => void;
    editingIdx: number | null;
    totalCost: number;
    onSubmit: () => void;
    canSubmit: boolean;
    isSubmitting?: boolean;
    isEditMode?: boolean;
}

const FamilySidebarSection: React.FC<FamilySidebarSectionProps> = React.memo(
    ({
        policies,
        onRemove,
        onEdit,
        editingIdx,
        totalCost,
        onSubmit,
        canSubmit,
        isSubmitting,
        isEditMode,
    }) => {
        return (
            <div className="w-72 bg-white border-r border-slate-200 flex flex-col shrink-0">
                <div className="p-4 border-b border-slate-100">
                    <h3 className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                        פוליסות שנוספו ({policies.length})
                    </h3>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-2 custom-scrollbar">
                    {policies.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-center opacity-40 space-y-3">
                            <div
                                className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center"
                                aria-hidden="true"
                            >
                                <ShieldCheck className="w-6 h-6 text-slate-400" />
                            </div>
                            <p className="text-[10px] font-bold leading-relaxed text-slate-500">
                                טרם נוספו פוליסות
                                <br />
                                אנא בחר חברה וכיסוי משמאל
                            </p>
                        </div>
                    ) : (
                        policies.map((p, idx) => (
                            <div
                                key={p.id}
                                className={`p-2.5 rounded-lg border flex justify-between items-center group animate-fadeIn transition-all ${
                                    editingIdx === idx
                                        ? 'bg-sky-50 border-sky-200 shadow-sm'
                                        : 'bg-slate-50 border-slate-100'
                                }`}
                            >
                                <div className="text-right">
                                    <div className="font-bold text-[11px] text-slate-900 leading-tight">
                                        {p.company}
                                    </div>
                                    <div className="text-[10px] text-sky-600 font-bold">
                                        {
                                            INSURANCE_TYPE_LABELS[
                                                p.type as keyof typeof INSURANCE_TYPE_LABELS
                                            ]
                                        }
                                    </div>
                                    <div className="text-[9px] text-slate-400 mt-0.5 font-medium">
                                        {(() => {
                                            if (isFinancialType(p.type)) {
                                                return `צבירה: ₪${(p.details?.accumulation || 0).toLocaleString()}`;
                                            }
                                            if (p.type === 'elementary') {
                                                const scope = p.details?.manualElementaryScope || 0;
                                                return `עמלה: ₪${scope.toLocaleString()}`;
                                            }
                                            if (p.type === 'abroad') {
                                                return `עמלה: ₪${(p.monthlyCost || 0).toLocaleString()}`;
                                            }
                                            return `₪${(p.monthlyCost || 0).toLocaleString()}`;
                                        })()}
                                    </div>
                                    {p.type === INSURANCE_TYPE.HEALTH && (
                                        <PolicyCoversList
                                            subPolicies={p.details?.subPolicies}
                                            variant="sky"
                                        />
                                    )}
                                </div>
                                <div className="flex flex-col gap-1">
                                    <button
                                        onClick={() => onEdit(idx)}
                                        aria-label={`ערוך פוליסת ${p.company}`}
                                        className={`w-7 h-7 flex items-center justify-center rounded-lg transition-all ${
                                            editingIdx === idx
                                                ? 'bg-sky-500 text-white'
                                                : 'text-slate-300 hover:text-sky-500 hover:bg-sky-50'
                                        }`}
                                    >
                                        <Pencil className="w-3.5 h-3.5" aria-hidden="true" />
                                    </button>
                                    <button
                                        onClick={() => onRemove(idx)}
                                        aria-label={`מחק פוליסת ${p.company}`}
                                        className="w-7 h-7 flex items-center justify-center text-slate-300 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all"
                                    >
                                        <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                                    </button>
                                </div>
                            </div>
                        ))
                    )}
                </div>
                <div className="p-6 border-t border-slate-100 bg-slate-50/50">
                    <div className="flex justify-between items-center mb-5">
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                            סה״כ פרמיה:
                        </span>
                        <span className="text-lg font-black text-slate-900 tabular-nums">
                            ₪{totalCost.toLocaleString()}
                        </span>
                    </div>
                    <button
                        disabled={!canSubmit || isSubmitting}
                        onClick={onSubmit}
                        className="w-full py-4 bg-slate-900 text-white font-bold rounded-2xl shadow-lg shadow-slate-900/20 hover:bg-blue-600 disabled:opacity-30 disabled:bg-slate-300 active:scale-[0.98] transition-all text-sm flex items-center justify-center gap-2"
                    >
                        {isSubmitting
                            ? 'שומר...'
                            : isEditMode
                              ? 'סיימתי ומעדכן'
                              : 'סיימתי והוספתי ללקוח'}
                        {!isSubmitting && <CheckCircle2 className="w-4 h-4" aria-hidden="true" />}
                    </button>
                </div>
            </div>
        );
    },
);

interface AddFamilyMemberModalProps {
    onClose: () => void;
    onSubmit: (fm: FamilyMember) => void | Promise<void>;
    profile: UserProfile;
    initialLastName: string;
    initialFamilyMember?: FamilyMember;
    parentCreationType?: 'existing' | 'new_production';
}

export const AddFamilyMemberModal: React.FC<AddFamilyMemberModalProps> = ({
    onClose,
    onSubmit,
    profile,
    initialLastName,
    initialFamilyMember,
    parentCreationType,
}) => {
    const isEditMode = !!initialFamilyMember;
    const [form, setForm] = useState<FamilyMember>(
        initialFamilyMember || {
            id: '',
            firstName: '',
            lastName: initialLastName,
            issueDate: '',
            relationship: 'child',
            policies: [],
            isPremiumSharedWithPrimary: false,
        },
    );

    const activeInsuranceTypes = useMemo(() => {
        const types = new Set<InsuranceType>();
        getSelectedCompanies(profile.agreements).forEach((company: string) => {
            const companyAgreements = profile.agreements[company] || {};
            (Object.keys(companyAgreements) as InsuranceType[]).forEach((type) => {
                const agreement = companyAgreements[type];
                if (agreement && (agreement.isActive || agreement.scope || agreement.ongoing)) {
                    types.add(type);
                }
            });
        });
        return (Object.keys(INSURANCE_TYPE_LABELS) as InsuranceType[]).filter((t) => types.has(t));
    }, [profile]);

    const [activeTab, setActiveTab] = useState<InsuranceType>(activeInsuranceTypes[0] || 'health');
    const [editingPolicyIdx, setEditingPolicyIdx] = useState<number | null>(null);

    const [currentInputs, setCurrentInputs] = useState<Partial<Policy>>({
        company: '',
        monthlyCost: 0,
        isAgentAppointmentOnly: false,
        premiumSchedule: [],
        details: { subPolicies: {} },
        status: 'active',
    });

    const handleEditPolicy = useCallback(
        (idx: number) => {
            if (editingPolicyIdx === idx) {
                setEditingPolicyIdx(null);
                setCurrentInputs({
                    company: '',
                    monthlyCost: 0,
                    isAgentAppointmentOnly: false,
                    premiumSchedule: [],
                    details: { subPolicies: {} },
                    status: 'active',
                });
                return;
            }
            const p = form.policies[idx];
            if (!p) return;
            setActiveTab(p.type as InsuranceType);
            setCurrentInputs({
                company: p.company,
                monthlyCost: p.monthlyCost,
                isAgentAppointmentOnly: p.isAgentAppointmentOnly,
                premiumSchedule: p.details?.premiumSchedule || p.premiumSchedule || [],
                excelColumns: p.details?.excelColumns || p.excelColumns || [],
                issueDate: p.issueDate,
                details: p.details || { subPolicies: {} },
            });
            setEditingPolicyIdx(idx);
        },
        [form.policies, editingPolicyIdx],
    );

    const handleAddPolicyToForm = useCallback(() => {
        let monthlyCost = currentInputs.monthlyCost || 0;
        if (isIndividualType(activeTab) && currentInputs.details?.subPolicies) {
            monthlyCost = Object.values(
                currentInputs.details.subPolicies as Record<string, number>,
            ).reduce((a, b) => a + (Number(b) || 0), 0);
        }
        if (
            monthlyCost === 0 &&
            currentInputs.premiumSchedule &&
            currentInputs.premiumSchedule.length > 0
        ) {
            monthlyCost = currentInputs.premiumSchedule[0].premium;
        }
        if (!currentInputs.company) return;

        const updatedPolicy: Policy = {
            id:
                editingPolicyIdx !== null
                    ? form.policies[editingPolicyIdx].id
                    : Math.random().toString(36).substring(2, 11),
            type: activeTab,
            company: currentInputs.company,
            monthlyCost,
            issueDate: form.issueDate || currentInputs.issueDate || new Date().toISOString(),
            premiumSchedule: currentInputs.premiumSchedule || [],
            excelColumns: currentInputs.excelColumns || [],
            isAgentAppointmentOnly: !!currentInputs.isAgentAppointmentOnly,
            details: {
                ...(currentInputs.details || { subPolicies: {} }),
                premiumSchedule: currentInputs.premiumSchedule || [],
                excelColumns: currentInputs.excelColumns || [],
            },
            status: 'active',
        };

        setForm((prev) => {
            const policies =
                editingPolicyIdx !== null
                    ? prev.policies.map((p, i) => (i === editingPolicyIdx ? updatedPolicy : p))
                    : [...prev.policies, updatedPolicy];
            return { ...prev, policies };
        });

        setEditingPolicyIdx(null);
        setCurrentInputs({
            company: '',
            monthlyCost: 0,
            isAgentAppointmentOnly: false,
            premiumSchedule: [],
            details: { subPolicies: {} },
            status: 'active',
        });
    }, [activeTab, currentInputs, editingPolicyIdx, form.issueDate, form.policies]);

    const deferredForm = useDeferredValue(form);
    const totalCost = useMemo(
        () => deferredForm.policies.reduce((sum, p) => sum + p.monthlyCost, 0),
        [deferredForm.policies],
    );

    const handleRemovePolicy = useCallback(
        (idx: number) => {
            if (editingPolicyIdx === idx) {
                setEditingPolicyIdx(null);
                setCurrentInputs({
                    company: '',
                    monthlyCost: 0,
                    isAgentAppointmentOnly: false,
                    premiumSchedule: [],
                    details: { subPolicies: {} },
                });
            }
            setForm((prev) => ({
                ...prev,
                policies: prev.policies.filter((_, i) => i !== idx),
            }));
        },
        [editingPolicyIdx],
    );

    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleFullSubmit = useCallback(async () => {
        setIsSubmitting(true);
        try {
            await onSubmit(form);
        } finally {
            setIsSubmitting(false);
        }
    }, [form, onSubmit]);

    const targetDate = useMemo(
        () => ({
            month: new Date().getMonth() + 1,
            year: new Date().getFullYear(),
        }),
        [],
    );

    const modalId = 'add-family-member-modal-title';

    return createPortal(
        <div
            role="dialog"
            aria-modal="true"
            aria-labelledby={modalId}
            className="fixed inset-0 z-[110] flex items-center justify-center p-6 bg-slate-900/60"
            dir="rtl"
            onKeyDown={(e) => e.key === Keys.Escape && onClose()}
        >
            <div className="bg-slate-50 w-full max-w-7xl max-h-[92vh] rounded-3xl shadow-xl flex flex-col overflow-hidden border border-slate-200 animate-fadeIn">
                {/* Modal Header */}
                <div className="p-5 border-b border-slate-200 flex justify-between items-center bg-white shrink-0">
                    <h2
                        id={modalId}
                        className="text-xl font-black text-slate-900 flex items-center gap-3"
                    >
                        <span
                            aria-hidden="true"
                            className={`w-8 h-8 rounded-lg flex items-center justify-center shadow-sm ${isEditMode ? 'bg-indigo-600' : 'bg-indigo-500'}`}
                        >
                            {isEditMode ? (
                                <Pencil className="w-4 h-4 text-white" />
                            ) : (
                                <HeartHandshake className="w-5 h-5 text-white" />
                            )}
                        </span>
                        {isEditMode
                            ? `עריכת בן משפחה — ${form.firstName} ${form.lastName}`
                            : 'הוספת בן משפחה'}
                    </h2>
                    <div className="flex items-center gap-2">
                        <button
                            onClick={onClose}
                            aria-label="סגור"
                            className="p-2 hover:bg-slate-100 rounded-full transition-standard text-slate-400"
                        >
                            <X className="w-5 h-5" aria-hidden="true" />
                        </button>
                    </div>
                </div>

                {/* Top Bar - Personal Details (Replicated) */}
                <FamilyDetailsSection form={form} setForm={setForm} />

                <div className="flex-1 overflow-hidden flex">
                    {/* Main Content - Left Area (Policy Configurator) */}
                    <div className="flex-1 overflow-y-auto p-10 space-y-6 scroll-smooth custom-scrollbar">
                        {/* Editing banner */}
                        {editingPolicyIdx !== null && (
                            <div className="bg-amber-50 border-2 border-amber-200 rounded-2xl p-4 flex items-center gap-4 animate-slideDown">
                                <span className="text-lg" aria-hidden="true">
                                    ✏️
                                </span>
                                <div>
                                    <div className="font-black text-slate-900">
                                        מצב עריכת פוליסה פעיל
                                    </div>
                                    <div className="text-[11px] font-medium text-amber-600 mt-0.5">
                                        לאחר עדכון הנתונים, לחץ על{' '}
                                        <span className="bg-amber-200 px-1.5 py-0.5 rounded font-black">
                                            עדכן פוליסה ✓
                                        </span>{' '}
                                        כדי להחיל את השינויים
                                    </div>
                                </div>
                            </div>
                        )}

                        <PolicyConfigurator
                            activeTab={activeTab}
                            setActiveTab={setActiveTab}
                            profile={profile}
                            currentInputs={currentInputs}
                            setCurrentInputs={setCurrentInputs}
                            onAddPolicy={handleAddPolicyToForm}
                            buttonLabel={
                                editingPolicyIdx !== null
                                    ? 'עדכן פוליסה ✓'
                                    : 'הוסף פוליסה ספציפית זו'
                            }
                            layout="t-shape"
                            customerIssueDate={deferredForm.issueDate}
                            targetMonth={targetDate.month}
                            targetYear={targetDate.year}
                            allowedTabs={['health', 'life', 'critical_illness']}
                            creationType={parentCreationType}
                        />
                    </div>

                    {/* Right Sidebar - Policies List */}
                    <FamilySidebarSection
                        policies={deferredForm.policies}
                        onRemove={handleRemovePolicy}
                        onEdit={handleEditPolicy}
                        editingIdx={editingPolicyIdx}
                        totalCost={totalCost}
                        onSubmit={handleFullSubmit}
                        canSubmit={
                            !!(form.id && form.id.trim() && form.firstName && form.firstName.trim())
                        }
                        isSubmitting={isSubmitting}
                        isEditMode={isEditMode}
                    />
                </div>
            </div>
        </div>,
        document.body,
    );
};
