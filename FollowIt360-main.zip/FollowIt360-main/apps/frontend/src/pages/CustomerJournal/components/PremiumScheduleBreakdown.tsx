import { PremiumScheduleItem } from '@repo/types';
import { Calendar, ChevronDown, Table as TableIcon, Trash2 } from 'lucide-react';
import React, { useState } from 'react';

interface PremiumScheduleBreakdownProps {
    premiumSchedule?: PremiumScheduleItem[];
    subPolicies?: Record<string, number>;
    currentAge: number;
    onReset: () => void;
    onDeleteSubPolicy?: (key: string) => void;
    insuranceType?: string;
}

export const PremiumScheduleBreakdown: React.FC<PremiumScheduleBreakdownProps> = React.memo(({
    premiumSchedule,
    subPolicies,
    currentAge,
    onReset,
    onDeleteSubPolicy,
    insuranceType,
}) => {
    const [showFullTable, setShowFullTable] = useState(false);

    // Calculate current age premium
    const relevantScheduleItem = premiumSchedule?.find(item => item.age === currentAge);
    const monthlyTotal = relevantScheduleItem 
        ? relevantScheduleItem.premium 
        : (premiumSchedule && premiumSchedule.length > 0 ? premiumSchedule[0].premium : 0);

    if (showFullTable) {
        return (
            <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-4 animate-fadeIn">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <h5 className="text-[11px] font-bold text-slate-900 flex items-center gap-2">
                        <TableIcon className="w-4 h-4 text-emerald-500" aria-hidden="true" /> וידוא ופענוח נתונים
                    </h5>
                    <button
                        onClick={onReset}
                        className="text-[10px] font-bold text-rose-500 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500/50 rounded px-1"
                    >
                        מחיקת טבלה
                    </button>
                </div>

                <div className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-sm animate-fadeIn">
                    <div className="p-3 border-b border-slate-100 flex justify-between items-center bg-slate-50 text-right">
                        <span className="text-[10px] font-bold text-slate-500 uppercase">
                            טבלת התפתחות פרמיה מלאה ({premiumSchedule?.length || 0} שורות)
                        </span>
                        <button
                            onClick={() => setShowFullTable(false)}
                            className="text-[10px] font-bold text-sky-600 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500/50 rounded p-1"
                        >
                            חזרה לתצוגה ממוקדת
                        </button>
                    </div>
                    <div className="overflow-x-auto max-h-[300px] custom-scrollbar">
                        <table
                            className="w-full text-right text-[10px] min-w-[300px] border-collapse"
                            dir="rtl"
                        >
                            <thead className="bg-slate-50 text-slate-400 font-bold border-b border-slate-100 sticky top-0 z-20">
                                <tr>
                                    <th className="p-2 px-4 bg-slate-50">גיל</th>
                                    <th className="p-2 px-4 bg-slate-50">פרמיה חודשית</th>
                                </tr>
                            </thead>
                            <tbody className="text-slate-700 font-medium">
                                {premiumSchedule?.map((row, i) => {
                                    const isCurrentAge = row.age === currentAge;
                                    return (
                                        <tr
                                            key={i}
                                            className={`border-t border-slate-50 hover:bg-slate-50/50 transition-colors ${
                                                isCurrentAge ? 'bg-sky-50 ring-2 ring-sky-200 ring-inset relative z-10 font-bold' : ''
                                            }`}
                                        >
                                            <td className={`p-2 px-4 ${isCurrentAge ? 'font-black text-slate-900 bg-slate-50/50' : 'text-slate-500'}`}>
                                                {row.age}
                                                {isCurrentAge && (
                                                    <span className="sr-only"> (הגיל הנוכחי של הלקוח)</span>
                                                )}
                                            </td>
                                            <td className={`p-2 px-4 ${isCurrentAge ? 'font-black text-sky-600 bg-sky-50' : 'text-slate-500'}`}>
                                                ₪{row.premium.toLocaleString(undefined, { maximumFractionDigits: 1 })}
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h5 className="text-[11px] font-bold text-slate-900 flex items-center gap-2">
                    <TableIcon className="w-4 h-4 text-emerald-500" aria-hidden="true" /> וידוא ופענוח נתונים
                </h5>
                <button
                    onClick={onReset}
                    className="text-[10px] font-bold text-rose-500 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500/50 rounded px-1"
                >
                    מחיקת טבלה
                </button>
            </div>

            <div className="bg-sky-50/50 border border-sky-100 rounded-2xl p-5 animate-slideDown shadow-sm">
                <div className="flex justify-between items-start mb-4 text-right border-b border-sky-100 pb-3">
                    <div className="space-y-1">
                        <div className="text-[10px] font-black text-sky-600 uppercase tracking-widest text-right">
                            תצוגה ממוקדת: גיל {currentAge}
                        </div>
                        <h4 className="text-sm font-bold text-slate-900 text-right">
                            פירוט כיסויים ופרמיה
                        </h4>
                    </div>
                    {premiumSchedule && premiumSchedule.length > 0 && (
                        <button
                            onClick={() => setShowFullTable(true)}
                            aria-expanded={showFullTable}
                            className="bg-white px-3 py-1.5 rounded-lg border border-slate-200 text-[10px] font-bold text-slate-500 hover:text-sky-600 hover:border-sky-200 transition-all flex items-center gap-1.5 shadow-sm active:scale-95 animate-fadeIn focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500/50"
                        >
                            הצג טבלה מלאה <ChevronDown className="w-3 h-3" aria-hidden="true" />
                        </button>
                    )}
                </div>

                <div className="space-y-4">
                    {subPolicies && Object.keys(subPolicies).length > 0 ? (
                        <div className="bg-white rounded-xl border border-slate-100 divide-y divide-slate-50 shadow-sm overflow-hidden">
                            {Object.entries(subPolicies).map(([key, val]) => (
                                <div
                                    key={key}
                                    className="flex justify-between items-center p-3 hover:bg-slate-50/50 transition-colors"
                                >
                                    <span className="text-xs font-bold text-slate-600 flex items-center gap-2">
                                        {insuranceType === 'health' && onDeleteSubPolicy && (
                                            <button
                                                type="button"
                                                onClick={() => onDeleteSubPolicy(key)}
                                                aria-label={`הסר כיסוי ${key}`}
                                                className="text-slate-300 hover:text-rose-500 transition-colors p-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500/50 rounded"
                                            >
                                                <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                                            </button>
                                        )}
                                        {key}
                                    </span>
                                    <span className="text-xs font-black text-slate-900 tabular-nums">
                                        ₪
                                        {parseFloat(
                                            String(val).replace(/[^\d.]/g, '') || '0',
                                        ).toLocaleString(undefined, {
                                            maximumFractionDigits: 1,
                                        })}
                                    </span>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="bg-white rounded-xl border border-slate-100 p-4 text-center text-xs text-slate-400 font-bold">
                            אין פירוט כיסויים זמין לפוליסה זו
                        </div>
                    )}

                    <div className="bg-sky-600 rounded-xl p-4 text-white flex justify-between items-center shadow-lg shadow-sky-600/20">
                        <div className="flex items-center gap-3">
                            <div className="bg-white/20 p-2 rounded-lg" aria-hidden="true">
                                <Calendar className="w-4 h-4 text-white" />
                            </div>
                            <div>
                                <div className="text-[10px] font-bold text-white/70 uppercase">
                                    סה״כ חודשי (משוקלל)
                                </div>
                                <div className="text-[9px] text-white/50">
                                    עדכון אוטומטי לגיל {currentAge + 1} בשנה הבאה
                                </div>
                            </div>
                        </div>
                        <div className="text-xl font-black text-white tabular-nums leading-none">
                            ₪
                            {monthlyTotal.toLocaleString(undefined, {
                                maximumFractionDigits: 1,
                            })}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
});

PremiumScheduleBreakdown.displayName = 'PremiumScheduleBreakdown';
