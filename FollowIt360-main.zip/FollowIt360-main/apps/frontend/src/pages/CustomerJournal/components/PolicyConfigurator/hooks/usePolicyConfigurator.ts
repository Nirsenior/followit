import {
    ELEMENTARY_COMPANIES,
    ELEMENTARY_OPTIONS,
    GEMEL_COMPANIES,
    GEMEL_INVEST_COMPANIES,
    HISHTALMUT_COMPANIES,
    INDIVIDUAL_POLICY_COMPANIES,
    INSURANCE_TYPE_LABELS,
    InsuranceType,
    PENSION_COMPANIES,
    POLIS_COMPANIES,
    PremiumScheduleItem,
    UserProfile,
    isFinancialType,
    isIndividualType,
} from '@repo/types';
import { useQuery } from '@tanstack/react-query';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { fetchYieldsTracks } from '../../../../../api/yields';
import { getSelectedCompanies } from '../../../../../utils/profileUtils';

interface UsePolicyConfiguratorProps {
    activeTab: InsuranceType;
    profile: UserProfile;
    currentInputs: any;
    setCurrentInputs: (i: any) => void;
    onAddPolicy: () => void;
    allowedTabs?: InsuranceType[];
}

export interface UsePolicyConfiguratorReturn {
    // state
    elementaryCategory: keyof typeof ELEMENTARY_OPTIONS;
    setElementaryCategory: (cat: keyof typeof ELEMENTARY_OPTIONS) => void;
    isCommsApproved: boolean;
    setIsCommsApproved: (v: boolean) => void;
    // handlers
    handleScheduleParsed: (sched: PremiumScheduleItem[], cols: string[], firstRawRow?: any) => void;
    handleResetSchedule: () => void;
    handleUpdateSubPolicy: (sub: string, val: number) => void;
    handleUpdateManualComm: (
        field: 'manualElementaryScope' | 'manualElementaryOngoing',
        val: number,
    ) => void;
    handleUpdateDetail: (field: string, val: any) => void;
    handleUpdateTracks: (track: string, weight: number, fundId?: number) => void;
    handleDeleteSubPolicy: (key: string) => void;
    handleAdd: () => void;
    // derived
    activeInsuranceTypes: InsuranceType[];
    filteredCompaniesUnderTab: string[];
    shouldShowComms: boolean;
    fetchedTracks: Array<{ trackName: string; fundId: number }> | undefined;
    isLoadingTracks: boolean;
}

export function usePolicyConfigurator({
    activeTab,
    profile,
    currentInputs,
    setCurrentInputs,
    onAddPolicy,
    allowedTabs,
}: UsePolicyConfiguratorProps): UsePolicyConfiguratorReturn {
    const [elementaryCategory, setElementaryCategory] =
        useState<keyof typeof ELEMENTARY_OPTIONS>('רכב');
    const [isCommsApproved, setIsCommsApproved] = useState(false);

    const handleScheduleParsed = useCallback(
        (sched: PremiumScheduleItem[], cols: string[], firstRawRow?: any) => {
            const totalPatterns = [
                'עלות ביטוח',
                'עלות חודשית',
                'עלות כוללת',
                'סה"כ',
                'סך הכל',
                'סה״כ',
                'total',
                'Total',
                'סכום לתשלום',
                'סיכום',
                'פרמיה',
                'לתשלום',
            ];
            const agePatterns = ['גיל', 'age', 'Age', 'סכום ביטוח', 'סכום כיסוי', 'סכום'];

            setCurrentInputs((prev: any) => {
                const firstRow = firstRawRow || (sched[0] as Record<string, any>) || {};
                const newSubPolicies: Record<string, number> = {};

                // Extract all valid numeric components for the breakdown
                const numericCols = cols.filter((col) => {
                    const k = col.trim();
                    const val = firstRow[col];

                    // Exclude ANY column that is a total or sub-total (e.g. סה"כ כיסויי בסיס)
                    if (totalPatterns.some((p) => col.includes(p))) return false;

                    // Exclude age columns
                    if (agePatterns.some((p) => k.includes(p))) return false;

                    const num =
                        typeof val === 'number'
                            ? val
                            : parseFloat(String(val).replace(/[^\d.]/g, '')) || 0;
                    return num > 0 && num < 10000;
                });

                // Populate the subPolicies dictionary with everything found
                numericCols.forEach((col) => {
                    const val = firstRow[col];
                    newSubPolicies[col] =
                        typeof val === 'number'
                            ? val
                            : parseFloat(String(val).replace(/[^\d.]/g, '')) || 0;
                });

                return {
                    ...prev,
                    premiumSchedule: sched,
                    excelColumns: cols,
                    details: {
                        ...prev.details,
                        subPolicies: newSubPolicies,
                    },
                };
            });
            setIsCommsApproved(true);
        },
        [setCurrentInputs],
    );

    const handleResetSchedule = useCallback(() => {
        setCurrentInputs((prev: any) => ({ ...prev, premiumSchedule: [], excelColumns: [] }));
        setIsCommsApproved(false);
    }, [setCurrentInputs]);

    useEffect(() => {
        const hasSchedule = !!(currentInputs?.premiumSchedule && currentInputs.premiumSchedule.length > 0);
        setIsCommsApproved(hasSchedule);
    }, [currentInputs?.premiumSchedule]);

    useEffect(() => {
        if (activeTab === 'elementary') {
            // Any initialization logic for elementary
        }
    }, [activeTab, currentInputs.id]);

    const handleUpdateSubPolicy = useCallback(
        (sub: string, val: number) => {
            setCurrentInputs((prev: any) => ({
                ...prev,
                details: {
                    ...prev.details,
                    subPolicies: { ...prev.details.subPolicies, [sub]: val },
                },
            }));
        },
        [setCurrentInputs],
    );

    const handleUpdateManualComm = useCallback(
        (field: 'manualElementaryScope' | 'manualElementaryOngoing', val: number) => {
            setCurrentInputs((prev: any) => ({
                ...prev,
                details: {
                    ...prev.details,
                    [field]: val,
                },
            }));
        },
        [setCurrentInputs],
    );

    const handleUpdateDetail = useCallback(
        (field: string, val: any) => {
            setCurrentInputs((prev: any) => {
                const newDetails = { ...prev.details, [field]: val };

                // Sync logic for mobility performed
                if (field === 'accumulation' && prev.details.mobilityPerformed) {
                    newDetails.mobility = val;
                }

                if (field === 'mobilityPerformed') {
                    if (val) {
                        newDetails.mobility = prev.details.accumulation || 0;
                    } else {
                        newDetails.mobility = 0;
                    }
                }

                return {
                    ...prev,
                    details: newDetails,
                };
            });
        },
        [setCurrentInputs],
    );

    const handleUpdateTracks = useCallback(
        (track: string, weight: number, fundId?: number) => {
            setCurrentInputs((prev: any) => {
                const tracks = [...(prev.details.investmentTracks || [])].filter((t: any) =>
                    fundId && t.fundId ? t.fundId !== fundId : t.trackName !== track,
                );
                if (weight > 0) tracks.push({ trackName: track, weight, fundId });
                return {
                    ...prev,
                    details: {
                        ...prev.details,
                        investmentTracks: tracks,
                    },
                };
            });
        },
        [setCurrentInputs],
    );

    const handleDeleteSubPolicy = useCallback(
        (sub: string) => {
            setCurrentInputs((prev: any) => {
                const subPolicies = { ...prev.details?.subPolicies };
                const deletedVal = subPolicies[sub] || 0;
                delete subPolicies[sub];

                const oldSum = Object.values(prev.details?.subPolicies || {}).reduce(
                    (a: number, b: any) => a + (parseFloat(b) || 0),
                    0,
                ) as number;

                let updatedSchedule = prev.premiumSchedule || [];
                let updatedMonthlyCost = prev.monthlyCost || 0;

                if (oldSum > 0) {
                    const ratio = (oldSum - deletedVal) / oldSum;
                    updatedSchedule = updatedSchedule.map((item: any) => ({
                        ...item,
                        premium: item.premium * ratio,
                    }));
                    updatedMonthlyCost = updatedMonthlyCost * ratio;
                } else {
                    updatedMonthlyCost = Math.max(0, updatedMonthlyCost - deletedVal);
                }

                return {
                    ...prev,
                    monthlyCost: updatedMonthlyCost,
                    premiumSchedule: updatedSchedule,
                    details: {
                        ...prev.details,
                        subPolicies,
                    },
                };
            });
        },
        [setCurrentInputs],
    );

    const handleAdd = useCallback(() => {
        onAddPolicy();
    }, [onAddPolicy]);

    const activeInsuranceTypes = useMemo(() => {
        const types = new Set<InsuranceType>();
        getSelectedCompanies(profile.agreements).forEach((company: string) => {
            const companyAgreements = profile.agreements[company] || {};
            (Object.keys(companyAgreements) as InsuranceType[]).forEach((type) => {
                const agreement = companyAgreements[type];
                if (
                    agreement &&
                    (agreement.isActive ||
                        agreement.scope ||
                        agreement.ongoing ||
                        agreement.mobility)
                ) {
                    types.add(type);
                }
            });
        });
        const allActive = (Object.keys(INSURANCE_TYPE_LABELS) as InsuranceType[]).filter((t) =>
            types.has(t),
        );
        if (allowedTabs && allowedTabs.length > 0) {
            return allActive.filter((t) => allowedTabs.includes(t));
        }
        return allActive;
    }, [profile, allowedTabs]);

    const filteredCompaniesUnderTab = useMemo(() => {
        return getSelectedCompanies(profile.agreements).filter((company: string) => {
            // Rule: Companies in ELEMENTARY_COMPANIES ONLY sell elementary
            if (activeTab !== 'elementary' && ELEMENTARY_COMPANIES.includes(company)) {
                return false;
            }

            const agreement = profile.agreements[company]?.[activeTab];
            const isActivated =
                agreement &&
                (agreement.isActive || agreement.scope || agreement.ongoing || agreement.mobility);

            if (!isActivated) return false;

            if (isIndividualType(activeTab)) {
                return INDIVIDUAL_POLICY_COMPANIES.includes(company);
            }

            if (isFinancialType(activeTab)) {
                if (activeTab === 'pension') return PENSION_COMPANIES.includes(company);
                if (activeTab === 'gemel') return GEMEL_COMPANIES.includes(company);
                if (activeTab === 'hishtalmut') return HISHTALMUT_COMPANIES.includes(company);
                if (activeTab === 'gemel_invest') return GEMEL_INVEST_COMPANIES.includes(company);
                if (activeTab === 'long_term_savings') return POLIS_COMPANIES.includes(company);
            }

            return true;
        });
    }, [profile, activeTab]);

    const shouldShowComms =
        isCommsApproved ||
        activeTab === 'elementary' ||
        isFinancialType(activeTab) ||
        activeTab === 'abroad';

    const { data: fetchedTracks, isLoading: isLoadingTracks } = useQuery({
        queryKey: ['tracks', activeTab, currentInputs.company],
        queryFn: () => fetchYieldsTracks(activeTab, currentInputs.company),
        enabled: !!currentInputs.company && isFinancialType(activeTab),
        staleTime: 60 * 60 * 1000, // 1 hour
    });

    return {
        elementaryCategory,
        setElementaryCategory,
        isCommsApproved,
        setIsCommsApproved,
        handleScheduleParsed,
        handleResetSchedule,
        handleUpdateSubPolicy,
        handleUpdateManualComm,
        handleUpdateDetail,
        handleUpdateTracks,
        handleDeleteSubPolicy,
        handleAdd,
        activeInsuranceTypes,
        filteredCompaniesUnderTab,
        shouldShowComms,
        fetchedTracks,
        isLoadingTracks,
    };
}
