export { PolicyConfigurator } from './PolicyConfigurator';
export type { PolicyConfiguratorProps } from './PolicyConfigurator';
