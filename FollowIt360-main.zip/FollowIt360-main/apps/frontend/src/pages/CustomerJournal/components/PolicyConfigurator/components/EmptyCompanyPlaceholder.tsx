import { ShieldCheck } from 'lucide-react';
import React from 'react';

export const EmptyCompanyPlaceholder: React.FC = React.memo(() => {
    return (
        <div className="py-16 flex flex-col items-center justify-center bg-slate-50/40 rounded-3xl border-2 border-dashed border-slate-100 animate-fadeIn mt-4">
            <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-sm mb-4 border border-slate-50">
                <ShieldCheck className="w-7 h-7 text-sky-200" aria-hidden="true" />
            </div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">
                נא לבחור חברת ביטוח כדי להמשיך
            </span>
            <p className="text-[10px] text-slate-400 mt-2 font-medium">
                הזנת נתונים והעלאת אקסל יתאפשרו רק לאחר בחירת חברה
            </p>
        </div>
    );
});

EmptyCompanyPlaceholder.displayName = 'EmptyCompanyPlaceholder';
