import { INSURANCE_TYPE_LABELS } from '@repo/types';
import { UserPlus, Search } from 'lucide-react';
import React, { useEffect, useState } from 'react';

interface CustomerHeaderProps {
    setIsAddModalOpen: (val: boolean) => void;
    selectedYear: number;
    setSelectedYear: (val: number) => void;
    selectedMonth: number;
    setSelectedMonth: (val: number) => void;
    years: number[];
    months: string[];
    companyFilter: string;
    setCompanyFilter: (val: string) => void;
    productFilter: string;
    setProductFilter: (val: string) => void;
    availableCompanies: string[];
    searchQuery: string;
    setSearchQuery: (val: string) => void;
}

export const CustomerHeader: React.FC<CustomerHeaderProps> = ({
    setIsAddModalOpen,
    selectedYear,
    setSelectedYear,
    selectedMonth,
    setSelectedMonth,
    years,
    months,
    companyFilter,
    setCompanyFilter,
    productFilter,
    setProductFilter,
    availableCompanies,
    searchQuery,
    setSearchQuery,
}) => {
    // Local state for debounced search
    const [localSearch, setLocalSearch] = useState(searchQuery);

    useEffect(() => {
        const timer = setTimeout(() => {
            setSearchQuery(localSearch);
        }, 300);
        return () => clearTimeout(timer);
    }, [localSearch, setSearchQuery]);

    return (
        <header className="bg-white border-b border-slate-100 p-6 flex justify-between items-center z-20 shrink-0" aria-label="סרגל כלים וחיפוש לקוחות">
            <div className="flex items-center gap-4">
                <button
                    onClick={() => setIsAddModalOpen(true)}
                    className="bg-blue-500 text-white px-8 py-2.5 rounded-xl font-semibold flex items-center gap-2 hover:bg-blue-600 shadow-lg shadow-blue-500/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 transition-all"
                >
                    <UserPlus className="w-5 h-5" aria-hidden="true" /> הוסף לקוח
                </button>
                <div className="hidden sm:flex items-center gap-2 bg-white border border-slate-200 p-1 rounded-xl">
                    <select
                        value={selectedYear}
                        onChange={(e) => setSelectedYear(parseInt(e.target.value))}
                        aria-label="בחר שנה"
                        className="bg-white font-semibold text-sm outline-none px-2 cursor-pointer border-l border-slate-200 focus-visible:ring-2 focus-visible:ring-blue-500/50 rounded-lg"
                    >
                        <option value="-1">כל השנים</option>
                        {years.map((y) => (
                            <option key={y} value={y}>
                                {y}
                            </option>
                        ))}
                    </select>
                    <select
                        value={selectedMonth}
                        onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
                        aria-label="בחר חודש"
                        className="bg-white font-semibold text-sm outline-none px-2 cursor-pointer focus-visible:ring-2 focus-visible:ring-blue-500/50 rounded-lg"
                    >
                        <option value="-1">כל החודשים</option>
                        {months.map((m, i) => (
                            <option key={i} value={i}>
                                {m}
                            </option>
                        ))}
                    </select>
                </div>
            </div>

            <div className="flex items-center gap-4">
                <div className="hidden md:flex items-center gap-3">
                    <div className="relative group">
                        <select
                            value={companyFilter}
                            onChange={(e) => setCompanyFilter(e.target.value)}
                            aria-label="סנן לפי חברה"
                            className="appearance-none bg-slate-50 border border-slate-200 rounded-xl py-2.5 pr-10 pl-4 focus-visible:ring-2 focus-visible:ring-sky-500/50 focus-visible:border-sky-500 outline-none text-xs font-semibold text-slate-600 transition-all cursor-pointer min-w-[140px]"
                        >
                            <option value="all">כל החברות</option>
                            {availableCompanies.map((c) => (
                                <option key={c} value={c}>
                                    {c}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div className="relative group">
                        <select
                            value={productFilter}
                            onChange={(e) => setProductFilter(e.target.value)}
                            aria-label="סנן לפי מוצר"
                            className="appearance-none bg-slate-50 border border-slate-200 rounded-xl py-2.5 pr-10 pl-4 focus-visible:ring-2 focus-visible:ring-sky-500/50 focus-visible:border-sky-500 outline-none text-xs font-semibold text-slate-600 transition-all cursor-pointer min-w-[140px]"
                        >
                            <option value="all">כל המוצרים</option>
                            {Object.entries(INSURANCE_TYPE_LABELS).map(([type, label]) => (
                                <option key={type} value={type}>
                                    {label}
                                </option>
                            ))}
                        </select>
                    </div>
                </div>

                <div className="relative">
                    <input
                        type="text"
                        placeholder="חיפוש לפי שם או ת״ז..."
                        value={localSearch}
                        onChange={(e) => setLocalSearch(e.target.value)}
                        aria-label="חיפוש לפי שם או תעודת זהות"
                        className="bg-white border border-slate-200 rounded-xl py-2.5 pr-11 pl-4 focus-visible:ring-2 focus-visible:ring-sky-500/50 focus-visible:border-sky-500 outline-none text-sm w-72 transition-all text-right"
                    />
                    <Search className="absolute right-4 top-3 w-4 h-4 text-slate-400" aria-hidden="true" />
                </div>
            </div>
        </header>
    );
};
