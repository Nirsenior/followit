import React from 'react';

export const PersonalDetailsSection: React.FC<{
    form: any;
    setForm: (f: any) => void;
}> = React.memo(({ form, setForm }) => {
    return (
        <div className="px-10 py-8 bg-white border-b border-slate-100 shrink-0 font-sans">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div className="space-y-1.5">
                    <label htmlFor="customer-firstName" className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mr-1">
                        שם פרטי
                    </label>
                    <input
                        id="customer-firstName"
                        type="text"
                        value={form.firstName}
                        onChange={(e) => setForm({ ...form, firstName: e.target.value })}
                        className="w-full p-3.5 border border-slate-200 rounded-2xl outline-none text-slate-900 font-bold bg-slate-50/50 focus-visible:bg-white focus-visible:border-blue-500 focus-visible:ring-2 focus-visible:ring-blue-500/50 transition-all text-sm"
                        placeholder="ישראל"
                    />
                </div>
                <div className="space-y-1.5">
                    <label htmlFor="customer-lastName" className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mr-1">
                        שם משפחה
                    </label>
                    <input
                        id="customer-lastName"
                        type="text"
                        value={form.lastName}
                        onChange={(e) => setForm({ ...form, lastName: e.target.value })}
                        className="w-full p-3.5 border border-slate-200 rounded-2xl outline-none text-slate-900 font-bold bg-slate-50/50 focus-visible:bg-white focus-visible:border-blue-500 focus-visible:ring-2 focus-visible:ring-blue-500/50 transition-all text-sm"
                        placeholder="ישראלי"
                    />
                </div>
                <div className="space-y-1.5">
                    <label htmlFor="customer-id" className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mr-1">
                        תעודת זהות
                    </label>
                    <input
                        id="customer-id"
                        type="text"
                        value={form.id}
                        onChange={(e) => setForm({ ...form, id: e.target.value })}
                        className="w-full p-3.5 border border-slate-200 rounded-2xl outline-none text-slate-900 font-bold bg-slate-50/50 focus-visible:bg-white focus-visible:border-blue-500 focus-visible:ring-2 focus-visible:ring-blue-500/50 transition-all text-sm"
                        placeholder="000000000"
                    />
                </div>
                <div className="space-y-1.5">
                    <label htmlFor="customer-issueDate" className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mr-1">
                        תאריך הפקה כללי
                    </label>
                    <input
                        id="customer-issueDate"
                        type="date"
                        value={form.issueDate || ''}
                        onChange={(e) => {
                            const newDate = e.target.value;
                            setForm({
                                ...form,
                                issueDate: newDate,
                                policies: form.policies.map(p => ({ ...p, issueDate: newDate }))
                            });
                        }}
                        className="w-full p-3.5 border border-slate-200 rounded-2xl outline-none text-slate-900 font-bold bg-slate-50/50 focus-visible:bg-white focus-visible:border-blue-500 focus-visible:ring-2 focus-visible:ring-blue-500/50 transition-all text-sm"
                    />
                </div>
            </div>
        </div>
    );
});

PersonalDetailsSection.displayName = 'PersonalDetailsSection';
