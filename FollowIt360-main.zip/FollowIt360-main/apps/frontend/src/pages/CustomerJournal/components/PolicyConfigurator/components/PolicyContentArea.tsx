import {
    ELEMENTARY_OPTIONS,
    InsuranceType,
    isFinancialType,
    isIndividualType,
    PremiumScheduleItem,
    UserProfile,
} from '@repo/types';
import React from 'react';
import { ExcelPremiumUploader } from '../../ExcelPremiumUploader';
import { AbroadManualEntry } from './AbroadManualEntry';
import { ElementaryManualEntry } from './ElementaryManualEntry';
import { EmptyCompanyPlaceholder } from './EmptyCompanyPlaceholder';
import { FinancialManualEntry } from './FinancialManualEntry';
import { LiveCommsDisplay } from './LiveCommsDisplay';

interface PolicyContentAreaProps {
    activeTab: InsuranceType;
    currentInputs: any;
    setCurrentInputs: (i: any) => void;
    profile: UserProfile;
    shouldShowComms: boolean;
    elementaryCategory: keyof typeof ELEMENTARY_OPTIONS;
    setElementaryCategory: (c: keyof typeof ELEMENTARY_OPTIONS) => void;
    onUpdateSubPolicy: (key: string, val: number) => void;
    onUpdateManualComm: (
        field: 'manualElementaryScope' | 'manualElementaryOngoing',
        val: number,
    ) => void;
    onUpdateDetail: (field: string, val: any) => void;
    onUpdateTracks: (track: string, weight: number, fundId?: number) => void;
    onScheduleParsed: (sched: PremiumScheduleItem[], cols: string[], firstRawRow?: any) => void;
    onResetSchedule: () => void;
    onDeleteSubPolicy: (key: string) => void;
    customerIssueDate?: string;
    targetMonth?: number;
    targetYear?: number;
    fetchedTracks?: Array<{ trackName: string; fundId: number }>;
    isLoadingTracks?: boolean;
    creationType?: 'existing' | 'new_production';
}

export const PolicyContentArea: React.FC<PolicyContentAreaProps> = React.memo(
    ({
        activeTab,
        currentInputs,
        setCurrentInputs,
        profile,
        shouldShowComms,
        elementaryCategory,
        setElementaryCategory,
        onUpdateSubPolicy,
        onUpdateManualComm,
        onUpdateDetail,
        onUpdateTracks,
        onScheduleParsed,
        onResetSchedule,
        onDeleteSubPolicy,
        customerIssueDate,
        targetMonth,
        targetYear,
        fetchedTracks,
        isLoadingTracks,
        creationType,
    }) => {
        if (!currentInputs.company) {
            return <EmptyCompanyPlaceholder />;
        }

        const canShowComms = shouldShowComms;

        return (
            <section className="pt-4 border-t border-slate-100" aria-label="פרטי כיסוי ופוליסה">
                {canShowComms && (
                    <LiveCommsDisplay
                        activeTab={activeTab}
                        currentInputs={currentInputs}
                        profile={profile}
                        customerIssueDate={customerIssueDate}
                        targetMonth={targetMonth}
                        targetYear={targetYear}
                        creationType={creationType}
                    />
                )}

                {isIndividualType(activeTab) && (
                    <div className="space-y-4 animate-fadeIn">
                        {!isFinancialType(activeTab) && (
                            <ExcelPremiumUploader
                                hasData={
                                    !!(
                                        currentInputs.premiumSchedule &&
                                        currentInputs.premiumSchedule.length > 0
                                    )
                                }
                                premiumSchedule={currentInputs.premiumSchedule}
                                subPolicies={currentInputs.details?.subPolicies}
                                onDeleteSubPolicy={onDeleteSubPolicy}
                                onScheduleParsed={onScheduleParsed}
                                onReset={onResetSchedule}
                                company={currentInputs.company}
                                insuranceType={activeTab}
                                customerIssueDate={customerIssueDate}
                                targetMonth={targetMonth}
                                targetYear={targetYear}
                            />
                        )}
                    </div>
                )}

                {activeTab === 'elementary' && (
                    <div className="space-y-6 animate-fadeIn">
                        <ElementaryManualEntry
                            currentInputs={currentInputs}
                            elementaryCategory={elementaryCategory}
                            setElementaryCategory={setElementaryCategory}
                            onUpdateSubPolicy={onUpdateSubPolicy}
                            onUpdateManualComm={onUpdateManualComm}
                            onUpdateDetail={onUpdateDetail}
                        />
                    </div>
                )}

                {isFinancialType(activeTab) && (
                    <div className="space-y-6 animate-fadeIn">
                        <FinancialManualEntry
                            currentInputs={currentInputs}
                            activeTab={activeTab}
                            onUpdateDetail={onUpdateDetail}
                            onUpdateTracks={onUpdateTracks}
                            fetchedTracks={fetchedTracks}
                            isLoadingTracks={isLoadingTracks}
                        />
                    </div>
                )}

                {activeTab === 'abroad' && (
                    <AbroadManualEntry
                        monthlyCost={currentInputs.monthlyCost}
                        onChangeMonthlyCost={(val) =>
                            setCurrentInputs({ ...currentInputs, monthlyCost: val })
                        }
                    />
                )}
            </section>
        );
    },
);
