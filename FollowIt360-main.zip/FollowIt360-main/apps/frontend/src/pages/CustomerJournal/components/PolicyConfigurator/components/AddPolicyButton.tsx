import { Plus } from 'lucide-react';
import React from 'react';

interface AddPolicyButtonProps {
    label: string;
    disabled: boolean;
    onClick: () => void;
    size?: 'sm' | 'lg';
}

export const AddPolicyButton: React.FC<AddPolicyButtonProps> = React.memo(
    ({ label, disabled, onClick, size = 'lg' }) => {
        if (size === 'sm') {
            return (
                <button
                    onClick={onClick}
                    disabled={disabled}
                    className="bg-blue-500 text-white px-6 py-2.5 rounded-xl font-bold hover:bg-blue-600 disabled:opacity-30 disabled:cursor-not-allowed transition-all flex items-center gap-2 text-sm shadow-lg shadow-blue-500/20 active:scale-95 font-sans focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50"
                >
                    <Plus className="w-5 h-5" aria-hidden="true" /> {label}
                </button>
            );
        }

        return (
            <button
                onClick={onClick}
                disabled={disabled}
                className="bg-blue-50 text-blue-600 px-8 py-3.5 rounded-2xl font-bold hover:bg-blue-100 disabled:opacity-30 disabled:cursor-not-allowed transition-all flex items-center gap-2 text-base shadow-sm font-sans focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50"
            >
                <Plus className="w-5 h-5" aria-hidden="true" /> {label}
            </button>
        );
    },
);

AddPolicyButton.displayName = 'AddPolicyButton';
