import { ELEMENTARY_OPTIONS } from '@repo/types';
import { Check, Info } from 'lucide-react';
import React from 'react';
import { DebouncedInput } from '../../../../../components/ui/DebouncedInput';

interface ElementaryManualEntryProps {
    currentInputs: any;
    elementaryCategory: keyof typeof ELEMENTARY_OPTIONS;
    setElementaryCategory: (cat: keyof typeof ELEMENTARY_OPTIONS) => void;
    onUpdateSubPolicy: (key: string, val: number) => void;
    onUpdateManualComm: (
        field: 'manualElementaryScope' | 'manualElementaryOngoing',
        val: number,
    ) => void;
    onUpdateDetail: (field: string, val: any) => void;
}

export const ElementaryManualEntry: React.FC<ElementaryManualEntryProps> = React.memo(
    ({
        currentInputs,
        elementaryCategory,
        setElementaryCategory,
        onUpdateSubPolicy,
        onUpdateManualComm,
        onUpdateDetail,
    }) => {
        return (
            <div className="space-y-8 animate-fadeIn">
                <div
                    role="note"
                    className="bg-gradient-to-br from-amber-50 to-white rounded-3xl p-6 border-2 border-amber-100 shadow-xl shadow-amber-500/5 space-y-5"
                >
                    <div className="flex items-start gap-4">
                        <div className="bg-amber-500 p-2.5 rounded-xl text-white shadow-lg shadow-amber-200">
                            <Info className="w-5 h-5" aria-hidden="true" />
                        </div>
                        <div className="space-y-1">
                            <h5 className="text-[13px] font-black text-slate-900">
                                הודעת מערכת לסוכן
                            </h5>
                            <p className="text-[11px] text-amber-900/60 font-bold leading-relaxed">
                                בעדכון פוליסה אלמנטרית הזן ידנית את סה״כ העמלה שהתקבלה
                            </p>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                            <label
                                htmlFor="elementary-scope"
                                className="text-[10px] font-black text-slate-400 block mr-1 uppercase tracking-wider"
                            >
                                עמלת היקף משוערת (₪)
                            </label>
                            <div className="relative">
                                <DebouncedInput
                                    id="elementary-scope"
                                    className="w-full p-3 pl-9 border-2 border-slate-100 rounded-2xl bg-white shadow-sm focus:border-amber-400 focus:ring-4 focus:ring-amber-400/10 outline-none transition-all font-black text-sm"
                                    placeholder="0"
                                    value={
                                        currentInputs.details.manualElementaryScope?.toString() ||
                                        ''
                                    }
                                    onCommit={(val) =>
                                        onUpdateManualComm(
                                            'manualElementaryScope',
                                            parseFloat(val) || 0,
                                        )
                                    }
                                />
                                <span className="absolute left-3.5 top-3 text-[11px] text-slate-300 font-black">
                                    ₪
                                </span>
                            </div>
                        </div>
                        <div className="space-y-1.5">
                            <label
                                htmlFor="elementary-ongoing"
                                className="text-[10px] font-black text-slate-400 block mr-1 uppercase tracking-wider"
                            >
                                עמלת נפרעים חודשית (₪)
                            </label>
                            <div className="relative">
                                <DebouncedInput
                                    id="elementary-ongoing"
                                    className="w-full p-3 pl-9 border-2 border-slate-100 rounded-2xl bg-white shadow-sm focus:border-amber-400 focus:ring-4 focus:ring-amber-400/10 outline-none transition-all font-black text-sm"
                                    placeholder="0"
                                    value={
                                        currentInputs.details.manualElementaryOngoing?.toString() ||
                                        ''
                                    }
                                    onCommit={(val) =>
                                        onUpdateManualComm(
                                            'manualElementaryOngoing',
                                            parseFloat(val) || 0,
                                        )
                                    }
                                />
                                <span className="absolute left-3.5 top-3 text-[11px] text-slate-300 font-black">
                                    ₪
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="space-y-4">
                    <label className="text-[10px] font-black text-slate-400 block uppercase tracking-[0.2em] mr-1">
                        סוג ביטוח
                    </label>
                    <div className="grid grid-cols-3 gap-3">
                        {(
                            Object.keys(ELEMENTARY_OPTIONS) as Array<
                                keyof typeof ELEMENTARY_OPTIONS
                            >
                        ).map((cat) => {
                            const isSelected = elementaryCategory === cat;
                            return (
                                <button
                                    key={cat}
                                    type="button"
                                    onClick={() => {
                                        setElementaryCategory(cat);
                                        onUpdateDetail('elementaryCategory', cat);
                                    }}
                                    aria-pressed={isSelected}
                                    className={`relative py-4 rounded-2xl font-black text-sm transition-all duration-300 border-2 flex flex-col items-center gap-1.5 group focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 focus-visible:border-sky-500 ${isSelected ? 'bg-slate-900 border-slate-900 text-white shadow-2xl transform scale-[1.03]' : 'bg-white border-slate-100 text-slate-400 hover:border-sky-200 hover:bg-sky-50/40 hover:scale-[1.01]'}`}
                                >
                                    <span>{cat}</span>
                                    {isSelected && (
                                        <div className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-sky-500 rounded-full flex items-center justify-center border-2 border-white shadow-md">
                                            <Check
                                                className="w-3 h-3 text-white stroke-[4px]"
                                                aria-hidden="true"
                                            />
                                        </div>
                                    )}
                                </button>
                            );
                        })}
                    </div>
                </div>

                <div className="space-y-4 animate-slideDown">
                    <div className="flex items-center justify-between mb-2">
                        <label className="text-[10px] font-black text-slate-400 block uppercase tracking-[0.2em] mr-1">
                            כיסויים כלולים: {elementaryCategory}
                        </label>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {ELEMENTARY_OPTIONS[elementaryCategory].map((opt) => {
                            const storageKey = `${elementaryCategory} - ${opt}`;
                            const isActive =
                                (currentInputs.details.subPolicies?.[storageKey] || 0) > 0;

                            return (
                                <label
                                    key={opt}
                                    className={`
                    flex items-center justify-between p-4 rounded-2xl border-2 transition-all duration-200 cursor-pointer group
                    focus-within:ring-2 focus-within:ring-sky-500/50 focus-within:border-sky-300 focus-within:outline-none
                    ${
                        isActive
                            ? 'bg-sky-50 border-sky-200 shadow-sm'
                            : 'bg-white border-slate-100 hover:border-sky-100 hover:bg-slate-50/50'
                    }
                `}
                                >
                                    <div className="flex items-center gap-3">
                                        <div
                                            className={`
                        w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all duration-200
                        ${
                            isActive
                                ? 'bg-sky-500 border-sky-500 text-white shadow-lg shadow-sky-200'
                                : 'bg-white border-slate-200 group-hover:border-sky-300'
                        }
                    `}
                                        >
                                            {isActive && (
                                                <Check
                                                    className="w-4 h-4 stroke-[3.5px]"
                                                    aria-hidden="true"
                                                />
                                            )}
                                        </div>
                                        <span
                                            className={`text-xs font-black transition-colors ${isActive ? 'text-sky-900' : 'text-slate-600'}`}
                                        >
                                            {opt}
                                        </span>
                                    </div>
                                    <input
                                        type="checkbox"
                                        className="sr-only"
                                        checked={isActive}
                                        onChange={(e) =>
                                            onUpdateSubPolicy(storageKey, e.target.checked ? 1 : 0)
                                        }
                                    />
                                </label>
                            );
                        })}
                    </div>
                </div>
            </div>
        );
    },
);

ElementaryManualEntry.displayName = 'ElementaryManualEntry';
