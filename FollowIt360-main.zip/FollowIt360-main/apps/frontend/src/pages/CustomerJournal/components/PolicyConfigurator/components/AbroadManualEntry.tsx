import { Info } from 'lucide-react';
import React from 'react';
import { DebouncedInput } from '../../../../../components/ui/DebouncedInput';

interface AbroadManualEntryProps {
    monthlyCost: number;
    onChangeMonthlyCost: (val: number) => void;
}

export const AbroadManualEntry: React.FC<AbroadManualEntryProps> = React.memo(
    ({ monthlyCost, onChangeMonthlyCost }) => {
        return (
            <div className="space-y-6 animate-fadeIn">
                <div
                    role="note"
                    className="bg-gradient-to-br from-amber-50 to-white rounded-3xl p-6 border-2 border-amber-100 shadow-xl shadow-amber-500/5 space-y-5"
                >
                    <div className="flex items-start gap-4">
                        <div className="bg-amber-500 p-2.5 rounded-xl text-white shadow-lg shadow-amber-200">
                            <Info className="w-5 h-5" aria-hidden="true" />
                        </div>
                        <div className="space-y-1">
                            <h5 className="text-[13px] font-black text-slate-900">
                                הודעת מערכת לסוכן
                            </h5>
                            <p className="text-[11px] text-amber-900/60 font-bold leading-relaxed">
                                בעדכון פוליסה חו״ל הזן ידנית את סה״כ העמלה שהתקבלה
                            </p>
                        </div>
                    </div>

                    <div className="space-y-1.5">
                        <label
                            htmlFor="abroad-commission-input"
                            className="text-[10px] font-black text-slate-400 block mr-1 uppercase tracking-wider"
                        >
                            הזן את העמלה שהתקבלה (₪)
                        </label>
                        <div className="relative">
                            <DebouncedInput
                                id="abroad-commission-input"
                                className="w-full p-3 pl-9 border-2 border-slate-100 rounded-2xl bg-white shadow-sm focus:border-amber-400 focus:ring-4 focus:ring-amber-400/10 outline-none transition-all font-black text-sm"
                                placeholder="0"
                                value={monthlyCost?.toString() || ''}
                                onCommit={(val) => onChangeMonthlyCost(parseFloat(val) || 0)}
                            />
                            <span className="absolute left-3.5 top-3 text-[11px] text-slate-300 font-black">
                                ₪
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        );
    },
);

AbroadManualEntry.displayName = 'AbroadManualEntry';
