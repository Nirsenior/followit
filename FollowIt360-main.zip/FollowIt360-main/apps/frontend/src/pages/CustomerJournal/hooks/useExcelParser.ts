import { ELEMENTARY_OPTIONS, isFinancialType, InsuranceType } from '@repo/types';
import { useCallback, useMemo, useState } from 'react';
import * as XLSX from 'xlsx';
import { CoverageCategory, getCoveragesForCompanyAndType } from '../../../data/policy_master_list';
import { calculateAge } from '../utils/calculations';

export const useExcelParser = (
    company?: string,
    insuranceType?: InsuranceType,
    customerIssueDate?: string,
    targetMonth?: number,
    targetYear?: number,
) => {
    const [data, setData] = useState<any[] | null>(null);
    const [mapping, setMapping] = useState({ age: '', premium: '', isAnnual: false });
    const [matches, setMatches] = useState<Record<string, string>>({});
    const [validationError, setValidationError] = useState<string | null>(null);

    const currentAge = useMemo(() => {
        if (!customerIssueDate) return 25;
        return calculateAge(
            customerIssueDate,
            targetMonth || new Date().getMonth() + 1,
            targetYear || new Date().getFullYear(),
        );
    }, [customerIssueDate, targetMonth, targetYear]);

    const autoMap = useCallback(
        (json: any[]) => {
            if (!json || json.length === 0) return;
            const firstRow = json[0];
            const keys = Object.keys(firstRow);

            const agePatterns = ['גיל', 'age', 'Age', 'תקופת ביטוח', 'שנה', 'year', 'issueDate', 'תאריך הפקה'];
            const premiumPatterns = [
                'פרמיה',
                'סכום לתשלום',
                'amount',
                'premium',
                'Premium',
                'עלות',
                'מחיר',
                'סכום',
                'סך הכל',
                'סה"כ',
            ];
            const annualPatterns = ['שנתית', 'annual', 'Annual', 'בשנה'];

            const ageKey = keys.find((k) => agePatterns.some((p) => k.includes(p)));
            const premiumKey = keys.find((k) => premiumPatterns.some((p) => k.includes(p)));
            const isAnnual = premiumKey
                ? annualPatterns.some((p) => premiumKey.includes(p))
                : false;

            const newMatches: Record<string, string> = {};
            if (company && insuranceType) {
                let standardCoverages: string[] = [];
                if (['health', 'life', 'critical_illness'].includes(insuranceType)) {
                    standardCoverages = getCoveragesForCompanyAndType(
                        company,
                        insuranceType as CoverageCategory,
                    );
                } else if (insuranceType === 'elementary') {
                    standardCoverages = Object.values(ELEMENTARY_OPTIONS).flat();
                } else if (isFinancialType(insuranceType)) {
                    standardCoverages = [
                        'צבירה',
                        'הפקדה',
                        'תגמולים',
                        'פיצויים',
                        'דמי ניהול',
                        'תשואה',
                        'מסלול',
                    ];
                }

                keys.forEach((key) => {
                    const match = standardCoverages.find(
                        (std) =>
                            key.trim() === std.trim() || key.includes(std) || std.includes(key),
                    );
                    if (match) newMatches[key] = match;
                });
            }

            setMatches(newMatches);
            setMapping({ age: ageKey || '', premium: premiumKey || '', isAnnual });

            if (!ageKey && ['health', 'life', 'critical_illness'].includes(insuranceType || '')) {
                setValidationError(
                    'חסרה עמודת "גיל" או "תקופה" בקובץ. אנא בחר ידנית את העמודה המתאימה לצורך חישוב התפתחות הפרמיה.',
                );
            } else {
                setValidationError(null);
            }
        },
        [company, insuranceType],
    );

    const handleFile = useCallback(
        async (file: File) => {
            if (!file) return;

            try {
                const buffer = await file.arrayBuffer();
                const workbook = XLSX.read(buffer);
                const worksheet = workbook.Sheets[workbook.SheetNames[0]];
                let json = XLSX.utils.sheet_to_json(worksheet);

                // Skip name row for Life policies if detected
                if (insuranceType === 'life' && json.length > 0) {
                    const values = Object.values(json[0] as any).filter(v => !!String(v || '').trim());
                    const isNameRow = values.length <= 2 && !values.some(v => !isNaN(Number(v)));
                    if (isNameRow) json = json.slice(1);
                }

                setData(json);
                setValidationError(null);
                autoMap(json);
            } catch (err) {
                setValidationError('שגיאה בפענוח הקובץ. וודא שמדובר בקובץ אקסל תקין.');
            }
        },
        [autoMap, insuranceType],
    );

    const resetParser = useCallback(() => {
        setData(null);
        setMapping({ age: '', premium: '', isAnnual: false });
        setMatches({});
        setValidationError(null);
    }, []);

    return {
        data,
        mapping,
        setMapping,
        matches,
        validationError,
        currentAge,
        handleFile,
        resetParser,
    };
};
