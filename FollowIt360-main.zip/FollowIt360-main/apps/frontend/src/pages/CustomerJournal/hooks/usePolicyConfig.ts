import { InsuranceType, PremiumScheduleItem } from '@repo/types';
import { useCallback, useState } from 'react';

export interface PolicyInputs {
    id?: string;
    company: string;
    cost: number;
    issueDate: string;
    isAgentAppointmentOnly: boolean;
    premiumSchedule: PremiumScheduleItem[];
    excelColumns: string[];
    details: {
        subPolicies?: Record<string, number>;
        establishmentDate?: string;
        accumulation?: number;
        mobility?: number;
        monthlyDeposit?: number;
        lumpSumDeposit?: number;
        investmentTracks?: Array<{ trackName: string; weight: number }>;
        manualElementaryScope?: number;
        manualElementaryOngoing?: number;
        elementaryCategory?: string;
        elementaryCoverage?: string;
    };
}

const initialInputs: PolicyInputs = {
    company: '',
    cost: 0,
    issueDate: new Date().toISOString().split('T')[0],
    isAgentAppointmentOnly: false,
    premiumSchedule: [],
    excelColumns: [],
    details: { subPolicies: {} },
};

export const usePolicyConfig = (activeTab: InsuranceType) => {
    const [currentInputs, setCurrentInputs] = useState<PolicyInputs>(initialInputs);
    const [isManualEntry, setIsManualEntry] = useState(false);
    const [elementaryCategory, setElementaryCategory] = useState<string>('רכב');

    const resetInputs = useCallback(() => {
        setCurrentInputs(initialInputs);
        setIsManualEntry(false);
    }, []);

    const setCompany = useCallback(
        (company: string) => {
            setCurrentInputs((prev) => {
                const needsDetailsReset = ['health', 'life', 'critical_illness'].includes(
                    activeTab,
                );
                return {
                    ...prev,
                    company,
                    details: needsDetailsReset ? { subPolicies: {} } : prev.details,
                };
            });
        },
        [activeTab],
    );

    const updateDetail = useCallback((field: string, val: any) => {
        setCurrentInputs((prev) => ({
            ...prev,
            details: {
                ...prev.details,
                [field]: val,
            },
        }));
    }, []);

    const updateSubPolicy = useCallback((sub: string, val: number) => {
        setCurrentInputs((prev) => ({
            ...prev,
            details: {
                ...prev.details,
                subPolicies: { ...prev.details.subPolicies, [sub]: val },
            },
        }));
    }, []);

    const updateTracks = useCallback((track: string, weight: number) => {
        setCurrentInputs((prev) => {
            const tracks = [...(prev.details.investmentTracks || [])].filter(
                (t) => t.trackName !== track,
            );
            if (weight > 0) tracks.push({ trackName: track, weight });
            return {
                ...prev,
                details: {
                    ...prev.details,
                    investmentTracks: tracks,
                },
            };
        });
    }, []);

    const setPremiumSchedule = useCallback((sched: PremiumScheduleItem[], cols: string[]) => {
        setCurrentInputs((prev) => ({ ...prev, premiumSchedule: sched, excelColumns: cols }));
    }, []);

    const resetPremiumSchedule = useCallback(() => {
        setCurrentInputs((prev) => ({ ...prev, premiumSchedule: [], excelColumns: [] }));
    }, []);

    return {
        currentInputs,
        setCurrentInputs,
        isManualEntry,
        setIsManualEntry,
        elementaryCategory,
        setElementaryCategory,
        setCompany,
        updateDetail,
        updateSubPolicy,
        updateTracks,
        setPremiumSchedule,
        resetPremiumSchedule,
        resetInputs,
    };
};
