import { Customer, POLICY_STATUS, UserProfile } from '@repo/types';
import {
    Activity,
    ArrowDownRight,
    ArrowUpRight,
    DollarSign,
    TrendingUp,
    Users,
} from 'lucide-react';
import React, { useMemo } from 'react';
import { CompanyLogo } from '../components/CompanyLogo';
import { PortfolioValuationModal } from '../components/PortfolioValuationModal';
import { getSelectedCompanies } from '../utils/profileUtils';
import {
    calculateCommissions,
    calculateCustomerTotalPremium,
} from './CustomerJournal/utils/calculations';
import { getAllPolicies, useDashboardStats } from './Dashboard/hooks/useDashboardStats';
import { useScopeStats } from './Dashboard/hooks/useScopeStats';

import InstagramLogo from '../components/InstagramLogo';
import { WelcomeWalkthrough } from '../components/WelcomeWalkthrough';
interface DashboardProps {
    profile: UserProfile;
    customers: Customer[];
    onNavigate: (s: any) => void;
    onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ profile, customers, onNavigate }) => {
    const currentYear = new Date().getFullYear();

    // --- Filter State ---
    const [selectedYear, setSelectedYear] = React.useState(currentYear);
    const [selectedMonth, setSelectedMonth] = React.useState<number | null>(null); // 0-indexed
    const [isValuationModalOpen, setIsValuationModalOpen] = React.useState(false);

    // --- Available years from real data ---
    const availableYears = useMemo(() => {
        const years = new Set<number>(
            customers.map((c) => {
                const date = new Date(c.issueDate || c.createdAt);
                return isNaN(date.getTime()) ? currentYear : date.getFullYear();
            }),
        );
        years.add(currentYear);
        return Array.from(years).sort((a, b) => b - a);
    }, [customers, currentYear]);

    const profileCompanies = useMemo(
        () => getSelectedCompanies(profile.agreements),
        [profile.agreements],
    );

    // --- Compute stats from filtered customers ---
    const getStats = useDashboardStats(
        customers,
        profile,
        profileCompanies,
        selectedMonth,
        selectedYear,
    );

    // --- Chart data: monthly premium per month of selected year ---
    const salesData = useMemo(() => {
        // Initialize an array of 12 zeros representing each month
        const monthlyAccumulators = Array(12).fill(0);

        // Iterate over customers exactly ONCE - O(N) performance vs previous O(12N)
        customers.forEach((c) => {
            const d = new Date(c.issueDate || c.createdAt);
            if (!isNaN(d.getTime()) && d.getFullYear() === selectedYear) {
                const monthIdx = d.getMonth();
                // Add the computed premium directly into the fast-access array index
                monthlyAccumulators[monthIdx] += calculateCustomerTotalPremium(
                    c,
                    monthIdx,
                    selectedYear,
                );
            }
        });

        return {
            premium: getStats.premium,
            scope: getStats.scope,
            ongoing: getStats.ongoing,
            assets: {
                pension: getStats.assets.pension,
                financial: getStats.assets.financial,
                gemel: getStats.assets.gemel,
            },
        };
    }, [customers, profile, profileCompanies]);

    const companyStats = useMemo(() => {
        const totals: Record<string, number> = {};
        customers.forEach((c) => {
            getAllPolicies(c).forEach((p) => {
                if (p.status === POLICY_STATUS.ACTIVE && profileCompanies.includes(p.company)) {
                    const { ongoing } = calculateCommissions(p, p.monthlyCost, profile);
                    totals[p.company] = (totals[p.company] || 0) + ongoing;
                }
            });
        });
        return Object.entries(totals)
            .map(([name, value]) => ({ name, value }))
            .sort((a, b) => b.value - a.value)
            .slice(0, 4);
    }, [customers, profile, profileCompanies]);

    // --- Helper calculations for Top Cards ---
    const activeCustomersCount = useMemo(() => {
        // Count only those who have at least one active policy
        return customers.filter((c) =>
            getAllPolicies(c).some((p) => p.status === POLICY_STATUS.ACTIVE),
        ).length;
    }, [customers]);

    const customersAddedThisMonth = useMemo(() => {
        // Determine the "current" month based on filter, fallback to actual current month
        const targetMonth = selectedMonth !== null ? selectedMonth : new Date().getMonth();

        return customers.filter((c) => {
            const dateStr = (c as any).createdAt || c.issueDate;
            if (!dateStr) return false;
            const date = new Date(dateStr);
            if (isNaN(date.getTime())) return false;
            return date.getFullYear() === selectedYear && date.getMonth() === targetMonth;
        }).length;
    }, [customers, selectedMonth, selectedYear]);

    const scopeStats = useScopeStats({
        customers,
        profile,
        profileCompanies,
        selectedMonth,
        selectedYear,
    });

    const scopeDiff = scopeStats.currentScope - scopeStats.prevScope;

    const totalOngoingSum = companyStats.reduce((acc, curr) => acc + curr.value, 0);

    const donutR = 110;
    const donutC = 2 * Math.PI * donutR;

    return (
        <main className="flex-1 bg-[#F8FAFC] overflow-y-auto p-6 lg:p-8 font-sans" dir="rtl">
            <WelcomeWalkthrough onComplete={() => onNavigate('customers')} />
            <div className="flex justify-between items-start mb-10">
                <div className="text-right">
                    <h1 className="text-2xl font-bold text-slate-800 tracking-tight leading-none">
                        דאשבורד
                    </h1>
                </div>
                <div className="flex items-center gap-4">
                    {/* InstagramLogo is decorative branding — hidden from screen readers */}
                    <InstagramLogo size={40} className="hidden sm:flex" aria-hidden="true" />
                    <div className="text-left hidden sm:block" aria-hidden="true">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none mb-1">
                            פרופיל סוכן
                        </p>
                        <p className="text-sm font-semibold text-slate-700 leading-none">
                            {profile.firstName} {profile.lastName}
                        </p>
                    </div>
                    {/*
                     * Avatar was a <div onClick> — inaccessible to keyboard and AT.
                     * Replaced with <button> so it is focusable, operable via Enter/Space,
                     * and has an explicit accessible name via aria-label.
                     */}
                    <button
                        onClick={() => onNavigate('profile')}
                        className="w-10 h-10 bg-slate-900 rounded-2xl flex items-center justify-center text-white font-bold text-xs shadow-xl shadow-slate-900/20 hover:bg-blue-600 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                        aria-label={`עבור לפרופיל של ${profile.firstName} ${profile.lastName}`}
                    >
                        <span aria-hidden="true">
                            {profile.firstName[0]}
                            {profile.lastName[0]}
                        </span>
                    </button>
                </div>
            </div>
            {/* ── Section Header: מבט על ── */}
            <div className="flex items-center gap-3 mb-6 mt-6">
                <span className="flex h-5 w-1 rounded-full bg-gradient-to-b from-cyan-600 to-blue-600 shrink-0" />
                <h2 className="text-sm font-bold text-slate-700 tracking-wide">מבט על</h2>
                <div className="flex-1 h-px bg-slate-200/50" />
            </div>

            {/* ── KPI Row – 4 equal cards ── */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
                {/* Card 1 – Customers */}
                <div className="bg-gradient-to-br from-cyan-700 to-cyan-600 rounded-2xl p-5 shadow-md shadow-cyan-700/20 flex flex-col justify-between min-h-[145px]">
                    <p className="text-[15px] font-semibold text-cyan-100 uppercase tracking-wider text-center">
                        סה"כ לקוחות
                    </p>
                    {/* Decorative icon — aria-hidden so the card label text is the only cue */}
                    <div
                        className="flex justify-center items-center my-1.5 text-cyan-200/40"
                        aria-hidden="true"
                    >
                        <Users className="w-6 h-6" />
                    </div>
                    <div className="flex items-center justify-around gap-2 mt-1">
                        <div className="flex flex-col text-center">
                            <span className="text-[10px] text-cyan-200 font-semibold leading-tight">
                                סה"כ פעילים
                            </span>
                            <span className="text-[17px] font-bold text-white tabular-nums mt-0.5">
                                {activeCustomersCount.toLocaleString()}
                            </span>
                        </div>
                        <div className="w-[1.5px] h-8 bg-cyan-400/30 shrink-0 self-center"></div>
                        <div className="flex flex-col text-center">
                            <span className="text-[10px] text-cyan-200 font-semibold leading-tight">
                                התווספו החודש
                            </span>
                            <span className="text-[17px] font-bold text-white tabular-nums mt-0.5">
                                {customersAddedThisMonth.toLocaleString()}
                            </span>
                        </div>
                    </div>
                </div>

                {/* Card 2 – Ongoing */}
                <div className="bg-gradient-to-br from-blue-600 to-blue-500 rounded-2xl p-5 shadow-md shadow-blue-600/20 flex flex-col justify-between min-h-[145px]">
                    <p className="text-[15px] font-semibold text-blue-100 uppercase tracking-wider text-center">
                        סה״כ עמלות נפרעים
                    </p>
                    <div
                        className="flex justify-center items-center my-1.5 text-blue-200/40"
                        aria-hidden="true"
                    >
                        <TrendingUp className="w-6 h-6" />
                    </div>
                    <div className="flex items-center justify-around gap-2 mt-1">
                        <div className="flex flex-col text-center">
                            <span className="text-[10px] text-blue-200 font-semibold leading-tight">
                                סה״כ
                            </span>
                            <span className="text-[17px] font-bold text-white tabular-nums mt-0.5">
                                ₪
                                {getStats.ongoing.toLocaleString(undefined, {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2,
                                })}
                            </span>
                        </div>
                        <div className="w-[1.5px] h-8 bg-blue-400/30 shrink-0 self-center"></div>
                        <div className="flex flex-col text-center">
                            <span className="text-[10px] text-blue-200 font-semibold leading-tight">
                                החודש
                            </span>
                            <span className="text-[17px] font-bold text-white tabular-nums mt-0.5">
                                ₪
                                {getStats.monthOngoing.toLocaleString(undefined, {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2,
                                })}
                            </span>
                        </div>
                    </div>
                </div>

                {/* Card 3 – Scope */}
                <div className="bg-gradient-to-br from-sky-600 to-sky-500 rounded-2xl p-5 shadow-md shadow-sky-600/20 flex flex-col justify-between min-h-[145px]">
                    <p className="text-[15px] font-semibold text-sky-100 uppercase tracking-wider text-center">
                        סה״כ עמלות היקף החודש
                    </p>
                    <div
                        className="flex justify-center items-center my-1.5 text-sky-200/40"
                        aria-hidden="true"
                    >
                        <DollarSign className="w-6 h-6" />
                    </div>
                    <div className="text-2xl font-bold text-white tabular-nums mt-1 leading-tight text-center">
                        ₪{Math.round(scopeStats.currentScope).toLocaleString()}
                    </div>
                    <div className="flex items-center justify-center gap-1 text-[10px] font-bold text-sky-200 mt-1.5">
                        {scopeDiff > 0 ? (
                            <>
                                <ArrowUpRight className="w-3 h-3 text-emerald-400" />
                                <span className="text-emerald-200" dir="ltr">
                                    +₪{Math.round(scopeDiff).toLocaleString()}
                                </span>
                                <span className="text-sky-200">לעומת חודש קודם</span>
                            </>
                        ) : scopeDiff < 0 ? (
                            <>
                                <ArrowDownRight className="w-3 h-3 text-rose-400" />
                                <span className="text-rose-200" dir="ltr">
                                    -₪{Math.round(Math.abs(scopeDiff)).toLocaleString()}
                                </span>
                                <span className="text-sky-200">לעומת חודש קודם</span>
                            </>
                        ) : (
                            <>
                                <Activity className="w-3 h-3 text-sky-300" />
                                <span>ללא שינוי לעומת חודש קודם</span>
                            </>
                        )}
                    </div>
                </div>

                {/* Card 4 – Change % */}
                <div className="bg-gradient-to-br from-indigo-600 to-indigo-500 rounded-2xl p-5 shadow-md shadow-indigo-600/20 flex flex-col justify-between min-h-[145px]">
                    <p className="text-[15px] font-semibold text-indigo-100 uppercase tracking-wider text-center">
                        סה״כ שינוי במכירות %
                    </p>
                    <div
                        className="flex justify-center items-center my-1.5 text-indigo-200/40"
                        aria-hidden="true"
                    >
                        <Activity className="w-6 h-6" />
                    </div>
                    <div
                        className="text-3xl font-bold text-white tabular-nums mt-1 text-center"
                        dir="ltr"
                    >
                        {scopeStats.percentChange >= 0 ? '+' : '-'}
                        {Math.abs(scopeStats.percentChange)}%
                    </div>
                    <div className="flex items-center justify-center gap-1 text-[10px] font-bold text-indigo-200 mt-1.5">
                        {scopeStats.percentChange >= 0 ? (
                            <>
                                <ArrowUpRight className="w-3 h-3 text-emerald-400" />
                                <span className="text-emerald-200">לעומת חודש קודם</span>
                            </>
                        ) : (
                            <>
                                <ArrowDownRight className="w-3 h-3 text-rose-400" />
                                <span className="text-rose-200">לעומת חודש קודם</span>
                            </>
                        )}
                    </div>
                </div>
            </div>

            {/* ── Section Header: נכסים מנוהלים ── */}
            <div className="flex items-center gap-3 mb-6 mt-10">
                <span className="flex h-5 w-1 rounded-full bg-gradient-to-b from-cyan-600 to-blue-600 shrink-0" />
                <h2 className="text-sm font-bold text-slate-700 tracking-wide">
                    נכסים מנוהלים על ידך
                </h2>
                <div className="flex-1 h-px bg-slate-200/50" />
            </div>

            <div className="mb-10">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-slate-200 rounded-2xl overflow-hidden shadow-sm border border-slate-200">
                    <div className="bg-white px-6 py-5 text-center">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                            סה״כ נכסי פנסיה
                        </p>
                        <div className="text-xl font-bold text-slate-800 tabular-nums">
                            ₪{Math.round(getStats.assets.pension).toLocaleString()}
                        </div>
                    </div>
                    <div className="bg-white px-6 py-5 text-center">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                            סה״כ נכסים פיננסיים וגמל
                        </p>
                        <div className="text-xl font-bold text-slate-800 tabular-nums">
                            ₪
                            {Math.round(
                                getStats.assets.financial + getStats.assets.gemel,
                            ).toLocaleString()}
                        </div>
                    </div>
                    <div className="bg-white px-6 py-5 text-center">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                            סה״כ פרמיות פרט
                        </p>
                        <div className="text-xl font-bold text-slate-800 tabular-nums">
                            ₪{Math.round(getStats.individualPremium).toLocaleString()}
                        </div>
                    </div>
                </div>
            </div>

            {/* ── Section Header: פירוט עמלות נפרעים ── */}
            <div className="flex items-center gap-3 mb-6 mt-10">
                <span className="flex h-5 w-1 rounded-full bg-gradient-to-b from-cyan-600 to-blue-600 shrink-0" />
                <h3 className="text-sm font-bold text-slate-700 tracking-wide">
                    פירוט עמלות נפרעים מצטבר
                </h3>
                <div className="flex-1 h-px bg-slate-200/50" />
            </div>

            {/* ── Ongoing Commissions Donut Chart Card ── */}
            <div className="bg-white rounded-2xl p-8 lg:p-12 shadow-sm border border-slate-100">
                <div className="flex flex-col lg:flex-row items-center justify-center gap-14 lg:gap-24">
                    {/* Donut — fixed pixel size, no CSS transforms */}
                    <div className="relative flex-shrink-0" style={{ width: 260, height: 260 }}>
                        {/*
                         * role="img" + aria-label turn the SVG into an accessible image.
                         * Screen readers will announce the label instead of the raw SVG paths.
                         * The numerical total is also visible inside the SVG overlay below.
                         */}
                        <svg
                            width="260"
                            height="260"
                            viewBox="0 0 260 260"
                            role="img"
                            aria-label={`תרשים עמלות נפרעים: סה״כ ₪${getStats.ongoing.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
                        >
                            <g transform="translate(130,130) rotate(-90)">
                                {/* Track */}
                                <circle
                                    cx="0"
                                    cy="0"
                                    r={donutR}
                                    fill="none"
                                    stroke="#f1f5f9"
                                    strokeWidth="30"
                                />
                                {/* Arc 1 */}
                                <circle
                                    cx="0"
                                    cy="0"
                                    r={donutR}
                                    fill="none"
                                    stroke="#06b6d4"
                                    strokeWidth="30"
                                    strokeDasharray={donutC}
                                    strokeDashoffset={donutC * 0.45}
                                    strokeLinecap="round"
                                />
                                {/* Arc 2 */}
                                <circle
                                    cx="0"
                                    cy="0"
                                    r={donutR}
                                    fill="none"
                                    stroke="#0891b2"
                                    strokeWidth="30"
                                    strokeDasharray={donutC}
                                    strokeDashoffset={donutC * 0.78}
                                    strokeLinecap="round"
                                />
                            </g>
                        </svg>
                        <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none mb-1">
                                סה״כ נפרעים
                            </span>
                            <span className="text-xl md:text-2xl font-bold text-slate-900 tabular-nums leading-tight">
                                ₪
                                {getStats.ongoing.toLocaleString(undefined, {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2,
                                })}
                            </span>
                        </div>
                    </div>

                    {/* Legend + Bars */}
                    <div className="flex-1 w-full max-w-2xl space-y-5">
                        {companyStats.length === 0 ? (
                            <div className="text-center py-10 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                                    אין נתונים להצגה
                                </p>
                            </div>
                        ) : (
                            companyStats.map((item, i) => {
                                const colors = ['#06b6d4', '#0891b2', '#0284c7', '#6366f1'];
                                const bgColors = [
                                    'bg-cyan-500',
                                    'bg-sky-600',
                                    'bg-blue-500',
                                    'bg-indigo-500',
                                ];
                                return (
                                    <div key={item.name} className="flex items-center gap-6">
                                        {/* Color dot is decorative; company name text is the label */}
                                        <div
                                            className="w-3 h-3 rounded-full flex-shrink-0"
                                            style={{ backgroundColor: colors[i % colors.length] }}
                                            aria-hidden="true"
                                        />
                                        {/* Company logo is decorative — the name text is the semantic label */}
                                        <CompanyLogo
                                            company={item.name}
                                            className="w-10 h-10 rounded-full flex-shrink-0 border-none bg-transparent"
                                            aria-hidden="true"
                                        />
                                        <span className="text-sm md:text-base font-bold text-slate-800 w-32 text-right shrink-0">
                                            {item.name}
                                        </span>
                                        <div className="flex-1 h-3 bg-slate-100 rounded-full overflow-hidden">
                                            <div
                                                className={`h-full ${bgColors[i % bgColors.length]} transition-all duration-700`}
                                                style={{
                                                    width: `${(item.value / (totalOngoingSum || 1)) * 100}%`,
                                                }}
                                            />
                                        </div>
                                        <span className="text-sm md:text-base font-bold text-slate-500 tabular-nums w-28 text-left shrink-0">
                                            ₪
                                            {item.value.toLocaleString(undefined, {
                                                minimumFractionDigits: 2,
                                                maximumFractionDigits: 2,
                                            })}
                                        </span>
                                    </div>
                                );
                            })
                        )}

                        {/* ── Interactive Valuation CTA Strip ── */}
                        <div className="pt-5 mt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                            <div className="text-right">
                                <p className="text-sm font-bold text-slate-700">
                                    מעוניין לדעת כמה שווה תיק הלקוחות שלך?
                                </p>
                                <p className="text-xs font-semibold text-slate-400">
                                    חשב עכשיו את השווי המוערך לפי ממוצע המכפלות המקובל בענף.
                                </p>
                            </div>
                            <button
                                onClick={() => setIsValuationModalOpen(true)}
                                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs md:text-sm px-4 py-2.5 rounded-xl transition-all shadow-md shadow-emerald-600/10 hover:shadow-emerald-600/20 shrink-0"
                            >
                                חשב את שווי התיק שלי
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <PortfolioValuationModal
                isOpen={isValuationModalOpen}
                onClose={() => setIsValuationModalOpen(false)}
                portfolioValue={getStats.ongoing * 24}
                initialEmail={profile.email}
                initialPhone={profile.phone}
                agentName={
                    profile.displayName || profile.firstName + ' ' + profile.lastName || 'Agent'
                }
            />
        </main>
    );
};

export default Dashboard;
