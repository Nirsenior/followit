import { zodResolver } from '@hookform/resolvers/zod';
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import * as z from 'zod';
import Logo from '../components/Logo';
import { translateError } from '../utils/errorTranslator';

const loginSchema = z.object({
    email: z.string().email('כתובת דוא״ל לא חוקית'),
    password: z.string().min(6, 'סיסמה חייבת להכיל לפחות 6 תווים'),
});

type LoginFormValues = z.infer<typeof loginSchema>;

interface LoginPageProps {
    onLogin: (data: { userId: string; name: string }) => Promise<void>;
    onBack: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin, onBack }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [isGoogleLoading, setIsGoogleLoading] = useState(false);

    const handleGoogleLogin = () => {
        setIsGoogleLoading(true);
        const baseUrl = import.meta.env.VITE_API_URL || '';
        window.location.href = `${baseUrl}/api/auth/google`;
    };
    const {
        register,
        handleSubmit,
        setError,
        formState: { errors },
    } = useForm<LoginFormValues>({
        resolver: zodResolver(loginSchema),
    });

    const onSubmit = async (data: LoginFormValues) => {
        setIsLoading(true);
        try {
            const baseUrl = import.meta.env.VITE_API_URL || '';
            const response = await fetch(`${baseUrl}/api/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify(data),
            });
            const result = await response.json();

            if (!response.ok) {
                setError('root', {
                    type: 'manual',
                    message: translateError(result.message),
                });
                setIsLoading(false);
                return;
            }

            await onLogin(result);
        } catch (err) {
            console.error('Login error:', err);
            setError('root', { type: 'manual', message: 'שגיאת תקשורת. בדוק את החיבור שלך.' });
        }
    };

    return (
        <main className="flex flex-col items-center justify-center min-h-screen p-6 bg-[#0A1128] text-white relative overflow-hidden" dir="rtl">
            {/* Background Glows — decorative, hidden from screen readers */}
            <div className="absolute inset-0 opacity-40 pointer-events-none" aria-hidden="true">
                <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-blue-600/20 rounded-full blur-[120px] -mr-[300px] -mt-[300px]"></div>
                <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-[100px] -ml-[250px] -mb-[250px]"></div>
            </div>

            <div className="bg-white/5 backdrop-blur-md p-8 rounded-3xl shadow-2xl max-w-sm w-full border border-white/10 animate-slideUp relative z-10">
                <div className="mb-10 flex justify-center scale-110">
                    <Logo variant="light" />
                </div>

                {errors.root && (
                    <div role="alert" className="mb-4 p-3 bg-red-950/40 text-red-200 rounded-xl text-sm font-semibold border border-red-500/30">
                        {errors.root.message}
                    </div>
                )}

                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                    <div>
                        <label htmlFor="login-email" className="block text-xs font-bold text-slate-300 mb-1 mr-1 uppercase tracking-wider">
                            דוא״ל
                        </label>
                        <input
                            {...register('email')}
                            id="login-email"
                            type="email"
                            placeholder="agent@pro.co.il"
                            aria-invalid={!!errors.email}
                            aria-describedby={errors.email ? 'login-email-error' : undefined}
                            className={`w-full p-2.5 border rounded-xl outline-none transition-all text-sm text-white focus-visible:ring-2 focus-visible:ring-sky-500/50 focus-visible:border-sky-500 ${
                                errors.email
                                    ? 'border-red-500/50 focus:border-red-500 focus:ring-red-500/20 bg-red-950/20 placeholder-red-300/40'
                                    : 'border-white/10 focus:border-sky-500 focus:ring-sky-500/20 bg-white/5 placeholder-slate-500'
                            }`}
                        />
                        {errors.email && (
                            <p id="login-email-error" className="mt-1 text-xs text-red-400 mr-1">{errors.email.message}</p>
                        )}
                    </div>

                    <div>
                        <label htmlFor="login-password" className="block text-xs font-bold text-slate-300 mb-1 mr-1 uppercase tracking-wider">
                            סיסמה
                        </label>
                        <input
                            {...register('password')}
                            id="login-password"
                            type="password"
                            placeholder="••••••••"
                            aria-invalid={!!errors.password}
                            aria-describedby={errors.password ? 'login-password-error' : undefined}
                            className={`w-full p-2.5 border rounded-xl outline-none transition-all text-sm text-white focus-visible:ring-2 focus-visible:ring-sky-500/50 focus-visible:border-sky-500 ${
                                errors.password
                                    ? 'border-red-500/50 focus:border-red-500 focus:ring-red-500/20 bg-red-950/20 placeholder-red-300/40'
                                    : 'border-white/10 focus:border-sky-500 focus:ring-sky-500/20 bg-white/5 placeholder-slate-500'
                            }`}
                        />
                        {errors.password && (
                            <p id="login-password-error" className="mt-1 text-xs text-red-400 mr-1">
                                {errors.password.message}
                            </p>
                        )}
                    </div>

                    <button
                        type="submit"
                        disabled={isLoading}
                        aria-busy={isLoading}
                        className="w-full mt-6 bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-500 active:scale-[0.98] transition-all shadow-lg shadow-blue-600/30 text-sm disabled:opacity-70 disabled:cursor-not-allowed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50"
                    >
                        {isLoading ? 'מתחבר...' : 'כניסה מאובטחת'}
                    </button>
                </form>

                <div className="flex items-center gap-3 my-4" aria-hidden="true">
                    <div className="h-px bg-white/10 flex-1"></div>
                    <span className="text-xs text-slate-400 font-bold">או</span>
                    <div className="h-px bg-white/10 flex-1"></div>
                </div>

                <button
                    type="button"
                    onClick={handleGoogleLogin}
                    disabled={isGoogleLoading}
                    className="w-full flex items-center justify-center gap-3 py-2.5 px-4 rounded-xl border border-white/10 font-bold text-white bg-white/5 hover:bg-white/10 hover:border-white/20 transition-all text-sm disabled:opacity-70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50"
                >
                    <svg className="w-5 h-5" viewBox="0 0 24 24" aria-hidden="true">
                        <path
                            d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                            fill="#4285F4"
                        />
                        <path
                            d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                            fill="#34A853"
                        />
                        <path
                            d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                            fill="#FBBC05"
                        />
                        <path
                            d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                            fill="#EA4335"
                        />
                    </svg>
                    {isGoogleLoading ? 'טוען...' : 'המשך באמצעות Google'}
                </button>

                <button
                    onClick={onBack}
                    type="button"
                    className="w-full mt-4 text-slate-400 font-medium hover:text-sky-400 text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-400/50"
                >
                    חזרה לדף הבית
                </button>
            </div>
        </main>
    );
};

export default LoginPage;
