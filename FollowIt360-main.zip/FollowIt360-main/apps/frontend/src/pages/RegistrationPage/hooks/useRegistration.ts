import { CompanyAgreements, InsuranceType, UserProfile } from '@repo/types';
import { useCallback, useEffect, useState } from 'react';
import {
    getSelectedCompanies,
    sanitizeAllAgreements,
    sanitizeCompanyAgreements,
} from '../../../utils/profileUtils';

const DEFAULT_GLOBAL_AGREEMENTS: CompanyAgreements = {
    health: { scope: '', ongoing: '' },
    life: { scope: '', ongoing: '' },
    critical_illness: { scope: '', ongoing: '' },
    pension: { scope: '', ongoing: '', mobility: '' },
    gemel: { scope: '', ongoing: '', mobility: '' },
    hishtalmut: { scope: '', ongoing: '', mobility: '' },
    gemel_invest: { scope: '', ongoing: '', mobility: '' },
    long_term_savings: { scope: '', ongoing: '', mobility: '' },
    elementary: { isActive: false },
    abroad: { scope: '' },
};

export const REGISTRATION_STEPS = [
    { id: 1, label: 'חברות ביטוח' },
    { id: 2, label: 'הסכם ברירת מחדל' },
    { id: 3, label: 'דיוק והתאמה' },
    { id: 4, label: 'אמצעי תשלום' },
] as const;

type RegistrationStepId = (typeof REGISTRATION_STEPS)[number]['id'];

interface UseRegistrationReturn {
    step: RegistrationStepId;
    profile: UserProfile;
    globalAgreements: CompanyAgreements;
    editingCompany: string | null;
    progress: number;
    setStep: (s: RegistrationStepId) => void;
    setGlobalAgreements: React.Dispatch<React.SetStateAction<CompanyAgreements>>;
    setEditingCompany: (company: string | null) => void;
    updateProfile: (fields: Partial<UserProfile>) => void;
    toggleCompany: (company: string) => void;
    handleAgreementChange: (
        company: string,
        type: InsuranceType,
        field: string,
        value: unknown,
    ) => void;
    applyGlobalDefaults: () => void;
    handleComplete: () => void;
}

export const useRegistration = (
    initialProfile: UserProfile,
    onComplete: (customers?: [], profile?: Partial<UserProfile>) => void,
): UseRegistrationReturn => {
    const [step, setStep] = useState<RegistrationStepId>(1);
    const [profile, setProfile] = useState<UserProfile>(initialProfile);
    const [globalAgreements, setGlobalAgreements] =
        useState<CompanyAgreements>(DEFAULT_GLOBAL_AGREEMENTS);
    const [editingCompany, setEditingCompany] = useState<string | null>(null);

    useEffect(() => {
        setProfile((prev) => ({ ...prev, ...initialProfile }));
    }, [initialProfile]);

    const updateProfile = useCallback((fields: Partial<UserProfile>) => {
        setProfile((prev) => ({ ...prev, ...fields }));
    }, []);

    const toggleCompany = useCallback((company: string) => {
        setProfile((prev) => {
            const isSelected = !!prev.agreements[company] && company !== 'GLOBAL';
            const newAgreements = { ...prev.agreements };
            if (isSelected) {
                delete newAgreements[company];
            } else {
                newAgreements[company] = {};
            }
            return { ...prev, agreements: newAgreements };
        });
    }, []);

    const handleAgreementChange = useCallback(
        (company: string, type: InsuranceType, field: string, value: unknown) => {
            setProfile((prev) => {
                const companyAgreements = prev.agreements[company] || {};
                const typeValues = companyAgreements[type] || {};
                return {
                    ...prev,
                    agreements: {
                        ...prev.agreements,
                        [company]: {
                            ...companyAgreements,
                            [type]: { ...typeValues, [field]: value },
                        },
                    },
                };
            });
        },
        [],
    );

    const applyGlobalDefaults = useCallback(() => {
        setProfile((prev) => {
            const nextAgreements = { ...prev.agreements };
            getSelectedCompanies(prev.agreements).forEach((company) => {
                nextAgreements[company] = JSON.parse(JSON.stringify(globalAgreements));
            });
            return { ...prev, agreements: nextAgreements };
        });
        setStep(3);
    }, [globalAgreements]);

    const handleComplete = useCallback(() => {
        const finalProfile: Partial<UserProfile> = {
            ...profile,
            agreements: sanitizeAllAgreements({
                ...profile.agreements,
                GLOBAL: sanitizeCompanyAgreements(globalAgreements),
            }),
        };
        onComplete([], finalProfile);
    }, [profile, globalAgreements, onComplete]);

    const progress = (step / REGISTRATION_STEPS.length) * 100;

    return {
        step,
        profile,
        globalAgreements,
        editingCompany,
        progress,
        setStep,
        setGlobalAgreements,
        setEditingCompany,
        updateProfile,
        toggleCompany,
        handleAgreementChange,
        applyGlobalDefaults,
        handleComplete,
    };
};
