import { INSURANCE_TYPES, INSURANCE_TYPE_LABELS, InsuranceType, UserProfile } from '@repo/types';
import { Settings2, X } from 'lucide-react';
import React from 'react';
import { CompanyAgreementEditor } from '../../profile/components/CompanyAgreementEditor';

const SHLOMO_RESTRICTED: InsuranceType[] = ['health', 'life', 'critical_illness'];

interface CompanyEditDrawerProps {
    company: string;
    agreements: UserProfile['agreements'];
    onClose: () => void;
    onChange: (company: string, type: InsuranceType, field: string, value: unknown) => void;
}

export const CompanyEditDrawer: React.FC<CompanyEditDrawerProps> = ({
    company,
    agreements,
    onClose,
    onChange,
}) => (
    <div 
        className="fixed inset-0 z-[100] flex justify-end"
        role="dialog"
        aria-modal="true"
        aria-labelledby="drawer-title"
    >
        <div className="absolute inset-0 bg-slate-900/60 animate-fadeIn" onClick={onClose} aria-hidden="true" />
        <div className="relative w-full max-w-md bg-white h-full shadow-2xl animate-slideLeft flex flex-col">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <div className="flex items-center gap-3">
                    <Settings2 className="w-5 h-5 text-sky-500" aria-hidden="true" />
                    <h3 id="drawer-title" className="text-lg font-bold text-slate-900">עריכת הסכם: {company}</h3>
                </div>
                <button
                    onClick={onClose}
                    aria-label="סגור"
                    className="p-2 hover:bg-slate-200 rounded-lg transition-colors text-slate-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500/50"
                >
                    <X className="w-6 h-6" aria-hidden="true" />
                </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {INSURANCE_TYPES.map((type) => {
                    const isRestricted = company === 'שלמה' && SHLOMO_RESTRICTED.includes(type);
                    if (isRestricted) {
                        return (
                            <div
                                key={type}
                                className="p-5 rounded-2xl border transition-all space-y-4 bg-slate-50 border-slate-200 opacity-60"
                            >
                                <div className="flex items-center justify-between">
                                    <h4 className="font-bold text-sm text-slate-400">
                                        {INSURANCE_TYPE_LABELS[type]}
                                    </h4>
                                    <span className="text-[9px] font-bold text-slate-400 bg-slate-200 px-2 py-0.5 rounded-full uppercase">
                                        לא רלוונטי
                                    </span>
                                    <div className="h-px flex-1 mx-4 opacity-50 bg-slate-200" />
                                </div>
                                <p className="text-[10px] text-slate-400 font-bold text-center py-2">
                                    חברת שלמה אינה משווקת ביטוחי בריאות, חיים או מחלות קשות
                                </p>
                            </div>
                        );
                    }
                    return (
                        <CompanyAgreementEditor
                            key={type}
                            company={company}
                            type={type}
                            agreement={agreements[company]?.[type]}
                            onChange={onChange}
                            onPendingChange={(c, t, f, v) => onChange(c, t, f, v)}
                        />
                    );
                })}
            </div>

            <div className="p-6 border-t border-slate-100 bg-slate-50/30">
                <button
                    onClick={onClose}
                    className="w-full py-4 bg-slate-900 text-white font-bold rounded-2xl shadow-xl shadow-slate-900/20 hover:bg-slate-800 active:scale-95 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-900/50"
                >
                    שמירה וסגירה
                </button>
            </div>
        </div>
    </div>
);
