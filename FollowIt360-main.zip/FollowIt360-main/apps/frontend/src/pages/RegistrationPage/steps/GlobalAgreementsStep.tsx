import {
    CompanyAgreements,
    isFinancialType,
    INSURANCE_TYPE_LABELS,
    InsuranceType,
    isMobilityType,
} from '@repo/types';
import React from 'react';
import { DebouncedInput } from '../../../components/ui/DebouncedInput';

const ALL_TYPES: InsuranceType[] = [
    'health',
    'life',
    'critical_illness',
    'pension',
    'gemel',
    'hishtalmut',
    'gemel_invest',
    'long_term_savings',
    'elementary',
    'abroad',
];

interface GlobalAgreementsStepProps {
    globalAgreements: CompanyAgreements;
    onChange: React.Dispatch<React.SetStateAction<CompanyAgreements>>;
}

export const GlobalAgreementsStep: React.FC<GlobalAgreementsStepProps> = ({
    globalAgreements,
    onChange,
}) => (
    <div className="animate-fadeIn space-y-6 font-sans">
        <div className="text-center mb-8">
            <h2 className="text-2xl font-bold mb-2 text-slate-800 pb-1">
                הגדרת הסכם ברירת מחדל
            </h2>
            <p className="text-slate-400 text-sm">
                הגדר שיעורי עמלות כלליים שיחולו על כל החברות.
            </p>
        </div>

        <div className="grid gap-4">
            {ALL_TYPES.map((type) => (
                <div key={type} className="bg-slate-50/50 p-6 rounded-2xl border border-slate-100">
                    <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                        <span className="w-1.5 h-6 bg-blue-500 rounded-full" />
                        {INSURANCE_TYPE_LABELS[type]}
                    </h4>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                        {type === 'elementary' ? (
                            <div className="col-span-full">
                                <label className="flex items-center gap-3 cursor-pointer group bg-white p-4 rounded-xl border border-slate-200 hover:border-blue-500 focus-within:ring-2 focus-within:ring-blue-500/50 transition-all w-fit">
                                    <input
                                        type="checkbox"
                                        className="w-5 h-5 accent-blue-500 rounded border-slate-200 focus-visible:outline-none"
                                        checked={globalAgreements[type]?.isActive || false}
                                        onChange={(e) =>
                                            onChange((prev) => ({
                                                ...prev,
                                                [type]: {
                                                    ...prev[type],
                                                    isActive: e.target.checked,
                                                },
                                            }))
                                        }
                                    />
                                    <span className="font-bold text-slate-700">
                                        האם מוכר אלמנטרי? (כן/לא)
                                    </span>
                                </label>
                            </div>
                        ) : (
                            <>
                                <div className="flex flex-col">
                                    <label htmlFor={`scope-global-${type}`} className="text-[11px] font-bold text-slate-500 mb-1.5 uppercase tracking-wider mr-1">
                                        {isFinancialType(type)
                                            ? 'היקף הפקדות (%)'
                                            : 'היקף (%)'}
                                    </label>
                                    <DebouncedInput
                                        id={`scope-global-${type}`}
                                        placeholder="0"
                                        className="p-3 border border-slate-200 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 focus-visible:border-blue-500 bg-white font-bold text-slate-900 transition-all"
                                        value={globalAgreements[type]?.scope || ''}
                                        onCommit={(v) =>
                                            onChange((prev) => ({
                                                ...prev,
                                                [type]: { ...prev[type], scope: v },
                                            }))
                                        }
                                    />
                                </div>
                                {type !== 'abroad' && (
                                    <div className="flex flex-col">
                                        <label htmlFor={`ongoing-global-${type}`} className="text-[11px] font-bold text-slate-500 mb-1.5 uppercase tracking-wider mr-1">
                                            נפרעים (%)
                                        </label>
                                        <DebouncedInput
                                            id={`ongoing-global-${type}`}
                                            placeholder="0"
                                            className="p-3 border border-slate-200 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 focus-visible:border-blue-500 bg-white font-bold text-slate-900 transition-all"
                                            value={globalAgreements[type]?.ongoing || ''}
                                            onCommit={(v) =>
                                                onChange((prev) => ({
                                                    ...prev,
                                                    [type]: { ...prev[type], ongoing: v },
                                                }))
                                            }
                                        />
                                    </div>
                                )}
                                {isMobilityType(type) && (
                                    <div className="flex flex-col">
                                        <label htmlFor={`mobility-global-${type}`} className="text-[11px] font-bold text-slate-500 mb-1.5 uppercase tracking-wider mr-1">
                                            היקף ניוד (%)
                                        </label>
                                        <DebouncedInput
                                            id={`mobility-global-${type}`}
                                            placeholder="0"
                                            className="p-3 border border-slate-200 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 focus-visible:border-blue-500 bg-white font-bold text-slate-900 transition-all"
                                            value={globalAgreements[type]?.mobility || ''}
                                            onCommit={(v) =>
                                                onChange((prev) => ({
                                                    ...prev,
                                                    [type]: { ...prev[type], mobility: v },
                                                }))
                                            }
                                        />
                                    </div>
                                )}
                            </>
                        )}
                    </div>
                </div>
            ))}
        </div>
    </div>
);
