import { INSURANCE_COMPANIES } from '@repo/types';
import { Check, Plus } from 'lucide-react';
import React from 'react';

import { CompanyLogo } from '../../../components/CompanyLogo';

interface CompanySelectionStepProps {
    selectedCompanies: string[];
    onToggle: (company: string) => void;
}

export const CompanySelectionStep: React.FC<CompanySelectionStepProps> = ({
    selectedCompanies,
    onToggle,
}) => (
    <div className="animate-fadeIn">
        <div className="text-center mb-6">
            <h2 className="text-2xl font-bold mb-2 text-slate-900 flex items-center justify-center gap-2">
                <Plus className="w-6 h-6 text-sky-500" aria-hidden="true" />
                הגדר את חברות הביטוח שאתה עובד מולן
            </h2>
            <p className="text-slate-500 text-sm">
                בחר את החברות איתן אתה עובד. תוכל לעדכן את הרשימה בכל עת.
            </p>
        </div>
        <div className="max-w-4xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 font-sans">
            {INSURANCE_COMPANIES.map((company) => {
                const isSelected = selectedCompanies.includes(company);
                return (
                    <button
                        key={company}
                        onClick={() => onToggle(company)}
                        aria-pressed={isSelected}
                        className={`px-5 py-4 rounded-2xl border transition-all flex items-center justify-between text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 ${
                            isSelected
                                ? 'bg-blue-50/50 border-blue-200 text-blue-900 font-bold shadow-sm'
                                : 'bg-white border-slate-100 text-slate-600 font-medium hover:bg-slate-50 hover:border-slate-200'
                        }`}
                    >
                        <div className="flex items-center gap-3">
                            <CompanyLogo company={company} className="w-8 h-8 rounded-full" aria-hidden="true" />
                            <span className="font-bold">{company}</span>
                        </div>
                        <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all ${
                            isSelected ? 'bg-blue-500 border-blue-500' : 'border-slate-200 bg-white'
                        }`} aria-hidden="true">
                            {isSelected && <Check className="w-3.5 h-3.5 text-white" strokeWidth={3} aria-hidden="true" />}
                        </div>
                    </button>
                );
            })}
        </div>
    </div>
);
