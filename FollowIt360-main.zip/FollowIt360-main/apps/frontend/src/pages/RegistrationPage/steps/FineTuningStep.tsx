import { InsuranceType, UserProfile } from '@repo/types';
import React from 'react';
import { CompanyLogo } from '../../../components/CompanyLogo';
import { CompanyEditDrawer } from './CompanyEditDrawer';

interface FineTuningStepProps {
    selectedCompanies: string[];
    editingCompany: string | null;
    agreements: UserProfile['agreements'];
    onEdit: (company: string) => void;
    onClose: () => void;
    onAgreementChange: (
        company: string,
        type: InsuranceType,
        field: string,
        value: unknown,
    ) => void;
}

export const FineTuningStep: React.FC<FineTuningStepProps> = ({
    selectedCompanies,
    editingCompany,
    agreements,
    onEdit,
    onClose,
    onAgreementChange,
}) => (
    <div className="animate-fadeIn space-y-6 font-sans">
        <div className="text-center mb-8">
            <h2 className="text-2xl font-bold mb-2 text-slate-800 pb-1">
                דיוק והתאמת הסכמים
            </h2>
            <p className="text-slate-400 text-sm">
                ערוך חברה ספציפית אם יש לה הסכם שונה.
            </p>
        </div>

        <div className="space-y-3">
            {[...selectedCompanies]
                .sort((a, b) => a.localeCompare(b, 'he'))
                .map((company) => (
                <div
                    key={company}
                    className="bg-slate-50/50 border border-slate-100 rounded-2xl p-4 shadow-sm flex items-center justify-between hover:border-blue-200 transition-all group"
                >
                    <div className="flex items-center gap-4">
                        <CompanyLogo company={company} className="w-10 h-10 rounded-xl shadow-sm group-hover:border-blue-200 transition-colors" aria-hidden="true" />
                        <div>
                            <h4 className="font-bold text-slate-800">{company}</h4>
                            <p className="text-[10px] text-slate-400 uppercase tracking-tighter">
                                הסכם מותאם אישית
                            </p>
                        </div>
                    </div>
                    <button
                        onClick={() => onEdit(company)}
                        aria-label={`ערוך הסכם עבור חברת ${company}`}
                        className="px-6 py-2 rounded-xl font-bold text-sm transition-all border border-blue-200 text-blue-600 hover:bg-blue-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50"
                    >
                        עריכה
                    </button>
                </div>
            ))}
        </div>

        {editingCompany && (
            <CompanyEditDrawer
                company={editingCompany}
                agreements={agreements}
                onClose={onClose}
                onChange={onAgreementChange}
            />
        )}
    </div>
);
