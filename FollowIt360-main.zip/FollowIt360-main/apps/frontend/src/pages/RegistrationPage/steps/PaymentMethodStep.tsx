import { UserProfile } from '@repo/types';
import { CreditCard } from 'lucide-react';
import React from 'react';

interface PaymentMethodStepProps {
    profile: UserProfile;
    onUpdate: (fields: Partial<UserProfile>) => void;
}

export const PaymentMethodStep: React.FC<PaymentMethodStepProps> = ({ profile, onUpdate }) => {
    const { paymentMethod, firstName, lastName } = profile;

    const setCard = (fields: Partial<typeof paymentMethod>) =>
        onUpdate({ paymentMethod: { ...paymentMethod, ...fields } });

    return (
        <div className="animate-fadeIn max-w-md mx-auto">
            <div className="text-center mb-6">
                <h2 className="text-2xl font-bold mb-2 text-slate-900">הפעלת מנוי</h2>
                <p className="text-slate-500 text-sm">
                    הזן פרטי אשראי לחיוב חודשי על השימוש בפלטפורמה.
                </p>
            </div>

            {/* Card preview */}
            <div className="bg-slate-900 text-white p-8 rounded-2xl shadow-2xl relative overflow-hidden mb-8" aria-hidden="true">
                <div className="relative z-10">
                    <div className="flex justify-between items-start mb-12">
                        <CreditCard className="w-10 h-10 text-sky-400" />
                        <div className="text-lg font-bold">FollowCard</div>
                    </div>
                    <div className="text-2xl tracking-[0.2em] mb-8 font-mono">
                        {paymentMethod.cardNumber || '**** **** **** ****'}
                    </div>
                    <div className="flex justify-between">
                        <div>
                            <div className="text-[10px] uppercase opacity-40">בעל הכרטיס</div>
                            <div className="font-medium text-sm">
                                {firstName} {lastName}
                            </div>
                        </div>
                        <div>
                            <div className="text-[10px] uppercase opacity-40">תוקף</div>
                            <div className="font-medium text-sm">
                                {paymentMethod.expiry || 'MM/YY'}
                            </div>
                        </div>
                    </div>
                </div>
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16" />
            </div>

            {/* Inputs */}
            <div className="space-y-4">
                <div className="flex flex-col">
                    <label htmlFor="reg-cardNumber" className="text-[10px] font-bold text-slate-400 mb-1 mr-1 uppercase">
                        מספר כרטיס
                    </label>
                    <input
                        id="reg-cardNumber"
                        type="text"
                        placeholder="0000 0000 0000 0000"
                        value={paymentMethod.cardNumber}
                        onChange={(e) => setCard({ cardNumber: e.target.value })}
                        className="w-full p-3 border border-slate-200 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-sky-500/50 focus-visible:border-sky-500 text-slate-900 font-medium bg-white placeholder:text-slate-300 text-sm"
                    />
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col">
                        <label htmlFor="reg-expiry" className="text-[10px] font-bold text-slate-400 mb-1 mr-1 uppercase">
                            תוקף
                        </label>
                        <input
                            id="reg-expiry"
                            type="text"
                            placeholder="MM/YY"
                            value={paymentMethod.expiry}
                            onChange={(e) => setCard({ expiry: e.target.value })}
                            className="w-full p-3 border border-slate-200 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-sky-500/50 focus-visible:border-sky-500 text-slate-900 font-medium bg-white placeholder:text-slate-300 text-sm"
                        />
                    </div>
                    <div className="flex flex-col">
                        <label htmlFor="reg-cvv" className="text-[10px] font-bold text-slate-400 mb-1 mr-1 uppercase">
                            CVV
                        </label>
                        <input
                            id="reg-cvv"
                            type="text"
                            placeholder="000"
                            value={paymentMethod.cvv}
                            onChange={(e) => setCard({ cvv: e.target.value })}
                            className="w-full p-3 border border-slate-200 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-sky-500/50 focus-visible:border-sky-500 text-slate-900 font-medium bg-white placeholder:text-slate-300 text-sm"
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};
