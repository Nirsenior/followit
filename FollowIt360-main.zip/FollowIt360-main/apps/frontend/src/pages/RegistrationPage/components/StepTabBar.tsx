import React from 'react';

interface Step {
    id: number;
    label: string;
}

interface StepTabBarProps {
    steps: Step[];
    currentStep: number;
    onSelect: (id: number) => void;
}

export const StepTabBar: React.FC<StepTabBarProps> = ({ steps, currentStep, onSelect }) => (
    <div role="tablist" aria-label="שלבי הרשמה" className="bg-white/50 p-1 rounded-2xl mb-8 flex justify-between gap-1 border border-slate-100 shadow-sm">
        {steps.map((s) => (
            <button
                key={s.id}
                role="tab"
                aria-selected={currentStep === s.id}
                disabled={s.id > currentStep}
                onClick={() => onSelect(s.id)}
                className={`flex-1 py-3 px-4 rounded-xl font-bold transition-all text-xs whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-900/50 ${
                    currentStep === s.id
                        ? 'bg-slate-900 text-white shadow-lg'
                        : currentStep > s.id
                          ? 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100'
                          : 'text-slate-400'
                }`}
            >
                {s.label}
            </button>
        ))}
    </div>
);
