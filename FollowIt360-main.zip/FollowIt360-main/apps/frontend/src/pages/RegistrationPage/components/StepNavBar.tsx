import { ArrowRight } from 'lucide-react';
import React from 'react';

interface StepNavBarProps {
    step: number;
    totalSteps: number;
    progress: number;
    onBack: () => void;
}

import Logo from '../../../components/Logo';

export const StepNavBar: React.FC<StepNavBarProps> = ({ step, progress, onBack }) => (
    <nav aria-label="סרגל התקדמות הרשמה" className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md border-b border-slate-100 z-50 p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
            <button
                onClick={onBack}
                className="text-slate-400 font-bold flex items-center gap-2 hover:text-slate-900 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-500/50 rounded-lg p-1"
            >
                <ArrowRight className="w-5 h-5" aria-hidden="true" />
                {step === 1 ? 'חזרה' : 'שלב קודם'}
            </button>

            <Logo variant="dark" showSubtitle={false} className="scale-75 hidden md:flex" aria-hidden="true" />

            <div 
                className="w-32 h-1.5 bg-slate-100 rounded-full overflow-hidden"
                role="progressbar"
                aria-valuenow={progress}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label={`התקדמות: ${progress}%`}
            >
                <div
                    className="h-full bg-sky-500 transition-all duration-500"
                    style={{ width: `${progress}%` }}
                />
            </div>
        </div>
    </nav>
);
