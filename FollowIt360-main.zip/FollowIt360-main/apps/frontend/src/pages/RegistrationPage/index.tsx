import { Customer, UserProfile } from '@repo/types';
import { ArrowRight } from 'lucide-react';
import React from 'react';
import { getSelectedCompanies } from '../../utils/profileUtils';
import { StepNavBar } from './components/StepNavBar';
import { StepTabBar } from './components/StepTabBar';
import { REGISTRATION_STEPS, useRegistration } from './hooks/useRegistration';
import { CompanySelectionStep } from './steps/CompanySelectionStep';
import { FineTuningStep } from './steps/FineTuningStep';
import { GlobalAgreementsStep } from './steps/GlobalAgreementsStep';
import { PaymentMethodStep } from './steps/PaymentMethodStep';

interface RegistrationPageProps {
    initialProfile: UserProfile;
    onComplete: (customers?: Customer[], profile?: Partial<UserProfile>) => void;
    onBack: () => void;
    onSkip: () => void;
}

const RegistrationPage: React.FC<RegistrationPageProps> = ({
    initialProfile,
    onComplete,
    onBack,
    onSkip,
}) => {
    const {
        step,
        profile,
        globalAgreements,
        editingCompany,
        progress,
        setStep,
        setGlobalAgreements,
        setEditingCompany,
        toggleCompany,
        handleAgreementChange,
        applyGlobalDefaults,
        handleComplete,
        updateProfile,
    } = useRegistration(initialProfile, onComplete);

    const handleNavBack = () => (step === 1 ? onBack() : setStep((step - 1) as 1 | 2 | 3 | 4));

    const renderCurrentStep = () => {
        switch (step) {
            case 1:
                return (
                    <CompanySelectionStep
                        selectedCompanies={getSelectedCompanies(profile.agreements)}
                        onToggle={toggleCompany}
                    />
                );
            case 2:
                return (
                    <GlobalAgreementsStep
                        globalAgreements={globalAgreements}
                        onChange={setGlobalAgreements}
                    />
                );
            case 3:
                return (
                    <FineTuningStep
                        selectedCompanies={getSelectedCompanies(profile.agreements)}
                        editingCompany={editingCompany}
                        agreements={profile.agreements}
                        onEdit={setEditingCompany}
                        onClose={() => setEditingCompany(null)}
                        onAgreementChange={handleAgreementChange}
                    />
                );
            case 4:
                return <PaymentMethodStep profile={profile} onUpdate={updateProfile} />;
        }
    };

    return (
        <main className="min-h-screen bg-slate-50 pb-20">
            <StepNavBar
                step={step}
                totalSteps={REGISTRATION_STEPS.length}
                progress={progress}
                onBack={handleNavBack}
            />

            <div className="max-w-4xl mx-auto pt-24 px-6">
                <StepTabBar
                    steps={[...REGISTRATION_STEPS]}
                    currentStep={step}
                    onSelect={(id) => setStep(id as 1 | 2 | 3 | 4)}
                />

                <div className="bg-white p-6 md:p-8 rounded-3xl shadow-xl shadow-slate-200/60 border border-slate-100">
                    {renderCurrentStep()}

                    <div className="mt-8 flex justify-between items-center border-t border-slate-100 pt-6">
                        {step > 1 ? (
                            <button
                                onClick={() => setStep((step - 1) as 1 | 2 | 3 | 4)}
                                className="px-8 py-3 text-slate-500 font-bold hover:text-slate-900 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-500/50 rounded-xl"
                            >
                                חזרה
                            </button>
                        ) : (
                            <div />
                        )}

                        {step < REGISTRATION_STEPS.length ? (
                            <button
                                onClick={
                                    step === 2
                                        ? applyGlobalDefaults
                                        : () => setStep((step + 1) as 1 | 2 | 3 | 4)
                                }
                                className="px-10 py-3.5 bg-sky-500 text-white font-bold rounded-xl shadow-lg shadow-sky-500/20 hover:bg-sky-600 active:scale-95 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500/50"
                            >
                                המשך לשלב הבא
                            </button>
                        ) : (
                            <button
                                onClick={handleComplete}
                                className="px-14 py-4 bg-emerald-500 text-white font-bold rounded-xl shadow-xl shadow-emerald-500/20 hover:bg-emerald-600 active:scale-95 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500/50"
                            >
                                סיימתי, אפשר לצאת לדרך
                            </button>
                        )}
                    </div>
                </div>

                <div className="mt-8 flex justify-center">
                    <button
                        onClick={onSkip}
                        className="text-slate-500 font-bold hover:text-sky-600 transition-all flex items-center gap-2 py-3 px-6 rounded-xl bg-white border border-slate-200 shadow-sm hover:shadow-md hover:border-sky-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500/50"
                    >
                        דלג על הגדרה כרגע <ArrowRight className="w-4 h-4" aria-hidden="true" />
                    </button>
                </div>
            </div>
        </main>
    );
};

export default RegistrationPage;
