import { INSURANCE_TYPE_LABELS, InsuranceType } from '@repo/types';
import { AlertTriangle, Calendar, History, X } from 'lucide-react';
import React from 'react';

interface EffectivityModalProps {
    pendingChange: { company: string; type: InsuranceType; oldValue: string; newValue: string };
    onCancel: () => void;
    applyChange: (isRetroactive: boolean) => void;
}

export const EffectivityModal: React.FC<EffectivityModalProps> = ({
    pendingChange,
    onCancel,
    applyChange,
}) => {
    return (
        <div 
            className="fixed inset-0 z-[200] flex items-center justify-center p-6 grayscale-0"
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-title"
            aria-describedby="modal-description"
        >
            <div
                className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm animate-fadeIn"
                onClick={onCancel}
                aria-hidden="true"
            />
            <div
                className="relative bg-white rounded-[32px] shadow-2xl w-full max-w-lg overflow-hidden animate-scaleIn border border-slate-100 font-sans"
                dir="rtl"
            >
                {/* Close Button */}
                <button
                    onClick={onCancel}
                    aria-label="סגור"
                    className="absolute top-6 right-6 p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400 hover:text-slate-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-500/50 z-10"
                >
                    <X className="w-5 h-5" aria-hidden="true" />
                </button>

                <div className="p-8 text-center space-y-6">
                    <div className="w-20 h-20 bg-amber-50 rounded-3xl flex items-center justify-center mx-auto mb-2 animate-bounce-subtle" aria-hidden="true">
                        <AlertTriangle className="w-10 h-10 text-amber-500" />
                    </div>

                    <div className="space-y-2">
                        <h3 id="modal-title" className="text-2xl font-bold text-slate-900">עדכון עמלת נפרעים</h3>
                        <p id="modal-description" className="text-slate-500 text-sm leading-relaxed px-4">
                            ביצעת שינוי בשיעור עמלת הנפרעים במוצר{' '}
                            <span className="text-slate-900 font-bold">
                                "{INSURANCE_TYPE_LABELS[pendingChange.type]}"
                            </span>
                            {pendingChange.company !== 'GLOBAL'
                                ? ` עבור חברת ${pendingChange.company}`
                                : ' באופן גורף'}
                            .
                            <br />
                            כיצד תרצה להחיל את השינוי על תיק הלקוחות הקיים?
                        </p>
                    </div>

                    <div className="grid grid-cols-1 gap-3 pt-2">
                        {/* Option 1: Retroactive Update (Cyan Theme) */}
                        <button
                            onClick={() => applyChange(true)}
                            className="group relative w-full p-5 bg-slate-50/60 hover:bg-cyan-50/50 border-2 border-slate-100 hover:border-cyan-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500 rounded-2xl transition-all duration-300 flex items-start gap-4 text-right shadow-sm hover:shadow-md active:scale-[0.99] overflow-hidden"
                        >
                            <div className="w-12 h-12 rounded-xl bg-slate-100 group-hover:bg-cyan-100 text-slate-500 group-hover:text-cyan-700 flex items-center justify-center transition-all duration-300 shrink-0" aria-hidden="true">
                                <History className="w-6 h-6 transition-transform duration-500" />
                            </div>
                            <div className="space-y-1">
                                <div className="font-bold text-slate-900 group-hover:text-cyan-900 transition-colors">
                                    עדכון רטרואקטיבי (גורף)
                                </div>
                                <div className="text-[11.5px] text-slate-400 group-hover:text-cyan-700 font-medium transition-colors leading-relaxed">
                                    החלת האחוז החדש ({pendingChange.newValue}%) על כל הפוליסות
                                    הקיימות במערכת.
                                </div>
                            </div>
                        </button>

                        {/* Option 2: Future Update (Sky Theme) */}
                        <button
                            onClick={() => applyChange(false)}
                            className="group relative w-full p-5 bg-slate-50/60 hover:bg-sky-50/50 border-2 border-slate-100 hover:border-sky-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded-2xl transition-all duration-300 flex items-start gap-4 text-right shadow-sm hover:shadow-md active:scale-[0.99] overflow-hidden"
                        >
                            <div className="w-12 h-12 rounded-xl bg-slate-100 group-hover:bg-sky-100 text-slate-500 group-hover:text-sky-700 flex items-center justify-center transition-all duration-300 shrink-0" aria-hidden="true">
                                <Calendar className="w-6 h-6 transition-transform duration-500 group-hover:scale-110" />
                            </div>
                            <div className="space-y-1">
                                <div className="font-bold text-slate-900 group-hover:text-sky-900 transition-colors">
                                    עדכון מיום השינוי בלבד
                                </div>
                                <div className="text-[11.5px] text-slate-400 group-hover:text-sky-700 font-medium transition-colors leading-relaxed">
                                    שמירה על האחוז הישן ({pendingChange.oldValue}%) לפוליסות קיימות,
                                    והפעלת האחוז החדש ({pendingChange.newValue}%) רק למכירות
                                    עתידיות.
                                </div>
                            </div>
                        </button>
                    </div>

                    <button
                        onClick={onCancel}
                        className="text-xs font-bold text-slate-400 hover:text-slate-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-400/50 p-2 rounded-lg transition-colors uppercase tracking-widest pt-4"
                    >
                        ביטול השינוי
                    </button>
                </div>
            </div>
        </div>
    );
};
