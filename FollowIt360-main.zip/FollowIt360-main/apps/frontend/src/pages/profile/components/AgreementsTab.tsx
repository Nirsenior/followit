import {
    FINANCIAL_ONLY_COMPANIES,
    isFinancialType,
    INSURANCE_COMPANIES,
    INSURANCE_TYPE_LABELS,
    InsuranceType,
    isMobilityType,
    UserProfile,
} from '@repo/types';
import { Settings2, Trash2, X, Check } from 'lucide-react';
import React, { useCallback, useState } from 'react';
import { DebouncedInput } from '../../../components/ui/DebouncedInput';
import { getSelectedCompanies } from '../../../utils/profileUtils';
import { CompanyAgreementEditor } from './CompanyAgreementEditor';
import { CompanyLogo } from '../../../components/CompanyLogo';

interface AgreementsTabProps {
    localProfile: UserProfile;
    setLocalProfile: React.Dispatch<React.SetStateAction<UserProfile>>;
    globalAgreements: Record<string, any>;
    handleGlobalAgreementChange: (type: InsuranceType, field: string, value: any) => void;
    setPendingChange: (val: any) => void;
}

export const AgreementsTab: React.FC<AgreementsTabProps> = ({
    localProfile,
    setLocalProfile,
    globalAgreements,
    handleGlobalAgreementChange,
    setPendingChange
}) => {
    const [agreementStep, setAgreementStep] = useState(1);
    const [editingCompany, setEditingCompany] = useState<string | null>(null);

    const applyGlobalDefaults = () => {
        const nextAgreements = { ...localProfile.agreements };
        getSelectedCompanies(localProfile.agreements).forEach((company: string) => {
            nextAgreements[company] = JSON.parse(JSON.stringify(globalAgreements));
        });
        setLocalProfile((prev: UserProfile) => ({ ...prev, agreements: nextAgreements }));
        setAgreementStep(3);
    };

    const removeCompany = (company: string) => {
        setLocalProfile((prev: UserProfile) => {
            const nextAgreements = { ...prev.agreements };
            delete nextAgreements[company];
            return { ...prev, agreements: nextAgreements };
        });
    };

    const handleAgreementChange = useCallback(
        (company: string, type: InsuranceType, field: string, value: any) => {
            setLocalProfile((prev: UserProfile) => {
                const next = { ...prev.agreements };
                if (!next[company]) next[company] = {};
                next[company] = {
                    ...next[company],
                    [type]: { ...(next[company][type] || {}), [field]: value },
                };
                return { ...prev, agreements: next };
            });
        },
        [setLocalProfile],
    );

    const handlePendingChange = useCallback(
        (
            company: string,
            type: InsuranceType,
            _field: string,
            newValue: string,
            oldValue: string,
        ) => {
            // Update state immediately
            handleAgreementChange(company, type, 'ongoing', newValue);
            
            setPendingChange({
                company,
                type,
                oldValue,
                newValue,
            });
        },
        [setPendingChange, handleAgreementChange],
    );

    return (
        <div className="space-y-8 animate-fadeIn">
            <nav aria-label="שלבי הגדרה" className="flex bg-slate-50/50 p-1.5 rounded-2xl mb-8 border border-slate-100 shadow-sm overflow-x-auto font-sans">
                {[
                    { id: 1, label: 'חברות' },
                    { id: 2, label: 'הסכם ברירת מחדל' },
                    { id: 3, label: 'דיוק והתאמה' },
                ].map((s) => (
                    <button
                        key={s.id}
                        onClick={() => setAgreementStep(s.id)}
                        aria-current={agreementStep === s.id ? 'step' : undefined}
                        className={`flex-1 py-3 px-4 rounded-xl font-bold transition-all text-xs whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-700/50 ${
                            agreementStep === s.id
                                ? 'bg-cyan-700 text-white shadow-lg shadow-cyan-700/20'
                                : agreementStep > s.id
                                  ? 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                                  : 'text-slate-400 hover:text-slate-600'
                        }`}
                    >
                        {s.label}
                    </button>
                ))}
            </nav>

            {agreementStep === 1 && (
                <div className="space-y-6 animate-fadeIn">
                    <div className="text-center mb-6">
                        <h2 className="text-xl font-bold text-slate-900">
                            בחר את החברות איתן אתה עובד
                        </h2>
                        <p className="text-slate-500 text-xs">
                            לחץ על החברות הרלוונטיות כדי להוסיף אותן להסכמי העמלות שלך.
                        </p>
                    </div>
                    <div className="max-w-4xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 font-sans">
                        {[...INSURANCE_COMPANIES]
                            .sort((a, b) => a.localeCompare(b, 'he'))
                            .map((company: string) => {
                            const isSelected =
                                !!localProfile.agreements[company] && company !== 'GLOBAL';
                            return (
                                <button
                                    key={company}
                                    onClick={() => {
                                        const nextAgreements = { ...localProfile.agreements };

                                        if (isSelected) {
                                            delete nextAgreements[company]; // optionally cleanup
                                        } else {
                                            // Fill the newly added company with the current global default agreement values immediately
                                            nextAgreements[company] = JSON.parse(
                                                JSON.stringify(globalAgreements),
                                            );
                                        }

                                        setLocalProfile((prev: UserProfile) => ({
                                            ...prev,
                                            agreements: nextAgreements,
                                        }));
                                    }}
                                    aria-pressed={isSelected}
                                    className={`px-5 py-4 rounded-2xl border transition-all flex items-center justify-between text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-700/50 ${
                                        isSelected
                                            ? 'bg-cyan-50/50 border-cyan-200 text-cyan-900 font-bold shadow-sm'
                                            : 'bg-white border-slate-100 text-slate-600 font-medium hover:bg-slate-50 hover:border-slate-200'
                                    }`}
                                >
                                    <div className="flex items-center gap-3">
                                        <CompanyLogo company={company} className="w-8 h-8 rounded-full" aria-hidden="true" />
                                        <span className="font-bold">{company}</span>
                                    </div>
                                    <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all ${
                                        isSelected ? 'bg-cyan-700 border-cyan-700' : 'border-slate-200 bg-white'
                                    }`} aria-hidden="true">
                                        {isSelected && <Check className="w-3.5 h-3.5 text-white" strokeWidth={3} />}
                                    </div>
                                </button>
                            );
                        })}
                    </div>
                    <div className="pt-6 border-t border-slate-100 flex justify-end">
                        <button
                            onClick={() => setAgreementStep(2)}
                            disabled={getSelectedCompanies(localProfile.agreements).length === 0}
                            className="px-10 py-3 bg-sky-500 text-white font-bold rounded-xl shadow-lg shadow-sky-500/20 hover:bg-sky-600 active:scale-95 transition-all disabled:opacity-50 disabled:grayscale focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500/50"
                        >
                            המשך לשלב הבא
                        </button>
                    </div>
                </div>
            )}

            {agreementStep === 2 && (
                <div className="space-y-6 animate-fadeIn font-sans">
                    <div className="text-center mb-8">
                        <h2 className="text-xl font-bold text-slate-800">
                            הסכם ברירת מחדל (Master Agreement)
                        </h2>
                        <p className="text-slate-400 text-sm mt-1">
                            הזן את העמלות שאתה מקבל ברוב החברות.
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {(
                            [
                                'health',
                                'life',
                                'critical_illness',
                                'pension',
                                'gemel',
                                'hishtalmut',
                                'gemel_invest',
                                'long_term_savings',
                                'elementary',
                                'abroad',
                            ] as InsuranceType[]
                        ).map((type) => (
                            <div
                                key={type}
                                className="bg-slate-50/50 p-6 rounded-2xl border border-slate-100 space-y-4"
                            >
                                <div className="flex items-center gap-3">
                                    <div className="w-1.5 h-6 bg-cyan-700 rounded-full"></div>
                                    <h4 className="font-bold text-slate-800">
                                        {INSURANCE_TYPE_LABELS[type]}
                                    </h4>
                                </div>

                                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                                    {type === 'elementary' || type === 'abroad' ? (
                                        <div className="col-span-full">
                                            <label className="flex items-center gap-3 cursor-pointer group bg-white p-4 rounded-xl border border-slate-200 hover:border-cyan-700 focus-within:ring-2 focus-within:ring-cyan-700/50 transition-all w-fit">
                                                <input
                                                    type="checkbox"
                                                    className="w-5 h-5 accent-cyan-700 rounded border-slate-200 focus-visible:outline-none"
                                                    checked={
                                                        globalAgreements[type]?.isActive || false
                                                    }
                                                    onChange={(e) =>
                                                        handleGlobalAgreementChange(
                                                            type,
                                                            'isActive',
                                                            e.target.checked,
                                                        )
                                                    }
                                                />
                                                <span className="font-bold text-slate-700 text-sm">
                                                    {type === 'elementary' ? 'האם מוכר אלמנטרי? (כן/לא)' : 'האם מוכר ביטוח חו"ל? (כן/לא)'}
                                                </span>
                                            </label>
                                        </div>
                                    ) : (
                                        <>
                                            <div className="flex flex-col">
                                                <label className="text-[11px] font-bold text-slate-500 mb-1 mr-1 uppercase">
                                                    {isFinancialType(type)
                                                        ? 'היקף הפקדות (%)'
                                                        : 'היקף (%)'}
                                                </label>
                                                <DebouncedInput
                                                    placeholder="0"
                                                    className="p-3 border border-slate-200 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-cyan-700/50 focus-visible:border-cyan-700 bg-white font-bold"
                                                    value={globalAgreements[type]?.scope}
                                                    onCommit={(v: string) =>
                                                        handleGlobalAgreementChange(
                                                            type,
                                                            'scope',
                                                            v,
                                                        )
                                                    }
                                                />
                                            </div>
                                            <div className="flex flex-col">
                                                <label className="text-[11px] font-bold text-slate-500 mb-1 mr-1 uppercase">נפרעים (%)</label>
                                                <DebouncedInput
                                                    placeholder="0"
                                                    className="p-3 border border-slate-200 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 focus-visible:border-blue-500 bg-white font-bold"
                                                    value={globalAgreements[type]?.ongoing}
                                                    onCommit={(v: string, oldVal: string) => {
                                                        // Update state immediately so UI reflects the change
                                                        handleGlobalAgreementChange(type, 'ongoing', v);
                                                        // Then trigger the modal for retroactive choice
                                                        setPendingChange({
                                                            company: 'GLOBAL',
                                                            type,
                                                            oldValue: oldVal,
                                                            newValue: v
                                                        });
                                                    }}
                                                />
                                            </div>
                                            {isMobilityType(type) && (
                                                <div className="flex flex-col">
                                                    <label className="text-[11px] font-bold text-slate-500 mb-1 mr-1 uppercase">
                                                        היקף ניוד (%)
                                                    </label>
                                                    <DebouncedInput
                                                        placeholder="0"
                                                        className="p-3 border border-slate-200 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 focus-visible:border-blue-500 bg-white font-bold"
                                                        value={globalAgreements[type]?.mobility}
                                                        onCommit={(v: string) =>
                                                            handleGlobalAgreementChange(
                                                                type,
                                                                'mobility',
                                                                v,
                                                            )
                                                        }
                                                    />
                                                </div>
                                            )}
                                        </>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>

                    <div className="pt-6 border-t border-slate-100 flex justify-between gap-4">
                        <button
                            onClick={() => setAgreementStep(1)}
                            className="px-8 py-3 text-slate-500 font-bold hover:text-slate-900 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-500/50 rounded-xl"
                        >
                            חזרה
                        </button>
                        <button
                            onClick={applyGlobalDefaults}
                            className="px-12 py-3.5 bg-sky-500 text-white font-bold rounded-xl shadow-lg shadow-sky-500/20 hover:bg-sky-600 active:scale-95 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500/50"
                        >
                            החל על כל החברות והמשך לדיוק והתאמה
                        </button>
                    </div>
                </div>
            )}

            {agreementStep === 3 && (
                <div className="animate-fadeIn space-y-6 font-sans">
                    <div className="text-center mb-6">
                        <h2 className="text-xl font-bold text-slate-800">דיוק והתאמת הסכמים</h2>
                        <p className="text-slate-400 text-sm">
                            ערוך חברה ספציפית אם יש לה הסכם שונה.
                        </p>
                    </div>

                    <div className="space-y-3">
                        {getSelectedCompanies(localProfile.agreements)
                            .sort((a, b) => a.localeCompare(b, 'he'))
                            .map((company: string) => (
                            <div
                                key={company}
                                className="bg-slate-50/50 border border-slate-100 rounded-2xl p-4 shadow-sm flex items-center justify-between hover:border-blue-200 transition-all group"
                            >
                                <div className="flex items-center gap-4">
                                    <CompanyLogo company={company} className="w-10 h-10 rounded-xl group-hover:border-cyan-700 transition-colors" aria-hidden="true" />
                                    <div>
                                        <h4 className="font-bold text-slate-800">{company}</h4>
                                        <p className="text-[10px] text-slate-400 uppercase tracking-tighter">
                                            הסכם מותאם אישית
                                        </p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-2">
                                    <button
                                        onClick={() => setEditingCompany(company)}
                                        className="px-6 py-2 rounded-xl font-bold text-sm transition-all border border-cyan-700/30 text-cyan-700 hover:bg-cyan-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-700/50"
                                    >
                                        עריכה
                                    </button>
                                    <button
                                        onClick={() => removeCompany(company)}
                                        aria-label={`מחק את הסכם ${company}`}
                                        className="p-2 text-slate-300 hover:text-rose-500 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500/50 rounded-lg"
                                    >
                                        <Trash2 className="w-4 h-4" aria-hidden="true" />
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>

                    <div className="pt-6 border-t border-slate-100 flex justify-between">
                        <button onClick={() => setAgreementStep(2)} className="px-8 py-3 text-slate-500 font-bold hover:text-slate-900 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-500/50 rounded-xl">חזרה להסכם כללי</button>
                    </div>
                </div>
            )}

            {/* Edit Drawer Overlay */}
            {editingCompany && (
                <div 
                    className="fixed inset-0 z-[100] flex justify-end"
                    role="dialog"
                    aria-modal="true"
                    aria-labelledby="drawer-title"
                >
                    <div
                        className="absolute inset-0 bg-slate-900/60 animate-fadeIn"
                        onClick={() => setEditingCompany(null)}
                        aria-hidden="true"
                    />
                    <div className="relative w-full max-w-md bg-white h-full shadow-2xl animate-slideLeft flex flex-col">
                        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                            <div className="flex items-center gap-3">
                                <Settings2 className="w-5 h-5 text-cyan-700" aria-hidden="true" />
                                <h3 id="drawer-title" className="text-lg font-bold text-slate-900">
                                    עריכת הסכם: {editingCompany}
                                </h3>
                            </div>
                            <button
                                onClick={() => setEditingCompany(null)}
                                aria-label="סגור"
                                className="p-2 hover:bg-slate-200 rounded-lg transition-colors text-slate-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-700/50"
                            >
                                <X className="w-6 h-6" aria-hidden="true" />
                            </button>
                        </div>

                        <div className="flex-1 overflow-y-auto p-6 space-y-6">
                            {(
                                [
                                    'health',
                                    'life',
                                    'critical_illness',
                                    'pension',
                                    'gemel',
                                    'hishtalmut',
                                    'gemel_invest',
                                    'long_term_savings',
                                    'elementary',
                                    'abroad',
                                ] as InsuranceType[]
                            )
                                .filter((type) => {
                                    if (
                                        editingCompany &&
                                        FINANCIAL_ONLY_COMPANIES.includes(editingCompany)
                                    ) {
                                        return isFinancialType(type);
                                    }
                                    return true;
                                })
                                .map((type) => (
                                    <CompanyAgreementEditor
                                        key={type}
                                        company={editingCompany as string}
                                        type={type}
                                        agreement={localProfile.agreements[editingCompany]?.[type]}
                                        onChange={handleAgreementChange}
                                        onPendingChange={handlePendingChange}
                                    />
                                ))}
                        </div>

                        <div className="p-6 border-t border-slate-100 bg-slate-50/30">
                            <button
                                onClick={() => setEditingCompany(null)}
                                className="w-full py-4 bg-slate-900 text-white font-bold rounded-2xl shadow-xl shadow-slate-900/20 hover:bg-slate-800 active:scale-95 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-900/50"
                            >
                                שמירה וסגירה
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
