import { INSURANCE_TYPE_LABELS, InsuranceType, isFinancialType, isMobilityType } from '@repo/types';
import React from 'react';
import { DebouncedInput } from '../../../components/ui/DebouncedInput';

interface CompanyAgreementEditorProps {
    company: string;
    type: InsuranceType;
    agreement: any;
    onChange: (company: string, type: InsuranceType, field: string, value: any) => void;
    onPendingChange: (
        company: string,
        type: InsuranceType,
        field: string,
        value: string,
        oldValue: string,
    ) => void;
}

export const CompanyAgreementEditor = React.memo(
    ({ company, type, agreement, onChange, onPendingChange }: CompanyAgreementEditorProps) => {
        return (
            <div className="bg-slate-50/50 p-5 rounded-2xl border border-slate-100 space-y-4 font-sans">
                <div className="flex items-center justify-between">
                    <h4 className="font-bold text-cyan-700 text-sm">
                        {INSURANCE_TYPE_LABELS[type]}
                    </h4>
                    <div className="h-px flex-1 bg-cyan-100 mx-4 opacity-50"></div>
                </div>
                <div className="grid grid-cols-1 gap-4">
                    {type === 'elementary' ? (
                        <label className="flex items-center gap-3 cursor-pointer group bg-white p-3 rounded-xl border border-slate-200 hover:border-cyan-700 focus-within:ring-2 focus-within:ring-cyan-700/50 transition-all">
                            <input
                                type="checkbox"
                                className="w-5 h-5 accent-cyan-700 rounded border-slate-200 focus-visible:outline-none"
                                checked={agreement?.isActive || false}
                                onChange={(e) =>
                                    onChange(company, type, 'isActive', e.target.checked)
                                }
                            />
                            <span className="font-bold text-slate-700 text-sm">
                                האם מוכר אלמנטרי? (כן/לא)
                            </span>
                        </label>
                    ) : (
                        <>
                            <div className="flex flex-col">
                                <label htmlFor={`scope-${company}-${type}`} className="text-[11px] font-bold text-slate-500 mb-1.5 uppercase tracking-wider mr-1">
                                    {isFinancialType(type)
                                        ? 'עמלת היקף הפקדות (%)'
                                        : 'עמלת היקף (%)'}
                                </label>
                                <DebouncedInput
                                    id={`scope-${company}-${type}`}
                                    placeholder="0"
                                    className="p-3 border border-slate-200 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 focus-visible:border-blue-500 bg-white font-bold text-slate-900 transition-all"
                                    value={agreement?.scope}
                                    onCommit={(v: string) => onChange(company, type, 'scope', v)}
                                />
                            </div>
                            {type !== 'abroad' && (
                                <div className="flex flex-col">
                                    <label htmlFor={`ongoing-${company}-${type}`} className="text-[11px] font-bold text-slate-500 mb-1.5 uppercase tracking-wider mr-1">
                                        עמלת נפרעים (%)
                                    </label>
                                    <DebouncedInput
                                        id={`ongoing-${company}-${type}`}
                                        placeholder="0"
                                        className="p-3 border border-slate-200 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 focus-visible:border-blue-500 bg-white font-bold text-slate-900 transition-all"
                                        value={agreement?.ongoing}
                                        onCommit={(v: string, oldVal: string) =>
                                            onPendingChange(company, type, 'ongoing', v, oldVal)
                                        }
                                    />
                                </div>
                            )}
                            {isMobilityType(type) && (
                                <div className="flex flex-col">
                                    <label htmlFor={`mobility-${company}-${type}`} className="text-[11px] font-bold text-slate-500 mb-1.5 uppercase tracking-wider mr-1">
                                        עמלת היקף ניוד (%)
                                    </label>
                                    <DebouncedInput
                                        id={`mobility-${company}-${type}`}
                                        placeholder="0"
                                        className="p-3 border border-slate-200 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-cyan-700/50 focus-visible:border-cyan-700 bg-white font-bold text-slate-900 transition-all"
                                        value={agreement?.mobility}
                                        onCommit={(v: string) =>
                                            onChange(company, type, 'mobility', v)
                                        }
                                    />
                                </div>
                            )}
                        </>
                    )}
                </div>
            </div>
        );
    },
);
