import { UserProfile } from '@repo/types';
import { CreditCard, Trash2 } from 'lucide-react';
import React from 'react';

interface PersonalTabProps {
    localProfile: UserProfile;
    setLocalProfile: React.Dispatch<React.SetStateAction<UserProfile>>;
}

export const PersonalTab: React.FC<PersonalTabProps> = ({ localProfile, setLocalProfile }) => {
    const updatePayment = (field: string, value: string) => {
        setLocalProfile((prev: UserProfile) => ({
            ...prev,
            paymentMethod: { ...(prev.paymentMethod || {}), [field]: value },
        }));
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 animate-fadeIn font-sans" dir="rtl">
            {/* Right Side: Agent Details */}
            <div className="space-y-6">
                <h3 className="text-sm font-bold text-slate-800 uppercase tracking-widest border-b border-slate-100 pb-3">
                    פרטי הסוכן
                </h3>
                
                <div className="space-y-5">
                    <div>
                        <label htmlFor="personal-firstName" className="text-[11px] font-bold text-slate-500 mb-1.5 block">
                            שם פרטי
                        </label>
                        <input
                            id="personal-firstName"
                            type="text"
                            value={localProfile.firstName || ''}
                            onChange={(e) => setLocalProfile({ ...localProfile, firstName: e.target.value })}
                            className="w-full p-3.5 border border-slate-200 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 focus-visible:border-blue-500 transition-all bg-slate-50/50 hover:bg-white text-slate-900 font-medium text-sm"
                        />
                    </div>
                    <div>
                        <label htmlFor="personal-lastName" className="text-[11px] font-bold text-slate-500 mb-1.5 block">
                            שם משפחה
                        </label>
                        <input
                            id="personal-lastName"
                            type="text"
                            value={localProfile.lastName || ''}
                            onChange={(e) => setLocalProfile({ ...localProfile, lastName: e.target.value })}
                            className="w-full p-3.5 border border-slate-200 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 focus-visible:border-blue-500 transition-all bg-slate-50/50 hover:bg-white text-slate-900 font-medium text-sm"
                        />
                    </div>
                    <div>
                        <label htmlFor="personal-email" className="text-[11px] font-bold text-slate-500 mb-1.5 block">
                            כתובת מייל לעדכונים
                        </label>
                        <input
                            id="personal-email"
                            type="email"
                            value={localProfile.email || ''}
                            onChange={(e) => setLocalProfile({ ...localProfile, email: e.target.value })}
                            className="w-full p-3.5 border border-slate-200 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 focus-visible:border-blue-500 transition-all bg-slate-50/50 hover:bg-white text-slate-900 font-medium text-sm text-left"
                            dir="ltr"
                        />
                    </div>
                    <div>
                        <label htmlFor="personal-phone" className="text-[11px] font-bold text-slate-500 mb-1.5 block">
                            מספר טלפון
                        </label>
                        <input
                            id="personal-phone"
                            type="tel"
                            value={localProfile.phone || ''}
                            onChange={(e) => setLocalProfile({ ...localProfile, phone: e.target.value })}
                            className="w-full p-3.5 border border-slate-200 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 focus-visible:border-blue-500 transition-all bg-slate-50/50 hover:bg-white text-slate-900 font-medium text-sm text-left"
                            dir="ltr"
                        />
                    </div>
                </div>
            </div>

            {/* Left Side: Payment & Subscription */}
            <div className="space-y-6">
                <h3 className="text-sm font-bold text-slate-800 uppercase tracking-widest border-b border-slate-100 pb-3">
                    אמצעי תשלום וניהול מנוי
                </h3>
                
                <div className="space-y-8">
                    {/* Payment Info */}
                    <div className="bg-blue-50/50 p-6 rounded-2xl border border-blue-100 space-y-5">
                        <div className="flex items-center gap-3 text-blue-900 font-bold mb-2">
                            <CreditCard className="w-5 h-5 text-blue-500" aria-hidden="true" />
                            <span>עריכת כרטיס אשראי</span>
                        </div>
                        
                        <div>
                            <label htmlFor="personal-cardNumber" className="text-[11px] font-bold text-slate-500 mb-1.5 block">
                                מספר כרטיס
                            </label>
                            <input
                                id="personal-cardNumber"
                                type="text"
                                value={localProfile.paymentMethod?.cardNumber || ''}
                                onChange={(e) => updatePayment('cardNumber', e.target.value)}
                                className="w-full p-3.5 border border-white rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 focus-visible:border-blue-500 transition-all bg-white text-slate-900 font-medium text-sm tracking-widest text-left"
                                placeholder="0000 0000 0000 0000"
                                dir="ltr"
                            />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="personal-expiry" className="text-[11px] font-bold text-slate-500 mb-1.5 block">
                                    תוקף (MM/YY)
                                </label>
                                <input
                                    id="personal-expiry"
                                    type="text"
                                    value={localProfile.paymentMethod?.expiry || ''}
                                    onChange={(e) => updatePayment('expiry', e.target.value)}
                                    className="w-full p-3.5 border border-white rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 focus-visible:border-blue-500 transition-all bg-white text-slate-900 font-medium text-sm text-center"
                                    placeholder="12/28"
                                    dir="ltr"
                                />
                            </div>
                            <div>
                                <label htmlFor="personal-cvv" className="text-[11px] font-bold text-slate-500 mb-1.5 block">
                                    CVV
                                </label>
                                <input
                                    id="personal-cvv"
                                    type="text"
                                    value={localProfile.paymentMethod?.cvv || ''}
                                    onChange={(e) => updatePayment('cvv', e.target.value)}
                                    className="w-full p-3.5 border border-white rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 focus-visible:border-blue-500 transition-all bg-white text-slate-900 font-medium text-sm text-center"
                                    placeholder="000"
                                    dir="ltr"
                                />
                            </div>
                        </div>
                    </div>

                    {/* Cancel Subscription */}
                    <div className="pt-4 border-t border-slate-100 flex flex-col items-start gap-2">
                        <button className="text-rose-600 font-bold hover:bg-rose-50 px-5 py-2.5 rounded-xl transition-all text-sm border border-transparent hover:border-rose-200 flex items-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500/50">
                            <Trash2 className="w-4 h-4" aria-hidden="true" />
                            ביטול מנוי Followit360
                        </button>
                        <p className="text-[11px] text-slate-400 leading-relaxed font-medium px-2">
                            ביטול המנוי יפסיק את הגישה ליומן הלקוחות ויעצור את חישוב העמלות.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
};
