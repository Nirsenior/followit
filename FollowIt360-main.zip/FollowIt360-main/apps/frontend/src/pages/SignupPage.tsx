import { zodResolver } from '@hookform/resolvers/zod';
import { UserProfile } from '@repo/types';
import { ArrowRight } from 'lucide-react';
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import * as z from 'zod';
import { translateError } from '../utils/errorTranslator';

const signupSchema = z.object({
    firstName: z.string().min(2, 'שם פרטי חייב להכיל לפחות 2 תווים'),
    lastName: z.string().min(2, 'שם משפחה חייב להכיל לפחות 2 תווים'),
    email: z.string().email('כתובת דוא״ל לא חוקית'),
    password: z.string().min(8, 'סיסמה חייבת להכיל לפחות 8 תווים'),
});

type SignupFormValues = z.infer<typeof signupSchema>;

interface SignupSuccessInfo {
    id: UserProfile['id'];
    firstName: UserProfile['firstName'];
    lastName: UserProfile['lastName'];
    email: UserProfile['email'];
}

interface SignupPageProps {
    onSignupSuccess: (basicInfo: SignupSuccessInfo) => void;
    onLoginClick: () => void;
}

const SignupPage: React.FC<SignupPageProps> = ({ onSignupSuccess, onLoginClick }) => {
    const [isLoading, setIsLoading] = useState(false);
    const {
        register,
        handleSubmit,
        setError,
        formState: { errors },
    } = useForm<SignupFormValues>({
        resolver: zodResolver(signupSchema),
    });

    const onSubmit = async (data: SignupFormValues) => {
        setIsLoading(true);
        try {
            const baseUrl = import.meta.env.VITE_API_URL || '';
            const response = await fetch(`${baseUrl}/api/auth/signup`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'include',
                body: JSON.stringify({
                    name: `${data.firstName} ${data.lastName}`.trim(),
                    email: data.email,
                    password: data.password,
                }),
            });

            const result = await response.json();

            if (!response.ok) {
                if (response.status === 409) {
                    setError('email', {
                        type: 'manual',
                        message: 'כתובת דוא״ל זו כבר רשומה במערכת',
                    });
                } else {
                    setError('root', {
                        type: 'manual',
                        message: translateError(result.message),
                    });
                }
                setIsLoading(false);
                return;
            }

            onSignupSuccess({
                id: result.userId,
                firstName: data.firstName,
                lastName: data.lastName,
                email: data.email,
            });
        } catch (err) {
            console.error('Signup error:', err);
            setError('root', { type: 'manual', message: 'שגיאת תקשורת. בדוק את החיבור שלך.' });
        } finally {
            setIsLoading(false);
        }
    };

    const handleGoogleLogin = () => {
        const baseUrl = import.meta.env.VITE_API_URL || '';
        window.location.href = `${baseUrl}/api/auth/google`;
    };

    return (
        <main
            className="min-h-screen bg-[#0A1128] text-white flex flex-col items-center justify-center p-6 relative overflow-hidden"
            dir="rtl"
        >
            <h1 className="sr-only">הרשמה ל-Followit360</h1>

            {/* Background Glows — decorative */}
            <div className="absolute inset-0 opacity-40 pointer-events-none" aria-hidden="true">
                <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-blue-600/20 rounded-full blur-[120px] -mr-[300px] -mt-[300px]"></div>
                <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-[100px] -ml-[250px] -mb-[250px]"></div>
            </div>

            <div className="bg-white/5 backdrop-blur-md w-full max-w-md rounded-2xl shadow-2xl relative z-10 overflow-hidden border border-white/10 animate-slideUp">
                <div className="p-6 pb-4 text-center">
                    <p className="text-2xl font-bold text-white mb-2">יצירת חשבון חדש</p>
                    <p className="text-slate-400 text-sm">
                        הצטרפו למאות סוכנים שכבר משתמשים ב-Followit360
                    </p>
                </div>

                <div className="px-6 pb-6 space-y-4">
                    <div className="flex flex-col gap-3">
                        <button
                            type="button"
                            onClick={handleGoogleLogin}
                            className="w-full flex items-center justify-center gap-3 py-2.5 px-4 rounded-xl border border-white/10 font-bold text-white bg-white/5 hover:bg-white/10 hover:border-white/20 transition-all active:scale-[0.99] text-sm"
                        >
                            <svg
                                className="w-5 h-5"
                                viewBox="0 0 24 24"
                                aria-hidden="true"
                                focusable="false"
                            >
                                <path
                                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                                    fill="#4285F4"
                                />
                                <path
                                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                                    fill="#34A853"
                                />
                                <path
                                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                                    fill="#FBBC05"
                                />
                                <path
                                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                                    fill="#EA4335"
                                />
                            </svg>
                            המשך באמצעות Google
                        </button>
                    </div>

                    <div className="flex items-center gap-4" aria-hidden="true">
                        <div className="h-px bg-white/10 flex-1"></div>
                        <span className="text-xs text-slate-400 font-bold">או הרשמה במייל</span>
                        <div className="h-px bg-white/10 flex-1"></div>
                    </div>

                    <form
                        onSubmit={handleSubmit(onSubmit)}
                        className="space-y-4"
                        aria-label="טופס הרשמה"
                        noValidate
                    >
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label
                                    htmlFor="signup-firstName"
                                    className="text-[10px] font-bold text-slate-300 mb-1 block mr-1 uppercase"
                                >
                                    שם פרטי
                                </label>
                                <input
                                    id="signup-firstName"
                                    {...register('firstName')}
                                    type="text"
                                    autoComplete="given-name"
                                    aria-invalid={!!errors.firstName}
                                    aria-describedby={
                                        errors.firstName ? 'signup-firstName-error' : undefined
                                    }
                                    className={`w-full p-2.5 border rounded-xl focus:ring-2 outline-none transition-all text-sm font-medium text-white ${
                                        errors.firstName
                                            ? 'border-red-500/50 focus:border-red-500 focus:ring-red-500/20 bg-red-950/20 placeholder-red-300/40'
                                            : 'border-white/10 focus:border-sky-500 focus:ring-sky-500/20 bg-white/5'
                                    }`}
                                />
                                {errors.firstName && (
                                    <p
                                        id="signup-firstName-error"
                                        role="alert"
                                        className="mt-1 text-xs text-red-400 mr-1"
                                    >
                                        {errors.firstName.message}
                                    </p>
                                )}
                            </div>
                            <div>
                                <label
                                    htmlFor="signup-lastName"
                                    className="text-[10px] font-bold text-slate-300 mb-1 block mr-1 uppercase"
                                >
                                    שם משפחה
                                </label>
                                <input
                                    id="signup-lastName"
                                    {...register('lastName')}
                                    type="text"
                                    autoComplete="family-name"
                                    aria-invalid={!!errors.lastName}
                                    aria-describedby={
                                        errors.lastName ? 'signup-lastName-error' : undefined
                                    }
                                    className={`w-full p-2.5 border rounded-xl focus:ring-2 outline-none transition-all text-sm font-medium text-white ${
                                        errors.lastName
                                            ? 'border-red-500/50 focus:border-red-500 focus:ring-red-500/20 bg-red-950/20 placeholder-red-300/40'
                                            : 'border-white/10 focus:border-sky-500 focus:ring-sky-500/20 bg-white/5'
                                    }`}
                                />
                                {errors.lastName && (
                                    <p
                                        id="signup-lastName-error"
                                        role="alert"
                                        className="mt-1 text-xs text-red-400 mr-1"
                                    >
                                        {errors.lastName.message}
                                    </p>
                                )}
                            </div>
                        </div>

                        <div>
                            <label
                                htmlFor="signup-email"
                                className="text-[10px] font-bold text-slate-300 mb-1 block mr-1 uppercase"
                            >
                                כתובת מייל
                            </label>
                            <input
                                id="signup-email"
                                {...register('email')}
                                type="email"
                                autoComplete="email"
                                placeholder="name@example.com"
                                aria-invalid={!!errors.email}
                                aria-describedby={errors.email ? 'signup-email-error' : undefined}
                                className={`w-full p-2.5 border rounded-xl focus:ring-2 outline-none transition-all text-sm font-medium text-white ${
                                    errors.email
                                        ? 'border-red-500/50 focus:border-red-500 focus:ring-red-500/20 bg-red-950/20 placeholder-red-300/40'
                                        : 'border-white/10 focus:border-sky-500 focus:ring-sky-500/20 bg-white/5 placeholder-slate-500'
                                }`}
                            />
                            {errors.email && (
                                <p
                                    id="signup-email-error"
                                    role="alert"
                                    className="mt-1 text-xs text-red-400 mr-1"
                                >
                                    {errors.email.message}
                                </p>
                            )}
                        </div>

                        <div>
                            <label
                                htmlFor="signup-password"
                                className="text-[10px] font-bold text-slate-300 mb-1 block mr-1 uppercase"
                            >
                                סיסמה
                            </label>
                            <input
                                id="signup-password"
                                {...register('password')}
                                type="password"
                                autoComplete="new-password"
                                placeholder="לפחות 8 תווים"
                                aria-invalid={!!errors.password}
                                aria-describedby={
                                    errors.password ? 'signup-password-error' : undefined
                                }
                                className={`w-full p-2.5 border rounded-xl focus:ring-2 outline-none transition-all text-sm font-medium text-white ${
                                    errors.password
                                        ? 'border-red-500/50 focus:border-red-500 focus:ring-red-500/20 bg-red-950/20 placeholder-red-300/40'
                                        : 'border-white/10 focus:border-sky-500 focus:ring-sky-500/20 bg-white/5 placeholder-slate-500'
                                }`}
                            />
                            {errors.password && (
                                <p
                                    id="signup-password-error"
                                    role="alert"
                                    className="mt-1 text-xs text-red-400 mr-1"
                                >
                                    {errors.password.message}
                                </p>
                            )}
                        </div>

                        <button
                            type="submit"
                            disabled={isLoading}
                            aria-busy={isLoading}
                            className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl shadow-lg shadow-blue-600/30 hover:bg-blue-500 active:scale-[0.98] transition-all flex items-center justify-center gap-2 mt-2 text-sm disabled:opacity-70 disabled:cursor-not-allowed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-[#0A1128]"
                        >
                            {isLoading ? (
                                'יוצר חשבון...'
                            ) : (
                                <>
                                    <span className="ml-1">צור חשבון</span>{' '}
                                    <ArrowRight
                                        className="w-5 h-5 animate-pulse"
                                        aria-hidden="true"
                                    />
                                </>
                            )}
                        </button>

                        {errors.root && (
                            <div
                                role="alert"
                                aria-live="polite"
                                className="p-3 mt-2 bg-red-950/40 border border-red-500/30 text-red-200 rounded-xl text-xs text-center font-medium"
                            >
                                {errors.root.message}
                            </div>
                        )}
                    </form>

                    <p className="text-center text-sm text-slate-400 mt-6">
                        יש לך כבר חשבון?{' '}
                        <button
                            type="button"
                            onClick={onLoginClick}
                            className="text-sky-400 font-bold hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 focus-visible:ring-offset-1 focus-visible:ring-offset-transparent rounded"
                        >
                            התחבר כאן
                        </button>
                    </p>
                </div>
            </div>

            <p className="mt-8 text-center text-[10px] text-slate-500 max-w-md">
                בלחיצה על &quot;צור חשבון&quot; אתה מסכים לתנאי השימוש ומדיניות הפרטיות שלנו.
            </p>
        </main>
    );
};

export default SignupPage;
