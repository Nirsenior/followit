import { ArrowRight, HelpCircle } from 'lucide-react';
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Logo from '../components/Logo';
import { ROUTES } from '../constants/routes';

const NotFoundPage: React.FC = () => {
    const navigate = useNavigate();

    return (
        <main
            className="min-h-screen bg-slate-50 flex items-center justify-center p-4 selection:bg-sky-100 selection:text-sky-900"
            dir="rtl"
        >
            <div className="max-w-md w-full bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden relative group">
                <div
                    className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-sky-400 via-blue-500 to-indigo-600"
                    aria-hidden="true"
                />

                <div className="p-8 md:p-10 text-center">
                    <div className="mb-8 flex justify-center" aria-hidden="true">
                        <Logo variant="dark" />
                    </div>

                    <div className="w-20 h-20 bg-sky-50 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-500">
                        <HelpCircle className="w-10 h-10 text-sky-500" aria-hidden="true" />
                    </div>

                    <h1 className="text-2xl md:text-3xl font-bold text-slate-800 mb-3 tracking-tight">
                        העמוד לא נמצא
                    </h1>

                    <p className="text-slate-500 mb-8 leading-relaxed">
                        מצטערים, אך העמוד שחיפשת אינו קיים או שהועבר לכתובת אחרת.
                    </p>

                    <button
                        onClick={() => navigate(ROUTES.HOME)}
                        className="w-full bg-slate-900 hover:bg-slate-800 text-white font-medium py-3.5 px-6 rounded-2xl transition-all duration-200 flex items-center justify-center gap-2 group/btn focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-900/50"
                    >
                        <span>חזרה לדף הבית</span>
                        <ArrowRight
                            className="w-4 h-4 group-hover/btn:-translate-x-1 transition-transform"
                            aria-hidden="true"
                        />
                    </button>
                </div>
            </div>
        </main>
    );
};

export default NotFoundPage;
