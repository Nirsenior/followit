import { INSURANCE_TYPE_LABELS, InsuranceType } from '@repo/types';
import {
    Activity,
    Briefcase,
    Coins,
    DollarSign,
    Eye,
    EyeOff,
    Heart,
    PiggyBank,
    Plane,
    Shield,
    ShieldAlert,
    TrendingUp,
    Umbrella,
    Users,
} from 'lucide-react';
import React from 'react';
import { useAdminData } from '../../hooks/useAdminData';
import { KpiCard } from './components/KpiCard';
import { TopListCard } from './components/TopListCard';
import { UsersTable } from './components/UsersTable';

// Helper function to resolve the correct, color-coded Lucide icon for each insurance type
const getInsuranceTypeIcon = (type: InsuranceType) => {
    switch (type) {
        case 'health':
            return <Heart className="w-3.5 h-3.5 text-rose-500 shrink-0" />;
        case 'life':
            return <Shield className="w-3.5 h-3.5 text-blue-500 shrink-0" />;
        case 'critical_illness':
            return <ShieldAlert className="w-3.5 h-3.5 text-amber-500 shrink-0" />;
        case 'pension':
            return <PiggyBank className="w-3.5 h-3.5 text-indigo-500 shrink-0" />;
        case 'gemel':
            return <Briefcase className="w-3.5 h-3.5 text-purple-500 shrink-0" />;
        case 'hishtalmut':
            return <Coins className="w-3.5 h-3.5 text-emerald-500 shrink-0" />;
        case 'gemel_invest':
            return <TrendingUp className="w-3.5 h-3.5 text-sky-500 shrink-0" />;
        case 'long_term_savings':
            return <DollarSign className="w-3.5 h-3.5 text-teal-500 shrink-0" />;
        case 'elementary':
            return <Umbrella className="w-3.5 h-3.5 text-orange-500 shrink-0" />;
        case 'abroad':
            return <Plane className="w-3.5 h-3.5 text-pink-500 shrink-0" />;
        default:
            return <Activity className="w-3.5 h-3.5 text-slate-500 shrink-0" />;
    }
};

const AdminDashboard: React.FC = () => {
    const { stats, insuranceStats, isLoading: isLoadingStats } = useAdminData();
    const [showStats, setShowStats] = React.useState(true);

    if (isLoadingStats) {
        return (
            <div className="flex items-center justify-center h-full w-full min-h-[500px]">
                <div className="flex flex-col items-center gap-4">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-500"></div>
                    <p className="text-slate-500 font-medium">טוען נתוני מערכת...</p>
                </div>
            </div>
        );
    }

    // Format top companies for TopListCard
    const topCompanies = (insuranceStats?.mostUsedCompanies || []).slice(0, 5).map((item) => ({
        id: item.company,
        label: item.company,
        value: `${item.count} פוליסות`,
    }));

    // Format top policy types for TopListCard
    const topPolicies = (insuranceStats?.mostUsedTypes || []).slice(0, 5).map((item) => ({
        id: item.type,
        label: INSURANCE_TYPE_LABELS[item.type as InsuranceType] || item.type,
        value: `${item.count} פוליסות`,
        logo: getInsuranceTypeIcon(item.type as InsuranceType),
    }));

    return (
        <div
            className="px-4 py-6 w-full max-w-none space-y-6 animate-in fade-in duration-500"
            dir="rtl"
        >
            <header className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div>
                    <h1 className="text-2xl font-bold bg-gradient-to-r from-sky-600 to-indigo-600 bg-clip-text text-transparent">
                        ניהול מערכת
                    </h1>
                    <p className="text-slate-500 text-sm mt-1">
                        נתוני שימוש, הכנסות וניהול משתמשים בזמן אמת
                    </p>
                </div>
                <div className="flex items-center gap-3">
                    {/* Collapsible drawer toggle button */}
                    <button
                        onClick={() => setShowStats(!showStats)}
                        className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 hover:text-slate-700 hover:border-slate-300 transition-all select-none shadow-2xs"
                    >
                        {showStats ? (
                            <>
                                <EyeOff className="w-3.5 h-3.5" />
                                <span>הסתר נתונים</span>
                            </>
                        ) : (
                            <>
                                <Eye className="w-3.5 h-3.5 text-indigo-600 animate-pulse" />
                                <span className="text-indigo-600 font-semibold">הצג נתונים</span>
                            </>
                        )}
                    </button>
                    <div className="bg-indigo-50 p-2.5 rounded-xl border border-indigo-100 shadow-sm relative group cursor-help select-none">
                        <ShieldAlert className="w-6 h-6 text-indigo-600" />
 
                        {/* Tooltip on Hover */}
                        <div className="absolute top-full mt-2 left-0 bg-slate-800 text-white text-[10.5px] font-semibold py-1.5 px-3 rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 shadow-lg z-50 whitespace-nowrap">
                            דף זה גלוי למנהלי המערכת בלבד
                        </div>
                    </div>
                </div>
            </header>
 
            {/* Collapsible Dashboard Statistics Layout with Smooth Transitions */}
            <div
                className={`grid grid-cols-1 lg:grid-cols-5 gap-4 overflow-hidden transition-all duration-500 ease-in-out ${
                    showStats
                        ? 'max-h-[400px] opacity-100 mb-2 visible'
                        : 'max-h-0 opacity-0 mb-0 invisible pointer-events-none'
                }`}
            >
                {/* 4 Simple KPI Cards */}
                <div className="lg:col-span-2 grid grid-cols-2 gap-3">
                    <KpiCard
                        title="משתמשים רשומים"
                        value={stats?.totalSubscribedUsers || 0}
                        icon={<Users className="w-4 h-4 text-emerald-600" />}
                        trend="+12%"
                        trendUp={true}
                        gradient="from-emerald-50 to-teal-50/50"
                        border="border-emerald-100"
                        iconBg="bg-emerald-100/80"
                    />
                    <KpiCard
                        title="הכנסה חודשית"
                        value={
                            stats?.totalMonthlyIncome !== undefined
                                ? `₪${stats.totalMonthlyIncome.toLocaleString()}`
                                : '₪0'
                        }
                        icon={<DollarSign className="w-4 h-4 text-amber-600" />}
                        trend="+5%"
                        trendUp={true}
                        gradient="from-amber-50 to-orange-50/50"
                        border="border-amber-100"
                        iconBg="bg-amber-100/80"
                    />
                    <KpiCard
                        title="כניסות החודש"
                        value={stats?.monthlyEntries || 0}
                        icon={<Activity className="w-4 h-4 text-sky-600" />}
                        trend="+18%"
                        trendUp={true}
                        gradient="from-sky-50 to-blue-50/50"
                        border="border-sky-100"
                        iconBg="bg-sky-100/80"
                    />
                    <KpiCard
                        title="ביטולי מנוי"
                        value={
                            <div className="flex items-center gap-6 mt-1.5">
                                <div className="flex flex-col">
                                    <span className="text-[10px] text-slate-400 font-semibold leading-tight">
                                        היום
                                    </span>
                                    <span className="text-[15px] font-bold text-slate-800 tracking-tight mt-0.5">
                                        {stats?.monthlyCancels?.today ?? 0}
                                    </span>
                                </div>
                                <div className="w-[1.5px] h-6 bg-slate-200 shrink-0 self-center"></div>
                                <div className="flex flex-col">
                                    <span className="text-[10px] text-slate-400 font-semibold leading-tight">
                                        החודש
                                    </span>
                                    <span className="text-[15px] font-bold text-slate-800 tracking-tight mt-0.5">
                                        {stats?.monthlyCancels?.thisMonth ?? 0}
                                    </span>
                                </div>
                            </div>
                        }
                        icon={<TrendingUp className="w-4 h-4 text-rose-600 transform rotate-180" />}
                        trend="-2%"
                        trendUp={false}
                        gradient="from-rose-50 to-red-50/50"
                        border="border-rose-100"
                        iconBg="bg-rose-100/80"
                    />
                </div>

                {/* Top Lists: Companies & Policy Types */}
                <div className="lg:col-span-3 grid grid-cols-2 gap-3">
                    <TopListCard
                        title="חברות ביטוח מובילות"
                        icon={<TrendingUp className="w-4 h-4 text-indigo-600" />}
                        items={topCompanies}
                        gradient="from-indigo-50 to-purple-50/50"
                        border="border-indigo-100"
                        iconBg="bg-indigo-100/80"
                    />
                    <TopListCard
                        title="סוגי פוליסות נפוצים"
                        icon={<Activity className="w-4 h-4 text-emerald-600" />}
                        items={topPolicies}
                        gradient="from-emerald-50 to-teal-50/50"
                        border="border-emerald-100"
                        iconBg="bg-emerald-100/80"
                    />
                </div>
            </div>

            {/* MAIN ADMIN USERS TABLE */}
            <UsersTable />
        </div>
    );
};

export default AdminDashboard;
