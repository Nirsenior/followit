import React from 'react';

export interface TopListItem {
    id: string | number;
    label: string;
    value: string | number;
    logo?: React.ReactNode;
}

export interface TopListCardProps {
    title: string;
    icon: React.ReactNode;
    items: TopListItem[];
    gradient: string;
    border: string;
    iconBg: string;
}

export const TopListCard: React.FC<TopListCardProps> = ({
    title,
    icon,
    items,
    gradient,
    border,
    iconBg,
}) => {
    return (
        <div
            className={`relative bg-gradient-to-br ${gradient} rounded-2xl p-3 border ${border} shadow-sm group hover:scale-[1.01] transition-all duration-300 flex flex-col justify-between h-full min-h-[175px]`}
        >
            {/* Header */}
            <div className="flex items-center gap-2 mb-2">
                <div className={`p-1.5 rounded-xl ${iconBg} shrink-0`}>{icon}</div>
                <h3 className="text-slate-700 text-xs font-semibold leading-tight truncate">{title}</h3>
            </div>

            {/* List Content */}
            <div className="flex-1 flex flex-col justify-between gap-1.5">
                {items && items.length > 0 ? (
                    items.map((item, idx) => (
                        <div
                            key={item.id}
                            className="flex items-center justify-between text-xs py-0.5 border-b border-slate-100/40 last:border-none group/item hover:bg-slate-50/20 px-1 rounded transition-colors"
                        >
                            <div className="flex items-center gap-1.5 min-w-0 flex-1">
                                <span className="w-3.5 h-3.5 rounded-lg bg-slate-200/60 flex items-center justify-center text-[9px] font-semibold text-slate-600 shrink-0">
                                    {idx + 1}
                                </span>
                                {item.logo && (
                                    <div className="shrink-0 flex items-center justify-center">
                                        {item.logo}
                                    </div>
                                )}
                                <span className="text-slate-600 font-semibold text-[10.5px] truncate max-w-[180px]">
                                    {item.label}
                                </span>
                            </div>
                            <span className="text-slate-700 font-semibold bg-white/80 border border-slate-100 px-1.5 py-0.5 rounded-md text-[9.5px] shrink-0 shadow-2xs">
                                {item.value}
                            </span>
                        </div>
                    ))
                ) : (
                    <div className="flex items-center justify-center h-full py-4">
                        <span className="text-[10px] text-slate-400 font-medium">אין נתונים</span>
                    </div>
                )}
            </div>
        </div>
    );
};
