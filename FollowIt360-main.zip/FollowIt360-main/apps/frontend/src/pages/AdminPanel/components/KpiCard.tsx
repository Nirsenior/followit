import React from 'react';

export interface KpiCardProps {
    title: string;
    value: number | string | React.ReactNode;
    icon: React.ReactNode;
    trend: string;
    trendUp: boolean;
    gradient: string;
    border: string;
    iconBg: string;
    action?: React.ReactNode;
    popover?: React.ReactNode;
}

export const KpiCard: React.FC<KpiCardProps> = ({
    title,
    value,
    icon,
    trend,
    trendUp,
    gradient,
    border,
    iconBg,
    action,
    popover,
}) => (
    <div
        className={`relative bg-gradient-to-br ${gradient} rounded-2xl p-3 border ${border} shadow-sm group hover:scale-[1.01] transition-all duration-300 flex flex-col justify-between`}
    >
        <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 max-w-[70%]">
                <div className={`p-1.5 rounded-xl ${iconBg} shrink-0`}>{icon}</div>
                <h3 className="text-slate-500 text-[11px] font-semibold leading-tight truncate">
                    {title}
                </h3>
            </div>
            <span
                className={`text-[9px] font-semibold px-1 py-0.5 rounded ${trendUp ? 'bg-green-100 text-green-700' : 'bg-rose-100 text-rose-700'} shrink-0`}
            >
                {trend}
            </span>
        </div>
        <div className="flex items-baseline justify-between mt-2.5">
            <div className="text-lg font-bold text-slate-800 tracking-tight leading-none w-full">
                {value}
            </div>
            {action && <div className="shrink-0">{action}</div>}
        </div>
        {popover}
    </div>
);
