import { ArrowDown, ArrowUp, ArrowUpDown, Mail, PhoneCall, UserCheck } from 'lucide-react';
import React from 'react';

export type SortableColumns = 'name' | 'customerCount' | 'isSubscribed';

interface TableHeaderProps {
    sortBy: SortableColumns;
    sortOrder: 'asc' | 'desc';
    onSort: (column: SortableColumns) => void;
}

export const TableHeader: React.FC<TableHeaderProps> = ({ sortBy, sortOrder, onSort }) => {
    const renderSortIcon = (column: SortableColumns) => {
        if (sortBy !== column) {
            return <ArrowUpDown className="w-3.5 h-3.5 text-slate-300" />;
        }
        return sortOrder === 'asc' ? (
            <ArrowUp className="w-3.5 h-3.5 text-sky-500 font-bold" />
        ) : (
            <ArrowDown className="w-3.5 h-3.5 text-sky-500 font-bold" />
        );
    };

    return (
        <thead>
            <tr className="bg-slate-50 text-slate-600 border-b border-slate-150 text-xs font-bold select-none">
                <th
                    onClick={() => onSort('name')}
                    className="p-4 cursor-pointer hover:bg-slate-100/60 hover:text-slate-800 transition-colors w-1/4 text-center"
                >
                    <div className="flex items-center justify-center gap-2 mx-auto">
                        <span>שם מלא</span>
                        {renderSortIcon('name')}
                    </div>
                </th>
                <th className="p-4 w-1/5 text-center">
                    <div className="flex items-center justify-center gap-2 mx-auto">
                        <PhoneCall className="w-3.5 h-3.5 text-slate-400" />
                        <span>טלפון</span>
                    </div>
                </th>
                <th className="p-4 w-1/4 text-center">
                    <div className="flex items-center justify-center gap-2 mx-auto">
                        <Mail className="w-3.5 h-3.5 text-slate-400" />
                        <span>אימייל</span>
                    </div>
                </th>
                <th
                    onClick={() => onSort('customerCount')}
                    className="p-4 cursor-pointer hover:bg-slate-100/60 hover:text-slate-800 transition-colors w-1/6 text-center"
                >
                    <div className="flex items-center justify-center gap-2 mx-auto">
                        <span>כמות לקוחות</span>
                        {renderSortIcon('customerCount')}
                    </div>
                </th>
                <th
                    onClick={() => onSort('isSubscribed')}
                    className="p-4 cursor-pointer hover:bg-slate-100/60 hover:text-slate-800 transition-colors w-1/6 text-center"
                >
                    <div className="flex items-center justify-center gap-2 mx-auto">
                        <UserCheck className="w-3.5 h-3.5 text-slate-400" />
                        <span>מנוי פעיל</span>
                        {renderSortIcon('isSubscribed')}
                    </div>
                </th>
            </tr>
        </thead>
    );
};
