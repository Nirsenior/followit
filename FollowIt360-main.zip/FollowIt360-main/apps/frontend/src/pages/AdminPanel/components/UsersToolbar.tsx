import { Search, X } from 'lucide-react';
import React from 'react';

interface UsersToolbarProps {
    search: string;
    onSearchChange: (value: string) => void;
    totalUsers?: number;
}

export const UsersToolbar: React.FC<UsersToolbarProps> = ({
    search,
    onSearchChange,
    totalUsers,
}) => (
    <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex flex-col gap-1">
            <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <span>רשימת משתמשי המערכת</span>
                {totalUsers !== undefined && (
                    <span className="text-xs px-2 py-0.5 bg-slate-150 text-slate-600 rounded-full font-medium">
                        {totalUsers} משתמשים
                    </span>
                )}
            </h2>
            <p className="text-xs text-slate-500">מיון, סינון וחיפוש מתקדם במאגר המשתמשים</p>
        </div>

        <div className="flex items-center gap-3">
            <div className="relative flex-1 sm:w-72">
                <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none text-slate-400">
                    <Search className="w-4 h-4" />
                </div>
                <input
                    type="text"
                    placeholder="חיפוש לפי שם או אימייל..."
                    value={search}
                    onChange={(e) => onSearchChange(e.target.value)}
                    className="w-full pl-8 pr-9 py-1.5 bg-white border border-slate-250 rounded-xl text-slate-700 text-xs font-medium placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all shadow-sm"
                />
                {search && (
                    <button
                        onClick={() => onSearchChange('')}
                        className="absolute inset-y-0 left-3 flex items-center text-slate-400 hover:text-slate-600"
                    >
                        <X className="w-3.5 h-3.5" />
                    </button>
                )}
            </div>
        </div>
    </div>
);
