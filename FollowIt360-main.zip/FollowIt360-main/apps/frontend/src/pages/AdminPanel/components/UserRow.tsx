import { ShieldCheck, ShieldAlert } from 'lucide-react';
import React from 'react';
import { createPortal } from 'react-dom';
import { useUpdateAdminStatus } from '../../../hooks/useUpdateAdminStatus';

interface UserRowProps {
    user: {
        id: string;
        name: string;
        email: string;
        phone?: string | null;
        customerCount: number;
        isSubscribed: boolean;
        isAdmin: boolean;
    };
}

interface ContextMenuState {
    x: number;
    y: number;
}

export const UserRow: React.FC<UserRowProps> = ({ user }) => {
    const [contextMenu, setContextMenu] = React.useState<ContextMenuState | null>(null);
    const menuRef = React.useRef<HTMLDivElement>(null);

    const { mutate: updateAdminStatus, isPending } = useUpdateAdminStatus();

    // Close context menu on outside click or scroll
    React.useEffect(() => {
        if (!contextMenu) return;

        const handleClose = () => setContextMenu(null);
        document.addEventListener('click', handleClose);
        document.addEventListener('scroll', handleClose, true);
        return () => {
            document.removeEventListener('click', handleClose);
            document.removeEventListener('scroll', handleClose, true);
        };
    }, [contextMenu]);

    const handleContextMenu = (e: React.MouseEvent) => {
        e.preventDefault();
        setContextMenu({ x: e.clientX, y: e.clientY });
    };

    const handlePromote = () => {
        setContextMenu(null);
        updateAdminStatus({ userId: user.id, isAdmin: true });
    };

    const handleDemote = () => {
        setContextMenu(null);
        updateAdminStatus({ userId: user.id, isAdmin: false });
    };

    return (
        <>
            <tr
                className="hover:bg-slate-50/80 transition-colors cursor-context-menu select-none"
                onContextMenu={handleContextMenu}
            >
                <td className="p-4 font-semibold text-slate-800 text-center">
                    <span className="relative inline-flex items-center justify-center">
                        {user.name}
                        {user.isAdmin && (
                            <span
                                title="מנהל"
                                className="absolute right-full mr-1.5 inline-flex items-center gap-0.5 text-[10px] font-bold bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-full px-1.5 py-0.5 whitespace-nowrap"
                            >
                                <ShieldCheck className="w-3 h-3" />
                                מנהל
                            </span>
                        )}
                    </span>
                </td>
                <td className="p-4 text-slate-500 font-medium text-center">{user.phone || '-'}</td>
                <td className="p-4 text-slate-500 font-medium text-center">{user.email}</td>
                <td className="p-4 text-center">
                    <span
                        className={`inline-flex items-center justify-center px-2 py-0.5 rounded-full font-bold ${
                            user.customerCount > 0
                                ? 'bg-sky-50 text-sky-700 border border-sky-100'
                                : 'bg-slate-100 text-slate-500'
                        }`}
                    >
                        {user.customerCount}
                    </span>
                </td>
                <td className="p-4 text-slate-400 text-center">-</td>
            </tr>

            {contextMenu && (
                <ContextMenuPortal
                    x={contextMenu.x}
                    y={contextMenu.y}
                    menuRef={menuRef}
                    isPending={isPending}
                    isAlreadyAdmin={user.isAdmin}
                    onPromote={handlePromote}
                    onDemote={handleDemote}
                    userName={user.name}
                />
            )}
        </>
    );
};

interface ContextMenuPortalProps {
    x: number;
    y: number;
    menuRef: React.RefObject<HTMLDivElement | null>;
    isPending: boolean;
    isAlreadyAdmin: boolean;
    onPromote: () => void;
    onDemote: () => void;
    userName: string;
}

const ContextMenuPortal: React.FC<ContextMenuPortalProps> = ({
    x,
    y,
    menuRef,
    isPending,
    isAlreadyAdmin,
    onPromote,
    onDemote,
    userName,
}) => {
    const [adjustedPos, setAdjustedPos] = React.useState({ x, y });

    React.useEffect(() => {
        if (!menuRef.current) return;
        const rect = menuRef.current.getBoundingClientRect();
        const vw = window.innerWidth;
        const vh = window.innerHeight;
        setAdjustedPos({
            x: x + rect.width > vw ? vw - rect.width - 8 : x,
            y: y + rect.height > vh ? vh - rect.height - 8 : y,
        });
    }, [x, y, menuRef]);

    return createPortal(
        <div
            ref={menuRef}
            onClick={(e) => e.stopPropagation()}
            style={{
                position: 'fixed',
                top: adjustedPos.y,
                left: adjustedPos.x,
                zIndex: 9999,
            }}
            className="
                bg-white border border-slate-200 rounded-xl shadow-xl
                min-w-[180px] py-1.5 overflow-hidden
                animate-[fadeIn_0.1s_ease-out]
            "
        >
            {/* Header */}
            <div className="px-3 py-1.5 border-b border-slate-100 mb-1">
                <p className="text-[11px] font-semibold text-slate-400 truncate max-w-[160px]">
                    {userName}
                </p>
            </div>

            {/* Promote or Demote button */}
            {isAlreadyAdmin ? (
                <button
                    onClick={onDemote}
                    disabled={isPending}
                    className="
                        w-full flex items-center gap-2.5 px-3 py-2 text-sm text-red-600
                        hover:bg-red-50 hover:text-red-700
                        transition-colors duration-100 disabled:opacity-50 disabled:cursor-not-allowed
                    "
                >
                    <ShieldAlert className="w-4 h-4 text-red-500 flex-shrink-0" />
                    <span className="font-medium">
                        {isPending ? '...מעדכן' : 'הסר מנהל'}
                    </span>
                </button>
            ) : (
                <button
                    onClick={onPromote}
                    disabled={isPending}
                    className="
                        w-full flex items-center gap-2.5 px-3 py-2 text-sm text-slate-700
                        hover:bg-indigo-50 hover:text-indigo-700
                        transition-colors duration-100 disabled:opacity-50 disabled:cursor-not-allowed
                    "
                >
                    <ShieldCheck className="w-4 h-4 text-indigo-500 flex-shrink-0" />
                    <span className="font-medium">
                        {isPending ? '...מעדכן' : 'הפוך למנהל'}
                    </span>
                </button>
            )}
        </div>,
        document.body,
    );
};
