import { ChevronLeft, ChevronRight } from 'lucide-react';
import React from 'react';

interface PaginationProps {
    page: number;
    limit: number;
    totalUsers: number;
    totalPages: number;
    onPageChange: (page: number | ((prev: number) => number)) => void;
    onLimitChange: (limit: number) => void;
}

export const Pagination: React.FC<PaginationProps> = ({
    page,
    limit,
    totalUsers,
    totalPages,
    onPageChange,
    onLimitChange,
}) => (
    <div className="p-4 border-t border-slate-150 bg-slate-50/50 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs select-none">
        {/* Paging sizes */}
        <div className="flex items-center gap-2 text-slate-500 font-medium">
            <span>הצג</span>
            <select
                value={limit}
                onChange={(e) => {
                    onLimitChange(Number(e.target.value));
                    onPageChange(1);
                }}
                className="bg-white border border-slate-250 rounded-lg px-2 py-1 text-slate-700 outline-none focus:ring-1 focus:ring-sky-500 shadow-sm"
            >
                <option value={5}>5</option>
                <option value={10}>10</option>
                <option value={25}>25</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
            </select>
            <span>שורות</span>
        </div>

        {/* Counts */}
        <div className="text-slate-600 font-semibold">
            מציג{' '}
            <span className="text-slate-800">{Math.min((page - 1) * limit + 1, totalUsers)}</span>{' '}
            עד <span className="text-slate-800">{Math.min(page * limit, totalUsers)}</span> מתוך{' '}
            <span className="text-slate-800">{totalUsers}</span> משתמשים
        </div>

        {/* Page Numbers navigation */}
        <div className="flex items-center gap-1.5">
            <button
                onClick={() => onPageChange((p) => Math.max(p - 1, 1))}
                disabled={page === 1}
                className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-white text-slate-600 shadow-sm transition-all"
                title="עמוד קודם"
            >
                <ChevronRight className="w-4 h-4" />
            </button>

            {Array.from({ length: totalPages }).map((_, idx) => {
                const pageNumber = idx + 1;
                // Simple sliding window for page numbers if there are too many pages
                if (
                    totalPages > 5 &&
                    pageNumber !== 1 &&
                    pageNumber !== totalPages &&
                    Math.abs(pageNumber - page) > 1
                ) {
                    if (pageNumber === 2 && page > 3) {
                        return (
                            <span key="dots-start" className="text-slate-400 px-1">
                                ...
                            </span>
                        );
                    }
                    if (pageNumber === totalPages - 1 && page < totalPages - 2) {
                        return (
                            <span key="dots-end" className="text-slate-400 px-1">
                                ...
                            </span>
                        );
                    }
                    return null;
                }

                return (
                    <button
                        key={pageNumber}
                        onClick={() => onPageChange(pageNumber)}
                        className={`min-w-8 h-8 px-2 rounded-lg font-bold transition-all border ${
                            page === pageNumber
                                ? 'bg-sky-500 border-sky-500 text-white shadow-sm shadow-sky-100'
                                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                    >
                        {pageNumber}
                    </button>
                );
            })}

            <button
                onClick={() => onPageChange((p) => Math.min(p + 1, totalPages))}
                disabled={page === totalPages || totalPages === 0}
                className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-white text-slate-600 shadow-sm transition-all"
                title="עמוד הבא"
            >
                <ChevronLeft className="w-4 h-4" />
            </button>
        </div>
    </div>
);
