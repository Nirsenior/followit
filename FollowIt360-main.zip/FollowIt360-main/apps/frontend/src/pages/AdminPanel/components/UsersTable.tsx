import { Users } from 'lucide-react';
import React from 'react';
import { useAdminUsers } from '../../../hooks/useAdminUsers';
import { Pagination } from './Pagination';
import { SortableColumns, TableHeader } from './TableHeader';
import { UserRow } from './UserRow';
import { UsersToolbar } from './UsersToolbar';

export const UsersTable: React.FC = () => {
    // Table States
    const [page, setPage] = React.useState(1);
    const [limit, setLimit] = React.useState(10);
    const [search, setSearch] = React.useState('');
    const [debouncedSearch, setDebouncedSearch] = React.useState('');
    const [sortBy, setSortBy] = React.useState<SortableColumns>('name');
    const [sortOrder, setSortOrder] = React.useState<'asc' | 'desc'>('asc');

    // Debounce search query
    React.useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedSearch(search);
            setPage(1); // Reset page on search query change
        }, 400);
        return () => clearTimeout(handler);
    }, [search]);

    // Fetch users with query params
    const {
        data: usersData,
        isLoading: isLoadingUsers,
        isError,
    } = useAdminUsers({
        page,
        limit,
        search: debouncedSearch,
        sortBy,
        sortOrder,
    });

    const handleSort = (column: SortableColumns) => {
        if (sortBy === column) {
            setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
        } else {
            setSortBy(column);
            setSortOrder('asc');
        }
        setPage(1); // Reset page to 1 on sort change
    };

    const totalPages = Math.ceil((usersData?.total || 0) / limit);

    return (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm flex flex-col">
            <UsersToolbar
                search={search}
                onSearchChange={setSearch}
                totalUsers={usersData?.total}
            />

            {/* Table container */}
            <div className="overflow-x-auto">
                <table className="w-full text-center border-collapse">
                    <TableHeader sortBy={sortBy} sortOrder={sortOrder} onSort={handleSort} />
                    <tbody className="divide-y divide-slate-100 text-slate-700 text-xs">
                        {isLoadingUsers ? (
                            // Loading Skeletons
                            Array.from({ length: limit }).map((_, idx) => (
                                <tr key={idx} className="animate-pulse">
                                    <td className="p-4 text-center">
                                        <div className="h-4 bg-slate-100 rounded w-2/3 mx-auto"></div>
                                    </td>
                                    <td className="p-4 text-center">
                                        <div className="h-4 bg-slate-100 rounded w-1/2 mx-auto"></div>
                                    </td>
                                    <td className="p-4 text-center">
                                        <div className="h-4 bg-slate-100 rounded w-3/4 mx-auto"></div>
                                    </td>
                                    <td className="p-4 text-center">
                                        <div className="h-4 bg-slate-100 rounded w-1/4 mx-auto"></div>
                                    </td>
                                    <td className="p-4 text-center">
                                        <div className="h-4 bg-slate-100 rounded w-1/3 mx-auto"></div>
                                    </td>
                                </tr>
                            ))
                        ) : isError ? (
                            <tr>
                                <td
                                    colSpan={5}
                                    className="p-8 text-center text-rose-600 bg-rose-50/20 font-medium"
                                >
                                    שגיאה בטעינת נתוני משתמשים. יש לנסות שנית מאוחר יותר.
                                </td>
                            </tr>
                        ) : !usersData?.users || usersData.users.length === 0 ? (
                            <tr>
                                <td colSpan={5} className="p-12 text-center text-slate-400">
                                    <div className="flex flex-col items-center justify-center gap-2 mx-auto">
                                        <Users className="w-8 h-8 text-slate-300" />
                                        <p className="font-semibold text-sm">
                                            לא נמצאו משתמשים במאגר
                                        </p>
                                        <p className="text-xs">
                                            נסה לשנות את ביטוי החיפוש או הסינון
                                        </p>
                                    </div>
                                </td>
                            </tr>
                        ) : (
                            usersData.users.map((user) => <UserRow key={user.id} user={user} />)
                        )}
                    </tbody>
                </table>
            </div>

            {/* Pagination Controls */}
            {!isLoadingUsers && !isError && usersData && usersData.total > 0 && (
                <Pagination
                    page={page}
                    limit={limit}
                    totalUsers={usersData.total}
                    totalPages={totalPages}
                    onPageChange={setPage}
                    onLimitChange={setLimit}
                />
            )}
        </div>
    );
};
