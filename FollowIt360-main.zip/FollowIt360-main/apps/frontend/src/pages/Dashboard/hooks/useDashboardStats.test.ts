// @vitest-environment happy-dom
import { renderHook } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { Customer, POLICY_STATUS, UserProfile } from '@repo/types';
import { useDashboardStats } from './useDashboardStats.js';
import { EMPTY_USER_PROFILE } from '../../../constants/profile.js';

describe('useDashboardStats hook', () => {
    const mockProfile: UserProfile = {
        ...EMPTY_USER_PROFILE,
        agreements: {
            הראל: {
                life: { scope: '50', ongoing: '10' },
                pension: { scope: '1', ongoing: '0.5', mobility: '0.8' },
            },
        },
    };

    const mockCompanies = ['הראל'];

    it('calculates total ongoing using effective premium, and filters month ongoing by issue date', () => {
        const customers: Customer[] = [
            {
                id: 'cust-1',
                issueDate: '2026-06-01',
                createdAt: '2026-06-01T00:00:00Z',
                creationType: 'new',
                policies: [
                    {
                        id: 'pol-1',
                        company: 'הראל',
                        type: 'life',
                        status: POLICY_STATUS.ACTIVE,
                        monthlyCost: 100,
                        issueDate: '2026-06-01',
                        premiumSchedule: [
                            { year: 0, premium: 100 },
                            { year: 1, premium: 120 },
                        ],
                        details: {},
                    },
                ],
            } as unknown as Customer,
            {
                id: 'cust-2',
                issueDate: '2025-06-01',
                createdAt: '2025-06-01T00:00:00Z',
                creationType: 'new',
                policies: [
                    {
                        id: 'pol-2',
                        company: 'הראל',
                        type: 'life',
                        status: POLICY_STATUS.ACTIVE,
                        monthlyCost: 100,
                        issueDate: '2025-06-01',
                        premiumSchedule: [
                            { year: 0, premium: 100 },
                            { year: 1, premium: 120 },
                        ],
                        details: {},
                    },
                ],
            } as unknown as Customer,
        ];

        // Let's query for June 2026 (selectedMonth = 5, selectedYear = 2026)
        // For cust-1: issueDate is June 2026 (0 years elapsed) -> effective premium is 100.
        //   Ongoing = 100 * 10% = 10.
        //   Issued this month? Yes (June 2026). So monthOngoing += 10.
        // For cust-2: issueDate is June 2025 (1 year elapsed in June 2026) -> effective premium is 120.
        //   Ongoing = 120 * 10% = 12.
        //   Issued this month? No (June 2025). So monthOngoing does not include this.
        // Totals:
        //   totalOngoing = 10 (cust-1) + 12 (cust-2) = 22.
        //   monthOngoing = 10 (cust-1 only) = 10.

        const { result } = renderHook(() =>
            useDashboardStats(customers, mockProfile, mockCompanies, 5, 2026)
        );

        expect(result.current.ongoing).toBe(22);
        expect(result.current.monthOngoing).toBe(10);
    });

    it('returns 0 for ongoing and monthOngoing if no policies match companies or status', () => {
        const customers: Customer[] = [
            {
                id: 'cust-1',
                issueDate: '2026-06-01',
                policies: [
                    {
                        id: 'pol-1',
                        company: 'מנורה', // not in mockCompanies
                        type: 'life',
                        status: POLICY_STATUS.ACTIVE,
                        monthlyCost: 100,
                        details: {},
                    },
                    {
                        id: 'pol-2',
                        company: 'הראל',
                        type: 'life',
                        status: POLICY_STATUS.PENDING, // not ACTIVE
                        monthlyCost: 100,
                        details: {},
                    },
                ],
            } as unknown as Customer,
        ];

        const { result } = renderHook(() =>
            useDashboardStats(customers, mockProfile, mockCompanies, 5, 2026)
        );

        expect(result.current.ongoing).toBe(0);
        expect(result.current.monthOngoing).toBe(0);
    });
});
