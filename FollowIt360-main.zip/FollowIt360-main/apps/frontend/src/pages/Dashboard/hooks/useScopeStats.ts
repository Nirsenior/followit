import { useMemo } from 'react';
import { Customer, POLICY_STATUS, UserProfile } from '@repo/types';
import { calculateCommissions } from '../../CustomerJournal/utils/calculations';
import { getAllPolicies } from './useDashboardStats';

interface UseScopeStatsProps {
    customers: Customer[];
    profile: UserProfile;
    profileCompanies: string[];
    selectedMonth: number | null;
    selectedYear: number;
}

/**
 * Custom React Hook to compute the current month's scope commission
 * and comparing it to the previous month to calculate the percentage change.
 */
export const useScopeStats = ({
    customers,
    profile,
    profileCompanies,
    selectedMonth,
    selectedYear,
}: UseScopeStatsProps) => {
    return useMemo(() => {
        const targetMonth = selectedMonth !== null ? selectedMonth : new Date().getMonth();
        const targetYear = selectedYear;

        const prevMonth = targetMonth === 0 ? 11 : targetMonth - 1;
        const prevYear = targetMonth === 0 ? targetYear - 1 : targetYear;

        const getScopeForMonth = (m: number, y: number) => {
            let total = 0;
            customers.forEach((c) => {
                if (c.creationType === 'existing') return;
                getAllPolicies(c).forEach((p) => {
                    if (p.status === POLICY_STATUS.ACTIVE && profileCompanies.includes(p.company)) {
                        const dateStr = p.issueDate || c.issueDate || (c as any).createdAt;
                        if (!dateStr) return;
                        const date = new Date(dateStr);
                        if (isNaN(date.getTime())) return;
                        if (date.getFullYear() === y && date.getMonth() === m) {
                            const { scope } = calculateCommissions(p, p.monthlyCost, profile);
                            total += scope;
                        }
                    }
                });
            });
            return total;
        };

        const currentScope = getScopeForMonth(targetMonth, targetYear);
        const prevScope = getScopeForMonth(prevMonth, prevYear);

        let percentChange = 0;
        if (prevScope > 0) {
            percentChange = Math.round(((currentScope - prevScope) / prevScope) * 100);
        } else if (currentScope > 0) {
            percentChange = 100;
        }

        return {
            currentScope,
            prevScope,
            percentChange,
        };
    }, [customers, selectedMonth, selectedYear, profile, profileCompanies]);
};
