import { Customer, INSURANCE_TYPE, isFinancialType, POLICY_STATUS, UserProfile } from '@repo/types';
import { useMemo } from 'react';
import {
    calculateCommissions,
    calculateCustomerTotalPremium,
    getEffectivePremium,
} from '../../CustomerJournal/utils/calculations';

/**
 * Helper to get all primary and family policies for a customer.
 */
export const getAllPolicies = (c: Customer) => [
    ...c.policies,
    ...(c.familyMembers?.flatMap((fm) => fm.policies) || []),
];

/**
 * Custom hook to calculate dashboard statistics based on filtered customers and profile settings.
 */
export const useDashboardStats = (
    customers: Customer[],
    profile: UserProfile,
    profileCompanies: string[],
    selectedMonth: number | null,
    selectedYear: number,
) => {
    return useMemo(() => {
        let totalPremium = 0,
            totalScope = 0,
            totalOngoing = 0,
            totalMonthOngoing = 0;
        let pensionAssets = 0,
            financialAssets = 0,
            gemelAssets = 0,
            individualPremium = 0;

        customers.forEach((c) => {
            // Use the single source of truth for realistic monthly premiums!
            const custPremium = calculateCustomerTotalPremium(
                c,
                selectedMonth ?? new Date().getMonth(),
                selectedYear,
            );
            totalPremium += custPremium;

            getAllPolicies(c).forEach((p) => {
                // Only consider active policies from companies the agent is affiliated with
                if (p.status === POLICY_STATUS.ACTIVE && profileCompanies.includes(p.company)) {
                    // Calculate effective monthly ongoing
                    const effectivePremium = getEffectivePremium(
                        p,
                        c.issueDate,
                        selectedMonth ?? new Date().getMonth(),
                        selectedYear,
                    );
                    const { scope, ongoing } = calculateCommissions(p, effectivePremium, profile);
                    if (c.creationType !== 'existing') {
                        totalScope += scope;
                    }
                    totalOngoing += ongoing;

                    // Only count ongoing commissions towards "this month" if the policy was issued in the selected month & year
                    const issueDateStr = p.issueDate || c.issueDate || (c as any).createdAt;
                    if (issueDateStr) {
                        const issueDate = new Date(issueDateStr);
                        const targetMonth = selectedMonth ?? new Date().getMonth();
                        const targetYear = selectedYear;
                        if (
                            !isNaN(issueDate.getTime()) &&
                            issueDate.getFullYear() === targetYear &&
                            issueDate.getMonth() === targetMonth
                        ) {
                            totalMonthOngoing += ongoing;
                        }
                    }

                    if (isFinancialType(p.type)) {
                        const assets = Math.max(
                            p.details?.accumulation || 0,
                            p.details?.mobility || 0,
                        );

                        if (p.type === INSURANCE_TYPE.PENSION) {
                            pensionAssets += assets;
                        } else if (
                            p.type === INSURANCE_TYPE.GEMEL ||
                            p.type === INSURANCE_TYPE.HISHTALMUT ||
                            p.type === INSURANCE_TYPE.GEMEL_INVEST
                        ) {
                            gemelAssets += assets;
                        } else {
                            financialAssets += assets;
                        }
                    } else if (
                        p.type !== INSURANCE_TYPE.ELEMENTARY &&
                        p.type !== INSURANCE_TYPE.ABROAD
                    ) {
                        // Individual products (health, life, critical illness, etc)
                        individualPremium += p.monthlyCost;
                    }
                }
            });
        });

        return {
            premium: totalPremium,
            scope: totalScope,
            ongoing: totalOngoing,
            monthOngoing: totalMonthOngoing,
            assets: {
                pension: pensionAssets,
                financial: financialAssets,
                gemel: gemelAssets,
            },
            individualPremium,
        };
    }, [customers, profile, profileCompanies, selectedMonth, selectedYear]);
};
