import { Customer, InsuranceType, UserProfile } from '@repo/types';
import { useQueryClient } from '@tanstack/react-query';
import { AlertTriangle, Save, Shield, User } from 'lucide-react';
import React, { useState } from 'react';

import { getSelectedCompanies } from '../utils/profileUtils';
import { AgreementsTab } from './profile/components/AgreementsTab';
import { EffectivityModal } from './profile/components/EffectivityModal';
import { PersonalTab } from './profile/components/PersonalTab';

interface ProfileSettingsProps {
    profile: UserProfile;
    setProfile: (p: Partial<UserProfile>) => void;
    onNavigate: (s: any) => void;
}

const ProfileSettings: React.FC<ProfileSettingsProps> = ({ profile, setProfile, onNavigate }) => {
    const queryClient = useQueryClient();
    const [localProfile, setLocalProfile] = useState<UserProfile>(
        JSON.parse(JSON.stringify(profile)),
    );
    const [activeTab, setActiveTab] = useState<'personal' | 'agreements'>('personal');
    const [globalAgreements, setGlobalAgreements] = useState<
        Record<string, { scope?: string; ongoing?: string; mobility?: string; isActive?: boolean }>
    >(() => {
        const defaultGlobal = {
            health: {},
            life: {},
            critical_illness: {},
            pension: {},
            elementary: { isActive: false },
            gemel: {},
            hishtalmut: {},
            gemel_invest: {},
            long_term_savings: {},
            abroad: {},
        };

        if (profile.agreements?.['GLOBAL']) {
            return { ...defaultGlobal, ...profile.agreements['GLOBAL'] };
        }

        // Fallback algorithm for older profiles without an explicit GLOBAL record saved yet
        const loadedAgreements = profile.agreements || {};
        const loadedCompanies = getSelectedCompanies(loadedAgreements);
        if (loadedCompanies.length > 0) {
            let isMaster = true;
            const firstCompanyRates = loadedAgreements[loadedCompanies[0]];
            for (let i = 1; i < loadedCompanies.length; i++) {
                if (
                    JSON.stringify(loadedAgreements[loadedCompanies[i]]) !==
                    JSON.stringify(firstCompanyRates)
                ) {
                    isMaster = false;
                    break;
                }
            }
            if (isMaster && Object.keys(firstCompanyRates || {}).length > 0) {
                return { ...defaultGlobal, ...firstCompanyRates };
            }
        }

        return defaultGlobal;
    });

    const [pendingChange, setPendingChange] = useState<{
        company: string | 'GLOBAL';
        type: InsuranceType;
        oldValue: string;
        newValue: string;
    } | null>(null);

    const [effectivityDecisions, setEffectivityDecisions] = useState<
        Array<{
            company: string;
            type: InsuranceType;
            oldValue: string;
            newValue: string;
            isRetroactive: boolean;
        }>
    >([]);

    const handleSave = async () => {
        // 1. Build a clean map of agreements, including the newest global settings
        const finalAgreementsMap = {
            ...localProfile.agreements,
            GLOBAL: globalAgreements,
        };

        // 2. Format for server (array of {company, rates})
        const agreementsPayload = Object.entries(finalAgreementsMap).map(([company, ratesObj]) => {
            return { company, rates: ratesObj };
        });

        try {
            if (profile.id) {
                const baseUrl = import.meta.env.VITE_API_URL || '';
                const fullName =
                    `${localProfile.firstName || ''} ${localProfile.lastName || ''}`.trim();

                await Promise.all([
                    fetch(`${baseUrl}/api/users/profile`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        credentials: 'include',
                        body: JSON.stringify({
                            name: fullName,
                            email: localProfile.email,
                            phone: localProfile.phone || null,
                        }),
                    }),
                    fetch(`${baseUrl}/api/agreements`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        credentials: 'include',
                        body: JSON.stringify({
                            userId: profile.id,
                            agreements: agreementsPayload,
                            effectivityDecisions,
                        }),
                    }),
                ]);
            }
        } catch (err) {
            console.error('Failed to save profile settings:', err);
        }

        setProfile({ ...localProfile, agreements: finalAgreementsMap, isSetupComplete: true });
        onNavigate('journal');
    };

    const cancelChange = () => {
        if (!pendingChange) return;
        const { company, type, oldValue } = pendingChange;

        if (company === 'GLOBAL') {
            setGlobalAgreements((prev) => ({
                ...prev,
                [type]: { ...prev[type], ongoing: oldValue },
            }));

            setLocalProfile((prev) => {
                const next = { ...prev.agreements };
                if (next.GLOBAL) {
                    next.GLOBAL = {
                        ...next.GLOBAL,
                        [type]: { ...next.GLOBAL[type], ongoing: oldValue },
                    };
                }
                getSelectedCompanies(next).forEach((c) => {
                    if (next[c]) {
                        next[c] = { ...next[c], [type]: { ...next[c][type], ongoing: oldValue } };
                    }
                });
                return { ...prev, agreements: next };
            });
        } else {
            setLocalProfile((prev) => ({
                ...prev,
                agreements: {
                    ...prev.agreements,
                    [company]: {
                        ...prev.agreements[company],
                        [type]: { ...prev.agreements[company]?.[type], ongoing: oldValue },
                    },
                },
            }));
        }

        setPendingChange(null);
    };

    const applyChange = (isRetroactive: boolean) => {
        if (!pendingChange) return;
        const { company, type, oldValue, newValue } = pendingChange;

        // Save effectivity decision to send to backend on Save
        setEffectivityDecisions((prev) => {
            const filtered = prev.filter((d) => !(d.company === company && d.type === type));
            return [...filtered, { company, type, oldValue, newValue, isRetroactive }];
        });

        queryClient.setQueryData(['customers'], (prevCustomers: Customer[] | undefined) => {
            if (!prevCustomers) return [];
            return prevCustomers.map((customer) => ({
                ...customer,
                policies: customer.policies.map((policy) => {
                    if (
                        policy.type === type &&
                        (company === 'GLOBAL' || policy.company === company)
                    ) {
                        if (isRetroactive) {
                            const { fixedCommissionRate, ...rest } = policy;
                            return rest;
                        } else {
                            return { ...policy, fixedCommissionRate: oldValue || '0' };
                        }
                    }
                    return policy;
                }),
                familyMembers: customer.familyMembers?.map((fm) => ({
                    ...fm,
                    policies: fm.policies.map((policy) => {
                        if (
                            policy.type === type &&
                            (company === 'GLOBAL' || policy.company === company)
                        ) {
                            if (isRetroactive) {
                                const { fixedCommissionRate, ...rest } = policy;
                                return rest;
                            } else {
                                return { ...policy, fixedCommissionRate: oldValue || '0' };
                            }
                        }
                        return policy;
                    }),
                })),
            }));
        });

        setPendingChange(null);
    };

    const handleGlobalAgreementChange = (type: InsuranceType, field: string, value: any) => {
        // 1. Update the top-level master agreement memory
        setGlobalAgreements((prev) => ({
            ...prev,
            [type]: { ...prev[type], [field]: value },
        }));

        // 2. Cascade changes to all selected companies + the GLOBAL key in localProfile
        setLocalProfile((prev) => {
            const nextAgreements = { ...prev.agreements };

            // Ensure GLOBAL entry is synced
            if (!nextAgreements.GLOBAL) nextAgreements.GLOBAL = {};
            nextAgreements.GLOBAL = {
                ...nextAgreements.GLOBAL,
                [type]: { ...(nextAgreements.GLOBAL[type] || {}), [field]: value },
            };

            getSelectedCompanies(prev.agreements).forEach((company) => {
                if (!nextAgreements[company]) nextAgreements[company] = {};
                nextAgreements[company] = {
                    ...nextAgreements[company],
                    [type]: { ...(nextAgreements[company][type] || {}), [field]: value },
                };
            });
            return { ...prev, agreements: nextAgreements };
        });
    };

    return (
        <main className="flex-1 overflow-y-auto p-10 max-w-6xl mx-auto w-full relative">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold text-slate-900 tracking-tight text-right">
                    הגדרות חשבון
                </h1>
                <div className="flex items-center gap-4">
                    <div className="text-left hidden sm:block">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none mb-1 text-left">
                            פרופיל סוכן
                        </p>
                        <p className="text-sm font-bold text-slate-900 leading-none">
                            {profile.firstName} {profile.lastName}
                        </p>
                    </div>
                    <button
                        onClick={() => onNavigate('profile')}
                        aria-label="עבור לפרופיל סוכן"
                        className="w-10 h-10 bg-slate-900 rounded-2xl flex items-center justify-center text-white font-black text-xs cursor-pointer shadow-xl shadow-slate-900/20 hover:scale-105 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-900/50"
                    >
                        {profile.firstName?.[0] || ''}
                        {profile.lastName?.[0] || ''}
                    </button>
                </div>
            </div>

            {!profile.isSetupComplete && (
                <div
                    role="alert"
                    className="bg-rose-50 border border-rose-200 p-6 rounded-2xl mb-8 flex items-start gap-4 animate-slideUp"
                >
                    <div className="w-10 h-10 bg-rose-100 rounded-full flex items-center justify-center shrink-0">
                        <AlertTriangle className="w-6 h-6 text-rose-500" aria-hidden="true" />
                    </div>
                    <div>
                        <h3 className="font-bold text-rose-800 text-lg">הגדרת החשבון טרם הושלמה</h3>
                        <p className="text-rose-600 mt-1">
                            כדי להתחיל לעבוד עם המערכת בצורה תקינה, אנא עבור על הלשוניות מטה:
                            <br />
                            1. בחר את <b>חברות הביטוח</b> איתן אתה עובד.
                            <br />
                            2. הגדר את <b>הסכמי העמלות</b> שלך.
                            <br />
                            3. וודא שפרטי התשלום שלך מעודכנים.
                            <br />
                            בסיום, לחץ על <b>"סיים הגדרה ושמור"</b>.
                        </p>
                    </div>
                </div>
            )}

            <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden mb-10">
                <div
                    role="tablist"
                    aria-label="לשוניות הגדרות"
                    className="flex border-b border-slate-100 bg-slate-50/50"
                >
                    {[
                        {
                            id: 'personal',
                            label: 'פרופיל סוכן',
                            icon: <User className="w-4 h-4" aria-hidden="true" />,
                        },
                        {
                            id: 'agreements',
                            label: 'הסכמי עמלות',
                            icon: <Shield className="w-4 h-4" aria-hidden="true" />,
                        },
                    ].map((tab) => (
                        <button
                            key={tab.id}
                            id={`${tab.id}-tab`}
                            role="tab"
                            aria-selected={activeTab === tab.id}
                            aria-controls={`${tab.id}-panel`}
                            onClick={() => setActiveTab(tab.id as any)}
                            className={`flex-1 py-5 flex items-center justify-center gap-3 font-bold transition-standard text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-700/50 ${activeTab === tab.id ? 'bg-white text-cyan-700 border-b-2 border-cyan-700' : 'text-slate-400 hover:text-slate-600'}`}
                        >
                            {tab.icon} {tab.label}
                        </button>
                    ))}
                </div>

                <div className="p-10">
                    {activeTab === 'personal' && (
                        <div id="personal-panel" role="tabpanel" aria-labelledby="personal-tab">
                            <PersonalTab
                                localProfile={localProfile}
                                setLocalProfile={setLocalProfile}
                            />
                        </div>
                    )}
                    {activeTab === 'agreements' && (
                        <div id="agreements-panel" role="tabpanel" aria-labelledby="agreements-tab">
                            <AgreementsTab
                                localProfile={localProfile}
                                setLocalProfile={setLocalProfile}
                                globalAgreements={globalAgreements}
                                handleGlobalAgreementChange={handleGlobalAgreementChange}
                                setPendingChange={setPendingChange}
                            />
                        </div>
                    )}
                </div>
            </div>

            <div className="flex justify-end pt-4 pb-10">
                <button
                    onClick={handleSave}
                    className="bg-emerald-500 text-white px-12 py-4 rounded-2xl font-bold shadow-xl shadow-emerald-500/30 hover:bg-emerald-600 active:scale-95 transition-all flex items-center gap-3 text-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500/50"
                >
                    <Save className="w-6 h-6" aria-hidden="true" /> שמירה ומעבר ליומן לקוחות
                </button>
            </div>

            {pendingChange && (
                <EffectivityModal
                    pendingChange={pendingChange}
                    onCancel={cancelChange}
                    applyChange={applyChange}
                />
            )}
        </main>
    );
};

export default ProfileSettings;
