import { useQueries, useQuery } from '@tanstack/react-query';
import React from 'react';
import { fetchPolicyYield } from '../api/yields';

/**
 * Hook: fetches the weighted monthly yield for a single policy.
 *
 * @param policyId - UUID of the policy (pass empty string / undefined to disable)
 *
 * @returns
 *   data     - monthly yield as a decimal (e.g. 0.0123 = 1.23%), or 0 if unavailable
 *   isLoading
 *   isError
 */
export function usePolicyYield(policyId: string | undefined) {
    return useQuery<number, Error>({
        queryKey: ['yield', policyId, 'latest'],
        queryFn: () => fetchPolicyYield(policyId!),
        enabled: !!policyId,
        staleTime: 1000 * 60 * 60, // 1 hour — yields don't change intra-day
        // Default to 0 so callers always get a number, even on error
        placeholderData: 0,
    });
}

/**
 * Hook: fetches weighted monthly yields for multiple policies in one shot.
 * Used by CustomerJournal to bulk-load accumulation data for all customers.
 * Uses useQueries for granular caching per policy ID.
 *
 * @param policyIds - array of policy UUIDs. Pass an empty array to disable.
 *
 * @returns
 *   data     - Record<policyId, monthlyYieldDecimal> or {} while loading
 *   isLoading
 */
export function usePortfolioYields(policyIds: string[]) {
    const results = useQueries({
        queries: policyIds.map((id) => ({
            queryKey: ['yield', id, 'latest'],
            queryFn: () => fetchPolicyYield(id),
            staleTime: 1000 * 60 * 60,
            placeholderData: 0,
        })),
    });

    const data = React.useMemo(() => {
        const map: Record<string, number> = {};
        results.forEach((r, i) => {
            if (r.data !== undefined) {
                map[policyIds[i]] = r.data;
            }
        });
        return map;
    }, [results, policyIds]);

    const isLoading = results.some((r) => r.isLoading);

    return { data, isLoading };
}
