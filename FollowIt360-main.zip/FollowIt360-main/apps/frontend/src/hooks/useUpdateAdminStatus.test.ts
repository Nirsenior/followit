// @vitest-environment happy-dom
import { renderHook, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { useUpdateAdminStatus } from './useUpdateAdminStatus.js';
import React from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

global.fetch = vi.fn();

describe('useUpdateAdminStatus hook', () => {
    let queryClient: QueryClient;
    let wrapper: React.FC<{ children: React.ReactNode }>;
    let invalidateSpy: any;

    beforeEach(() => {
        vi.clearAllMocks();
        queryClient = new QueryClient({
            defaultOptions: {
                queries: {
                    retry: false,
                },
                mutations: {
                    retry: false,
                },
            },
        });
        invalidateSpy = vi.spyOn(queryClient, 'invalidateQueries');
        wrapper = ({ children }: { children: React.ReactNode }) =>
            React.createElement(QueryClientProvider, { client: queryClient }, children);
    });

    it('should call fetch with POST method and invalidate query when promoting (isAdmin is true)', async () => {
        (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
            ok: true,
            json: async () => ({ success: true, message: 'Role ADMIN granted successfully' }),
        });

        const { result } = renderHook(() => useUpdateAdminStatus(), { wrapper });

        result.current.mutate({ userId: 'user-123', isAdmin: true });

        await waitFor(() => {
            expect(result.current.isSuccess).toBe(true);
        });

        expect(global.fetch).toHaveBeenCalledWith('/api/admin/users/user-123/roles', {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ role: 'ADMIN' }),
        });

        expect(invalidateSpy).toHaveBeenCalledWith({ queryKey: ['admin', 'users'] });
    });

    it('should call fetch with DELETE method and invalidate query when demoting (isAdmin is false)', async () => {
        (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
            ok: true,
            json: async () => ({ success: true, message: 'Role ADMIN removed successfully' }),
        });

        const { result } = renderHook(() => useUpdateAdminStatus(), { wrapper });

        result.current.mutate({ userId: 'user-123', isAdmin: false });

        await waitFor(() => {
            expect(result.current.isSuccess).toBe(true);
        });

        expect(global.fetch).toHaveBeenCalledWith('/api/admin/users/user-123/roles', {
            method: 'DELETE',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ role: 'ADMIN' }),
        });

        expect(invalidateSpy).toHaveBeenCalledWith({ queryKey: ['admin', 'users'] });
    });

    it('should throw an error and not invalidate query if the fetch request fails', async () => {
        (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
            ok: false,
        });

        const { result } = renderHook(() => useUpdateAdminStatus(), { wrapper });

        result.current.mutate({ userId: 'user-123', isAdmin: true });

        await waitFor(() => {
            expect(result.current.isError).toBe(true);
        });

        expect(result.current.error).toBeDefined();
        expect(result.current.error?.message).toContain('Failed to promote user');
        expect(invalidateSpy).not.toHaveBeenCalled();
    });
});
