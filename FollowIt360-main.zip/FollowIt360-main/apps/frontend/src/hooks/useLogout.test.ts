// @vitest-environment happy-dom
import { renderHook } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { useLogout } from './useLogout.js';
import { ROUTES } from '../constants/routes.js';

const mockNavigate = vi.fn();
vi.mock('react-router-dom', () => ({
    useNavigate: () => mockNavigate
}));

const mockClear = vi.fn();
vi.mock('@tanstack/react-query', () => ({
    useQueryClient: () => ({ clear: mockClear })
}));

const mockResetAuthStore = vi.fn();
vi.mock('../store/authStore.js', () => ({
    useAuthStore: () => ({ logout: mockResetAuthStore })
}));

global.fetch = vi.fn();

describe('useLogout hook', () => {
    beforeEach(() => {
        vi.clearAllMocks();
    });

    it('should call fetch, clear query cache, reset auth store, and navigate', async () => {
        (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValueOnce({ ok: true });
        
        const { result } = renderHook(() => useLogout());
        
        await result.current.handleLogout();

        expect(global.fetch).toHaveBeenCalledWith('/api/auth/logout', {
            method: 'POST',
            credentials: 'include'
        });
        expect(mockClear).toHaveBeenCalledTimes(1);
        expect(mockResetAuthStore).toHaveBeenCalledTimes(1);
        expect(mockNavigate).toHaveBeenCalledWith(ROUTES.HOME);
    });

    it('should still clear cache and navigate even if fetch fails', async () => {
        (global.fetch as ReturnType<typeof vi.fn>).mockRejectedValueOnce(new Error('Network error'));
        
        const { result } = renderHook(() => useLogout());
        
        await result.current.handleLogout();

        expect(mockClear).toHaveBeenCalledTimes(1);
        expect(mockResetAuthStore).toHaveBeenCalledTimes(1);
        expect(mockNavigate).toHaveBeenCalledWith(ROUTES.HOME);
    });
});
