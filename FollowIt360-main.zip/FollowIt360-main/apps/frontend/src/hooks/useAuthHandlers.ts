import type { UserProfile } from '@repo/types';
import { useNavigate } from 'react-router-dom';
import { EMPTY_USER_PROFILE } from '../constants/profile';
import { ROUTES } from '../constants/routes';
import { useAuthStore } from '../store/authStore';

interface LoginPayload {
    userId: string;
    name: string;
    phone?: string | null;
    isAdmin?: boolean;
}
interface SignupPayload {
    id: string;
    firstName?: string;
    lastName?: string;
    email: string;
}

/** Returns stable handlers for login and signup flows. */
export const useAuthHandlers = () => {
    const navigate = useNavigate();
    const { login } = useAuthStore();

    const handleLogin = async (data: LoginPayload & { email: string; agreements: any[] }) => {
        const names = data.name ? data.name.split(' ') : [];
        const [first = 'סוכן', ...rest] = names;
        const profile: UserProfile = {
            ...EMPTY_USER_PROFILE,
            id: data.userId,
            firstName: first,
            lastName: rest.join(' '),
            email: data.email,
            phone: data.phone || '',
            isAdmin: data.isAdmin,
            isSetupComplete: true,
        };

        // Map agreements from array to record
        if (data.agreements && Array.isArray(data.agreements)) {
            const loadedAgreements: Record<string, any> = {};
            data.agreements.forEach((item: any) => {
                loadedAgreements[item.company] = item.rates || {};
            });
            profile.agreements = loadedAgreements;
        }

        login(profile);
        navigate(ROUTES.DASHBOARD);
    };

    /**
     * Called after a successful signup. Sets `isSetupComplete = true` to bypass onboarding
     * and redirects directly to the dashboard.
     */
    const handleSignup = (data: SignupPayload) => {
        const profile: UserProfile = {
            ...EMPTY_USER_PROFILE,
            ...(data as any),
            id: data.id,
            firstName: data.firstName ?? 'משתמש',
            lastName: data.lastName ?? 'חדש',
            email: data.email,
            isSetupComplete: true,
        };
        login(profile);
        navigate(ROUTES.DASHBOARD);
    };

    return { handleLogin, handleSignup };
};
