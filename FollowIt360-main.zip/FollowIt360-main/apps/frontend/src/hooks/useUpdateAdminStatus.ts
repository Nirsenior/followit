import { useMutation, useQueryClient } from '@tanstack/react-query';

const getBaseUrl = () => import.meta.env.VITE_API_URL || '';

interface UpdateAdminStatusParams {
    userId: string;
    isAdmin: boolean;
}

export const useUpdateAdminStatus = () => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async ({ userId, isAdmin }: UpdateAdminStatusParams) => {
            const res = await fetch(`${getBaseUrl()}/api/admin/users/${userId}/roles`, {
                method: isAdmin ? 'POST' : 'DELETE',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ role: 'ADMIN' }),
            });
            const action = isAdmin ? 'promote' : 'demote';
            if (!res.ok) throw new Error(`Failed to ${action} user`);
            return res.json();
        },
        onSuccess: () => {
            // Invalidate admin users list so the table can reflect any role changes if needed
            queryClient.invalidateQueries({ queryKey: ['admin', 'users'] });
        },
    });
};
