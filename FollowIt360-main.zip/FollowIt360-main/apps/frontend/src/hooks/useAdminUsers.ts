import { useQuery } from '@tanstack/react-query';

export interface AdminUser {
    id: string;
    name: string;
    email: string;
    phone: string | null;
    isSubscribed: boolean;
    isAdmin: boolean;
    customerCount: number;
}

export interface AdminUsersResponse {
    users: AdminUser[];
    total: number;
    page: number;
    limit: number;
}

const getBaseUrl = () => import.meta.env.VITE_API_URL || '';

export const useAdminUsers = (params: {
    page: number;
    limit: number;
    search?: string;
    sortBy?: 'name' | 'email' | 'customerCount' | 'isSubscribed';
    sortOrder?: 'asc' | 'desc';
}) => {
    const { page, limit, search, sortBy, sortOrder } = params;

    return useQuery<AdminUsersResponse>({
        queryKey: ['admin', 'users', page, limit, search, sortBy, sortOrder],
        queryFn: async () => {
            const queryParams = new URLSearchParams();
            queryParams.append('page', String(page));
            queryParams.append('limit', String(limit));
            if (search !== undefined && search !== '') queryParams.append('search', search);
            if (sortBy) queryParams.append('sortBy', sortBy);
            if (sortOrder) queryParams.append('sortOrder', sortOrder);

            const res = await fetch(`${getBaseUrl()}/api/admin/users?${queryParams.toString()}`, {
                credentials: 'include',
            });
            if (!res.ok) throw new Error('Failed to fetch admin users');
            return res.json();
        },
        placeholderData: (previousData) => previousData,
    });
};
