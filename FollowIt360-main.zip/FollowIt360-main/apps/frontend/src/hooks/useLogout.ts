import { useQueryClient } from '@tanstack/react-query';
import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { ROUTES } from '../constants/routes';
import { useAuthStore } from '../store/authStore';

export const useLogout = () => {
    const navigate = useNavigate();
    const queryClient = useQueryClient();
    const { logout: resetAuthStore } = useAuthStore();

    const handleLogout = useCallback(async () => {
        try {
            const baseUrl = import.meta.env.VITE_API_URL || '';
            // 1. Call backend logout to clear session cookies
            await fetch(`${baseUrl}/api/auth/logout`, { 
                method: 'POST', 
                credentials: 'include' 
            });
        } catch (err) {
            console.error('Logout API call failed:', err);
        } finally {
            // 2. Clear React Query cache. This is critical to prevent data leaking between users.
            queryClient.clear();
            
            // 3. Optional: Clear local storage if there's any non-auth persistent state
            // localStorage.clear(); 

            // 4. Reset auth store (isAuthenticated: false, user: null)
            resetAuthStore();

            // 5. Redirect to landing page
            navigate(ROUTES.HOME);
        }
    }, [navigate, queryClient, resetAuthStore]);

    return { handleLogout };
};
