import { useQuery } from '@tanstack/react-query';

export interface AdminDashboardStats {
    monthlyEntries: number;
    totalSubscribedUsers: number;
    totalMonthlyIncome: number;
    monthlyCancels: {
        today: number;
        thisMonth: number;
    };
}

export interface InsuranceStats {
    mostUsedCompanies: { company: string; count: number }[];
    mostUsedTypes: { type: string; count: number }[];
}

const getBaseUrl = () => import.meta.env.VITE_API_URL || '';

export const useAdminData = () => {
    const { data: stats, isLoading: isLoadingStats } = useQuery<AdminDashboardStats>({
        queryKey: ['admin', 'dashboard-stats'],
        queryFn: async () => {
            const res = await fetch(`${getBaseUrl()}/api/admin/dashboard-stats`, {
                credentials: 'include',
            });
            if (!res.ok) throw new Error('Failed to fetch dashboard stats');
            return res.json();
        },
    });

    const { data: insuranceStats, isLoading: isLoadingInsurance } = useQuery<InsuranceStats>({
        queryKey: ['admin', 'insurance-stats'],
        queryFn: async () => {
            const res = await fetch(`${getBaseUrl()}/api/admin/insurance-stats`, {
                credentials: 'include',
            });
            if (!res.ok) throw new Error('Failed to fetch insurance stats');
            return res.json();
        },
    });

    return {
        stats,
        insuranceStats,
        isLoading: isLoadingStats || isLoadingInsurance,
    };
};
