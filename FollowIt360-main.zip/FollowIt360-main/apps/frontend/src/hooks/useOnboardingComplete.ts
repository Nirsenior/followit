import type { UserProfile } from '@repo/types';
import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { ROUTES } from '../constants/routes';
import { useAuthStore } from '../store/authStore';

const API_BASE = () => import.meta.env.VITE_API_URL || '';

/** Returns the onComplete handler for RegistrationPage. Syncs agreements to the backend then navigates to /journal. */
export const useOnboardingComplete = () => {
    const navigate = useNavigate();
    const { user, setProfile } = useAuthStore();

    const handleOnboardingComplete = useCallback(
        async (_customers: unknown, profile?: Partial<UserProfile>) => {
            if (profile) setProfile(profile);

            if (user?.id && profile?.agreements) {
                const agreementsPayload = Object.entries(profile.agreements).map(
                    ([company, rates]) => ({
                        company,
                        rates,
                    }),
                );

                try {
                    await fetch(`${API_BASE()}/api/agreements`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        credentials: 'include',
                        body: JSON.stringify({ userId: user.id, agreements: agreementsPayload }),
                    });
                } catch (err) {
                    console.error('Failed to sync agreements:', err);
                }
            }

            navigate(ROUTES.JOURNAL);
        },
        [user?.id, setProfile, navigate],
    );

    return { handleOnboardingComplete };
};
