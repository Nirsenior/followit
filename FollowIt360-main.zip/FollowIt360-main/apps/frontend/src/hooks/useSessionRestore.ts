import type { UserProfile } from '@repo/types';
import { useEffect, useState } from 'react';
import { EMPTY_USER_PROFILE } from '../constants/profile';
import { useAuthStore } from '../store/authStore';

const API_BASE = () => import.meta.env.VITE_API_URL || '';

/** Restores an existing server session on first load. Returns isInitializing. */
export const useSessionRestore = (): { isInitializing: boolean } => {
    const [isInitializing, setIsInitializing] = useState(true);
    const { login } = useAuthStore();

    useEffect(() => {
        const restore = async () => {
            try {
                const res = await fetch(`${API_BASE()}/api/auth/me`, { credentials: 'include' });
                if (res.ok) {
                    const data = await res.json();
                    const [first = '', ...rest] = (data.name ?? '').split(' ');
                    const profile: UserProfile = {
                        ...EMPTY_USER_PROFILE,
                        id: data.userId || data.id || '',
                        firstName: first,
                        lastName: rest.join(' '),
                        email: data.email,
                        phone: data.phone || '',
                        isAdmin: data.isAdmin,
                        isSetupComplete: true,
                    };

                    // Map agreements from array to record
                    if (data.agreements && Array.isArray(data.agreements)) {
                        const loadedAgreements: Record<string, any> = {};
                        data.agreements.forEach((item: any) => {
                            loadedAgreements[item.company] = item.rates || {};
                        });
                        profile.agreements = loadedAgreements;
                    }

                    login(profile);
                }
            } catch (err) {
                console.error('Session restore failed:', err);
            } finally {
                setIsInitializing(false);
            }
        };
        restore();
    }, [login]);

    return { isInitializing };
};
