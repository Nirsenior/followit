// @vitest-environment happy-dom
import { renderHook, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { useAuthHandlers } from './useAuthHandlers.js';
import { ROUTES } from '../constants/routes.js';
import { EMPTY_USER_PROFILE } from '../constants/profile.js';

const mockNavigate = vi.fn();
vi.mock('react-router-dom', () => ({
    useNavigate: () => mockNavigate,
}));

const mockLogin = vi.fn();
vi.mock('../store/authStore.js', () => ({
    useAuthStore: () => ({ login: mockLogin })
}));

global.fetch = vi.fn();

describe('useAuthHandlers hook', () => {
    beforeEach(() => {
        vi.clearAllMocks();
    });

    it('successfully handles login and fetches agreements', async () => {
        const { result } = renderHook(() => useAuthHandlers());

        const loginPayload = {
            userId: '123',
            name: 'John Doe',
            email: 'john@example.com',
            agreements: [{ company: 'מגדל', rates: { someRate: 0.5 } }]
        };

        await result.current.handleLogin(loginPayload);

        // No sequential fetch expected anymore
        expect(global.fetch).not.toHaveBeenCalled();

        const expectedProfile = {
            ...EMPTY_USER_PROFILE,
            id: '123',
            firstName: 'John',
            lastName: 'Doe',
            email: 'john@example.com',
            isSetupComplete: true,
            agreements: {
                'מגדל': { someRate: 0.5 }
            }
        };

        expect(mockLogin).toHaveBeenCalledWith(expectedProfile);
        expect(mockNavigate).toHaveBeenCalledWith(ROUTES.DASHBOARD);
    });

    it('handles signup properly and sets isSetupComplete true', () => {
        const { result } = renderHook(() => useAuthHandlers());

        result.current.handleSignup({ id: 'new-user', firstName: 'Jane', lastName: 'Doe', email: 'jane@example.com' });

        expect(mockLogin).toHaveBeenCalledWith({
            ...EMPTY_USER_PROFILE,
            id: 'new-user',
            firstName: 'Jane',
            lastName: 'Doe',
            email: 'jane@example.com',
            isSetupComplete: true
        });
        expect(mockNavigate).toHaveBeenCalledWith(ROUTES.DASHBOARD);
    });

    it('handles login with missing name and agreements properly', async () => {
        const { result } = renderHook(() => useAuthHandlers());

        const loginPayload = {
            userId: '123',
            name: undefined as any,
            email: 'john@example.com',
            agreements: undefined as any
        };

        await result.current.handleLogin(loginPayload);

        const expectedProfile = {
            ...EMPTY_USER_PROFILE,
            id: '123',
            firstName: 'סוכן',
            lastName: '',
            email: 'john@example.com',
            isSetupComplete: true,
            agreements: {} // Default empty agreements from EMPTY_USER_PROFILE
        };

        expect(mockLogin).toHaveBeenCalledWith(expectedProfile);
    });

    it('handles signup properly with missing first and last name', () => {
        const { result } = renderHook(() => useAuthHandlers());

        result.current.handleSignup({ id: 'new-user', email: 'jane@example.com' });

        expect(mockLogin).toHaveBeenCalledWith({
            ...EMPTY_USER_PROFILE,
            id: 'new-user',
            firstName: 'משתמש',
            lastName: 'חדש',
            email: 'jane@example.com',
            isSetupComplete: true
        });
    });
});
