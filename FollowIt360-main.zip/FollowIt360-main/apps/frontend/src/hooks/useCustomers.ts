import type { Customer } from '@repo/types';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
    createCustomer,
    CreateCustomerPayload,
    deleteCustomer,
    fetchCustomers,
    updateCustomer,
} from '../api/customers';

const normalizePolicy = (p: any) => ({
    ...p,
    premiumSchedule: p.premiumSchedule || p.details?.premiumSchedule || [],
    excelColumns: p.excelColumns || p.details?.excelColumns || [],
});

const normalizeFamilyMember = (fm: any) => ({
    ...fm,
    policies: (fm.policies || []).map(normalizePolicy),
});

const normalizeCustomer = (c: any) => ({
    ...c,
    policies: (c.policies || []).map(normalizePolicy),
    familyMembers: (c.familyMembers || []).map(normalizeFamilyMember),
});

export const useCustomers = () => {
    return useQuery<Customer[], Error>({
        queryKey: ['customers'],
        queryFn: async () => {
            const data = await fetchCustomers();
            return data.map(normalizeCustomer);
        },
        staleTime: 5 * 60 * 1000,
    });
};

export const useCreateCustomer = () => {
    const queryClient = useQueryClient();
    return useMutation<{ status: string; customerId: string }, Error, CreateCustomerPayload>({
        mutationFn: createCustomer,
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['customers'] });
        },
    });
};

export const useUpdateCustomer = () => {
    const queryClient = useQueryClient();
    return useMutation({
        mutationFn: ({ dbId, payload }: { dbId: string; payload: CreateCustomerPayload }) =>
            updateCustomer(dbId, payload),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['customers'] });
        },
    });
};

export const useDeleteCustomer = () => {
    const queryClient = useQueryClient();
    return useMutation({
        mutationFn: (dbId: string) => deleteCustomer(dbId),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['customers'] });
        },
    });
};
