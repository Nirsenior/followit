import React, { useEffect, useState } from 'react';

interface DebouncedInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
    value?: string;
    onCommit: (newValue: string, oldValue: string) => void;
}

export const DebouncedInput = ({
    value,
    onCommit,
    className,
    placeholder,
    ...rest
}: DebouncedInputProps) => {
    const [localVal, setLocalVal] = useState(value || '');
    useEffect(() => setLocalVal(value || ''), [value]);

    return (
        <input
            type="number"
            value={localVal}
            placeholder={placeholder}
            className={className}
            onChange={(e) => setLocalVal(e.target.value)}
            onBlur={() => {
                if (localVal !== (value || '')) {
                    onCommit(localVal, value || '0');
                }
            }}
            {...rest}
        />
    );
};
