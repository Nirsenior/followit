import { CalendarDays, DollarSign, Heart } from 'lucide-react';
import React from 'react';
import { CompanyLogo } from './CompanyLogo';

interface Client {
    name: string;
    id: string;
    tag: string;
    company: string;
    premium: string;
    ongoing: string;
    accumulation: string;
    policiesCount: number;
    hasFamily: boolean;
}

export const CustomersJournalMockup: React.FC = () => {
    const clients: Client[] = [
        {
            name: 'ישראל ישראלי',
            id: '012345678',
            tag: 'פנסיה',
            company: 'מגדל',
            premium: '₪3,500',
            ongoing: '₪45.50',
            accumulation: '₪187,400',
            policiesCount: 2,
            hasFamily: true,
        },
        {
            name: 'שרה כהן',
            id: '098765432',
            tag: 'ריסק',
            company: 'הראל',
            premium: '₪280',
            ongoing: '₪18.20',
            accumulation: '—',
            policiesCount: 1,
            hasFamily: false,
        },
        {
            name: 'משה לוי',
            id: '034567891',
            tag: 'גמל',
            company: 'כלל',
            premium: '₪1,200',
            ongoing: '₪32.40',
            accumulation: '₪64,200',
            policiesCount: 3,
            hasFamily: false,
        },
        {
            name: 'רחל אברהם',
            id: '056789123',
            tag: 'מנהלים',
            company: 'מור',
            premium: '₪2,500',
            ongoing: '₪22.50',
            accumulation: '₪142,000',
            policiesCount: 1,
            hasFamily: false,
        },
    ];

    return (
        <div
            className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden h-64 flex flex-col relative font-sans text-right select-none"
            dir="rtl"
        >
            {/* Header bar styled like App page header */}
            <div className="bg-[#0A1128] px-3 py-2 flex items-center gap-2 shrink-0">
                <CalendarDays className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-[10px] font-bold text-white">יומן לקוחות</span>
                <div className="mr-auto bg-cyan-500/20 text-cyan-300 text-[9px] font-bold px-2 py-0.5 rounded-full">
                    127 לקוחות
                </div>
            </div>

            {/* Table Area matching the real CustomerTable */}
            <div className="flex-1 overflow-hidden flex flex-col bg-white">
                <table className="w-full text-right border-collapse text-[9px] table-fixed">
                    <thead>
                        <tr className="border-b border-slate-200 text-slate-900 font-bold uppercase tracking-wider bg-slate-100 py-1 px-2 shrink-0 h-8">
                            <th className="p-2 border-l border-slate-200 w-[24%]">שם לקוח / ת״ז</th>
                            <th className="p-2 border-l border-slate-200 w-[16%]">חברה</th>
                            <th className="p-2 border-l border-slate-200 text-center w-[20%] bg-slate-100/50">
                                עלות / הפקדה
                            </th>
                            {/* Commission column highlighted */}
                            <th className="p-2 border-l border-slate-200 text-center w-[20%] bg-emerald-50/40 text-emerald-800 font-bold">
                                <span className="flex items-center justify-center gap-0.5">
                                    <DollarSign className="w-2.5 h-2.5 text-emerald-600 shrink-0" />
                                    עמלת נפרעים
                                </span>
                            </th>
                            <th className="p-2 text-center w-[20%]">סכום צבירה</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 flex-1 overflow-y-auto">
                        {clients.map((client) => (
                            <tr
                                key={client.id}
                                className="hover:bg-indigo-50/50 transition-colors cursor-pointer"
                            >
                                {/* Customer Name & ID */}
                                <td className="p-2 font-bold text-slate-900 border-l border-slate-100 truncate">
                                    <div className="flex flex-col">
                                        <span className="flex items-center gap-1 text-[9px] truncate">
                                            {client.name}
                                            {client.hasFamily && (
                                                <span className="bg-indigo-100/50 text-indigo-600 px-1 rounded-sm flex items-center scale-90 shrink-0">
                                                    <Heart className="w-2 h-2 fill-current text-indigo-500" />
                                                </span>
                                            )}
                                        </span>
                                        <span className="text-[7px] text-slate-400 font-medium tracking-tight">
                                            {client.id}
                                        </span>
                                    </div>
                                </td>

                                {/* Company Badges matching real app style */}
                                <td className="p-2 text-slate-700 font-medium border-l border-slate-100">
                                    <div className="flex items-center gap-1">
                                        <CompanyLogo
                                            company={client.company}
                                            className="w-4 h-4 rounded-full shrink-0"
                                        />
                                        <span className="text-[7.5px] bg-slate-100 px-1 rounded text-slate-600 font-bold truncate">
                                            {client.company}
                                        </span>
                                    </div>
                                </td>

                                {/* Premium / Deposit Amount Column */}
                                <td className="p-2 text-center font-bold border-l border-slate-100 text-slate-700 tabular-nums bg-slate-50/20">
                                    {client.premium}
                                </td>

                                {/* Commission Column (Bold Green highlight) */}
                                <td className="p-2 text-center font-extrabold border-l border-slate-100 text-emerald-600 tabular-nums bg-emerald-50/20 text-[9.5px]">
                                    {client.ongoing}
                                </td>

                                {/* Accumulation Column */}
                                <td className="p-2 text-center text-slate-600 font-semibold tabular-nums">
                                    {client.accumulation}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Pagination simulator at bottom of Table */}
            <div className="bg-slate-50 border-t border-slate-200 p-2 flex justify-between items-center text-[7.5px] text-slate-500 shrink-0 font-sans">
                <span>מציג 1-4 מתוך 127 לקוחות</span>
                <div className="flex gap-1">
                    <button className="bg-white border border-slate-200 px-1.5 py-0.5 rounded cursor-not-allowed">
                        הקודם
                    </button>
                    <button className="bg-white border border-slate-250 px-1.5 py-0.5 rounded shadow-xs font-bold text-slate-800">
                        הבא
                    </button>
                </div>
            </div>
        </div>
    );
};

export default CustomersJournalMockup;
