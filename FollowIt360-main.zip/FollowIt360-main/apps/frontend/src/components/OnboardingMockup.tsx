import React, { useState } from 'react';
import { Check } from 'lucide-react';
import { CompanyLogo } from './CompanyLogo';

interface Company {
    id: string;
    name: string;
}

export const OnboardingMockup: React.FC = () => {
    const [selectedIds, setSelectedIds] = useState<string[]>(['הראל', 'מגדל', 'כלל']);
    const [step, setStep] = useState(1);

    const companies: Company[] = [
        { id: 'הראל', name: 'הראל' },
        { id: 'מגדל', name: 'מגדל' },
        { id: 'כלל', name: 'כלל' },
        { id: 'מור', name: 'מור' },
    ];

    const toggleCompany = (name: string) => {
        setSelectedIds(prev =>
            prev.includes(name) ? prev.filter(item => item !== name) : [...prev, name]
        );
    };

    return (
        <div
            className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden h-64 flex flex-col select-none font-sans text-right"
            dir="rtl"
        >
            {/* Real App Wizards Tab Bar (Mini version) */}
            <div className="flex bg-slate-50/50 p-1 rounded-t-2xl border-b border-slate-100 shrink-0">
                {[
                    { id: 1, label: 'חברות' },
                    { id: 2, label: 'הסכם ברירת מחדל' },
                    { id: 3, label: 'דיוק והתאמה' },
                ].map((s) => (
                    <button
                        key={s.id}
                        onClick={() => setStep(s.id)}
                        className={`flex-1 py-1.5 px-2 rounded-lg font-bold transition-all text-[9px] whitespace-nowrap text-center ${
                            step === s.id
                                ? 'bg-cyan-700 text-white shadow-sm'
                                : step > s.id
                                  ? 'bg-slate-100/80 text-slate-500'
                                  : 'text-slate-400'
                        }`}
                    >
                        {s.label}
                    </button>
                ))}
            </div>

            {step === 1 && (
                <div className="p-3 flex-1 flex flex-col justify-between bg-slate-50/20">
                    <div className="space-y-2">
                        <div className="text-center">
                            <h4 className="text-[11px] font-bold text-slate-800">
                                בחר את החברות איתן אתה עובד
                            </h4>
                            <p className="text-slate-400 text-[8px] mt-0.5">
                                לחץ על החברות כדי להוסיף אותן להסכמי העמלות.
                            </p>
                        </div>

                        {/* Company Grid */}
                        <div className="grid grid-cols-2 gap-2">
                            {companies.map((co) => {
                                const isSelected = selectedIds.includes(co.id);
                                return (
                                    <button
                                        key={co.id}
                                        onClick={() => toggleCompany(co.id)}
                                        className={`px-3 py-2 rounded-xl border transition-all flex items-center justify-between text-[10px] cursor-pointer ${
                                            isSelected
                                                ? 'bg-cyan-50/50 border-cyan-200 text-cyan-900 font-bold shadow-sm'
                                                : 'bg-white border-slate-100 text-slate-600 font-medium hover:bg-slate-50 hover:border-slate-200'
                                        }`}
                                    >
                                        <div className="flex items-center gap-2">
                                            <CompanyLogo
                                                company={co.name}
                                                className="w-5 h-5 rounded-full"
                                            />
                                            <span className="font-bold">{co.name}</span>
                                        </div>
                                        <div
                                            className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center transition-all shrink-0 ${
                                                isSelected
                                                    ? 'bg-cyan-700 border-cyan-700 text-white'
                                                    : 'border-slate-200 bg-white'
                                            }`}
                                        >
                                            {isSelected && (
                                                <Check className="w-2.5 h-2.5 stroke-[3]" />
                                            )}
                                        </div>
                                    </button>
                                );
                            })}
                        </div>
                    </div>

                    {/* Continuation button */}
                    <div className="pt-2 border-t border-slate-100 flex justify-end shrink-0">
                        <button
                            onClick={() => setStep(2)}
                            disabled={selectedIds.length === 0}
                            className="px-4 py-1.5 bg-sky-500 text-white font-bold text-[9px] rounded-lg shadow-sm hover:bg-sky-600 active:scale-95 transition-all disabled:opacity-50"
                        >
                            המשך לשלב הבא
                        </button>
                    </div>
                </div>
            )}

            {step === 2 && (
                <div className="p-3 flex-1 flex flex-col justify-between bg-slate-50/20">
                    <div className="space-y-2">
                        <div className="text-center">
                            <h4 className="text-[11px] font-bold text-slate-800">
                                הסכם ברירת מחדל
                            </h4>
                            <p className="text-slate-400 text-[8px] mt-0.5">
                                הזן את עמלות ברירת המחדל למוצרים.
                            </p>
                        </div>

                        <div className="grid grid-cols-2 gap-1.5 text-[8px]">
                            <div className="bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                                <div className="font-bold text-slate-700">פנסיה</div>
                                <div className="flex justify-between items-center mt-1">
                                    <span className="text-slate-400">נפרעים:</span>
                                    <span className="font-bold text-cyan-800">1.8%</span>
                                </div>
                            </div>
                            <div className="bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                                <div className="font-bold text-slate-700">בריאות</div>
                                <div className="flex justify-between items-center mt-1">
                                    <span className="text-slate-400">היקף:</span>
                                    <span className="font-bold text-cyan-800">12%</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex justify-between shrink-0">
                        <button
                            onClick={() => setStep(1)}
                            className="text-slate-500 font-bold text-[9px] hover:text-slate-900"
                        >
                            חזרה
                        </button>
                        <button
                            onClick={() => setStep(3)}
                            className="px-4 py-1.5 bg-sky-500 text-white font-bold text-[9px] rounded-lg shadow-sm hover:bg-sky-600 active:scale-95 transition-all"
                        >
                            המשך
                        </button>
                    </div>
                </div>
            )}

            {step === 3 && (
                <div className="p-3 flex-1 flex flex-col justify-between bg-slate-50/20">
                    <div className="space-y-2">
                        <div className="text-center">
                            <h4 className="text-[11px] font-bold text-slate-800 font-sans">
                                דיוק והתאמת הסכמים
                            </h4>
                            <p className="text-slate-400 text-[8px] mt-0.5">
                                ערוך חברה ספציפית אם יש לה הסכם שונה.
                            </p>
                        </div>

                        <div className="space-y-1.5 max-h-[100px] overflow-y-auto">
                            {selectedIds.map((company) => (
                                <div
                                    key={company}
                                    className="bg-white border border-slate-100 rounded-lg p-1.5 flex items-center justify-between shadow-xs text-[9px]"
                                >
                                    <div className="flex items-center gap-1.5">
                                        <CompanyLogo company={company} className="w-5 h-5 rounded-full" />
                                        <span className="font-bold text-slate-700">{company}</span>
                                    </div>
                                    <button 
                                        className="text-[8.5px] px-2 py-0.5 rounded border border-cyan-700/30 text-cyan-700 font-bold hover:bg-cyan-50 cursor-pointer active:scale-95 transition-all leading-none"
                                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); }}
                                    >
                                        עריכה
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex justify-between shrink-0">
                        <button
                            onClick={() => setStep(2)}
                            className="text-slate-500 font-bold text-[9px] hover:text-slate-900"
                        >
                            חזרה
                        </button>
                        <button
                            onClick={() => setStep(1)}
                            className="px-4 py-1.5 bg-slate-900 text-white font-bold text-[9px] rounded-lg shadow-sm"
                        >
                            סיום הגדרה
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default OnboardingMockup;
