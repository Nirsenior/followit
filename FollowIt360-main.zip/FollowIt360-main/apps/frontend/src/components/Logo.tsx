import React from 'react';

interface LogoProps {
    className?: string;
    variant?: 'dark' | 'light';
    showSubtitle?: boolean;
}

const Logo: React.FC<LogoProps> = ({ className = '', variant = 'dark', showSubtitle = true }) => {
    const isDark = variant === 'dark';

    return (
        /* Force LTR for the logo since it's English-based branding to ensure 'Followit' is on the left and '360' is on the right */
        <div
            className={`flex flex-col items-center justify-center select-none ${className}`}
            dir="ltr"
        >
            {/* Main Title Container with Star */}
            <div className="relative">
                <h1
                    className="text-4xl font-black tracking-tight leading-none flex items-center gap-1.5"
                >
                    <span className={isDark ? 'text-[#0A1128]' : 'text-white'}>Followit</span>
                    <span className="text-[#06b9d2]">360</span>
                </h1>
                
                {/* AI Star Icon (Wider Sparkle Style) */}
                <svg 
                    viewBox="0 0 24 24" 
                    fill="currentColor" 
                    className="w-6 h-6 text-cyan-400 absolute -top-3.5 -right-6 drop-shadow-[0_0_10px_rgba(34,211,238,0.6)]"
                >
                    <path d="M12 0c0 6.627-5.373 12-12 12 6.627 0 12 5.373 12 12 0-6.627 5.373-12 12-12-6.627 0-12-5.373-12-12z" />
                </svg>
            </div>

            {showSubtitle && (
                <>
                    {/* Subtitle with explicit layout for DOT placement */}
                    <div
                        className={`mt-2.5 text-[10px] font-black tracking-[0.3em] uppercase flex items-center ${isDark ? 'text-slate-400' : 'text-slate-400/60'}`}
                    >
                        <span>TRACK</span>
                        <span className="mx-1.5 opacity-30">•</span>
                        <span>MANAGE</span>
                        <span className="mx-1.5 opacity-30">•</span>
                        <span>GROW</span>
                    </div>
                </>
            )}
        </div>
    );
};

export default Logo;
