import { Trash2 } from 'lucide-react';
import React, { useEffect, useRef } from 'react';
import { Keys } from '../utils/keys';

interface DeleteConfirmModalProps {
    isOpen: boolean;
    title: string;
    description: React.ReactNode;
    confirmText?: string;
    cancelText?: string;
    isPending?: boolean;
    onConfirm: () => void;
    onCancel: () => void;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
    isOpen,
    title,
    description,
    confirmText = 'כן, מחק',
    cancelText = 'בטל',
    isPending = false,
    onConfirm,
    onCancel,
}) => {
    /*
     * cancelButtonRef: The "Cancel" button is the safe default and receives focus
     * when the dialog opens, preventing accidental deletion on Enter.
     * (WCAG 3.3.4 – Error Prevention, and general focus management guidance)
     */
    const cancelButtonRef = useRef<HTMLButtonElement>(null);

    useEffect(() => {
        if (isOpen) {
            // Move focus into the dialog as soon as it appears
            cancelButtonRef.current?.focus();
        }
    }, [isOpen]);

    useEffect(() => {
        if (!isOpen) return;

        /*
         * Escape key closes the modal (standard dialog UX and WCAG 2.1 F79).
         */
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === Keys.Escape) {
                onCancel();
            }
        };

        document.addEventListener('keydown', handleKeyDown);
        return () => document.removeEventListener('keydown', handleKeyDown);
    }, [isOpen, onCancel]);

    if (!isOpen) return null;

    return (
        /*
         * The outer overlay traps pointer events.
         * aria-modal="true" on the inner dialog tells AT to ignore background content.
         * role="alertdialog" is appropriate for destructive confirmation dialogs because
         * it signals urgency and ensures the message is announced immediately.
         * aria-labelledby/aria-describedby create the accessible name/description.
         */
        <div
            className="absolute inset-0 z-50 flex items-center justify-center bg-black/40 rounded-3xl animate-fadeIn backdrop-blur-sm"
            role="presentation"
            /*
             * Clicking the backdrop cancels the dialog, consistent with the Escape key.
             * The inner dialog stops propagation so clicking inside does not dismiss it.
             */
            onClick={onCancel}
        >
            <div
                role="alertdialog"
                aria-modal="true"
                aria-labelledby="delete-modal-title"
                aria-describedby="delete-modal-desc"
                className="bg-white rounded-2xl shadow-2xl p-8 max-w-sm w-full mx-6 text-center border border-slate-200"
                onClick={(e) => e.stopPropagation()}
            >
                {/*
                 * The trash icon is decorative; aria-hidden hides it from screen readers.
                 * The dialog's aria-labelledby (title) already communicates the action.
                 */}
                <div
                    className="w-14 h-14 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-4"
                    aria-hidden="true"
                >
                    <Trash2 className="w-7 h-7 text-rose-500" />
                </div>

                <h3 id="delete-modal-title" className="text-lg font-black text-slate-900 mb-1">
                    {title}
                </h3>
                <div id="delete-modal-desc" className="text-sm text-slate-500 font-medium mb-6">
                    {description}
                </div>

                <div className="flex gap-3">
                    {/*
                     * Cancel button receives initial focus (ref) and is the keyboard-safe default.
                     */}
                    <button
                        ref={cancelButtonRef}
                        onClick={onCancel}
                        disabled={isPending}
                        className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 font-bold text-sm hover:bg-slate-50 disabled:opacity-50 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-400"
                    >
                        {cancelText}
                    </button>
                    <button
                        onClick={onConfirm}
                        disabled={isPending}
                        className="flex-1 py-2.5 rounded-xl bg-rose-500 text-white font-bold text-sm hover:bg-rose-600 disabled:opacity-50 transition-all shadow-md shadow-rose-500/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
                    >
                        {isPending ? 'מוחק...' : confirmText}
                    </button>
                </div>
            </div>
        </div>
    );
};
