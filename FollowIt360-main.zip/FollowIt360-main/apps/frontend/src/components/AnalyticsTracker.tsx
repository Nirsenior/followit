import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { ROUTES } from '../constants/routes';

export const AnalyticsTracker = () => {
    const location = useLocation();

    useEffect(() => {
        // We only want to track main entry points, not sub-routes or dialogs.
        // Adjust this list based on what is considered a "main page"
        const trackedPaths = [ROUTES.DASHBOARD, ROUTES.JOURNAL, ROUTES.HOME];
        
        if (trackedPaths.includes(location.pathname)) {
            // Fire and forget
            fetch(`${import.meta.env.VITE_API_URL || ''}/api/analytics/visit`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ path: location.pathname }),
            }).catch(() => {
                // Ignore analytics errors silently
            });
        }
    }, [location.pathname]);

    return null;
};
