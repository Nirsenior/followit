import { FileSpreadsheet } from 'lucide-react';
import React from 'react';

export const CloudUploadMockup: React.FC = () => {
    return (
        <div className="bg-gradient-to-b from-sky-50 to-blue-50 h-64 rounded-xl border border-sky-100 flex flex-col items-center justify-center gap-4 relative overflow-hidden group/upload select-none">
            {/* Cloud SVG */}
            <svg
                width="64"
                height="40"
                viewBox="0 0 64 40"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="group-hover/upload:scale-105 transition-transform duration-300"
            >
                <path
                    d="M50 38H14C7.37 38 2 32.63 2 26C2 19.82 6.72 14.76 12.77 14.08C13.62 8.34 18.59 4 24.5 4C27.27 4 29.82 4.96 31.84 6.54C33.5 4.96 35.73 4 38.2 4C43.73 4 48.2 8.47 48.2 14C48.2 14.07 48.19 14.14 48.19 14.21C55.01 15.1 60 21 60 28C60 33.52 55.52 38 50 38Z"
                    fill="#bfdbfe"
                    stroke="#93c5fd"
                    strokeWidth="1.5"
                />
                {/* Up arrow */}
                <path
                    d="M32 36V20M32 20L27 25M32 20L37 25"
                    stroke="#2563eb"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                />
            </svg>
            {/* Excel file badge */}
            <div className="flex items-center gap-2 bg-white rounded-lg px-3 py-1.5 shadow-md border border-slate-200 group-hover/upload:translate-y-[-2px] transition-transform duration-300">
                <div className="w-6 h-6 rounded bg-[#1D6F42] flex items-center justify-center">
                    <FileSpreadsheet className="w-3.5 h-3.5 text-white" />
                </div>
                <span className="text-xs font-bold text-slate-700">התפתחות_פרמיה.xlsx</span>
            </div>
        </div>
    );
};

export default CloudUploadMockup;
