import { Accessibility, Contrast, EyeOff, RotateCcw, Type } from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';

export const AccessibilityWidget: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [isMonochrome, setIsMonochrome] = useState(
        () => localStorage.getItem('a11y-monochrome') === 'true',
    );
    const [isHighContrast, setIsHighContrast] = useState(
        () => localStorage.getItem('a11y-high-contrast') === 'true',
    );
    const [isLargeText, setIsLargeText] = useState(
        () => localStorage.getItem('a11y-large-text') === 'true',
    );

    const [position, setPosition] = useState<{ x: number; y: number } | null>(null);
    const [popupAlign, setPopupAlign] = useState<'right' | 'left'>('right');
    const [popupValign, setPopupValign] = useState<'above' | 'below'>('above');

    const widgetRef = useRef<HTMLDivElement>(null);
    const toggleButtonRef = useRef<HTMLButtonElement>(null);
    const isDraggingRef = useRef(false);
    const dragStart = useRef({ x: 0, y: 0 });
    const posStart = useRef({ x: 0, y: 0 });
    const dragDistance = useRef(0);

    // Apply or remove body classes when settings change
    useEffect(() => {
        const root = document.documentElement;

        if (isMonochrome) {
            root.classList.add('a11y-monochrome');
            localStorage.setItem('a11y-monochrome', 'true');
        } else {
            root.classList.remove('a11y-monochrome');
            localStorage.removeItem('a11y-monochrome');
        }

        if (isHighContrast) {
            root.classList.add('a11y-high-contrast');
            localStorage.setItem('a11y-high-contrast', 'true');
        } else {
            root.classList.remove('a11y-high-contrast');
            localStorage.removeItem('a11y-high-contrast');
        }

        if (isLargeText) {
            root.classList.add('a11y-large-text');
            localStorage.setItem('a11y-large-text', 'true');
        } else {
            root.classList.remove('a11y-large-text');
            localStorage.removeItem('a11y-large-text');
        }
    }, [isMonochrome, isHighContrast, isLargeText]);

    // Keyboard handlers (close on ESC, close on click outside)
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'Escape' && isOpen) {
                setIsOpen(false);
                toggleButtonRef.current?.focus();
            }
        };

        const handleClickOutside = (e: MouseEvent) => {
            if (widgetRef.current && !widgetRef.current.contains(e.target as Node) && isOpen) {
                setIsOpen(false);
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [isOpen]);

    // Adjust menu popup orientation dynamically based on viewport position
    useEffect(() => {
        if (isOpen && widgetRef.current) {
            const rect = widgetRef.current.getBoundingClientRect();
            // Decide horizontal alignment
            if (rect.left < 280) {
                setPopupAlign('left');
            } else {
                setPopupAlign('right');
            }
            // Decide vertical alignment
            if (rect.top < 320) {
                setPopupValign('below');
            } else {
                setPopupValign('above');
            }
        }
    }, [isOpen, position]);

    const handlePointerDown = (e: React.PointerEvent<HTMLButtonElement>) => {
        if (e.button !== 0) return;
        isDraggingRef.current = true;
        dragStart.current = { x: e.clientX, y: e.clientY };
        dragDistance.current = 0;

        const rect = widgetRef.current?.getBoundingClientRect();
        if (rect) {
            posStart.current = { x: rect.left, y: rect.top };
        }
        e.currentTarget.setPointerCapture(e.pointerId);
    };

    const handlePointerMove = (e: React.PointerEvent<HTMLButtonElement>) => {
        if (!isDraggingRef.current) return;
        const dx = e.clientX - dragStart.current.x;
        const dy = e.clientY - dragStart.current.y;
        dragDistance.current = Math.sqrt(dx * dx + dy * dy);

        let newX = posStart.current.x + dx;
        let newY = posStart.current.y + dy;

        const rect = widgetRef.current?.getBoundingClientRect();
        const width = rect?.width || 48;
        const height = rect?.height || 48;

        newX = Math.max(10, Math.min(window.innerWidth - width - 10, newX));
        newY = Math.max(10, Math.min(window.innerHeight - height - 10, newY));

        setPosition({ x: newX, y: newY });
    };

    const handlePointerUp = (e: React.PointerEvent<HTMLButtonElement>) => {
        if (!isDraggingRef.current) return;
        isDraggingRef.current = false;
        e.currentTarget.releasePointerCapture(e.pointerId);
    };

    const handleButtonClick = (e: React.MouseEvent) => {
        if (dragDistance.current > 5) {
            e.preventDefault();
            e.stopPropagation();
            return;
        }
        setIsOpen(!isOpen);
    };

    const handleReset = () => {
        setIsMonochrome(false);
        setIsHighContrast(false);
        setIsLargeText(false);
    };

    const popupClass = `absolute ${popupValign === 'below' ? 'top-14' : 'bottom-14'} ${
        popupAlign === 'left' ? 'left-0' : 'right-0'
    } w-64 bg-slate-900 text-white p-5 rounded-2xl shadow-2xl border border-white/10 animate-slideDown space-y-4`;

    return (
        <div
            ref={widgetRef}
            className="fixed bottom-32 right-6 z-[999] font-sans touch-none"
            dir="rtl"
            style={
                position
                    ? {
                          left: `${position.x}px`,
                          top: `${position.y}px`,
                          bottom: 'auto',
                          right: 'auto',
                      }
                    : undefined
            }
        >
            {/* Toggle Button */}
            <button
                ref={toggleButtonRef}
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onClick={handleButtonClick}
                aria-expanded={isOpen}
                aria-haspopup="true"
                aria-label="פתח תפריט נגישות"
                className="w-12 h-12 bg-blue-600 hover:bg-blue-700 text-white rounded-full flex items-center justify-center shadow-xl hover:scale-105 active:scale-95 transition-all focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-blue-500/50 cursor-grab active:cursor-grabbing"
            >
                <Accessibility className="w-6 h-6 pointer-events-none" aria-hidden="true" />
            </button>

            {/* Menu Drawer/Popup */}
            {isOpen && (
                <div
                    role="dialog"
                    aria-modal="true"
                    aria-label="אפשרויות נגישות"
                    className={popupClass}
                >
                    <div className="flex justify-between items-center border-b border-white/10 pb-2">
                        <span className="text-xs font-semibold text-blue-400 tracking-wider">
                            נגישות אתר (IS 5568)
                        </span>
                    </div>

                    <div className="space-y-2">
                        {/* Monochrome Grayscale Toggle */}
                        <button
                            onClick={() => setIsMonochrome(!isMonochrome)}
                            aria-pressed={isMonochrome}
                            className={`w-full flex items-center justify-between p-3 rounded-xl text-xs font-bold transition-all border border-transparent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 ${
                                isMonochrome
                                    ? 'bg-blue-600 text-white shadow-md'
                                    : 'bg-white/5 hover:bg-white/10 text-slate-300'
                            }`}
                        >
                            <span className="flex items-center gap-2">
                                <EyeOff className="w-4 h-4" aria-hidden="true" />
                                גווני אפור (שחור-לבן)
                            </span>
                            <span className="text-[10px] opacity-75">
                                {isMonochrome ? 'פעיל' : 'כבוי'}
                            </span>
                        </button>

                        {/* High Contrast Toggle */}
                        <button
                            onClick={() => setIsHighContrast(!isHighContrast)}
                            aria-pressed={isHighContrast}
                            className={`w-full flex items-center justify-between p-3 rounded-xl text-xs font-bold transition-all border border-transparent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 ${
                                isHighContrast
                                    ? 'bg-blue-600 text-white shadow-md'
                                    : 'bg-white/5 hover:bg-white/10 text-slate-300'
                            }`}
                        >
                            <span className="flex items-center gap-2">
                                <Contrast className="w-4 h-4" aria-hidden="true" />
                                ניגודיות גבוהה
                            </span>
                            <span className="text-[10px] opacity-75">
                                {isHighContrast ? 'פעיל' : 'כבוי'}
                            </span>
                        </button>

                        {/* Large Text Toggle */}
                        <button
                            onClick={() => setIsLargeText(!isLargeText)}
                            aria-pressed={isLargeText}
                            className={`w-full flex items-center justify-between p-3 rounded-xl text-xs font-bold transition-all border border-transparent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 ${
                                isLargeText
                                    ? 'bg-blue-600 text-white shadow-md'
                                    : 'bg-white/5 hover:bg-white/10 text-slate-300'
                            }`}
                        >
                            <span className="flex items-center gap-2">
                                <Type className="w-4 h-4" aria-hidden="true" />
                                הגדלת גופן
                            </span>
                            <span className="text-[10px] opacity-75">
                                {isLargeText ? 'פעיל' : 'כבוי'}
                            </span>
                        </button>

                        {/* Reset Toggles */}
                        <button
                            onClick={handleReset}
                            className="w-full flex items-center justify-center gap-2 p-2 rounded-xl text-[11px] font-bold text-slate-400 hover:text-white transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-500"
                        >
                            <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                            איפוס הגדרות נגישות
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};
