import { CheckCircle, Mail, Phone, TrendingUp, X } from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import { Keys } from '../utils/keys';

interface PortfolioValuationModalProps {
    isOpen: boolean;
    onClose: () => void;
    portfolioValue: number;
    initialEmail?: string;
    initialPhone?: string;
    agentName: string;
}

export const PortfolioValuationModal: React.FC<PortfolioValuationModalProps> = ({
    isOpen,
    onClose,
    portfolioValue,
    initialEmail = '',
    initialPhone = '',
    agentName,
}) => {
    const [showContactForm, setShowContactForm] = useState(false);
    const [phone, setPhone] = useState(initialPhone);
    const [email, setEmail] = useState(initialEmail);
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    /*
     * closeButtonRef: receives focus when the dialog opens (safe, cancellable entry point).
     * triggerRef: stores the element that opened the modal so focus can be returned on close.
     */
    const closeButtonRef = useRef<HTMLButtonElement>(null);
    const triggerRef = useRef<HTMLElement | null>(null);

    useEffect(() => {
        if (isOpen) {
            setShowContactForm(false);
            setPhone(initialPhone);
            setEmail(initialEmail);
            setIsSubmitted(false);
            setIsSubmitting(false);
            // Capture the currently focused element so we can return to it on close
            triggerRef.current = document.activeElement as HTMLElement;
            // Move focus into the dialog
            setTimeout(() => closeButtonRef.current?.focus(), 0);
        }
    }, [isOpen, initialEmail, initialPhone]);

    useEffect(() => {
        if (!isOpen) return;

        /*
         * Escape key closes the dialog (WCAG 2.1 F79 / standard dialog pattern).
         */
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === Keys.Escape) {
                handleClose();
            }
        };

        document.addEventListener('keydown', handleKeyDown);
        return () => document.removeEventListener('keydown', handleKeyDown);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isOpen]);

    const handleClose = () => {
        onClose();
        // Return focus to the trigger element (e.g. the "חשב שווי" button in Dashboard)
        setTimeout(() => triggerRef.current?.focus(), 0);
    };

    if (!isOpen) return null;

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        try {
            const response = await fetch(
                `${import.meta.env.VITE_API_URL || ''}/api/leads/sell-portfolio`,
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'include',
                    body: JSON.stringify({
                        phone,
                        email,
                        portfolioValue,
                        agentName,
                    }),
                },
            );

            if (response.ok) {
                setIsSubmitted(true);
            } else {
                console.error('Failed to submit lead');
            }
        } catch (error) {
            console.error('Error submitting lead', error);
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        /*
         * Backdrop — aria-hidden keeps it out of the AT tree; clicking dismisses the dialog.
         */
        <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 transition-all duration-300"
            aria-hidden="true"
            onClick={handleClose}
        >
            {/*
             * role="dialog" + aria-modal: tells screen readers this is a modal dialog and
             * that background content should be ignored.
             * aria-labelledby links to the visible heading for the accessible name.
             */}
            <div
                role="dialog"
                aria-modal="true"
                aria-labelledby="valuation-modal-title"
                className="font-sans bg-white rounded-3xl shadow-2xl border border-slate-100 max-w-lg w-full overflow-hidden p-6 md:p-8 relative text-right flex flex-col gap-6 animate-in fade-in zoom-in-95 duration-200"
                dir="rtl"
                // Stop backdrop-click from closing when clicking inside the dialog
                onClick={(e) => e.stopPropagation()}
                // Remove from aria-hidden scope (the parent has aria-hidden, this overrides)
                aria-hidden="false"
            >
                {/*
                 * Close button receives initial focus (ref).
                 * aria-label="סגור" gives it an explicit accessible name for the icon-only button.
                 */}
                <button
                    ref={closeButtonRef}
                    onClick={handleClose}
                    className="absolute top-6 left-6 text-slate-400 hover:text-slate-600 transition-colors p-1 rounded-lg hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-400"
                    aria-label="סגור"
                >
                    <X className="w-5 h-5" aria-hidden="true" />
                </button>

                {!isSubmitted ? (
                    <div className="space-y-6">
                        {/* Valuation Section */}
                        <div className="text-center space-y-4 pt-4">
                            {/* Decorative icon — aria-hidden, the heading is the accessible label */}
                            <div
                                className="mx-auto w-16 h-16 rounded-full bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600 shadow-inner"
                                aria-hidden="true"
                            >
                                <TrendingUp className="w-8 h-8" />
                            </div>

                            <div className="space-y-2">
                                <h3
                                    id="valuation-modal-title"
                                    className="text-base md:text-lg font-bold text-slate-600 leading-snug"
                                >
                                    מדהים, השווי המוערך של התיק שלך הינו:
                                </h3>
                                {/*
                                 * select-all helps keyboard users easily copy the value.
                                 * tabIndex={0} makes it reachable by keyboard without being interactive.
                                 */}
                                <div
                                    className="text-3xl md:text-4xl font-bold text-emerald-600 tracking-tight py-2 drop-shadow-sm select-all"
                                    tabIndex={0}
                                    aria-label={`שווי מוערך: ${Math.round(portfolioValue).toLocaleString()} שקלים חדשים`}
                                >
                                    {Math.round(portfolioValue).toLocaleString()} ש״ח
                                </div>
                                <p className="text-xs font-semibold text-slate-400">
                                    (לפי ממוצע מכפלות מקובל בענף) .
                                </p>
                            </div>
                        </div>

                        {/* CTA / Contact Form Toggle Button */}
                        {!showContactForm ? (
                            <button
                                onClick={() => setShowContactForm(true)}
                                className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-2xl transition-all shadow-md shadow-emerald-600/20 hover:shadow-lg hover:shadow-emerald-600/30 flex items-center justify-center gap-2 text-sm md:text-base focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2"
                            >
                                אני מעוניין למכור - אשמח שתצרו איתי קשר.
                            </button>
                        ) : (
                            /* Expanded Contact Form */
                            <form
                                onSubmit={handleSubmit}
                                className="space-y-4 pt-4 border-t border-slate-100 animate-in fade-in slide-in-from-top-4 duration-300"
                                aria-label="טופס יצירת קשר למכירת תיק"
                            >
                                <div className="text-right pb-1">
                                    <h4 className="font-bold text-slate-700 text-sm">
                                        אני מעוניין למכור - אשמח שתצרו איתי קשר:
                                    </h4>
                                </div>

                                {/*
                                 * Each <label> uses htmlFor → input id for a programmatic association.
                                 * This means clicking the label focuses the input (WCAG 1.3.1 / 2.5.3).
                                 */}
                                <div className="space-y-1.5">
                                    <label
                                        htmlFor="contact-phone"
                                        className="block text-xs font-bold text-slate-500"
                                    >
                                        מספר טלפון:
                                    </label>
                                    <div className="relative">
                                        <span
                                            className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400"
                                            aria-hidden="true"
                                        >
                                            <Phone className="w-4 h-4" />
                                        </span>
                                        <input
                                            id="contact-phone"
                                            type="tel"
                                            required
                                            placeholder="050-0000000"
                                            value={phone}
                                            onChange={(e) => setPhone(e.target.value)}
                                            className="w-full pr-10 pl-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-semibold text-slate-700 text-right text-sm"
                                        />
                                    </div>
                                </div>

                                <div className="space-y-1.5">
                                    <label
                                        htmlFor="contact-email"
                                        className="block text-xs font-bold text-slate-500"
                                    >
                                        כתובת מייל:
                                    </label>
                                    <div className="relative">
                                        <span
                                            className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400"
                                            aria-hidden="true"
                                        >
                                            <Mail className="w-4 h-4" />
                                        </span>
                                        <input
                                            id="contact-email"
                                            type="email"
                                            required
                                            placeholder="example@mail.com"
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                            className="w-full pr-10 pl-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-semibold text-slate-700 text-right text-sm"
                                        />
                                    </div>
                                </div>

                                <button
                                    type="submit"
                                    disabled={!phone.trim() || !email.trim() || isSubmitting}
                                    className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl transition-all shadow-md flex items-center justify-center gap-2 mt-2 text-sm disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-slate-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-600 focus-visible:ring-offset-2"
                                    /*
                                     * aria-busy announces to screen readers that a request is in progress.
                                     */
                                    aria-busy={isSubmitting}
                                >
                                    {isSubmitting ? 'שולח...' : 'שלח'}
                                </button>
                            </form>
                        )}
                    </div>
                ) : (
                    /* Success / Submitted view */
                    <div
                        className="text-center py-6 space-y-4 animate-in fade-in duration-300"
                        /*
                         * role="status" + aria-live="polite": announces the success message
                         * to screen readers after the form submission (WCAG 4.1.3 Status Messages).
                         */
                        role="status"
                        aria-live="polite"
                    >
                        <div
                            className="mx-auto w-16 h-16 rounded-full bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600 shadow-inner"
                            aria-hidden="true"
                        >
                            <CheckCircle className="w-8 h-8" />
                        </div>
                        <div className="space-y-2">
                            <h3 className="text-xl font-bold text-slate-800">
                                פנייתך התקבלה בהצלחה!
                            </h3>
                            <p className="text-sm text-slate-500 font-semibold leading-relaxed">
                                תודה על פנייתך. נציג מקצועי יחזור אליך בהקדם לפרטי הקשר שהשארת.
                            </p>
                        </div>
                        <button
                            onClick={handleClose}
                            className="mt-4 px-6 py-2.5 bg-slate-950 hover:bg-slate-800 text-white font-bold rounded-xl transition-all text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-600 focus-visible:ring-offset-2"
                        >
                            סגור
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};
