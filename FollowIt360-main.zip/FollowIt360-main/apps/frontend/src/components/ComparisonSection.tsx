import { Check, X } from 'lucide-react';
import React from 'react';

const ComparisonSection: React.FC = () => {
    return (
        <section className="py-24 bg-[#F0F4FF] relative overflow-hidden">
            <div className="absolute inset-0 pointer-events-none">
                <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-600/5 rounded-full blur-[100px] -mr-64 -mt-64" />
                <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-emerald-500/5 rounded-full blur-[80px] -ml-40 -mb-40" />
            </div>

            <div className="max-w-7xl mx-auto px-6 relative z-10">
                <h2
                    className="text-3xl md:text-4xl font-bold text-center mb-16"
                    style={{ color: '#0A1128' }}
                >
                    תפסיק לנהל את העסק באקסלים
                </h2>

                <div className="grid md:grid-cols-2 gap-8 relative items-stretch max-w-5xl mx-auto">
                    {/* Right Card: Old Way */}
                    <div className="bg-white rounded-3xl border-2 border-red-200 shadow-2xl shadow-red-500/10 relative overflow-hidden flex flex-col">
                        <div className="absolute top-0 right-0 w-48 h-48 bg-red-500/5 rounded-bl-full -mr-20 -mt-20 pointer-events-none" />
                        <div className="px-10 pt-10 pb-6 text-center">
                            <h3 className="text-2xl font-bold text-red-600 tracking-tight">
                                איך סוכנים עובדים כיום
                            </h3>
                            <div className="mt-2 h-1 w-16 bg-red-500 rounded-full mx-auto" />
                        </div>
                        <div className="flex flex-row gap-6 px-8 pb-10 flex-1 items-center">
                            {/* Items */}
                            <div className="flex flex-col gap-5 flex-1">
                                {[
                                    'אין מעקב אחר התפתחות הפרמיה.',
                                    'אקסלים מפוזרים ולא מעודכנים.',
                                    'בזבוז זמן יקר על עבודה ידנית.',
                                    'אין תמונת מצב אמיתית.',
                                ].map((text) => (
                                    <div key={text} className="flex items-start gap-3">
                                        <div className="mt-0.5 shrink-0 w-6 h-6 rounded-full bg-red-100 border-2 border-red-400 flex items-center justify-center">
                                            <X className="w-3.5 h-3.5 text-red-600 stroke-[3]" />
                                        </div>
                                        <span className="text-slate-700 font-semibold text-sm leading-snug">
                                            {text}
                                        </span>
                                    </div>
                                ))}
                            </div>
                            {/* Excel image column */}
                            <div className="shrink-0 w-44 h-44 relative mt-4 select-none scale-[0.8] origin-center">
                                {/* Sheet 1 (Back-Left): Donut/Pie Chart */}
                                <div className="absolute left-[-24px] top-[-16px] w-[145px] h-[145px] bg-white border border-slate-200 rounded-lg shadow-md rotate-[-12deg] p-2 flex flex-col gap-1.5 opacity-90 text-[7px] text-slate-700 font-sans z-0">
                                    <div className="bg-[#107C41]/10 text-[#107C41] font-bold px-1 py-0.5 rounded-sm text-center font-sans text-[8px]">
                                        חלוקת תיק לקוחות
                                    </div>
                                    {/* Donut Chart and Legend */}
                                    <div className="flex-1 flex items-center justify-between gap-1 mt-1">
                                        {/* Donut SVG */}
                                        <div className="relative w-16 h-16 flex items-center justify-center shrink-0">
                                            <svg
                                                className="w-full h-full transform -rotate-90"
                                                viewBox="0 0 36 36"
                                            >
                                                {/* Background circle */}
                                                <circle
                                                    cx="18"
                                                    cy="18"
                                                    r="15.915"
                                                    fill="none"
                                                    stroke="#f1f5f9"
                                                    strokeWidth="4"
                                                />
                                                {/* Category 1: Life Insurance (60%) */}
                                                <circle
                                                    cx="18"
                                                    cy="18"
                                                    r="15.915"
                                                    fill="none"
                                                    stroke="#107C41"
                                                    strokeWidth="4"
                                                    strokeDasharray="60 100"
                                                    strokeDashoffset="0"
                                                />
                                                {/* Category 2: Car Insurance (25%) */}
                                                <circle
                                                    cx="18"
                                                    cy="18"
                                                    r="15.915"
                                                    fill="none"
                                                    stroke="#22c55e"
                                                    strokeWidth="4"
                                                    strokeDasharray="25 100"
                                                    strokeDashoffset="-60"
                                                />
                                                {/* Category 3: Health Insurance (15%) */}
                                                <circle
                                                    cx="18"
                                                    cy="18"
                                                    r="15.915"
                                                    fill="none"
                                                    stroke="#bbf7d0"
                                                    strokeWidth="4"
                                                    strokeDasharray="15 100"
                                                    strokeDashoffset="-85"
                                                />
                                            </svg>
                                            <div className="absolute font-sans font-bold text-[7px] text-slate-800">
                                                100%
                                            </div>
                                        </div>
                                        {/* Legend */}
                                        <div className="flex-1 flex flex-col gap-1 text-[6px]">
                                            <div className="flex items-center gap-0.5">
                                                <div className="w-1.5 h-1.5 bg-[#107C41] rounded-sm" />
                                                <span className="font-semibold text-slate-600">
                                                    חיים (60%)
                                                </span>
                                            </div>
                                            <div className="flex items-center gap-0.5">
                                                <div className="w-1.5 h-1.5 bg-[#22c55e] rounded-sm" />
                                                <span className="font-semibold text-slate-600">
                                                    רכב (25%)
                                                </span>
                                            </div>
                                            <div className="flex items-center gap-0.5">
                                                <div className="w-1.5 h-1.5 bg-[#bbf7d0] rounded-sm" />
                                                <span className="font-semibold text-slate-600">
                                                    בריאות (15%)
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Sheet 2 (Back-Right): Line Chart and Bar Chart */}
                                <div className="absolute right-[-28px] top-[-20px] w-[145px] h-[145px] bg-white border border-slate-200 rounded-lg shadow-md rotate-[10deg] p-2 flex flex-col gap-1.5 opacity-95 text-[7px] z-0">
                                    <div className="font-bold text-slate-700 text-center font-sans mb-0.5 text-[8px] border-b border-slate-100 pb-0.5">
                                        ניתוח עמלות ומגמות
                                    </div>
                                    {/* Chart Area */}
                                    <div className="flex-1 relative border border-slate-100 rounded-sm bg-slate-50/50 p-1 flex flex-col justify-between">
                                        {/* Mini Dual Chart (Bars + SVG Line) */}
                                        <div className="flex-1 w-full relative flex items-end justify-between px-2 pt-2 border-b border-l border-slate-300">
                                            {/* Bar Chart Columns */}
                                            <div className="flex items-end gap-2 w-full h-full pb-0.5 justify-around">
                                                <div className="flex gap-[1.5px] items-end">
                                                    <div className="w-2 h-12 bg-green-600/80 rounded-t-sm" />
                                                    <div className="w-2 h-7 bg-slate-400/50 rounded-t-sm" />
                                                </div>
                                                <div className="flex gap-[1.5px] items-end">
                                                    <div className="w-2 h-16 bg-green-600/80 rounded-t-sm" />
                                                    <div className="w-2 h-9 bg-slate-400/50 rounded-t-sm" />
                                                </div>
                                                <div className="flex gap-[1.5px] items-end">
                                                    <div className="w-2 h-14 bg-green-600/80 rounded-t-sm" />
                                                    <div className="w-2 h-8 bg-slate-400/50 rounded-t-sm" />
                                                </div>
                                                <div className="flex gap-[1.5px] items-end">
                                                    <div className="w-2 h-20 bg-green-700 rounded-t-sm" />
                                                    <div className="w-2 h-11 bg-slate-500/50 rounded-t-sm" />
                                                </div>
                                            </div>

                                            {/* SVG Line Overlay */}
                                            <svg
                                                className="absolute inset-0 w-full h-full overflow-visible"
                                                viewBox="0 0 100 60"
                                                preserveAspectRatio="none"
                                            >
                                                {/* Grid lines */}
                                                <line
                                                    x1="0"
                                                    y1="15"
                                                    x2="100"
                                                    y2="15"
                                                    stroke="#e2e8f0"
                                                    strokeWidth="0.5"
                                                    strokeDasharray="2 2"
                                                />
                                                <line
                                                    x1="0"
                                                    y1="30"
                                                    x2="100"
                                                    y2="30"
                                                    stroke="#e2e8f0"
                                                    strokeWidth="0.5"
                                                    strokeDasharray="2 2"
                                                />
                                                <line
                                                    x1="0"
                                                    y1="45"
                                                    x2="100"
                                                    y2="45"
                                                    stroke="#e2e8f0"
                                                    strokeWidth="0.5"
                                                    strokeDasharray="2 2"
                                                />
                                                {/* Line chart */}
                                                <path
                                                    d="M 12 40 L 37 20 L 62 28 L 88 12"
                                                    fill="none"
                                                    stroke="#dc2626"
                                                    strokeWidth="1.5"
                                                    strokeLinecap="round"
                                                />
                                                {/* Points */}
                                                <circle cx="12" cy="40" r="2" fill="#dc2626" />
                                                <circle cx="37" cy="20" r="2" fill="#dc2626" />
                                                <circle cx="62" cy="28" r="2" fill="#dc2626" />
                                                <circle cx="88" cy="12" r="2" fill="#dc2626" />
                                            </svg>
                                        </div>
                                        {/* Legend */}
                                        <div className="flex justify-center gap-2 mt-1 text-[5px] font-sans">
                                            <div className="flex items-center gap-0.5">
                                                <div className="w-1.5 h-1.5 bg-green-600 rounded-sm" />
                                                <span>עמלה</span>
                                            </div>
                                            <div className="flex items-center gap-0.5">
                                                <div className="w-1.5 h-1.5 bg-slate-400" />
                                                <span>פרמיה</span>
                                            </div>
                                            <div className="flex items-center gap-0.5">
                                                <div className="w-1.5 h-0.5 bg-red-600" />
                                                <span>מגמה</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Sheet 3 (Frontmost - main spreadsheet window) */}
                                <div className="absolute left-[12px] top-[24px] w-[160px] h-[160px] bg-white border border-slate-300 rounded-lg shadow-xl z-10 flex flex-col overflow-hidden text-[7px]">
                                    {/* Excel top menu bar */}
                                    <div className="bg-[#107C41] text-white px-1.5 py-0.5 flex justify-between items-center font-sans font-medium text-[6px]">
                                        <div className="flex gap-2">
                                            <span>קובץ</span>
                                            <span className="font-bold border-b border-white">
                                                בית
                                            </span>
                                            <span>הוספה</span>
                                            <span>נוסחאות</span>
                                        </div>
                                        <div className="flex gap-0.5">
                                            <div className="w-1 h-1 bg-white/40 rounded-full" />
                                            <div className="w-1 h-1 bg-white/40 rounded-full" />
                                        </div>
                                    </div>

                                    {/* Formula Bar */}
                                    <div className="bg-slate-50 border-b border-slate-200 px-1 py-0.5 flex items-center gap-1 font-mono text-slate-600 text-[6px]">
                                        <span className="text-[#107C41] font-bold font-sans">
                                            fx
                                        </span>
                                        <div className="h-3.5 bg-white border border-slate-200 rounded px-1 flex-1 flex items-center text-[6px]">
                                            =SUM(C2:C4)
                                        </div>
                                    </div>

                                    {/* Excel columns & rows grid */}
                                    <div className="flex-1 flex flex-col font-mono text-slate-700 bg-white">
                                        {/* Column Headers */}
                                        <div className="grid grid-cols-4 bg-slate-100 border-b border-slate-200 text-center font-sans text-slate-500">
                                            <div className="border-r border-slate-200 py-0.5 bg-slate-200/50"></div>
                                            <div className="border-r border-slate-200 py-0.5">
                                                A
                                            </div>
                                            <div className="border-r border-slate-200 py-0.5">
                                                B
                                            </div>
                                            <div className="py-0.5">C</div>
                                        </div>

                                        {/* Row 1 */}
                                        <div className="grid grid-cols-4 border-b border-slate-150">
                                            <div className="bg-slate-100 text-slate-500 text-center font-sans border-r border-slate-200 py-0.5">
                                                1
                                            </div>
                                            <div className="border-r border-slate-150 p-0.5 font-sans font-bold">
                                                חודש
                                            </div>
                                            <div className="border-r border-slate-150 p-0.5 font-sans font-bold">
                                                פרמיה
                                            </div>
                                            <div className="p-0.5 font-sans font-bold">
                                                עמלה
                                            </div>
                                        </div>

                                        {/* Row 2 */}
                                        <div className="grid grid-cols-4 border-b border-slate-150">
                                            <div className="bg-slate-100 text-slate-500 text-center font-sans border-r border-slate-200 py-0.5">
                                                2
                                            </div>
                                            <div className="border-r border-slate-150 p-0.5 font-sans">
                                                ינואר
                                            </div>
                                            <div className="border-r border-slate-150 p-0.5">
                                                ₪250,000
                                            </div>
                                            <div className="p-0.5 text-green-600 font-semibold">
                                                ₪12,500
                                            </div>
                                        </div>

                                        {/* Row 3 */}
                                        <div className="grid grid-cols-4 border-b border-slate-150">
                                            <div className="bg-slate-100 text-slate-500 text-center font-sans border-r border-slate-200 py-0.5">
                                                3
                                            </div>
                                            <div className="border-r border-slate-150 p-0.5 font-sans">
                                                פברואר
                                            </div>
                                            <div className="border-r border-slate-150 p-0.5">
                                                ₪310,000
                                            </div>
                                            <div className="p-0.5 text-green-600 font-semibold">
                                                ₪15,500
                                            </div>
                                        </div>

                                        {/* Row 4 */}
                                        <div className="grid grid-cols-4 border-b border-slate-150">
                                            <div className="bg-slate-100 text-slate-500 text-center font-sans border-r border-slate-200 py-0.5">
                                                4
                                            </div>
                                            <div className="border-r border-slate-150 p-0.5 font-sans">
                                                מרץ
                                            </div>
                                            <div className="border-r border-slate-150 p-0.5">
                                                ₪280,000
                                            </div>
                                            <div className="p-0.5 text-green-600 font-semibold">
                                                ₪14,000
                                            </div>
                                        </div>

                                        {/* Row 5 (Total) */}
                                        <div className="grid grid-cols-4 bg-green-50/50 font-bold border-b border-slate-200">
                                            <div className="bg-slate-100 text-slate-500 text-center font-sans border-r border-slate-200 py-0.5">
                                                5
                                            </div>
                                            <div className="border-r border-slate-150 p-0.5 font-sans text-green-800">
                                                סה"כ
                                            </div>
                                            <div className="border-r border-slate-150 p-0.5 text-slate-800">
                                                ₪840,000
                                            </div>
                                            <div className="p-0.5 text-[#107C41] border-b-2 border-double border-[#107C41]">
                                                ₪42,000
                                            </div>
                                        </div>
                                    </div>

                                    {/* Bottom Tabs Bar */}
                                    <div className="bg-slate-100 border-t border-slate-200 px-1 py-0.5 flex gap-1 items-center font-sans text-[6px] text-slate-500 select-none">
                                        <div className="bg-white border-x border-t border-slate-200 rounded-t px-1 py-0.5 text-[#107C41] font-bold flex items-center gap-0.5">
                                            <div className="w-1 h-1 bg-[#107C41] rounded-full" />
                                            <span>גיליון1</span>
                                        </div>
                                        <span>גיליון2</span>
                                        <span>+</span>
                                    </div>
                                </div>

                                {/* Excel Modern Logo (Floating bottom-left) */}
                                <div className="absolute left-[-26px] bottom-[-14px] w-14 h-14 z-20 drop-shadow-lg select-none">
                                    {/* Right panel (grid background) */}
                                    <div className="absolute right-0 top-1 w-10 h-12 bg-[#107C41] rounded-r-md flex flex-col p-1 gap-[2px] border-y border-r border-[#0d6434]">
                                        <div className="flex gap-[2px] flex-1">
                                            <div className="flex-1 bg-[#1F9A55] rounded-sm opacity-90" />
                                            <div className="flex-1 bg-[#1F9A55] rounded-sm opacity-90" />
                                        </div>
                                        <div className="flex gap-[2px] flex-1">
                                            <div className="flex-1 bg-[#107C41] rounded-sm opacity-90" />
                                            <div className="flex-1 bg-[#107C41] rounded-sm opacity-90" />
                                        </div>
                                        <div className="flex gap-[2px] flex-1">
                                            <div className="flex-1 bg-[#0B5930] rounded-sm opacity-90" />
                                            <div className="flex-1 bg-[#0B5930] rounded-sm opacity-90" />
                                        </div>
                                    </div>
                                    {/* Left overlapping panel (X shield) */}
                                    <div className="absolute left-0 top-0 w-9 h-14 bg-[#107C41] rounded-md shadow-md flex items-center justify-center border border-[#0d6434] z-20">
                                        <svg
                                            className="w-5 h-5 text-white stroke-[2.5]"
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                        >
                                            <line x1="18" y1="6" x2="6" y2="18"></line>
                                            <line x1="6" y1="6" x2="18" y2="18"></line>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* VS Badge */}
                    <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-20 hidden md:flex items-center justify-center w-16 h-16 bg-[#0A1128] text-white rounded-full font-black text-xl border-4 border-[#F0F4FF] shadow-xl shadow-black/30">
                        VS
                    </div>

                    {/* Left Card: Followit360 */}
                    <div className="bg-[#F3FBF5] rounded-3xl border-2 border-emerald-200 shadow-2xl shadow-emerald-900/5 relative overflow-hidden flex flex-col">
                        <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-400/10 rounded-bl-full -mr-20 -mt-20 pointer-events-none" />
                        <div className="px-10 pt-10 pb-6 text-center">
                            <h3 className="text-2xl font-bold text-slate-900 tracking-tight">
                                עם Followit360
                            </h3>
                            <div className="mt-2 h-1 w-16 bg-emerald-500 rounded-full mx-auto" />
                        </div>
                        <div className="flex flex-row gap-6 px-8 pb-10 flex-1 items-center">
                            {/* Items */}
                            <div className="flex flex-col gap-5 flex-1">
                                {[
                                    'חישוב עמלות אוטומטי ומדויק',
                                    'מעקב פרמיה בזמן אמת',
                                    'כל הלקוחות במקום אחד',
                                    'יותר שליטה, יותר רווחים.',
                                ].map((text) => (
                                    <div key={text} className="flex items-start gap-3">
                                        <div className="mt-0.5 shrink-0 w-6 h-6 rounded-full bg-emerald-100 border-2 border-emerald-500/40 flex items-center justify-center">
                                            <Check className="w-3.5 h-3.5 text-emerald-700 stroke-[3]" />
                                        </div>
                                        <span className="text-slate-700 font-semibold text-sm leading-snug">
                                            {text}
                                        </span>
                                    </div>
                                ))}
                            </div>
                            {/* Split-screen Followit mockup */}
                            <div className="shrink-0 w-44 flex flex-col gap-2 mt-1 scale-95 origin-center select-none">
                                {/* Top: Dashboard KPIs */}
                                <div className="bg-white border border-slate-200/80 rounded-xl p-2 flex flex-col gap-1.5 shadow-sm">
                                    <div className="flex justify-between items-center border-b border-slate-100 pb-1">
                                        <span className="font-bold text-[8px] text-slate-800 font-sans">
                                            דאשבורד
                                        </span>
                                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                                    </div>
                                    <div className="flex gap-1.5 items-center justify-between">
                                        {/* KPI Grid */}
                                        <div className="grid grid-cols-2 gap-1 flex-1 font-sans">
                                            <div className="bg-gradient-to-br from-cyan-700 to-cyan-600 rounded-md p-1 text-white flex flex-col justify-between h-[32px]">
                                                <span className="text-[4.5px] text-cyan-100 font-bold leading-tight">
                                                    סה"כ לקוחות
                                                </span>
                                                <span className="text-[8px] font-extrabold leading-none">
                                                    142
                                                </span>
                                            </div>
                                            <div className="bg-gradient-to-br from-blue-600 to-blue-500 rounded-md p-1 text-white flex flex-col justify-between h-[32px]">
                                                <span className="text-[4.5px] text-blue-100 font-bold leading-tight">
                                                    עמלות נפרעים
                                                </span>
                                                <span className="text-[8px] font-extrabold leading-none">
                                                    ₪36.4K
                                                </span>
                                            </div>
                                            <div className="bg-gradient-to-br from-sky-600 to-sky-500 rounded-md p-1 text-white flex flex-col justify-between h-[32px]">
                                                <span className="text-[4.5px] text-sky-100 font-bold leading-tight">
                                                    היקף החודש
                                                </span>
                                                <span className="text-[8px] font-extrabold leading-none">
                                                    ₪2,850
                                                </span>
                                            </div>
                                            <div className="bg-gradient-to-br from-indigo-600 to-indigo-500 rounded-md p-1 text-white flex flex-col justify-between h-[32px]">
                                                <span className="text-[4.5px] text-indigo-100 font-bold leading-tight">
                                                    שינוי במכירות
                                                </span>
                                                <span className="text-[8px] font-extrabold leading-none">
                                                    +12%
                                                </span>
                                            </div>
                                        </div>

                                        {/* Donut/Pie Chart */}
                                        <div className="relative w-[48px] h-[48px] flex items-center justify-center shrink-0">
                                            <svg
                                                className="w-full h-full transform -rotate-90"
                                                viewBox="0 0 36 36"
                                            >
                                                {/* Background circle */}
                                                <circle
                                                    cx="18"
                                                    cy="18"
                                                    r="15.915"
                                                    fill="none"
                                                    stroke="#f1f5f9"
                                                    strokeWidth="4"
                                                />
                                                {/* Category 1: Sky (45%) */}
                                                <circle
                                                    cx="18"
                                                    cy="18"
                                                    r="15.915"
                                                    fill="none"
                                                    stroke="#0ea5e9"
                                                    strokeWidth="4"
                                                    strokeDasharray="45 100"
                                                    strokeDashoffset="0"
                                                />
                                                {/* Category 2: Blue (30%) */}
                                                <circle
                                                    cx="18"
                                                    cy="18"
                                                    r="15.915"
                                                    fill="none"
                                                    stroke="#3b82f6"
                                                    strokeWidth="4"
                                                    strokeDasharray="30 100"
                                                    strokeDashoffset="-45"
                                                />
                                                {/* Category 3: Emerald (25%) */}
                                                <circle
                                                    cx="18"
                                                    cy="18"
                                                    r="15.915"
                                                    fill="none"
                                                    stroke="#10b981"
                                                    strokeWidth="4"
                                                    strokeDasharray="25 100"
                                                    strokeDashoffset="-75"
                                                />
                                            </svg>
                                            <div className="absolute font-sans font-bold text-[5.5px] text-slate-800 text-center leading-none">
                                                <div>₪36K</div>
                                                <div className="text-[3.5px] text-slate-400 font-normal">
                                                    סה״כ
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="h-px bg-emerald-300/30 mx-1" />

                                {/* Bottom: Customers Journal */}
                                <div className="bg-white border border-slate-200/80 rounded-xl p-2 flex flex-col gap-1.5 shadow-sm">
                                    <div className="flex justify-between items-center border-b border-slate-100 pb-1">
                                        <span className="font-bold text-[8px] text-slate-800 font-sans">
                                            יומן לקוחות
                                        </span>
                                        <span className="text-[6px] text-slate-400 font-sans">
                                            פעילים
                                        </span>
                                    </div>
                                    <div className="flex flex-col gap-1 text-[5px] text-slate-700 font-sans">
                                        <div className="grid grid-cols-4 bg-slate-50 font-bold border-b border-slate-200 py-0.5 text-slate-500">
                                            <div className="text-right pr-0.5">
                                                שם לקוח / ת״ז
                                            </div>
                                            <div className="text-center">סוג מוצר</div>
                                            <div className="text-center">חברה</div>
                                            <div className="text-left pl-0.5">
                                                נפרעים (סה״כ)
                                            </div>
                                        </div>
                                        {[
                                            ['גל טנא', 'פנסיוני', 'מגדל', '₪350'],
                                            ['ישראל י.', 'בריאות', 'הראל', '₪120'],
                                            ['מיכל לוי', 'חיים', 'הפניקס', '₪280'],
                                            ['אברהם כ.', 'אלמנטרי', 'כלל', '₪95'],
                                        ].map(([name, product, company, fee], index) => (
                                            <div
                                                key={index}
                                                className={`grid grid-cols-4 border-b border-slate-100 py-0.5 ${index % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}`}
                                            >
                                                <div className="font-bold text-slate-800 truncate pr-0.5">
                                                    {name}
                                                </div>
                                                <div className="text-slate-600 text-center truncate">
                                                    {product}
                                                </div>
                                                <div className="text-slate-500 text-center truncate">
                                                    {company}
                                                </div>
                                                <div className="text-green-600 font-bold text-left pl-0.5 truncate">
                                                    {fee}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default ComparisonSection;
