import { ArrowLeft, FileSpreadsheet, Handshake, ShieldCheck, X } from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import { Keys } from '../utils/keys';

interface WelcomeWalkthroughProps {
    onComplete: () => void;
}

export const WelcomeWalkthrough: React.FC<WelcomeWalkthroughProps> = ({ onComplete }) => {
    const [isVisible, setIsVisible] = useState(false);
    const [step, setStep] = useState(0);
    /*
     * nextButtonRef: Focus is moved to the Next/CTA button on each step change so
     * keyboard users do not have to re-navigate the dialog on every step.
     */
    const nextButtonRef = useRef<HTMLButtonElement>(null);
    /*
     * triggerRef: Stores the element that opened (triggered) the modal.
     * Focus is returned here when the walkthrough closes (WCAG 2.4.3).
     */
    const triggerRef = useRef<HTMLElement | null>(null);

    useEffect(() => {
        const hasSeen = localStorage.getItem('f360_hasSeenWalkthrough');
        if (hasSeen !== 'true') {
            triggerRef.current = document.activeElement as HTMLElement;
            setIsVisible(true);
        }
    }, []);

    // Shift focus to the action button whenever the step changes
    useEffect(() => {
        if (isVisible) {
            nextButtonRef.current?.focus();
        }
    }, [step, isVisible]);

    useEffect(() => {
        if (!isVisible) return;

        /*
         * Escape key closes/skips the walkthrough (standard dialog keyboard interaction).
         */
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === Keys.Escape) {
                handleClose();
            }
        };

        document.addEventListener('keydown', handleKeyDown);
        return () => document.removeEventListener('keydown', handleKeyDown);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isVisible]);

    const handleClose = () => {
        localStorage.setItem('f360_hasSeenWalkthrough', 'true');
        setIsVisible(false);
        // Return focus to the element that was focused before the modal opened
        triggerRef.current?.focus();
    };

    const handleNext = () => {
        if (step === 2) {
            handleClose();
            onComplete();
        } else {
            setStep((s) => s + 1);
        }
    };

    if (!isVisible) return null;

    const steps = [
        {
            title: 'ברוכים הבאים ל-Followit360 👋',
            desc: 'הגיע הזמן להיפרד מהאקסלים ולעבור לניהול חכם. המערכת תעזור לך לעקוב אחרי העמלות, הנפרעים והלקוחות שלך באופן אוטומטי ובזמן אמת.',
            icon: (
                // aria-hidden: the icon is decorative; the heading text is the accessible label
                <div
                    className="w-20 h-20 bg-blue-50 rounded-2xl flex items-center justify-center mb-6 shadow-inner"
                    aria-hidden="true"
                >
                    <ShieldCheck className="w-10 h-10 text-blue-600" />
                </div>
            ),
            btnText: 'הבא',
        },
        {
            title: 'הכל מתחיל בלקוחות',
            desc: 'ביומן הלקוחות תוכל להזין פוליסות ידנית או פשוט להעלות את קובץ האקסל שלך, והמערכת תשאב את כל הנתונים בשניות.',
            icon: (
                <div
                    className="w-20 h-20 bg-emerald-50 rounded-2xl flex items-center justify-center mb-6 shadow-inner"
                    aria-hidden="true"
                >
                    <FileSpreadsheet className="w-10 h-10 text-emerald-600" />
                </div>
            ),
            btnText: 'הבא',
        },
        {
            title: 'הסכמים ורווחים',
            desc: 'אחרי שתגדיר פעם אחת את הסכמי העמלות שלך בהגדרות, הדאשבורד יתעורר לחיים ויציג לך בדיוק כמה אתה מרוויח ואיפה אפשר להשתפר.',
            icon: (
                <div
                    className="w-20 h-20 bg-sky-50 rounded-2xl flex items-center justify-center mb-6 shadow-inner"
                    aria-hidden="true"
                >
                    <Handshake className="w-10 h-10 text-sky-600" />
                </div>
            ),
            btnText: 'קדימה, בוא נתחיל!',
        },
    ];

    return (
        /*
         * role="dialog" + aria-modal="true": tells screen readers this is a modal dialog
         * and that content behind it should be ignored (virtual cursor trap).
         * aria-labelledby links to the step heading for the dialog's accessible name.
         * dir="rtl" is set here so the dialog itself is consistently RTL.
         */
        <div
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm"
            dir="rtl"
            role="dialog"
            aria-modal="true"
            aria-labelledby="walkthrough-title"
        >
            {/* Modal Box */}
            <div className="bg-white rounded-[2rem] max-w-lg w-full shadow-2xl overflow-hidden relative animate-slideDown">
                {/*
                 * Skip button — aria-label="דלג על ההדרכה" is explicit about the action.
                 */}
                <button
                    onClick={handleClose}
                    className="absolute top-6 left-6 p-2 text-slate-400 hover:bg-slate-100 rounded-full transition-colors z-10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-400"
                    aria-label="דלג על ההדרכה"
                >
                    <X className="w-5 h-5" aria-hidden="true" />
                </button>

                <div className="p-10 flex flex-col items-center text-center relative z-0">
                    {/* Decorative glow — hidden from AT */}
                    <div
                        className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-64 bg-blue-400/10 rounded-full blur-3xl -z-10"
                        aria-hidden="true"
                    />

                    {steps[step].icon}

                    {/*
                     * id="walkthrough-title" is used as the dialog's aria-labelledby target.
                     * Screen readers announce this heading when the dialog opens/updates.
                     */}
                    <h2
                        id="walkthrough-title"
                        className="text-3xl font-bold text-slate-800 mb-4 tracking-tight"
                    >
                        {steps[step].title}
                    </h2>
                    <p className="text-lg text-slate-500 font-medium leading-relaxed mb-10">
                        {steps[step].desc}
                    </p>

                    {/*
                     * Progress indicators — role="status" + aria-label announce the current step
                     * to screen readers without using visual-only dots as the sole cue.
                     */}
                    <div
                        className="flex gap-2.5 mb-8"
                        role="status"
                        aria-label={`שלב ${step + 1} מתוך ${steps.length}`}
                    >
                        {steps.map((_, idx) => (
                            <div
                                key={idx}
                                aria-hidden="true"
                                className={`h-2 rounded-full transition-all duration-500 ease-out ${idx === step ? 'w-10 bg-blue-600 shadow-sm shadow-blue-500/50' : 'w-2 bg-slate-200'}`}
                            />
                        ))}
                    </div>

                    <button
                        ref={nextButtonRef}
                        onClick={handleNext}
                        className="w-full bg-blue-600 text-white font-bold text-lg py-4 rounded-xl shadow-lg shadow-blue-600/30 hover:bg-blue-500 hover:shadow-blue-500/40 hover:-translate-y-0.5 active:translate-y-0 transition-all flex items-center justify-center gap-2 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                    >
                        {steps[step].btnText}
                        {step !== 2 && (
                            <ArrowLeft
                                className="w-5 h-5 group-hover:-translate-x-1.5 transition-transform"
                                aria-hidden="true"
                            />
                        )}
                    </button>
                </div>
            </div>
        </div>
    );
};
