const LOGO_MAP: Record<string, string> = {
    'הראל': '/logos/harel.svg',
    'מגדל': '/logos/migdal.svg',
    'מנורה': '/logos/menora.svg',
    'הפניקס': '/logos/phoenix.svg',
    'כלל': '/logos/clal.svg',
    'איילון': '/logos/ayalon.svg',
    'שומרה': '/logos/shomera.svg',
    'שלמה חברה לביטוח': '/logos/shlomo.svg',
    'הכשרה': '/logos/hachshara.svg',
    'פספורטקארד': '/logos/passportcard.svg',
    'אלטשולר שחם': '/logos/altschuler.svg',
    'אינפיניטי': '/logos/infinity.svg',
    'מור': '/logos/more.svg',
    'פסגות': '/logos/psagot.svg',
    'אנליסט': '/logos/analyst.svg',
    'IBI': '/logos/IBI.svg',
    'ילין לפידות': '/logos/yalin-lapidot.svg',
    'מיטב': '/logos/meitav.svg',
};

export const CompanyLogo = ({ company, className = "w-10 h-10" }: { company: string, className?: string }) => {
    const src = LOGO_MAP[company];
    
    if (!src) {
        // Fallback to the first letter if logo is missing
        return (
            <div className={`bg-white border border-slate-100 flex items-center justify-center font-bold text-slate-400 ${className}`}>
                {company.charAt(0)}
            </div>
        );
    }

    return (
        <div className={`bg-white border border-slate-100 flex items-center justify-center p-1 ${className}`}>
            <img src={src} alt={`${company} logo`} className="w-full h-full object-contain" loading="lazy" />
        </div>
    );
};
