import {
    Activity,
    ArrowDownRight,
    ArrowUpRight,
    DollarSign,
    LayoutDashboard,
    LogOut,
    Settings,
    TrendingUp,
    Users,
} from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import { CompanyLogo } from './CompanyLogo';
import Logo from './Logo';

interface InteractiveDashboardMockupProps {
    className?: string;
    simulatedVideo?: boolean;
}

const InteractiveDashboardMockup: React.FC<InteractiveDashboardMockupProps> = ({
    className = '',
    simulatedVideo = false,
}) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const [scale, setScale] = useState(1);
    const [progress, setProgress] = useState(0);
    const [activeCompany, setActiveCompany] = useState<string | null>(null);
    const [cursor, setCursor] = useState({ x: 900, y: 700, opacity: 0, clickScale: 1 });
    const [virtualHoverTarget, setVirtualHoverTarget] = useState<string | null>(null);

    // Easing progress state for entry animations
    useEffect(() => {
        let startTimestamp: number | null = null;
        const duration = 1500; // 1.5 seconds animation

        const step = (timestamp: number) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const elapsed = timestamp - startTimestamp;
            const progressVal = Math.min(elapsed / duration, 1);

            // Cubic decel easing for smooth motion
            const easedProgress = 1 - Math.pow(1 - progressVal, 3);
            setProgress(easedProgress);

            if (elapsed < duration) {
                window.requestAnimationFrame(step);
            }
        };

        window.requestAnimationFrame(step);
    }, []);

    // Resize observer to handle scaling dynamically based on layout offsetWidth
    useEffect(() => {
        const handleResize = () => {
            if (containerRef.current) {
                const width = containerRef.current.offsetWidth;
                if (width > 0) {
                    setScale(width / 1100);
                }
            }
        };

        handleResize();
        window.addEventListener('resize', handleResize);

        // Setup ResizeObserver for immediate feedback on parent container changes
        const observer = new ResizeObserver(handleResize);
        if (containerRef.current) {
            observer.observe(containerRef.current);
        }

        return () => {
            window.removeEventListener('resize', handleResize);
            observer.disconnect();
        };
    }, []);

    // Simulated Video Timeline
    useEffect(() => {
        if (!simulatedVideo) return;

        let timeoutIds: NodeJS.Timeout[] = [];

        const runSequence = () => {
            setCursor({ x: 900, y: 700, opacity: 0, clickScale: 1 });
            setVirtualHoverTarget(null);
            setActiveCompany(null);

            timeoutIds.push(
                setTimeout(() => {
                    setCursor({ x: 600, y: 250, opacity: 1, clickScale: 1 });
                }, 2000),
            );

            timeoutIds.push(
                setTimeout(() => {
                    setVirtualHoverTarget('kpi2');
                }, 2700),
            );

            timeoutIds.push(
                setTimeout(() => {
                    setVirtualHoverTarget(null);
                    setCursor({ x: 350, y: 440, opacity: 1, clickScale: 1 });
                }, 4500),
            );

            timeoutIds.push(
                setTimeout(() => {
                    setCursor((prev) => ({ ...prev, clickScale: 0.8 }));
                }, 5200),
            );
            timeoutIds.push(
                setTimeout(() => {
                    setCursor((prev) => ({ ...prev, clickScale: 1 }));
                    setActiveCompany('harel');
                    setVirtualHoverTarget('harel');
                }, 5350),
            );

            timeoutIds.push(
                setTimeout(() => {
                    setCursor({ x: 350, y: 500, opacity: 1, clickScale: 1 });
                    setActiveCompany(null);
                    setVirtualHoverTarget(null);
                }, 7500),
            );

            timeoutIds.push(
                setTimeout(() => {
                    setCursor((prev) => ({ ...prev, clickScale: 0.8 }));
                }, 8200),
            );
            timeoutIds.push(
                setTimeout(() => {
                    setCursor((prev) => ({ ...prev, clickScale: 1 }));
                    setActiveCompany('mor');
                    setVirtualHoverTarget('mor');
                }, 8350),
            );

            timeoutIds.push(
                setTimeout(() => {
                    setCursor({ x: 950, y: 160, opacity: 1, clickScale: 1 });
                    setActiveCompany(null);
                    setVirtualHoverTarget(null);
                }, 10500),
            );

            timeoutIds.push(
                setTimeout(() => {
                    setVirtualHoverTarget('sidebar-dash');
                }, 11200),
            );

            timeoutIds.push(
                setTimeout(() => {
                    setCursor((prev) => ({ ...prev, opacity: 0 }));
                }, 12500),
            );

            timeoutIds.push(
                setTimeout(() => {
                    runSequence();
                }, 13500),
            );
        };

        runSequence();

        return () => timeoutIds.forEach(clearTimeout);
    }, [simulatedVideo]);

    // Target values to animate
    const targets = {
        customers: 127,
        scope: 36587,
        ongoing: 16486,
        change: 12,
        assetsPension: 24850000,
        assetsPensionGemel: 12350000,
        assetsIndividual: 350000,
        harelValue: 60041.67,
        morValue: 1004.17,
        clalValue: 0.0,
    };

    // Interpolated values based on progress
    const currentCustomers = Math.round(targets.customers * progress);
    const currentScope = Math.round(targets.scope * progress);
    const currentScopeDiff = Math.round((targets.scope - 18000) * progress);
    const currentOngoing = targets.ongoing * progress;
    const currentChange = Math.round(targets.change * progress);

    const currentAssetsPension = Math.round(targets.assetsPension * progress);
    const currentAssetsPensionGemel = Math.round(targets.assetsPensionGemel * progress);
    const currentAssetsIndividual = Math.round(targets.assetsIndividual * progress);

    const currentHarel = targets.harelValue * progress;
    const currentMor = targets.morValue * progress;
    const currentClal = targets.clalValue * progress;

    // Donut chart calculations
    const donutR = 42;
    const donutC = 2 * Math.PI * donutR; // ~263.89

    // Percentages of total ongoing (61045.83)
    const harelPercent = targets.harelValue / targets.ongoing; // ~0.9835
    const morPercent = targets.morValue / targets.ongoing; // ~0.0165

    // Stroke dash offsets
    const harelStrokeDash = donutC * harelPercent;
    const morStrokeDash = donutC * morPercent;

    return (
        <div
            ref={containerRef}
            className={`w-full relative overflow-hidden bg-[#F8FAFC] select-none ${className}`}
            style={{ height: `${620 * scale}px` }}
        >
            {/* Scaled Desktop Dashboard Mockup */}
            <div
                className="absolute top-0 right-0 origin-top-right flex flex-row text-right bg-[#F8FAFC] overflow-hidden"
                style={{
                    width: '1100px',
                    height: '620px',
                    transform: `scale(${scale})`,
                }}
                dir="rtl"
            >
                {/* 1. Sidebar (Right Side in RTL) */}
                <aside className="w-[230px] shrink-0 bg-[#0A1128] text-white flex flex-col justify-between p-6 border-l border-white/5 relative z-10">
                    <div>
                        {/* Brand Logo */}
                        <Logo variant="light" className="scale-75 mx-auto mb-6 mt-2" />

                        <div className="h-px bg-white/5 my-6" />

                        {/* Navigation Items */}
                        <nav className="space-y-2">
                            <div
                                className={`flex items-center gap-4 px-4 py-3 rounded-xl text-sm font-medium transition-all shadow-inner border border-white/5 ${virtualHoverTarget === 'sidebar-dash' ? 'bg-[#1a2952] text-[#0cf0ff] ring-1 ring-[#06b9d2]' : 'bg-[#141f3d] text-[#06b9d2]'}`}
                            >
                                <LayoutDashboard className="w-5 h-5" />
                                <span>דאשבורד</span>
                            </div>
                            <div className="flex items-center gap-4 px-4 py-3 rounded-xl text-slate-400 hover:text-slate-200 text-sm font-medium transition-all hover:bg-white/5 cursor-pointer">
                                <Users className="w-5 h-5" />
                                <span>יומן לקוחות</span>
                            </div>
                            <div className="flex items-center gap-4 px-4 py-3 rounded-xl text-slate-400 hover:text-slate-200 text-sm font-medium transition-all hover:bg-white/5 cursor-pointer">
                                <Settings className="w-5 h-5" />
                                <span>הגדרות</span>
                            </div>
                        </nav>
                    </div>

                    {/* Bottom Signout */}
                    <div className="flex items-center gap-4 px-4 py-3 rounded-xl text-slate-400 hover:text-red-400 text-sm font-medium transition-all hover:bg-white/5 cursor-pointer">
                        <LogOut className="w-5 h-5" />
                        <span>התנתקות</span>
                    </div>
                </aside>

                {/* 2. Main Dashboard Area (Left Side in RTL) */}
                <main className="flex-1 p-6 overflow-hidden flex flex-col justify-between bg-[#F8FAFC] min-w-0">
                    {/* Header Row */}
                    <div className="flex justify-between items-center mb-4 shrink-0">
                        <h1 className="text-2xl font-bold text-slate-800 tracking-tight">
                            דאשבורד
                        </h1>

                        {/* User Profile Info */}
                        <div className="flex items-center gap-4">
                            <div className="flex flex-col text-left shrink-0">
                                <span className="text-[10px] font-bold text-slate-400 leading-none mb-1">
                                    פרופיל סוכן
                                </span>
                                <span className="text-sm font-bold text-slate-700 leading-none">
                                    Nir Senior
                                </span>
                            </div>
                            <div className="w-10 h-10 rounded-full bg-slate-900 text-white flex items-center justify-center font-extrabold text-sm shadow-md border border-slate-700">
                                NS
                            </div>
                        </div>
                    </div>

                    {/* ── Section: מבט על ── */}
                    <div className="flex items-center gap-3 mb-3 shrink-0">
                        <span className="flex h-5 w-1 rounded-full bg-gradient-to-b from-cyan-500 to-blue-600 shrink-0" />
                        <h2 className="text-sm font-bold text-slate-700 tracking-wide">מבט על</h2>
                        <div className="flex-1 h-px bg-slate-200/50" />
                    </div>

                    {/* ── KPI Grid (4 cards) ── */}
                    <div className="grid grid-cols-4 gap-4 mb-4 shrink-0">
                        {/* Card 1 – Active Customers (Cyan) */}
                        <div className="bg-gradient-to-br from-cyan-600 to-cyan-500 rounded-2xl p-4 text-white shadow-md shadow-cyan-600/10 flex flex-col justify-between min-h-[145px] transform hover:scale-[1.02] hover:shadow-lg hover:shadow-cyan-600/20 transition-all duration-300">
                            <p className="text-[15px] font-semibold text-cyan-100 uppercase tracking-wider text-center">
                                לקוחות
                            </p>
                            <div className="flex justify-center items-center my-1 text-cyan-200/40">
                                <Users className="w-5 h-5" />
                            </div>
                            <div className="flex items-center justify-around gap-2 mt-1">
                                <div className="flex flex-col text-center">
                                    <span className="text-[10px] text-cyan-200 font-semibold leading-tight">
                                        פעילים
                                    </span>
                                    <span className="text-[17px] font-bold text-white tabular-nums mt-0.5">
                                        {currentCustomers}
                                    </span>
                                </div>
                                <div className="w-[1.5px] h-8 bg-cyan-400/30 shrink-0 self-center"></div>
                                <div className="flex flex-col text-center">
                                    <span className="text-[10px] text-cyan-200 font-semibold leading-tight">
                                        התווספו החודש
                                    </span>
                                    <span className="text-[17px] font-bold text-white tabular-nums mt-0.5">
                                        {Math.round(currentCustomers * 0.08)}
                                    </span>
                                </div>
                            </div>
                        </div>

                        {/* Card 2 – Ongoing (Blue) */}
                        <div
                            className={`bg-gradient-to-br from-blue-600 to-blue-500 rounded-2xl p-4 text-white flex flex-col justify-between min-h-[145px] transform transition-all duration-300 ${virtualHoverTarget === 'kpi2' ? 'scale-[1.05] shadow-xl shadow-blue-600/40 ring-2 ring-white/20' : 'hover:scale-[1.02] hover:shadow-lg hover:shadow-blue-600/20 shadow-md shadow-blue-600/10'}`}
                        >
                            <p className="text-[15px] font-semibold text-blue-100 uppercase tracking-wider text-center">
                                סה״כ עמלות נפרעים
                            </p>
                            <div className="flex justify-center items-center my-1 text-blue-200/40">
                                <TrendingUp className="w-5 h-5" />
                            </div>
                            <div className="flex items-center justify-around gap-2 mt-1">
                                <div className="flex flex-col text-center">
                                    <span className="text-[10px] text-blue-200 font-semibold leading-tight">
                                        סה״כ
                                    </span>
                                    <span className="text-[17px] font-bold text-white tabular-nums mt-0.5">
                                        ₪{Math.round(currentOngoing).toLocaleString()}
                                    </span>
                                </div>
                                <div className="w-[1.5px] h-8 bg-blue-400/30 shrink-0 self-center"></div>
                                <div className="flex flex-col text-center">
                                    <span className="text-[10px] text-blue-200 font-semibold leading-tight">
                                        החודש
                                    </span>
                                    <span className="text-[17px] font-bold text-white tabular-nums mt-0.5">
                                        ₪{Math.round(currentOngoing * 0.45).toLocaleString()}
                                    </span>
                                </div>
                            </div>
                        </div>

                        {/* Card 3 – Scope (Sky) */}
                        <div className="bg-gradient-to-br from-sky-600 to-sky-500 rounded-2xl p-4 text-white shadow-md shadow-sky-600/10 flex flex-col justify-between min-h-[145px] transform hover:scale-[1.02] hover:shadow-lg hover:shadow-sky-600/20 transition-all duration-300">
                            <p className="text-[15px] font-semibold text-sky-100 uppercase tracking-wider text-center">
                                סה״כ עמלות היקף החודש
                            </p>
                            <div className="flex justify-center items-center my-1 text-sky-200/40">
                                <DollarSign className="w-5 h-5" />
                            </div>
                            <div className="text-2xl font-bold text-white tabular-nums mt-1 leading-tight text-center">
                                ₪{currentScope.toLocaleString()}
                            </div>
                            <div className="flex items-center justify-center gap-1 text-[10px] font-bold text-sky-200 mt-1">
                                {currentScopeDiff > 0 ? (
                                    <>
                                        <ArrowUpRight className="w-3 h-3 text-emerald-400 animate-pulse" />
                                        <span className="text-emerald-200" dir="ltr">
                                            +₪{currentScopeDiff.toLocaleString()}
                                        </span>
                                        <span className="text-sky-200">לעומת חודש קודם</span>
                                    </>
                                ) : currentScopeDiff < 0 ? (
                                    <>
                                        <ArrowDownRight className="w-3 h-3 text-rose-400" />
                                        <span className="text-rose-200" dir="ltr">
                                            -₪{Math.abs(currentScopeDiff).toLocaleString()}
                                        </span>
                                        <span className="text-sky-200">לעומת חודש קודם</span>
                                    </>
                                ) : (
                                    <>
                                        <Activity className="w-3 h-3 text-sky-300" />
                                        <span>ללא שינוי לעומת חודש קודם</span>
                                    </>
                                )}
                            </div>
                        </div>

                        {/* Card 4 – Change % (Indigo) */}
                        <div className="bg-gradient-to-br from-indigo-600 to-indigo-500 rounded-2xl p-4 text-white shadow-md shadow-indigo-600/10 flex flex-col justify-between min-h-[145px] transform hover:scale-[1.02] hover:shadow-lg hover:shadow-indigo-600/20 transition-all duration-300">
                            <p className="text-[15px] font-semibold text-indigo-100 uppercase tracking-wider text-center">
                                סה״כ שינוי במכירות %
                            </p>
                            <div className="flex justify-center items-center my-1 text-indigo-200/40">
                                <Activity className="w-5 h-5" />
                            </div>
                            <div
                                className="text-3xl font-bold text-white tabular-nums mt-1 text-center"
                                dir="ltr"
                            >
                                {currentChange >= 0 ? '+' : '-'}
                                {Math.abs(currentChange)}%
                            </div>
                            <div className="flex items-center justify-center gap-1 text-[10px] font-bold text-indigo-200 mt-1">
                                {currentChange >= 0 ? (
                                    <>
                                        <ArrowUpRight className="w-3 h-3 text-emerald-400" />
                                        <span className="text-emerald-200">לעומת חודש קודם</span>
                                    </>
                                ) : (
                                    <>
                                        <ArrowDownRight className="w-3 h-3 text-rose-400" />
                                        <span className="text-rose-200">לעומת חודש קודם</span>
                                    </>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* ── Section: נכסים מנוהלים ── */}
                    <div className="flex items-center gap-3 mb-3 shrink-0">
                        <span className="flex h-5 w-1 rounded-full bg-gradient-to-b from-cyan-500 to-blue-600 shrink-0" />
                        <h2 className="text-sm font-bold text-slate-700 tracking-wide">
                            נכסים מנוהלים על ידך
                        </h2>
                        <div className="flex-1 h-px bg-slate-200/50" />
                    </div>

                    {/* ── Assets Multi-Column Strip ── */}
                    <div className="bg-white rounded-2xl shadow-sm border border-slate-200/70 overflow-hidden mb-4 shrink-0">
                        <div className="grid grid-cols-3 divide-x divide-x-reverse divide-slate-100 text-center">
                            <div className="py-3 px-4">
                                <p className="text-[10px] font-bold text-slate-400 leading-none mb-1 uppercase tracking-wider">
                                    סה"כ פרמיות פרט
                                </p>
                                <p className="text-lg font-black text-slate-800">
                                    ₪{currentAssetsIndividual.toLocaleString()}
                                </p>
                            </div>
                            <div className="py-3 px-4">
                                <p className="text-[10px] font-bold text-slate-400 leading-none mb-1 uppercase tracking-wider">
                                    סה"כ נכסי פנסיה וגמל
                                </p>
                                <p className="text-lg font-black text-slate-800">
                                    ₪{currentAssetsPensionGemel.toLocaleString()}
                                </p>
                            </div>
                            <div className="py-3 px-4">
                                <p className="text-[10px] font-bold text-slate-400 leading-none mb-1 uppercase tracking-wider">
                                    סה"כ נכסי פנסיה
                                </p>
                                <p className="text-lg font-black text-slate-800">
                                    ₪{currentAssetsPension.toLocaleString()}
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* ── Section: פירוט עמלות ── */}
                    <div className="flex items-center gap-3 mb-3 shrink-0">
                        <span className="flex h-5 w-1 rounded-full bg-gradient-to-b from-cyan-500 to-blue-600 shrink-0" />
                        <h2 className="text-sm font-bold text-slate-700 tracking-wide">
                            פירוט עמלות נפרעים מצטבר
                        </h2>
                        <div className="flex-1 h-px bg-slate-200/50" />
                    </div>

                    {/* ── Chart Card ── */}
                    <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200/70 flex-1 flex flex-col justify-center min-h-[170px]">
                        <div className="flex items-center justify-between gap-12 h-full">
                            {/* Company Progress Bars (Left Side) */}
                            <div className="flex-1 space-y-4">
                                {/* Harel */}
                                <div
                                    className={`flex items-center gap-4 p-2 rounded-xl transition-all duration-300 ${activeCompany === 'harel' || virtualHoverTarget === 'harel' ? 'bg-slate-50 ring-1 ring-slate-100 shadow-sm' : ''}`}
                                    onMouseEnter={() =>
                                        !simulatedVideo && setActiveCompany('harel')
                                    }
                                    onMouseLeave={() => !simulatedVideo && setActiveCompany(null)}
                                >
                                    <div className="w-3 h-3 rounded-full bg-[#06b6d4] shrink-0" />
                                    <CompanyLogo
                                        company="הראל"
                                        className="w-8 h-8 rounded-full shrink-0 border-0 p-0 bg-transparent"
                                    />
                                    <span className="text-sm font-bold text-slate-700 w-16 text-right shrink-0">
                                        הראל
                                    </span>

                                    <div className="flex-1 h-3 bg-slate-100 rounded-full overflow-hidden shrink-0">
                                        <div
                                            className="h-full bg-cyan-500 rounded-full transition-all duration-500 shadow-sm"
                                            style={{ width: `${98.35 * progress}%` }}
                                        />
                                    </div>
                                    <span className="text-sm font-bold text-slate-500 w-28 text-left shrink-0 font-mono">
                                        ₪
                                        {currentHarel.toLocaleString(undefined, {
                                            minimumFractionDigits: 2,
                                            maximumFractionDigits: 2,
                                        })}
                                    </span>
                                </div>

                                {/* Mor */}
                                <div
                                    className={`flex items-center gap-4 p-2 rounded-xl transition-all duration-300 ${activeCompany === 'mor' || virtualHoverTarget === 'mor' ? 'bg-slate-50 ring-1 ring-slate-100 shadow-sm' : ''}`}
                                    onMouseEnter={() => !simulatedVideo && setActiveCompany('mor')}
                                    onMouseLeave={() => !simulatedVideo && setActiveCompany(null)}
                                >
                                    <div className="w-3 h-3 rounded-full bg-[#0891b2] shrink-0" />
                                    <CompanyLogo
                                        company="מור"
                                        className="w-8 h-8 rounded-full shrink-0 border-0 p-0 bg-transparent"
                                    />
                                    <span className="text-sm font-bold text-slate-700 w-16 text-right shrink-0">
                                        מור
                                    </span>

                                    <div className="flex-1 h-3 bg-slate-100 rounded-full overflow-hidden shrink-0">
                                        <div
                                            className="h-full bg-sky-600 rounded-full transition-all duration-500 shadow-sm"
                                            style={{ width: `${1.65 * progress}%` }}
                                        />
                                    </div>
                                    <span className="text-sm font-bold text-slate-500 w-28 text-left shrink-0 font-mono">
                                        ₪
                                        {currentMor.toLocaleString(undefined, {
                                            minimumFractionDigits: 2,
                                            maximumFractionDigits: 2,
                                        })}
                                    </span>
                                </div>

                                {/* Clal */}
                                <div className="flex items-center gap-4 p-2 rounded-xl opacity-60">
                                    <div className="w-3 h-3 rounded-full bg-slate-300 shrink-0" />
                                    <CompanyLogo
                                        company="כלל"
                                        className="w-8 h-8 rounded-full shrink-0 border-0 p-0 bg-transparent"
                                    />
                                    <span className="text-sm font-bold text-slate-700 w-16 text-right shrink-0">
                                        כלל
                                    </span>

                                    <div className="flex-1 h-3 bg-slate-100 rounded-full overflow-hidden shrink-0">
                                        <div
                                            className="h-full bg-slate-200 rounded-full"
                                            style={{ width: `0%` }}
                                        />
                                    </div>
                                    <span className="text-sm font-bold text-slate-400 w-28 text-left shrink-0 font-mono">
                                        ₪
                                        {currentClal.toLocaleString(undefined, {
                                            minimumFractionDigits: 2,
                                            maximumFractionDigits: 2,
                                        })}
                                    </span>
                                </div>
                            </div>

                            {/* Donut Chart (Right Side) */}
                            <div className="relative shrink-0 flex items-center justify-center w-40 h-40">
                                <svg
                                    className="w-full h-full transform rotate-[-90deg]"
                                    viewBox="0 0 120 120"
                                >
                                    {/* Track (Background Circle) */}
                                    <circle
                                        cx="60"
                                        cy="60"
                                        r={donutR}
                                        fill="transparent"
                                        stroke="#F1F5F9"
                                        strokeWidth="12"
                                    />

                                    {/* Mor Segment */}
                                    <circle
                                        cx="60"
                                        cy="60"
                                        r={donutR}
                                        fill="transparent"
                                        stroke={activeCompany === 'mor' ? '#0891b2' : '#0284c7'}
                                        strokeWidth={activeCompany === 'mor' ? '16' : '12'}
                                        strokeDasharray={donutC}
                                        strokeDashoffset={donutC - morStrokeDash * progress}
                                        strokeLinecap="round"
                                        transform={`rotate(${360 * harelPercent} 60 60)`}
                                        className="transition-all duration-300"
                                    />

                                    {/* Harel Segment */}
                                    <circle
                                        cx="60"
                                        cy="60"
                                        r={donutR}
                                        fill="transparent"
                                        stroke={activeCompany === 'harel' ? '#22d3ee' : '#06b6d4'}
                                        strokeWidth={activeCompany === 'harel' ? '16' : '12'}
                                        strokeDasharray={donutC}
                                        strokeDashoffset={donutC - harelStrokeDash * progress}
                                        strokeLinecap="round"
                                        className="transition-all duration-300"
                                    />
                                </svg>

                                {/* Center Labels */}
                                <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
                                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none mb-1">
                                        סה"כ נפרעים
                                    </span>
                                    <span className="text-sm font-extrabold text-slate-800 font-mono tracking-tight leading-none">
                                        ₪
                                        {currentOngoing.toLocaleString(undefined, {
                                            minimumFractionDigits: 2,
                                            maximumFractionDigits: 2,
                                        })}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>

                {/* Virtual Cursor for Simulated Video */}
                {simulatedVideo && (
                    <div
                        className="absolute z-50 pointer-events-none drop-shadow-2xl flex items-center justify-center"
                        style={{
                            left: `${cursor.x}px`,
                            top: `${cursor.y}px`,
                            opacity: cursor.opacity,
                            transform: `scale(${cursor.clickScale})`,
                            transitionProperty: 'left, top, opacity, transform',
                            transitionTimingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)',
                            transitionDuration: cursor.clickScale < 1 ? '150ms' : '700ms',
                        }}
                    >
                        <svg
                            width="24"
                            height="36"
                            viewBox="0 0 24 36"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="origin-top-left drop-shadow-md"
                        >
                            <path
                                d="M5.5 3L20 18H13L18 28L15 29.5L10 20L4.5 25V3Z"
                                fill="#000000"
                                stroke="#FFFFFF"
                                strokeWidth="1.5"
                                strokeLinejoin="round"
                            />
                        </svg>
                        {/* Optional click ripple effect */}
                        {cursor.clickScale < 1 && (
                            <div className="absolute top-1 left-2 w-10 h-10 -ml-5 -mt-5 bg-sky-400/40 rounded-full animate-ping" />
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default InteractiveDashboardMockup;
