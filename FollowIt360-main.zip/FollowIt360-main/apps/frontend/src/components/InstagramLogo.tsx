import React from 'react';
import { Instagram } from 'lucide-react';

interface InstagramLogoProps {
    className?: string;
    size?: number;
}

const InstagramLogo: React.FC<InstagramLogoProps> = ({ className = '', size = 48 }) => {
    return (
        <a
            href="https://www.instagram.com/followit360/"
            target="_blank"
            rel="noopener noreferrer"
            className={`flex items-center justify-center rounded-2xl bg-gradient-to-tr from-amber-400 via-pink-500 to-purple-600 text-white shadow-lg shadow-pink-500/20 hover:shadow-xl hover:shadow-pink-500/40 hover:scale-105 transition-all duration-300 group ${className}`}
            style={{ width: size, height: size }}
            title="עקבו אחרינו באינסטגרם"
        >
            <Instagram className="w-3/5 h-3/5" strokeWidth={2} />
        </a>
    );
};

export default InstagramLogo;
