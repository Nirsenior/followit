import { LayoutDashboard, LogOut, Settings, ShieldAlert, Users, X } from 'lucide-react';
import React from 'react';
import { useAuthStore } from '../store/authStore';
import Logo from './Logo';

interface SidebarProps {
    activeScreen: string;
    onNavigate: (screen: any) => void;
    onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeScreen, onNavigate, onLogout }) => {
    const { user } = useAuthStore();

    const menuItems = [
        {
            id: 'dashboard',
            label: 'דשבורד',
            icon: LayoutDashboard,
        },
        {
            id: 'journal',
            label: 'יומן לקוחות',
            icon: Users,
        },
        {
            id: 'profile',
            label: 'הגדרות',
            icon: Settings,
        },
    ];

    if (user?.isAdmin) {
        menuItems.push({
            id: 'admin',
            label: 'ניהול',
            icon: ShieldAlert,
        });
    }

    return (
        /*
         * <aside> is the correct landmark for complementary/navigation content.
         * id="sidebar-nav" lets the mobile header button reference it via aria-controls.
         */
        <aside
            id="sidebar-nav"
            className="w-[240px] h-full text-white flex flex-col py-8 z-50 transition-all border-l border-white/10 relative shadow-xl overflow-hidden"
            style={{ backgroundColor: '#011132' }}
            dir="rtl"
        >
            {/* Brand Logo Section */}
            <div className="mb-10 px-6 relative group flex items-center justify-between">
                {/*
                 * Dedicated close button for mobile.
                 * aria-label="סגור תפריט" tells screen readers exactly what it does.
                 */}
                <button
                    onClick={() => onNavigate(activeScreen)}
                    className="md:hidden p-2 hover:bg-white/10 rounded-xl transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50"
                    aria-label="סגור תפריט"
                >
                    <X className="w-5 h-5 text-white/50" aria-hidden="true" />
                </button>
                {/*
                 * Clicking the logo is a navigation action — use a <button> so it is
                 * reachable and operable via keyboard. aria-label clarifies the destination.
                 */}
                <button
                    onClick={() => onNavigate('dashboard')}
                    className="flex-1 flex justify-center cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50 rounded-lg"
                    aria-label="עבור לדשבורד הראשי"
                >
                    <Logo variant="light" className="scale-75 mx-auto" />
                </button>
                {/* Visual spacer that mirrors the close button width on mobile */}
                <div className="w-9 md:hidden" aria-hidden="true" />
            </div>

            {/*
             * <nav> is the correct landmark for primary navigation.
             * aria-label="ניווט ראשי" distinguishes it if multiple <nav> elements exist on page.
             */}
            <nav className="flex-1 flex flex-col gap-2 w-full px-4" aria-label="ניווט ראשי">
                {menuItems.map((item) => {
                    const isActive = activeScreen === item.id;
                    const Icon = item.icon;

                    return (
                        <button
                            key={item.id}
                            onClick={() => onNavigate(item.id)}
                            /*
                             * aria-current="page" is the semantic signal for screen readers that
                             * this is the currently active destination.
                             */
                            aria-current={isActive ? 'page' : undefined}
                            className={`
                                flex items-center gap-3.5 px-4 py-3.5 rounded-2xl transition-all duration-300 w-full group
                                focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50
                                ${
                                    isActive
                                        ? 'bg-white/10 font-bold'
                                        : 'text-white/50 hover:text-white hover:bg-white/5'
                                }
                            `}
                            style={isActive ? { color: '#06b9d2' } : {}}
                        >
                            {/* aria-hidden on the icon because the adjacent text label conveys the same meaning */}
                            <Icon
                                className={`w-5 h-5 transition-transform duration-300 ${isActive ? 'scale-110' : 'group-hover:scale-110'}`}
                                aria-hidden="true"
                            />
                            <span className="text-sm tracking-wide">{item.label}</span>

                            {/* Active Indicator Bar — decorative, hidden from AT */}
                            {isActive && (
                                <div
                                    className="absolute -left-4 w-1.5 h-8 rounded-r-full shadow-sm"
                                    style={{ backgroundColor: '#06b9d2' }}
                                    aria-hidden="true"
                                />
                            )}
                        </button>
                    );
                })}
            </nav>

            {/* Logout Section */}
            <div className="mt-auto px-4 w-full">
                {/* Decorative separator — hidden from AT */}
                <div className="h-px bg-white/10 w-full mb-6" aria-hidden="true" />
                <button
                    onClick={onLogout}
                    className="flex items-center gap-3.5 px-4 py-3.5 rounded-2xl text-white/40 hover:text-rose-400 hover:bg-rose-500/10 transition-all duration-300 w-full group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-400/50"
                >
                    <LogOut
                        className="w-5 h-5 group-hover:scale-110 transition-transform"
                        aria-hidden="true"
                    />
                    <span className="text-sm font-medium">התנתקות</span>
                </button>
            </div>
        </aside>
    );
};

export default Sidebar;
