import React from 'react';
import OnboardingMockup from './OnboardingMockup';
import CloudUploadMockup from './CloudUploadMockup';
import CustomersJournalMockup from './CustomersJournalMockup';

export const HowItWorksSection: React.FC = () => {
    return (
        <section id="how-it-works" className="py-24 bg-white relative">
            <div className="max-w-7xl mx-auto px-6">
                <h2
                    className="text-3xl md:text-4xl font-bold text-center mb-16 font-sans"
                    style={{ color: '#0A1128' }}
                >
                    איך זה עובד?
                </h2>

                <div className="grid md:grid-cols-3 gap-8 relative">
                    {/* Step 1: Insurance companies selection */}
                    <div className="bg-slate-50 rounded-3xl p-8 border border-slate-100 text-center relative pt-14 shadow-sm hover:shadow-md transition-shadow flex flex-col h-full">
                        <div
                            className="absolute -top-6 left-1/2 -translate-x-1/2 w-12 h-12 rounded-full flex items-center justify-center font-bold text-xl shadow-lg"
                            style={{
                                backgroundColor: '#0A1128',
                                color: 'white',
                                boxShadow: '0 8px 24px rgba(10,17,40,0.35)',
                            }}
                        >
                            1
                        </div>
                        <h3 className="text-xl font-bold mb-4" style={{ color: '#0A1128' }}>
                            מגדירים הסכמים וחברות
                        </h3>
                        <p className="text-slate-500 mb-6 h-12 text-sm leading-relaxed">
                            מזינים את תנאי העמלות מול חברות הביטוח השונות במקום אחד.
                        </p>
                        
                        {/* Custom Onboarding Mockup */}
                        <div className="mt-auto">
                            <OnboardingMockup />
                        </div>
                    </div>

                    {/* Arrow Step 1 to 2 */}
                    <div className="hidden md:flex items-center justify-center absolute right-[33%] top-[58%] -translate-y-1/2 z-10 text-slate-300">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path
                                d="M15 18L9 12L15 6"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                            />
                        </svg>
                    </div>

                    {/* Step 2: Cloud upload Excel */}
                    <div className="bg-slate-50 rounded-3xl p-8 border border-slate-100 text-center relative pt-14 shadow-sm mt-10 md:mt-0 hover:shadow-md transition-shadow flex flex-col h-full">
                        <div
                            className="absolute -top-6 left-1/2 -translate-x-1/2 w-12 h-12 rounded-full flex items-center justify-center font-bold text-xl shadow-lg"
                            style={{
                                backgroundColor: '#0A1128',
                                color: 'white',
                                boxShadow: '0 8px 24px rgba(10,17,40,0.35)',
                            }}
                        >
                            2
                        </div>
                        <h3 className="text-xl font-bold mb-4" style={{ color: '#0A1128' }}>
                            מקימים לקוח ומעלים טבלת התפתחות פרמיה
                        </h3>
                        <p className="text-slate-500 mb-6 h-12 text-sm leading-relaxed">
                            יוצרים כרטיס לקוח חדש ומסנכרנים את דוח התפתחות הפרמיה בקלות.
                        </p>
                        
                        {/* Custom Cloud Upload Mockup */}
                        <div className="mt-auto">
                            <CloudUploadMockup />
                        </div>
                    </div>

                    {/* Arrow Step 2 to 3 */}
                    <div className="hidden md:flex items-center justify-center absolute right-[66%] top-[58%] -translate-y-1/2 z-10 text-slate-300">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path
                                d="M15 18L9 12L15 6"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                            />
                        </svg>
                    </div>

                    {/* Step 3: Client diary */}
                    <div className="bg-slate-50 rounded-3xl p-8 border border-slate-100 text-center relative pt-14 shadow-sm mt-10 md:mt-0 hover:shadow-md transition-shadow flex flex-col h-full">
                        <div
                            className="absolute -top-6 left-1/2 -translate-x-1/2 w-12 h-12 rounded-full flex items-center justify-center font-bold text-xl shadow-lg"
                            style={{
                                backgroundColor: '#0A1128',
                                color: 'white',
                                boxShadow: '0 8px 24px rgba(10,17,40,0.35)',
                            }}
                        >
                            3
                        </div>
                        <h3 className="text-xl font-bold mb-4" style={{ color: '#0A1128' }}>
                            מקבלים תמונה שקופה, ברורה ואמיתית בזמן אמת
                        </h3>
                        <p className="text-slate-500 mb-6 h-12 text-sm leading-relaxed">
                            נהנים מנתונים עדכניים, חישובי עמלות אוטומטיים ושליטה מלאה בתיק.
                        </p>
                        
                        {/* Custom Customers Table Mockup */}
                        <div className="mt-auto">
                            <CustomersJournalMockup />
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default HowItWorksSection;
