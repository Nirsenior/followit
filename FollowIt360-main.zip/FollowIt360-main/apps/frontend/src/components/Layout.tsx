import { Menu } from 'lucide-react';
import React, { useRef, useState } from 'react';
import Sidebar from './Sidebar';

interface LayoutProps {
    children: React.ReactNode;
    activeScreen: string;
    onNavigate: (screen: any) => void;
    onLogout: () => void;
    showSidebar: boolean;
}

const Layout: React.FC<LayoutProps> = ({
    children,
    activeScreen,
    onNavigate,
    onLogout,
    showSidebar,
}) => {
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    // Ref to the mobile menu toggle so we can return focus to it when the sidebar closes
    const mobileMenuTriggerRef = useRef<HTMLButtonElement>(null);

    const handleNavigate = (screen: any) => {
        onNavigate(screen);
        setIsMobileMenuOpen(false);
        // Return focus to the trigger that opened the sidebar (focus management rule)
        mobileMenuTriggerRef.current?.focus();
    };

    const closeMobileMenu = () => {
        setIsMobileMenuOpen(false);
        mobileMenuTriggerRef.current?.focus();
    };

    return (
        <div className="flex h-screen bg-slate-50 overflow-hidden font-sans" dir="rtl">
            <a
                href="#main-content"
                className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:right-4 focus:z-[200] focus:rounded-xl focus:bg-blue-600 focus:px-4 focus:py-2 focus:text-white focus:font-bold focus:shadow-lg"
            >
                עבור לתוכן הראשי
            </a>

            {showSidebar && (
                <>
                    <div
                        aria-hidden="true"
                        className={`fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[60] md:hidden transition-opacity duration-300 ${
                            isMobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
                        }`}
                        onClick={closeMobileMenu}
                    />

                    {/* Sidebar container */}
                    <div
                        className={`fixed inset-y-0 right-0 z-[70] md:relative md:z-50 md:h-full transition-transform duration-300 transform ${
                            isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full md:translate-x-0'
                        }`}
                        /*
                         * aria-modal + role="dialog" turn the mobile sidebar into a proper dialog
                         * so screen readers know navigation is constrained while it is open.
                         */
                        role={isMobileMenuOpen ? 'dialog' : undefined}
                        aria-modal={isMobileMenuOpen ? 'true' : undefined}
                        aria-label="תפריט ניווט"
                    >
                        <Sidebar
                            activeScreen={activeScreen}
                            onNavigate={handleNavigate}
                            onLogout={onLogout}
                        />
                    </div>
                </>
            )}

            <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
                {/* Mobile Header */}
                {showSidebar && (
                    <header className="md:hidden bg-white border-b border-slate-100 p-4 flex justify-between items-center shrink-0 z-[55]">
                        {/*
                         * aria-label describes the icon-only button for screen readers.
                         * aria-expanded communicates sidebar open/closed state.
                         * aria-controls links the button to the sidebar region it controls.
                         */}
                        <button
                            ref={mobileMenuTriggerRef}
                            onClick={() => setIsMobileMenuOpen(true)}
                            className="p-2 hover:bg-slate-50 rounded-xl transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
                            aria-label="פתח תפריט ניווט"
                            aria-expanded={isMobileMenuOpen}
                            aria-controls="sidebar-nav"
                        >
                            <Menu className="w-6 h-6 text-slate-600" aria-hidden="true" />
                        </button>
                        <div className="text-sm font-bold text-slate-900">Followit360</div>
                        <div className="w-10" aria-hidden="true" /> {/* Visual spacer */}
                    </header>
                )}

                {/*
                 * id="main-content" is the skip-link target.
                 * Using <main> (already here as a wrapping element via page components)
                 * but we wrap children in a region landmark so the skip link has a target.
                 */}
                <div id="main-content" className="flex-1 overflow-y-auto relative" tabIndex={-1}>
                    {children}
                </div>
            </div>
        </div>
    );
};

export default Layout;
