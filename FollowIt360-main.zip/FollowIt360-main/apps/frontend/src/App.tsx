import React from 'react';
import { BrowserRouter, Route, Routes, useNavigate } from 'react-router-dom';
import { AccessibilityWidget } from './components/AccessibilityWidget';
import CustomerJournal from './pages/CustomerJournal';
import Dashboard from './pages/Dashboard';
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import ProfileSettings from './pages/ProfileSettings';
import RegistrationPage from './pages/RegistrationPage';
import SignupPage from './pages/SignupPage';

export {
    CustomerJournal,
    Dashboard,
    LandingPage,
    LoginPage,
    ProfileSettings,
    RegistrationPage,
    SignupPage,
};

// Shared
import type { UserProfile } from '@repo/types';
import { AnalyticsTracker } from './components/AnalyticsTracker';
import Layout from './components/Layout';
import { EMPTY_USER_PROFILE } from './constants/profile';
import AdminDashboard from './pages/AdminPanel/AdminDashboard';
import ForbiddenPage from './pages/ForbiddenPage';
import NotFoundPage from './pages/NotFoundPage';
import { useAuthStore } from './store/authStore';

// Route guards
import { ProtectedRoute, PublicRoute } from './routes/guards';

// Constants
import { ROUTES } from './constants/routes';

// Hooks
import { useAuthHandlers } from './hooks/useAuthHandlers';
import { useCustomers } from './hooks/useCustomers';
import { useLogout } from './hooks/useLogout';
import { useOnboardingComplete } from './hooks/useOnboardingComplete';
import { useSessionRestore } from './hooks/useSessionRestore';

// ---------------------------------------------------------------------------
// Fallback profile used until the user object is fully loaded
// ---------------------------------------------------------------------------
const EMPTY_PROFILE: UserProfile = {
    ...EMPTY_USER_PROFILE,
    id: '',
    firstName: '',
    lastName: '',
    email: '',
};

// ---------------------------------------------------------------------------
// Route components fetching state using hooks
// ---------------------------------------------------------------------------
const DashboardRoute: React.FC = () => {
    const navigate = useNavigate();
    const { user } = useAuthStore();
    const { handleLogout } = useLogout();
    const { data: customers = [] } = useCustomers();

    const toPath = (screen: string) => {
        return (
            {
                journal: ROUTES.JOURNAL,
                profile: ROUTES.PROFILE,
                dashboard: ROUTES.DASHBOARD,
                admin: ROUTES.ADMIN,
            }[screen] ?? ROUTES.HOME
        );
    };

    return (
        <Layout
            activeScreen="dashboard"
            onNavigate={(s) => navigate(toPath(s))}
            onLogout={handleLogout}
            showSidebar
        >
            <Dashboard
                profile={user ?? EMPTY_PROFILE}
                customers={customers}
                onNavigate={(s) => navigate(toPath(s))}
                onLogout={handleLogout}
            />
        </Layout>
    );
};

const JournalRoute: React.FC = () => {
    const navigate = useNavigate();
    const { user } = useAuthStore();
    const { handleLogout } = useLogout();

    const toPath = (screen: string) => {
        return (
            {
                journal: ROUTES.JOURNAL,
                profile: ROUTES.PROFILE,
                dashboard: ROUTES.DASHBOARD,
                admin: ROUTES.ADMIN,
            }[screen] ?? ROUTES.HOME
        );
    };

    return (
        <Layout
            activeScreen="journal"
            onNavigate={(s) => navigate(toPath(s))}
            onLogout={handleLogout}
            showSidebar
        >
            <CustomerJournal
                profile={user ?? EMPTY_PROFILE}
                onLogout={handleLogout}
                onNavigate={(s) => navigate(toPath(s))}
            />
        </Layout>
    );
};

const ProfileRoute: React.FC = () => {
    const navigate = useNavigate();
    const { user, setProfile } = useAuthStore();
    const { handleLogout } = useLogout();

    const toPath = (screen: string) => {
        return (
            {
                journal: ROUTES.JOURNAL,
                profile: ROUTES.PROFILE,
                dashboard: ROUTES.DASHBOARD,
                admin: ROUTES.ADMIN,
            }[screen] ?? ROUTES.HOME
        );
    };

    return (
        <Layout
            activeScreen="profile"
            onNavigate={(s) => navigate(toPath(s))}
            onLogout={handleLogout}
            showSidebar
        >
            <ProfileSettings
                profile={(user ?? EMPTY_PROFILE) as UserProfile}
                setProfile={setProfile}
                onNavigate={(s) => navigate(toPath(s))}
            />
        </Layout>
    );
};

const OnboardingRoute: React.FC = () => {
    const navigate = useNavigate();
    const { user } = useAuthStore();
    const { handleLogout } = useLogout();
    const { handleOnboardingComplete } = useOnboardingComplete();

    return (
        <Layout
            activeScreen="onboarding"
            onNavigate={() => {}}
            onLogout={handleLogout}
            showSidebar={false}
        >
            <RegistrationPage
                initialProfile={user ?? EMPTY_PROFILE}
                onComplete={handleOnboardingComplete}
                onBack={() => navigate(ROUTES.SIGNUP)}
                onSkip={() => navigate(ROUTES.DASHBOARD)}
            />
        </Layout>
    );
};

const AdminRoute: React.FC = () => {
    const navigate = useNavigate();
    const { user } = useAuthStore();
    const { handleLogout } = useLogout();

    const toPath = (screen: string) => {
        return (
            {
                journal: ROUTES.JOURNAL,
                profile: ROUTES.PROFILE,
                dashboard: ROUTES.DASHBOARD,
                admin: ROUTES.ADMIN,
            }[screen] ?? ROUTES.HOME
        );
    };

    if (!user?.isAdmin) {
        return <ForbiddenPage />;
    }

    return (
        <Layout
            activeScreen="admin"
            onNavigate={(s) => navigate(toPath(s))}
            onLogout={handleLogout}
            showSidebar
        >
            <AdminDashboard />
        </Layout>
    );
};

// ---------------------------------------------------------------------------
// Top-level route tree
// ---------------------------------------------------------------------------
const AppRoutes: React.FC = () => {
    const navigate = useNavigate();
    const { isInitializing } = useSessionRestore();
    const { handleLogin, handleSignup } = useAuthHandlers();

    if (isInitializing) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-slate-50">
                <div className="flex flex-col items-center gap-4">
                    <div className="w-12 h-12 border-4 border-sky-500/20 border-t-sky-500 rounded-full animate-spin"></div>
                    <div className="text-slate-400 font-medium animate-pulse">
                        טוען את המערכת...
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen selection:bg-sky-100 selection:text-sky-900 font-sans">
            <AccessibilityWidget />
            <Routes>
                {/* Public routes */}
                <Route
                    path={ROUTES.HOME}
                    element={
                        <PublicRoute>
                            <Layout
                                activeScreen="landing"
                                onNavigate={(s) =>
                                    navigate(
                                        s === 'signup'
                                            ? ROUTES.SIGNUP
                                            : s === 'login'
                                              ? ROUTES.LOGIN
                                              : ROUTES.HOME,
                                    )
                                }
                                onLogout={() => {}}
                                showSidebar={false}
                            >
                                <LandingPage
                                    onRegister={() => navigate(ROUTES.SIGNUP)}
                                    onLogin={() => navigate(ROUTES.LOGIN)}
                                />
                            </Layout>
                        </PublicRoute>
                    }
                />

                <Route
                    path={ROUTES.LOGIN}
                    element={
                        <PublicRoute>
                            <LoginPage onLogin={handleLogin} onBack={() => navigate(ROUTES.HOME)} />
                        </PublicRoute>
                    }
                />

                <Route
                    path={ROUTES.SIGNUP}
                    element={
                        <PublicRoute>
                            <SignupPage
                                onSignupSuccess={handleSignup}
                                onLoginClick={() => navigate(ROUTES.LOGIN)}
                            />
                        </PublicRoute>
                    }
                />

                {/* Protected routes */}
                <Route
                    path={ROUTES.DASHBOARD}
                    element={
                        <ProtectedRoute>
                            <DashboardRoute />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path={ROUTES.JOURNAL}
                    element={
                        <ProtectedRoute>
                            <JournalRoute />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path={ROUTES.PROFILE}
                    element={
                        <ProtectedRoute>
                            <ProfileRoute />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path={ROUTES.ONBOARDING}
                    element={
                        <ProtectedRoute>
                            <OnboardingRoute />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path={ROUTES.ADMIN}
                    element={
                        <ProtectedRoute>
                            <AdminRoute />
                        </ProtectedRoute>
                    }
                />
                <Route path="*" element={<NotFoundPage />} />
            </Routes>
        </div>
    );
};

// ---------------------------------------------------------------------------
// App root
// ---------------------------------------------------------------------------
const App: React.FC = () => (
    <BrowserRouter>
        <AnalyticsTracker />
        <AppRoutes />
    </BrowserRouter>
);

export default App;
