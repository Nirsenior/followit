import type { UserProfile } from '@repo/types';

/**
 * Zero-value UserProfile used to seed the auth store before the real data
 * is available (session restore, login, signup).
 */
export const EMPTY_USER_PROFILE: Omit<UserProfile, 'id' | 'firstName' | 'lastName' | 'email'> = {
    phone: '',
    agreements: {},
    paymentMethod: { cardNumber: '', expiry: '', cvv: '' },
    isSetupComplete: false,
};
