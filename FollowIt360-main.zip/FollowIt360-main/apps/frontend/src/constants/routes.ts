export const ROUTES = {
    HOME: '/',
    LOGIN: '/login',
    SIGNUP: '/signup',
    ONBOARDING: '/onboarding',
    DASHBOARD: '/dashboard',
    JOURNAL: '/journal',
    PROFILE: '/profile',
    ADMIN: '/admin',
} as const;

export type AppRoute = (typeof ROUTES)[keyof typeof ROUTES];
