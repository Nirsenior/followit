import { UserProfile } from '@repo/types';
import { create } from 'zustand';

interface AuthState {
    isAuthenticated: boolean;
    user: UserProfile | null;

    // Actions
    login: (user: UserProfile) => void;
    logout: () => void;
    setProfile: (profile: Partial<UserProfile>) => void;
}

export const useAuthStore = create<AuthState>((set) => ({
    isAuthenticated: false,
    user: null,

    login: (user) => set({ isAuthenticated: true, user }),

    logout: () => set({ isAuthenticated: false, user: null }),

    setProfile: (profileChanges) =>
        set((state) => ({
            user: state.user ? { ...state.user, ...profileChanges } : null,
        })),
}));
