import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';
import pkg from '../../package.json';

// https://vite.dev/config/
export default defineConfig({
    plugins: [
        react(),
        {
            name: 'html-version',
            transformIndexHtml(html) {
                return html.replace('%APP_VERSION%', pkg.version);
            },
        },
    ],
    define: {
        'import.meta.env.APP_VERSION': JSON.stringify(pkg.version),
    },
    optimizeDeps: {
        exclude: ['@repo/types'],
    },
    server: {
        proxy: {
            '/api': {
                target: 'http://localhost:8080',
                changeOrigin: true,
            },
        },
    },
});
