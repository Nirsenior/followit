import cookie from '@fastify/cookie';
import cors from '@fastify/cors';
import jwt from '@fastify/jwt';
import fastifyOauth2 from '@fastify/oauth2';
import rateLimit from '@fastify/rate-limit';
import Fastify, { FastifyReply, FastifyRequest } from 'fastify';
import { serializerCompiler, validatorCompiler, ZodTypeProvider } from 'fastify-type-provider-zod';
import { initDb } from './db/connection.js';
import { errorHandler } from './errors/errorHandler.js';

// Routes
import {
    agreementsRoutes,
    authRoutes,
    customersRoutes,
    healthRoutes,
    leadsRoutes,
    userRoutes,
    yieldsRoute,
} from './routes/index.js';
import adminRoutes from './routes/admin/index.js';
import analyticsRoutes from './routes/analytics/index.js';

declare module 'fastify' {
    interface FastifyInstance {
        authenticate: (request: FastifyRequest, reply: FastifyReply) => Promise<void>;
    }
}

const fastify = Fastify({
    logger: true,
    trustProxy: true,
}).withTypeProvider<ZodTypeProvider>();

fastify.setValidatorCompiler(validatorCompiler);
fastify.setSerializerCompiler(serializerCompiler);
fastify.setErrorHandler(errorHandler);

await fastify.register(cors, {
    origin: (origin, cb) => {
        if (process.env.NODE_ENV === 'production') {
            // Allow requests without origin (e.g. server-to-server) or from specific known domains
            if (!origin || origin.includes('followit360') || origin.endsWith('.run.app')) {
                cb(null, true);
            } else {
                cb(new Error('Not allowed by CORS'), false);
            }
        } else {
            cb(null, true); // Allow all origins in development
        }
    },
    credentials: true, // Required for cookies
});

const isDevOrTest = process.env.NODE_ENV === 'development' || process.env.NODE_ENV === 'test';
if (!process.env.JWT_SECRET && !isDevOrTest) {
    throw new Error('FATAL: JWT_SECRET environment variable is missing.');
}

const jwtSecret = process.env.JWT_SECRET || 'supersecret';

await fastify.register(cookie, {
    secret: jwtSecret,
    parseOptions: {},
});

await fastify.register(jwt, {
    secret: jwtSecret,
    cookie: {
        cookieName: '__session',
        signed: false,
    },
});

fastify.decorate('authenticate', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
        await request.jwtVerify();
    } catch (err) {
        reply.status(401).send({ status: 'error', message: 'Unauthorized' });
    }
});

await fastify.register(rateLimit, {
    max: 100,
    timeWindow: '1 minute',
});

// Google OAuth2
const parsedOauthUrl = process.env.BASE_URL ? new URL(process.env.BASE_URL) : null;
fastify.log.info(
    {
        detectedHostname: parsedOauthUrl?.hostname,
        baseUrl: process.env.BASE_URL,
    },
    'Registering Google OAuth plugin',
);

await fastify.register(fastifyOauth2, {
    name: 'googleOAuth2',
    scope: ['openid', 'email', 'profile'],
    credentials: {
        client: {
            id: process.env.GOOGLE_CLIENT_ID!,
            secret: process.env.GOOGLE_CLIENT_SECRET!,
        },
        auth: (fastifyOauth2 as any).GOOGLE_CONFIGURATION,
    },
    startRedirectPath: '/api/auth/google',
    callbackUri: `${process.env.BASE_URL}/api/auth/google/callback`,
    redirectStateCookieName: '__session', // CRITICAL: Bypass Firebase cookie stripping
    cookie: {
        secure: true,
        sameSite: 'none',
        path: '/',
    },
});

// Register Routes
await fastify.register(authRoutes, { prefix: '/api/auth' });
await fastify.register(healthRoutes);
await fastify.register(userRoutes);
await fastify.register(agreementsRoutes, { prefix: '/api/agreements' });
await fastify.register(customersRoutes, { prefix: '/api/customers' });
await fastify.register(leadsRoutes, { prefix: '/api/leads' });
await fastify.register(yieldsRoute, { prefix: '/api/yields' });
await fastify.register(adminRoutes, { prefix: '/api/admin' });
await fastify.register(analyticsRoutes, { prefix: '/api/analytics' });

fastify.get('/', async (request, reply) => {
    return { hello: 'world', db: process.env.DB_NAME };
});

const start = async () => {
    try {
        const port = Number(process.env.PORT) || 8080;

        // Initialize DB synchronously before listening
        await initDb(fastify.log);

        await fastify.listen({ port, host: '0.0.0.0' });
        fastify.log.info(`Server listening on port ${port}`);
    } catch (err) {
        fastify.log.error(err);
        process.exit(1);
    }
};

// Graceful shutdown
const shutdown = async () => {
    await fastify.close();
};
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

start();
