import { type CompanyAgreements, INSURANCE_COMPANIES, INSURANCE_TYPES } from '@repo/types';
import { sql } from 'drizzle-orm';
import {
    boolean,
    date,
    index,
    integer,
    jsonb,
    numeric,
    pgEnum,
    pgTable,
    serial,
    text,
    timestamp,
    unique,
    uuid,
    varchar,
    primaryKey,
} from 'drizzle-orm/pg-core';

// --- Types & Enums --- //
// We explicitly append 'GLOBAL' to the database enum so the Master Agreement can be stored seamlessly
const DB_COMPANIES = [...INSURANCE_COMPANIES, 'GLOBAL'] as const;
export const companyEnum = pgEnum('company_enum', DB_COMPANIES);

export const insuranceTypeEnum = pgEnum('insuranceType_enum', INSURANCE_TYPES);

// --- Tables --- //
export const users = pgTable('users', {
    id: uuid('id').primaryKey().defaultRandom(),
    name: text('name').notNull(),
    email: text('email').notNull().unique(),
    password: text('password'),
    googleId: text('google_id').unique(),
    phone: text('phone'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const agreements = pgTable(
    'agreements',
    {
        id: uuid('id').primaryKey().defaultRandom(),
        userId: uuid('user_id')
            .references(() => users.id, { onDelete: 'cascade' })
            .notNull(),
        company: companyEnum('company').notNull(),
        rates: jsonb('rates').$type<CompanyAgreements>().notNull().default({}),
    },
    (t) => ({
        unq: unique().on(t.userId, t.company),
    }),
);

export const customers = pgTable(
    'customers',
    {
        id: uuid('id').primaryKey().defaultRandom(),
        userId: uuid('user_id')
            .references(() => users.id, { onDelete: 'cascade' })
            .notNull(),
        name: text('name').notNull(),
        issueDate: date('issue_date'),
        governmentId: text('government_id').notNull(),
        familyMembers: jsonb('family_members').default([]),
        creationType: text('creation_type').default('existing'),
        createdAt: timestamp('created_at').defaultNow().notNull(),
    },
    (t) => ({
        userIdx: index('customers_user_id_idx').on(t.userId),
        unq: unique('customers_user_id_gov_idx').on(t.userId, t.governmentId),
    }),
);

export const policies = pgTable(
    'policies',
    {
        id: uuid('id').primaryKey().defaultRandom(),
        customerId: uuid('customer_id')
            .references(() => customers.id, { onDelete: 'cascade' })
            .notNull(),
        company: companyEnum('company').notNull(),
        insuranceType: insuranceTypeEnum('insurance_type').notNull(),
        issueDate: date('issue_date'),
        details: jsonb('details').notNull().default({}),
        fixedCommissionRate: numeric('fixed_commission_rate', { precision: 5, scale: 2 }),
        // --- Accumulation Tracking ---
        systemEntryDate: date('system_entry_date'),
        initialAccumulation: numeric('initial_accumulation', { precision: 14, scale: 2 }),
        lastCalculatedDate: date('last_calculated_date'),
        currentAccumulation: numeric('current_accumulation', { precision: 14, scale: 2 }),
    },
    (t) => ({
        detailsIdx: index('policies_details_gin_idx').using(
            'gin',
            sql`${t.details} jsonb_path_ops`,
        ),
    }),
);

export const healthCheck = pgTable('health_check', {
    id: serial('id').primaryKey(),
    status: text('status').notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

/**
 * policy_tracks — links a policy to one or more government fund IDs.
 * Each row represents a single track allocation for a policy.
 * share_percentage is stored as a decimal (0.4 = 40%).
 */
export const policyTracks = pgTable(
    'policy_tracks',
    {
        id: serial('id').primaryKey(),
        policyId: uuid('policy_id')
            .references(() => policies.id, { onDelete: 'cascade' })
            .notNull(),
        fundId: integer('fund_id').notNull(),
        sharePercentage: numeric('share_percentage', { precision: 5, scale: 4 }).notNull(),
        // Store the Hebrew track name for display / reverse-lookup
        trackName: text('track_name'),
    },
    (t) => ({
        policyIdx: index('policy_tracks_policy_id_idx').on(t.policyId),
    }),
);

/**
 * fund_yield_cache — caches monthly yields fetched from the Government API.
 * report_period is formatted as YYYYMM (e.g. '202503').
 */
export const fundYieldCache = pgTable(
    'fund_yield_cache',
    {
        id: serial('id').primaryKey(),
        fundId: integer('fund_id').notNull(),
        reportPeriod: varchar('report_period', { length: 6 }).notNull(),
        monthlyYield: numeric('monthly_yield', { precision: 10, scale: 6 }).notNull(),
        fetchedAt: timestamp('fetched_at').defaultNow().notNull(),
    },
    (t) => ({
        unq: unique('fund_yield_cache_fund_period_unq').on(t.fundId, t.reportPeriod),
        fundIdx: index('fund_yield_cache_fund_id_idx').on(t.fundId),
    }),
);

/**
 * gemel_resource_state — tracks the last processed report period per government API resource.
 *
 * One row per resource (gemel/hishtalmut, pension, polis). Used by the nightly cron
 * for fast-exit logic: if the probed latest period equals lastProcessedPeriod, the cron
 * skips all DB + API work for that resource.
 *
 * lastProcessedPeriod = NULL means "never processed by the smart cron" — first run
 * handles this by performing a full catch-up with a 6-month pre-warm lookback.
 *
 * report_period format: YYYYMM (e.g. '202504')
 */
export const gemelResourceState = pgTable('gemel_resource_state', {
    resourceId: varchar('resource_id', { length: 36 }).primaryKey(),
    resourceName: text('resource_name').notNull(),
    lastProcessedPeriod: varchar('last_processed_period', { length: 6 }),
    lastProbedAt: timestamp('last_probed_at'),
    lastProcessedAt: timestamp('last_processed_at'),
});

export const userRoles = pgTable('user_roles', {
    userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
    role: text('role').notNull(),
}, (t) => ({
    pk: primaryKey({ columns: [t.userId, t.role] }),
}));

export const dailyPageVisits = pgTable('daily_page_visits', {
    date: date('date').notNull(),
    path: text('path').notNull(),
    visitCount: integer('visit_count').default(0).notNull(),
}, (t) => ({
    pk: primaryKey({ columns: [t.date, t.path] }),
}));

