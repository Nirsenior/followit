import { AuthTypes, Connector, IpAddressTypes } from '@google-cloud/cloud-sql-connector';
import { drizzle } from 'drizzle-orm/node-postgres';
import { migrate } from 'drizzle-orm/node-postgres/migrator';
import fs from 'fs';
import { fileURLToPath } from 'node:url';
import path from 'path';
import pg from 'pg';

let pool: pg.Pool | null = null;
export let db: any = null;

export const initDb = async (log: any) => {
    try {
        if (process.env.DATABASE_URL) {
            pool = new pg.Pool({
                connectionString: process.env.DATABASE_URL,
                max: 5,
            });
            log.info('Connecting to database via DATABASE_URL');
        } else {
            const connector = new Connector();
            const dbIpType = (process.env.DB_IP_TYPE || 'PSC').toUpperCase();
            const pscTarget = process.env.DB_PSC_TARGET || '10.1.2.2';

            log.info({ dbIpType, pscTarget }, 'Configuring Cloud SQL Connector options');

            const clientOpts = await connector.getOptions({
                instanceConnectionName:
                    process.env.INSTANCE_CONNECTION_NAME ||
                    'followit360-prod:me-west1:follow-it-cluster',
                ipType: dbIpType === 'PRIVATE' ? IpAddressTypes.PRIVATE : IpAddressTypes.PSC,
                authType: AuthTypes.IAM,
                ...(dbIpType === 'PSC' ? { pscConfig: { pscTarget } } : {}),
            } as any);

            pool = new pg.Pool({
                ...clientOpts,
                user: process.env.DB_USER,
                database: process.env.DB_NAME || 'follow_it_staging',
                options: '-c search_path=public',
                max: 5,
            } as pg.PoolConfig);
            log.info('Connecting to database via Cloud SQL Connector');
        }

        db = drizzle(pool);

        const dbUser = process.env.DB_USER || 'followit360-app-sa@followit360-stg.iam';
        log.info({ dbUser }, 'Initializing database schema');

        // Best Practice: Use fileURLToPath for reliable ESM path resolution across OSs
        const __filename = fileURLToPath(import.meta.url);
        const __dirname = path.dirname(__filename);

        const possibleMigrationPaths = [
            path.join(__dirname, '../../drizzle'), // dist/db/connection.js -> dist/drizzle
            path.join(__dirname, '../drizzle'), // dist/connection.js -> dist/drizzle
            path.join(process.cwd(), 'apps/backend/drizzle'),
            path.join(process.cwd(), 'drizzle'),
        ];

        let migrationsFolder = '';
        for (const p of possibleMigrationPaths) {
            const journalPath = path.join(p, 'meta', '_journal.json');
            if (fs.existsSync(journalPath)) {
                migrationsFolder = p;
                break;
            }
        }

        if (!migrationsFolder) {
            log.error(
                { triedPaths: possibleMigrationPaths, cwd: process.cwd() },
                'FATAL: Could not find Drizzle migrations folder.',
            );
            throw new Error('Migrations folder not found');
        }

        // Log files in migration folder to verify they exist in the container
        const migrationFiles = fs.readdirSync(migrationsFolder);
        log.info({ migrationsFolder, files: migrationFiles }, 'Found migrations folder');

        log.info('Starting Drizzle migration...');
        try {
            await migrate(db, { migrationsFolder });
            log.info('Drizzle migrate() call completed');



        } catch (migrationErr) {
            log.error({ err: migrationErr, migrationsFolder }, 'FATAL: Migration execution failed');
            throw migrationErr;
        }
    } catch (err) {
        log.error({ err }, 'Database initialization failed');
        throw err;
    }
};
