export interface ErrorResponse {
    status: 'fail' | 'error';
    message: string;
    details?: any;
}

export interface DevErrorResponse extends ErrorResponse {
    error: any;
    stack?: string;
}
