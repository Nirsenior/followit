import { FastifyReply, FastifyRequest } from 'fastify';

// Wrapper for controller functions to ensure any synchronous thrown errors
// or rejected promises are automatically passed to the Fastify error handler.
export const catchAsync = (
    fn: (request: FastifyRequest, reply: FastifyReply) => Promise<any> | void,
) => {
    return (request: FastifyRequest, reply: FastifyReply) => {
        try {
            const result = fn(request, reply);
            if (result instanceof Promise) {
                result.catch((err) => {
                    reply.send(err);
                });
            }
        } catch (err) {
            reply.send(err);
        }
    };
};
