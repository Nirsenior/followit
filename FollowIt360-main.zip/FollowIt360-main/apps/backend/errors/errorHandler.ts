import { FastifyError, FastifyReply, FastifyRequest } from 'fastify';
import { StatusCodes } from 'http-status-codes';
import { AppError } from './AppError.js';
import { mapPostgresError } from './PostgresErrorMapper.js';
import { DevErrorResponse, ErrorResponse } from './types.js';

const sendErrorDev = (err: AppError, request: FastifyRequest, reply: FastifyReply) => {
    if (err.statusCode >= 500) {
        request.log.error(err);
    }
    const response: DevErrorResponse = {
        status: err.status,
        message: err.message,
        error: err,
        stack: err.stack,
    };
    reply.status(err.statusCode).send(response);
};

const sendErrorProd = (err: AppError | any, request: FastifyRequest, reply: FastifyReply) => {
    // Operational, trusted error: send message to client
    if (err instanceof AppError && err.isOperational) {
        const response: ErrorResponse = {
            status: err.status,
            message: err.message,
            ...(err.details && { details: err.details }),
        };
        return reply.status(err.statusCode).send(response);
    }

    // Programming or other unknown error: don't leak error details
    request.log.error(`ERROR 💥 =>>> ${err} `, err);

    const response: ErrorResponse = {
        status: 'error',
        message: 'Something went very wrong!',
    };
    return reply.status(StatusCodes.INTERNAL_SERVER_ERROR).send(response);
};

export const errorHandler = (
    error: FastifyError | Error | any,
    request: FastifyRequest,
    reply: FastifyReply,
) => {
    // Base configuration for incoming errors
    let err = error;

    // Fastify-specific schema validation errors (e.g. from Zod or native compiler)
    if (error.validation) {
        err = new AppError(
            `Validation Error: Invalid Input Data`,
            StatusCodes.BAD_REQUEST,
            error.validation,
        );
    }
    // Handle JWT Authentication errors
    else if (error.name === 'JsonWebTokenError') {
        err = new AppError('Invalid token. Please log in again.', StatusCodes.UNAUTHORIZED);
    } else if (error.name === 'TokenExpiredError') {
        err = new AppError(
            'Your token has expired! Please log in again.',
            StatusCodes.UNAUTHORIZED,
        );
    }
    // If not already an AppError, check if it's a Postgres constraint error
    else if (!(error instanceof AppError)) {
        const pgError = mapPostgresError(error);
        if (pgError) {
            err = pgError;
        } else if (error.statusCode) {
            // Handle native Fastify HTTP errors (e.g., 404s, rate-limit 429s) gracefully
            err = new AppError(error.message, error.statusCode);
        } else {
            // Fallback mapping
            err = new AppError(
                error.message || 'Internal Server Error',
                StatusCodes.INTERNAL_SERVER_ERROR,
            );
            (err as any).isOperational = false;
            // Attach original error for internal logging
            (err as AppError & { originalError: any }).originalError = error;
            err.stack = error.stack;
        }
    }

    if (process.env.NODE_ENV === 'development') {
        sendErrorDev(err as AppError, request, reply);
    } else {
        sendErrorProd(err as AppError, request, reply);
    }
};
