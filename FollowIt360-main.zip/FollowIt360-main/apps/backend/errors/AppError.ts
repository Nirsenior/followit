import { StatusCodes } from 'http-status-codes';

export class AppError extends Error {
    public readonly statusCode: StatusCodes;
    public readonly status: 'fail' | 'error';
    public readonly isOperational: boolean;
    public readonly details?: any;

    constructor(message: string, statusCode: StatusCodes, details?: any) {
        super(message);
        this.statusCode = statusCode;
        // 4xx HTTP responses are client failures, 5xx are server errors
        this.status = `${statusCode}`.startsWith('4') ? 'fail' : 'error';
        this.isOperational = true;

        if (details) {
            this.details = details;
        }

        // Capture stack trace, excluding the constructor call from it
        Error.captureStackTrace(this, this.constructor);
    }
}
