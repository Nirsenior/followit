import { StatusCodes } from 'http-status-codes';
import { AppError } from './AppError.js';
import { PostgresErrorCode } from './postgresErrorCodes.js';

export const mapPostgresError = (err: any): AppError | null => {
    // Determine if it's a Postgres error. Typically `pg` driver errors have a `.code` property string.
    if (!err.code) return null;

    switch (err.code) {
        case PostgresErrorCode.UNIQUE_VIOLATION:
            return new AppError(
                `Duplicate field value entered. Please use another value.`,
                StatusCodes.CONFLICT,
            );
        case PostgresErrorCode.FOREIGN_KEY_VIOLATION:
            return new AppError(
                `Invalid reference. The related record does not exist.`,
                StatusCodes.BAD_REQUEST,
            );
        case PostgresErrorCode.NOT_NULL_VIOLATION:
            return new AppError(`Missing required field.`, StatusCodes.BAD_REQUEST);
        case PostgresErrorCode.INVALID_TEXT_REPRESENTATION:
            return new AppError(`Invalid input format.`, StatusCodes.BAD_REQUEST);
        case PostgresErrorCode.STRING_DATA_RIGHT_TRUNCATION:
            return new AppError(`Input value is too long.`, StatusCodes.BAD_REQUEST);
        default:
            return null; // Not a common handled operational PG error, fallback to generic
    }
};
