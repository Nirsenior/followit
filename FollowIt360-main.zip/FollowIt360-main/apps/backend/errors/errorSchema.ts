import { z } from 'zod';

export const SuccessStatusSchema = z.object({
    status: z.literal('success'),
});

export const ErrorResponseSchema = z.object({
    status: z.enum(['fail', 'error']),
    message: z.string(),
    details: z.any().optional(),
});

/**
 * Standardized Zod schemas for our globally handled AppError responses.
 * Spread this into any Fastify route schema's response object to instantly
 * type-check and document all possible error outputs.
 */
export const commonErrorResponses = {
    400: ErrorResponseSchema,
    401: ErrorResponseSchema,
    403: ErrorResponseSchema,
    404: ErrorResponseSchema,
    409: ErrorResponseSchema,
    429: ErrorResponseSchema,
    500: ErrorResponseSchema,
    503: ErrorResponseSchema,
};
