import { eq, and } from 'drizzle-orm';
import { FastifyReply, FastifyRequest } from 'fastify';
import { StatusCodes } from 'http-status-codes';
import { db } from '../db/connection.js';
import { userRoles } from '../db/schema.js';
import { AppError } from '../errors/AppError.js';

export const requireAdmin = async (request: FastifyRequest, reply: FastifyReply) => {
    // fastify.authenticate should be called before this
    const payload = request.user as { userId?: string };

    if (!payload || !payload.userId) {
        throw new AppError('Unauthorized', StatusCodes.UNAUTHORIZED);
    }

    const adminRole = await db
        .select()
        .from(userRoles)
        .where(and(eq(userRoles.userId, payload.userId), eq(userRoles.role, 'ADMIN')))
        .limit(1);

    if (adminRole.length === 0) {
        throw new AppError('Forbidden: Admins only', StatusCodes.FORBIDDEN);
    }
};
