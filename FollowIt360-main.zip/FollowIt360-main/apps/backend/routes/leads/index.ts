import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';
import { emailService } from '../../services/emailService.js';

const leadsRoutes = async (fastify: FastifyInstance) => {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.post(
        '/sell-portfolio',
        {
            preValidation: [fastify.authenticate],
            schema: {
                body: z.object({
                    phone: z.string().min(1, 'Phone is required'),
                    email: z.string().email('Invalid email'),
                    portfolioValue: z.number().min(0),
                    agentName: z.string().min(1, 'Agent name is required'),
                }),
            },
        },
        async (request, reply) => {
            const { phone, email, portfolioValue, agentName } = request.body;

            try {
                await emailService.sendPortfolioValuationLead({
                    agentName,
                    phone,
                    email,
                    portfolioValue,
                });

                return reply.send({ success: true });
            } catch (error) {
                fastify.log.error(error);
                return reply.status(500).send({ success: false, message: 'Failed to send lead email' });
            }
        }
    );
};

export default leadsRoutes;
