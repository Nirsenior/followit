import { companyAgreementsSchema } from '@repo/types';
import { sql } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { StatusCodes } from 'http-status-codes';
import z from 'zod';
import { db } from '../../db/connection.js';
import { agreements, companyEnum, insuranceTypeEnum } from '../../db/schema.js';
import { AppError } from '../../errors/AppError.js';
import { commonErrorResponses, SuccessStatusSchema } from '../../errors/errorSchema.js';
import { applyEffectivityDecisions } from './effectivityHelper.js';

// Schema for the incoming array items
const agreementItemSchema = z.object({
    company: z.enum(companyEnum.enumValues),
    rates: companyAgreementsSchema,
});

const effectivityDecisionSchema = z.object({
    company: z.string(),
    type: z.enum(insuranceTypeEnum.enumValues),
    oldValue: z.string(),
    newValue: z.string(),
    isRetroactive: z.boolean(),
});

// Request body schema for saving agreements
const saveAgreementsRequestSchema = z.object({
    userId: z.string().uuid('Invalid User ID format'),
    agreements: z.array(agreementItemSchema),
    effectivityDecisions: z.array(effectivityDecisionSchema).optional().default([]),
});

export default async function saveAgreementsRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.post(
        '/',
        {
            preHandler: [fastify.authenticate],
            schema: {
                body: saveAgreementsRequestSchema,
                response: {
                    200: SuccessStatusSchema.extend({ count: z.number() }),
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            if (!db) {
                throw new AppError('Database not ready', StatusCodes.SERVICE_UNAVAILABLE);
            }

            const { userId, agreements: userAgreements, effectivityDecisions } = request.body;
            const authPayload = request.user as { userId: string };

            // Security check: Ensure user is updating their own data
            if (userId !== authPayload.userId) {
                throw new AppError(
                    'Forbidden: You can only update your own agreements',
                    StatusCodes.FORBIDDEN,
                );
            }

            const agreementsToInsert = userAgreements.map((item) => ({
                userId: userId,
                company: item.company,
                rates: item.rates,
            }));

            await db.transaction(async (tx: any) => {
                if (agreementsToInsert.length > 0) {
                    // Use Drizzle's ON CONFLICT DO UPDATE
                    // Target the unique constraint (userId, company) and update the rates.
                    await tx
                        .insert(agreements)
                        .values(agreementsToInsert)
                        .onConflictDoUpdate({
                            target: [agreements.userId, agreements.company],
                            set: { rates: sql`excluded.rates` },
                        });
                }

                // Apply effectivity decisions if any exist
                await applyEffectivityDecisions(tx, userId, effectivityDecisions);
            });

            return { status: 'success' as const, count: userAgreements.length };
        },
    );
}
