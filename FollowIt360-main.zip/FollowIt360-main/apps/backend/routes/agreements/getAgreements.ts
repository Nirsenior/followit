import { eq } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { StatusCodes } from 'http-status-codes';
import z from 'zod';
import { db } from '../../db/connection.js';
import { agreements } from '../../db/schema.js';
import { AppError } from '../../errors/AppError.js';
import { commonErrorResponses } from '../../errors/errorSchema.js';

export default async function getAgreementsRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.get(
        '/:userId',
        {
            preHandler: [fastify.authenticate],
            schema: {
                params: z.object({
                    userId: z.string().uuid('Invalid User ID format'),
                }),
                response: {
                    200: z.array(
                        z.object({
                            company: z.string(),
                            rates: z.any(),
                        }),
                    ),
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            if (!db) {
                throw new AppError('Database not ready', StatusCodes.SERVICE_UNAVAILABLE);
            }

            const { userId } = request.params;
            const authPayload = request.user as { userId: string };

            // Security check: Ensure user is fetching their own data
            if (userId !== authPayload.userId) {
                throw new AppError(
                    'Forbidden: You can only access your own agreements',
                    StatusCodes.FORBIDDEN,
                );
            }

            const dbAgreements = await db
                .select({
                    company: agreements.company,
                    rates: agreements.rates,
                })
                .from(agreements)
                .where(eq(agreements.userId, userId));

            return dbAgreements;
        },
    );
}
