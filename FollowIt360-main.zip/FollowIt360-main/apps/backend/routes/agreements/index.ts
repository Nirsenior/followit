import { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import getAgreementsRoute from './getAgreements.js';
import saveAgreementsRoute from './saveAgreements.js';

declare module 'fastify' {
    interface FastifyInstance {
        authenticate: (request: FastifyRequest, reply: FastifyReply) => Promise<void>;
    }
}

export default async function agreementsRoutes(fastify: FastifyInstance) {
    await fastify.register(saveAgreementsRoute);
    await fastify.register(getAgreementsRoute);
}
