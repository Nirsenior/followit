import { and, eq, inArray, isNull } from 'drizzle-orm';
import { policies, customers } from '../../db/schema.js';

export interface EffectivityDecision {
    company: string;
    type: any;
    oldValue: string;
    newValue: string;
    isRetroactive: boolean;
}

/**
 * Applies retroactive vs. from-now-on commission rate overrides in a database transaction.
 * Locks the oldValue for future only choices or clears locks for retroactive choices.
 */
export async function applyEffectivityDecisions(
    tx: any,
    userId: string,
    effectivityDecisions: EffectivityDecision[]
): Promise<void> {
    if (!effectivityDecisions || effectivityDecisions.length === 0) {
        return;
    }

    const userCustomers = await tx
        .select({ id: customers.id, familyMembers: customers.familyMembers })
        .from(customers)
        .where(eq(customers.userId, userId));

    if (userCustomers.length === 0) {
        return;
    }

    const customerIds = userCustomers.map((c: any) => c.id);

    for (const decision of effectivityDecisions) {
        const conditions = [
            inArray(policies.customerId, customerIds),
            eq(policies.insuranceType, decision.type),
        ];

        if (decision.company !== 'GLOBAL') {
            conditions.push(eq(policies.company, decision.company as any));
        }

        if (decision.isRetroactive) {
            // Retroactive choice: clear lock on matching policies
            await tx
                .update(policies)
                .set({ fixedCommissionRate: null })
                .where(and(...conditions));
        } else {
            // From now on choice: freeze old rate on matching policies where rate is not already locked
            conditions.push(isNull(policies.fixedCommissionRate));
            await tx
                .update(policies)
                .set({ fixedCommissionRate: decision.oldValue })
                .where(and(...conditions));
        }

        // Update nested family members' policies in JSONB inside the customers table
        for (const customer of userCustomers) {
            let familyMembersUpdated = false;
            const familyMembers = (customer.familyMembers as any[]) || [];

            const updatedFamilyMembers = familyMembers.map((fm) => {
                const updatedPolicies = (fm.policies as any[] || []).map((policy) => {
                    const isMatch = policy.type === decision.type &&
                        (decision.company === 'GLOBAL' || policy.company === decision.company);

                    if (isMatch) {
                        familyMembersUpdated = true;
                        if (decision.isRetroactive) {
                            const { fixedCommissionRate, ...rest } = policy;
                            return rest;
                        } else {
                            if (!policy.fixedCommissionRate) {
                                return { ...policy, fixedCommissionRate: decision.oldValue };
                            }
                        }
                    }
                    return policy;
                });
                return { ...fm, policies: updatedPolicies };
            });

            if (familyMembersUpdated) {
                await tx
                    .update(customers)
                    .set({ familyMembers: updatedFamilyMembers })
                    .where(eq(customers.id, customer.id));
            }
        }
    }
}
