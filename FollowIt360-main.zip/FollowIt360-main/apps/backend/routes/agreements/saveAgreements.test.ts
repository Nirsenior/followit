import Fastify from 'fastify';
import supertest from 'supertest';
import { afterAll, beforeAll, describe, expect, it, vi, beforeEach } from 'vitest';
import { serializerCompiler, validatorCompiler, ZodTypeProvider } from 'fastify-type-provider-zod';
import saveAgreementsRoute from './saveAgreements.js';

let mockDb: any;
let mockTx: any;

vi.mock('../../db/connection.js', () => ({
    get db() {
        return mockDb;
    }
}));

describe('POST /agreements', () => {
    let app: any;

    beforeAll(async () => {
        app = Fastify().withTypeProvider<ZodTypeProvider>();
        app.setValidatorCompiler(validatorCompiler);
        app.setSerializerCompiler(serializerCompiler);

        // Mock authenticate decorator
        // Mock authenticate decorator
        app.decorate('authenticate', async (request: any, reply: any) => {
            const authHeader = request.headers['authorization'];
            if (authHeader === 'Bearer valid') {
                request.user = { userId: '12345678-1234-4234-8234-123456789012' };
            } else {
                reply.status(401).send({ status: 'error', message: 'Unauthorized' });
            }
        });

        // Register global error handler to format validation errors cleanly
        const { errorHandler } = await import('../../errors/errorHandler.js');
        app.setErrorHandler(errorHandler);

        await app.register(saveAgreementsRoute);
        await app.ready();
    });

    beforeEach(() => {
        mockTx = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            where: vi.fn().mockImplementation(function (this: any) {
                return Promise.resolve([
                    {
                        id: 'cust-123',
                        familyMembers: [
                            {
                                id: 'fm-1',
                                policies: [
                                    { id: 'fm-pol-1', type: 'pension', company: 'GLOBAL' }
                                ]
                            }
                        ]
                    }
                ]);
            }),
            update: vi.fn().mockReturnThis(),
            set: vi.fn().mockReturnThis(),
            insert: vi.fn().mockReturnThis(),
            values: vi.fn().mockReturnThis(),
            onConflictDoUpdate: vi.fn().mockResolvedValue({}),
        };

        mockDb = {
            transaction: vi.fn((cb) => cb(mockTx)),
            insert: vi.fn().mockReturnThis(),
            values: vi.fn().mockReturnThis(),
            onConflictDoUpdate: vi.fn().mockResolvedValue({}),
        };
    });

    afterAll(async () => {
        await app.close();
    });

    it('returns 200 OK and saves agreements without decisions', async () => {
        const response = await supertest(app.server)
            .post('/')
            .set('Authorization', 'Bearer valid')
            .send({
                userId: '12345678-1234-4234-8234-123456789012',
                agreements: [
                    {
                        company: 'GLOBAL',
                        rates: {
                            pension: { ongoing: '0.5' }
                        }
                    }
                ]
            });

        if (response.status !== 200) console.error("SAVE AGREEMENTS ERROR:", response.body);
        expect(response.status).toBe(200);
        expect(response.body).toEqual({ status: 'success', count: 1 });
        expect(mockTx.insert).toHaveBeenCalled();
    });

    it('processes non-retroactive (from now on) decisions correctly', async () => {
        const response = await supertest(app.server)
            .post('/')
            .set('Authorization', 'Bearer valid')
            .send({
                userId: '12345678-1234-4234-8234-123456789012',
                agreements: [
                    {
                        company: 'GLOBAL',
                        rates: {
                            pension: { ongoing: '0.5' }
                        }
                    }
                ],
                effectivityDecisions: [
                    {
                        company: 'GLOBAL',
                        type: 'pension',
                        oldValue: '0.3',
                        newValue: '0.5',
                        isRetroactive: false
                    }
                ]
            });

        if (response.status !== 200) console.error("DECISION NON-RETRO ERROR:", response.body);
        expect(response.status).toBe(200);
        expect(mockTx.update).toHaveBeenCalled();
        expect(mockTx.set).toHaveBeenCalledWith(expect.objectContaining({
            fixedCommissionRate: '0.3'
        }));
    });

    it('processes retroactive decisions correctly', async () => {
        const response = await supertest(app.server)
            .post('/')
            .set('Authorization', 'Bearer valid')
            .send({
                userId: '12345678-1234-4234-8234-123456789012',
                agreements: [
                    {
                        company: 'GLOBAL',
                        rates: {
                            pension: { ongoing: '0.5' }
                        }
                    }
                ],
                effectivityDecisions: [
                    {
                        company: 'GLOBAL',
                        type: 'pension',
                        oldValue: '0.3',
                        newValue: '0.5',
                        isRetroactive: true
                    }
                ]
            });

        if (response.status !== 200) console.error("DECISION RETRO ERROR:", response.body);
        expect(response.status).toBe(200);
        expect(mockTx.update).toHaveBeenCalled();
        expect(mockTx.set).toHaveBeenCalledWith(expect.objectContaining({
            fixedCommissionRate: null
        }));
    });
});
