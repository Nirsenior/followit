import { eq, inArray } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { StatusCodes } from 'http-status-codes';
import { db } from '../../db/connection.js';
import { customers, policies, policyTracks } from '../../db/schema.js';
import { AppError } from '../../errors/AppError.js';
import { commonErrorResponses } from '../../errors/errorSchema.js';

export default async function getCustomersRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.get(
        '/',
        {
            preHandler: [fastify.authenticate],
            schema: {
                response: {
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            if (!db) {
                throw new AppError('Database not ready', StatusCodes.SERVICE_UNAVAILABLE);
            }

            const authPayload = request.user as { userId?: string; id?: string };
            const userId = authPayload.userId || authPayload.id;

            if (!userId) {
                throw new AppError('Unauthorized: Missing user ID', StatusCodes.UNAUTHORIZED);
            }

            // 1. Fetch all customers for this user
            const userCustomers = await db
                .select()
                .from(customers)
                .where(eq(customers.userId, userId));
            if (userCustomers.length === 0) {
                return [];
            }

            // 2. Fetch all policies for these customers in a single query
            const customerIds = userCustomers.map((c: any) => c.id);
            const allPolicies = await db
                .select()
                .from(policies)
                .where(inArray(policies.customerId, customerIds));

            // 3. Fetch all policy_tracks for these policies in a single query.
            // Wrapped in try/catch: if the migration hasn't run yet (table doesn't
            // exist), we degrade gracefully and return empty tracks instead of crashing.
            const policyIds = allPolicies.map((p: any) => p.id);
            let allTracks: any[] = [];
            try {
                if (policyIds.length > 0) {
                    allTracks = await db
                        .select()
                        .from(policyTracks)
                        .where(inArray(policyTracks.policyId, policyIds));
                }
            } catch (trackErr: any) {
                // Table doesn't exist yet — log and continue without track data
                console.warn(
                    '[getCustomers] policy_tracks table not available yet (migration pending?):',
                    trackErr.message,
                );
            }

            // Group tracks by policyId in O(N)
            const tracksByPolicy = new Map<string, any[]>();
            for (const t of allTracks) {
                if (!tracksByPolicy.has(t.policyId)) {
                    tracksByPolicy.set(t.policyId, []);
                }
                tracksByPolicy.get(t.policyId)!.push(t);
            }

            // 3. Group policies by customerId in O(N)
            const policiesByCustomer = new Map<string, typeof allPolicies>();
            for (const p of allPolicies) {
                if (!policiesByCustomer.has(p.customerId)) {
                    policiesByCustomer.set(p.customerId, []);
                }
                policiesByCustomer.get(p.customerId)!.push(p);
            }

            // 4. Map to frontend format
            const result = userCustomers.map((c: any) => {
                const parts = c.name.split(' ');
                const firstName = parts[0];
                const lastName = parts.slice(1).join(' ') || '';

                const customerPolicies = policiesByCustomer.get(c.id) || [];

                return {
                    id: c.governmentId, // Frontend uses governmentId as the main ID
                    dbId: c.id,
                    firstName,
                    lastName,
                    issueDate: c.issueDate || undefined,
                    familyMembers: c.familyMembers || [],
                    creationType: c.creationType || 'existing',
                    createdAt: c.createdAt || undefined,
                    policies: customerPolicies.map((p: any) => {
                        // Attempt to extract monthlyCost if it was saved in details, otherwise default to 0
                        const details = p.details as Record<string, any>;
                        let computedCost = 0;
                        if (details?.subPolicies) {
                            computedCost = Object.values(details.subPolicies).reduce(
                                (a: any, b: any) => a + (parseFloat(b) || 0),
                                0,
                            ) as number;
                        } else if (details?.monthlyDeposit) {
                            computedCost = parseFloat(details.monthlyDeposit as any) || 0;
                        } else if (details?.monthlyCost) {
                            computedCost = parseFloat(details.monthlyCost as any) || 0;
                        }

                        return {
                            id: p.id,
                            type: p.insuranceType,
                            company: p.company,
                            issueDate: p.issueDate || undefined,
                            isAgentAppointmentOnly: !!details?.isAgentAppointmentOnly,
                            details: p.details,
                            monthlyCost: computedCost,
                            status: 'active',
                            currentAccumulation: p.currentAccumulation || undefined,
                            initialAccumulation: p.initialAccumulation || undefined,
                            fixedCommissionRate: p.fixedCommissionRate || undefined,
                            systemEntryDate: p.systemEntryDate || undefined,
                            lastCalculatedDate: p.lastCalculatedDate || undefined,
                            // Include normalized tracks for yield lookups
                            policyTracks: (tracksByPolicy.get(p.id) || []).map((t: any) => ({
                                fundId: t.fundId,
                                sharePercentage: parseFloat(t.sharePercentage),
                                trackName: t.trackName,
                            })),
                        };
                    }),
                };
            });

            return result;
        },
    );
}
