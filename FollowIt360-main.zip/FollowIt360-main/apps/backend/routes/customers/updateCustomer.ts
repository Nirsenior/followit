import { and, eq, inArray } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { StatusCodes } from 'http-status-codes';
import z from 'zod';
import { db } from '../../db/connection.js';
import { customers, policies, policyTracks } from '../../db/schema.js';
import { AppError } from '../../errors/AppError.js';
import { commonErrorResponses, SuccessStatusSchema } from '../../errors/errorSchema.js';
import { createCustomerSchema, scrubPolicies } from './schemas.js';

export default async function updateCustomerRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.put(
        '/:id',
        {
            preHandler: [fastify.authenticate],
            schema: {
                params: z.object({ id: z.string() }),
                body: createCustomerSchema,
                response: {
                    200: SuccessStatusSchema,
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            if (!db) {
                throw new AppError('Database not ready', StatusCodes.SERVICE_UNAVAILABLE);
            }

            const authPayload = request.user as { userId?: string; id?: string };
            const userId = authPayload.userId || authPayload.id;

            if (!userId) {
                throw new AppError('Unauthorized: Missing user ID', StatusCodes.UNAUTHORIZED);
            }

            const customerDbId = request.params.id;
            const { customer, policies: incomingPolicies } = request.body;

            // 1. Data Transformation: Name Concatenation
            const fullName = `${customer.firstName.trim()} ${customer.surname.trim()}`;

            // 2. Data Scrubbing (The "Zero-Bloat" Rule)
            const scrubbedPolicies = scrubPolicies(incomingPolicies);

            await db.transaction(async (tx: any) => {
                // Verify ownership
                const existingCustomer = await tx
                    .select()
                    .from(customers)
                    .where(
                        and(
                            eq(customers.id, customerDbId as any),
                            eq(customers.userId, userId as any),
                        ),
                    )
                    .limit(1);

                if (existingCustomer.length === 0) {
                    throw new AppError(
                        'Customer not found or access denied',
                        StatusCodes.NOT_FOUND,
                    );
                }

                // Update customer details
                const familyMembersToSave = request.body.familyMembers || [];
                await tx
                    .update(customers)
                    .set({
                        name: fullName,
                        governmentId: customer.governmentId,
                        issueDate: customer.issueDate || undefined,
                        familyMembers: familyMembersToSave,
                        creationType: customer.creationType,
                    })
                    .where(eq(customers.id, customerDbId as any));

                // Fetch existing policies for this customer
                const existingPolicies = await tx
                    .select()
                    .from(policies)
                    .where(eq(policies.customerId, customerDbId as any));

                const existingPolicyMap = new Map(existingPolicies.map((p: any) => [p.id, p]));

                const incomingPolicyIds = new Set(
                    scrubbedPolicies.map((p: any) => p.id).filter(Boolean),
                );

                // Delete policies that are not in the incoming payload
                const policiesToDelete = existingPolicies.filter(
                    (p: any) => !incomingPolicyIds.has(p.id),
                );
                if (policiesToDelete.length > 0) {
                    await tx.delete(policies).where(
                        inArray(
                            policies.id,
                            policiesToDelete.map((p: any) => p.id),
                        ),
                    );
                }

                const todayStr = new Date().toISOString().slice(0, 10);

                // Helper to insert tracks
                const insertTracks = async (policyId: string, details: Record<string, any>) => {
                    const tracksToInsert: any[] = [];
                    const investmentTracks: any[] = details?.investmentTracks || [];
                    for (const track of investmentTracks) {
                        if (!track.fundId) continue;
                        tracksToInsert.push({
                            policyId,
                            fundId: track.fundId,
                            sharePercentage: String((track.weight || 0) / 100),
                            trackName: track.trackName?.replace(/S1;P/gi, 'S&P'),
                        });
                    }
                    if (tracksToInsert.length > 0) {
                        await tx.insert(policyTracks).values(tracksToInsert);
                    }
                };

                // Insert or Update
                for (const incomingPolicy of scrubbedPolicies) {
                    const det = incomingPolicy.details as Record<string, any>;

                    let systemEntryDate = incomingPolicy.systemEntryDate || undefined;
                    let initialAccumulation = incomingPolicy.initialAccumulation || undefined;
                    let lastCalculatedDate = incomingPolicy.lastCalculatedDate || undefined;
                    let currentAccumulation = incomingPolicy.currentAccumulation || undefined;

                    const newAccumulation =
                        det?.accumulation !== undefined &&
                        det?.accumulation !== null &&
                        det?.accumulation !== ''
                            ? parseFloat(det.accumulation)
                            : undefined;
                    const newMonthlyDeposit =
                        det?.monthlyDeposit !== undefined &&
                        det?.monthlyDeposit !== null &&
                        det?.monthlyDeposit !== ''
                            ? parseFloat(det.monthlyDeposit)
                            : undefined;
                    const newLumpSumDeposit =
                        det?.lumpSumDeposit !== undefined &&
                        det?.lumpSumDeposit !== null &&
                        det?.lumpSumDeposit !== ''
                            ? parseFloat(det.lumpSumDeposit)
                            : undefined;

                    const existingPolicy = (
                        incomingPolicy.id ? existingPolicyMap.get(incomingPolicy.id) : undefined
                    ) as any;

                    if (existingPolicy) {
                        // UPDATE LOGIC
                        systemEntryDate = existingPolicy.systemEntryDate || undefined; // Rule 1

                        const oldDet = existingPolicy.details as Record<string, any>;
                        const oldAccumulation =
                            oldDet?.accumulation !== undefined &&
                            oldDet?.accumulation !== null &&
                            oldDet?.accumulation !== ''
                                ? parseFloat(oldDet.accumulation)
                                : undefined;
                        const oldMonthlyDeposit =
                            oldDet?.monthlyDeposit !== undefined &&
                            oldDet?.monthlyDeposit !== null &&
                            oldDet?.monthlyDeposit !== ''
                                ? parseFloat(oldDet.monthlyDeposit)
                                : undefined;
                        const oldLumpSumDeposit =
                            oldDet?.lumpSumDeposit !== undefined &&
                            oldDet?.lumpSumDeposit !== null &&
                            oldDet?.lumpSumDeposit !== ''
                                ? parseFloat(oldDet.lumpSumDeposit)
                                : undefined;

                        const accumulationChanged = newAccumulation !== oldAccumulation;
                        const depositsChanged =
                            newMonthlyDeposit !== oldMonthlyDeposit ||
                            newLumpSumDeposit !== oldLumpSumDeposit;

                        // Rule 2 & 4
                        if (
                            accumulationChanged &&
                            newAccumulation !== undefined &&
                            !isNaN(newAccumulation)
                        ) {
                            initialAccumulation = String(newAccumulation);
                            currentAccumulation = String(newAccumulation);
                        } else {
                            initialAccumulation = existingPolicy.initialAccumulation || undefined;
                            currentAccumulation = existingPolicy.currentAccumulation || undefined;
                        }

                        // Rule 3
                        if (accumulationChanged || depositsChanged) {
                            lastCalculatedDate = todayStr;
                        } else {
                            lastCalculatedDate = existingPolicy.lastCalculatedDate || undefined;
                        }

                        const [updatedPolicyRecord] = await tx
                            .update(policies)
                            .set({
                                company: incomingPolicy.company,
                                insuranceType: incomingPolicy.insuranceType,
                                issueDate: incomingPolicy.issueDate,
                                details: incomingPolicy.details,
                                fixedCommissionRate: incomingPolicy.fixedCommissionRate,
                                systemEntryDate,
                                initialAccumulation,
                                lastCalculatedDate,
                                currentAccumulation,
                            })
                            .where(eq(policies.id, existingPolicy.id as any))
                            .returning({ id: policies.id });

                        // Update tracks
                        await tx
                            .delete(policyTracks)
                            .where(eq(policyTracks.policyId, existingPolicy.id as any));
                        await insertTracks(updatedPolicyRecord.id, incomingPolicy.details);
                    } else {
                        // INSERT LOGIC
                        systemEntryDate = todayStr;
                        if (newAccumulation !== undefined && !isNaN(newAccumulation)) {
                            initialAccumulation = String(newAccumulation);
                            currentAccumulation = String(newAccumulation);
                            lastCalculatedDate = todayStr;
                        }

                        const [insertedPolicyRecord] = await tx
                            .insert(policies)
                            .values({
                                customerId: customerDbId,
                                company: incomingPolicy.company,
                                insuranceType: incomingPolicy.insuranceType,
                                issueDate: incomingPolicy.issueDate,
                                details: incomingPolicy.details,
                                fixedCommissionRate: incomingPolicy.fixedCommissionRate,
                                systemEntryDate,
                                initialAccumulation,
                                lastCalculatedDate,
                                currentAccumulation,
                            })
                            .returning({ id: policies.id });

                        await insertTracks(insertedPolicyRecord.id, incomingPolicy.details);
                    }
                }
            });

            return { status: 'success' as const };
        },
    );
}
