import { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import createCustomerRoute from './createCustomer.js';
import deleteCustomerRoute from './deleteCustomer.js';
import getCustomersRoute from './getCustomers.js';
import updateCustomerRoute from './updateCustomer.js';

declare module 'fastify' {
    interface FastifyInstance {
        authenticate: (request: FastifyRequest, reply: FastifyReply) => Promise<void>;
    }
}

export default async function customersRoutes(fastify: FastifyInstance) {
    await fastify.register(createCustomerRoute);
    await fastify.register(updateCustomerRoute);
    await fastify.register(deleteCustomerRoute);
    await fastify.register(getCustomersRoute);
}
