import { and, eq } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { StatusCodes } from 'http-status-codes';
import z from 'zod';
import { db } from '../../db/connection.js';
import { customers, policies } from '../../db/schema.js';
import { AppError } from '../../errors/AppError.js';
import { commonErrorResponses, SuccessStatusSchema } from '../../errors/errorSchema.js';

export default async function deleteCustomerRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.delete(
        '/:id',
        {
            preHandler: [fastify.authenticate],
            schema: {
                params: z.object({ id: z.string() }),
                response: {
                    200: SuccessStatusSchema,
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            if (!db) {
                throw new AppError('Database not ready', StatusCodes.SERVICE_UNAVAILABLE);
            }

            const authPayload = request.user as { userId?: string; id?: string };
            const userId = authPayload.userId || authPayload.id;

            if (!userId) {
                throw new AppError('Unauthorized: Missing user ID', StatusCodes.UNAUTHORIZED);
            }

            const customerDbId = request.params.id;

            await db.transaction(async (tx: any) => {
                // Verify ownership
                const existing = await tx
                    .select()
                    .from(customers)
                    .where(and(eq(customers.id, customerDbId as any), eq(customers.userId, userId as any)))
                    .limit(1);

                if (existing.length === 0) {
                    throw new AppError('Customer not found or access denied', StatusCodes.NOT_FOUND);
                }

                // Delete policies first (FK constraint)
                await tx.delete(policies).where(eq(policies.customerId, customerDbId as any));

                // Delete customer
                await tx.delete(customers).where(eq(customers.id, customerDbId as any));
            });

            return { status: 'success' as const };
        },
    );
}
