import Fastify from 'fastify';
import supertest from 'supertest';
import { afterAll, beforeAll, describe, expect, it, vi, beforeEach } from 'vitest';
import { serializerCompiler, validatorCompiler, ZodTypeProvider } from 'fastify-type-provider-zod';
import createCustomerRoute from './createCustomer.js';

let mockDb: any;
let mockTx: any;

vi.mock('../../db/connection.js', () => ({
    get db() {
        return mockDb;
    }
}));

describe('POST /customers/', () => {
    let app: any;

    beforeAll(async () => {
        app = Fastify().withTypeProvider<ZodTypeProvider>();
        app.setValidatorCompiler(validatorCompiler);
        app.setSerializerCompiler(serializerCompiler);

        // Mock authenticate decorator
        app.decorate('authenticate', async (request: any, reply: any) => {
            const authHeader = request.headers['authorization'];
            if (authHeader === 'Bearer valid') {
                request.user = { userId: 'user-123' };
            } else {
                reply.status(401).send({ status: 'error', message: 'Unauthorized' });
            }
        });

        await app.register(createCustomerRoute);
        await app.ready();
    });

    beforeEach(() => {
        mockTx = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            where: vi.fn().mockReturnThis(),
            limit: vi.fn().mockResolvedValue([]), // Default: no existing customer
            insert: vi.fn().mockReturnThis(),
            values: vi.fn().mockReturnThis(),
            returning: vi.fn().mockResolvedValue([{ id: 'new-cust-123' }])
        };

        mockDb = {
            transaction: vi.fn((cb) => cb(mockTx))
        };
    });

    afterAll(async () => {
        await app.close();
    });

    it('returns 200 OK and creates a customer with no policies', async () => {
        const response = await supertest(app.server)
            .post('/')
            .set('Authorization', 'Bearer valid')
            .send({
                customer: {
                    firstName: 'John',
                    surname: 'Doe',
                    governmentId: '123456789'
                },
                policies: []
            });
        
        expect(response.status).toBe(200);
        expect(response.body).toEqual({ status: 'success', customerId: 'new-cust-123' });
        expect(mockTx.insert).toHaveBeenCalledTimes(1); // Only customer is inserted, no policies
    });

    it('returns 200 OK and creates a customer with policies', async () => {
        const response = await supertest(app.server)
            .post('/')
            .set('Authorization', 'Bearer valid')
            .send({
                customer: {
                    firstName: 'John',
                    surname: 'Doe',
                    governmentId: '123456789'
                },
                policies: [
                    { company: 'מגדל', insuranceType: 'pension', details: {} }
                ]
            });
        
        if (response.status !== 200) console.log(response.body);
        expect(response.status).toBe(200);
        expect(response.body).toEqual({ status: 'success', customerId: 'new-cust-123' });
        expect(mockTx.insert).toHaveBeenCalledTimes(2); // One for customer, one for policies
    });

    it('returns 409 Conflict if customer with same government ID already exists for the user', async () => {
        // Change mock behavior for this test to signify customer exists
        mockTx.limit = vi.fn().mockResolvedValue([{ id: 'existing-cust-123' }]);

        const response = await supertest(app.server)
            .post('/')
            .set('Authorization', 'Bearer valid')
            .send({
                customer: {
                    firstName: 'Existing',
                    surname: 'Customer',
                    governmentId: '123456789'
                },
                policies: []
            });
        
        expect(response.status).toBe(409);
        expect(response.body.message).toContain('לקוח עם תעודת זהות זו כבר קיים במערכת');
    });

    it('returns 401 if user is unauthenticated', async () => {
        const response = await supertest(app.server)
            .post('/')
            .send({
                customer: { firstName: 'None', surname: 'None', governmentId: '0' },
                policies: []
            });
            
        expect(response.status).toBe(401);
    });

    it('throws AppError if database is not ready', async () => {
        mockDb = undefined;
        const response = await supertest(app.server)
            .post('/')
            .set('Authorization', 'Bearer valid')
            .send({
                customer: { firstName: 'DB', surname: 'Test', governmentId: '0000' },
                policies: []
            });
            
        expect(response.status).toBe(503);
    });
});
