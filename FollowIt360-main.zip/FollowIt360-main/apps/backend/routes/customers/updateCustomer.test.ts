import Fastify from 'fastify';
import supertest from 'supertest';
import { afterAll, beforeAll, describe, expect, it, vi, beforeEach } from 'vitest';
import { serializerCompiler, validatorCompiler, ZodTypeProvider } from 'fastify-type-provider-zod';
import updateCustomerRoute from './updateCustomer.js';

let mockDb: any;
let mockTx: any;

vi.mock('../../db/connection.js', () => ({
    get db() {
        return mockDb;
    }
}));

describe('PUT /customers/:id', () => {
    let app: any;

    beforeAll(async () => {
        app = Fastify().withTypeProvider<ZodTypeProvider>();
        app.setValidatorCompiler(validatorCompiler);
        app.setSerializerCompiler(serializerCompiler);

        // Mock authenticate decorator
        app.decorate('authenticate', async (request: any, reply: any) => {
            const authHeader = request.headers['authorization'];
            if (authHeader === 'Bearer valid') {
                request.user = { userId: 'user-123' };
            } else {
                reply.status(401).send({ status: 'error', message: 'Unauthorized' });
            }
        });

        await app.register(updateCustomerRoute);
        await app.ready();
    });

    beforeEach(() => {
        mockTx = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            where: vi.fn().mockImplementation(function (this: any) {
                // If this is chained after limit, or just returns a resolved promise
                const chainable: any = Promise.resolve([{ id: 'cust-123' }]);
                chainable.limit = vi.fn(() => Promise.resolve([{ id: 'cust-123' }]));
                chainable.returning = vi.fn(() => Promise.resolve([{ id: 'updated-123' }]));
                return chainable;
            }),
            update: vi.fn().mockReturnThis(),
            set: vi.fn().mockReturnThis(),
            delete: vi.fn().mockReturnThis(),
            insert: vi.fn().mockReturnThis(),
            values: vi.fn().mockReturnThis(),
            returning: vi.fn().mockResolvedValue([{ id: 'updated-pol-123', details: {} }])
        };

        // We override where on a per-test basis to return different things per call
        const mockWhere = vi.fn();
        mockTx.where = mockWhere;

        mockDb = {
            transaction: vi.fn((cb) => cb(mockTx))
        };
    });

    afterAll(async () => {
        await app.close();
    });

    it('returns 200 OK and updates customer with policies', async () => {
        let whereCallCount = 0;
        mockTx.where.mockImplementation(() => {
            whereCallCount++;
            if (whereCallCount === 1) { // 1: check ownership
                const chainable: any = Promise.resolve([{ id: 'cust-123' }]);
                chainable.limit = vi.fn(() => Promise.resolve([{ id: 'cust-123' }]));
                return chainable;
            } else if (whereCallCount === 2) { // 2: update customer
                const chainable: any = Promise.resolve();
                chainable.returning = vi.fn(() => Promise.resolve([{ id: 'updated-123' }]));
                return chainable;
            } else if (whereCallCount === 3) { // 3: select policies
                return Promise.resolve([
                    {
                        id: 'pol-1',
                        company: 'מגדל',
                        insuranceType: 'pension',
                        systemEntryDate: '2023-01-01',
                        initialAccumulation: '1000',
                        currentAccumulation: '1100',
                        lastCalculatedDate: '2023-05-01',
                        details: { accumulation: 1100 }
                    }
                ]);
            } else if (whereCallCount === 4) { // 4: update policies
                const chainable: any = Promise.resolve();
                chainable.returning = vi.fn(() => Promise.resolve([{ id: 'pol-1' }]));
                return chainable;
            } else { // 5: delete tracks
                return Promise.resolve();
            }
        });

        const response = await supertest(app.server)
            .put('/cust-123')
            .set('Authorization', 'Bearer valid')
            .send({
                customer: {
                    firstName: 'John',
                    surname: 'Doe',
                    governmentId: '123456789'
                },
                policies: [
                    { 
                        id: 'pol-1', 
                        company: 'מגדל', 
                        insuranceType: 'pension', 
                        details: { accumulation: 2000 } 
                    }
                ]
            });
        
        if (response.status !== 200) console.log(response.body);
        expect(response.status).toBe(200);
        expect(response.body).toEqual({ status: 'success' });
        
        // Assert that the logic preserves systemEntryDate and updates accumulation tracking
        expect(mockTx.update).toHaveBeenCalled();
        expect(mockTx.set).toHaveBeenCalledWith(expect.objectContaining({
            currentAccumulation: '2000',
            initialAccumulation: '2000',
        }));
    });

    it('returns 401 if missing user ID', async () => {
        const response = await supertest(app.server)
            .put('/cust-123')
            .send({
                customer: { firstName: 'John', surname: 'Doe', governmentId: '123' },
                policies: []
            });
        expect(response.status).toBe(401);
    });

    it('returns 404 if customer not found', async () => {
        let whereCallCount = 0;
        mockTx.where.mockImplementation(() => {
            whereCallCount++;
            if (whereCallCount === 1) { // check ownership
                const chainable: any = Promise.resolve([]);
                chainable.limit = vi.fn(() => Promise.resolve([]));
                return chainable;
            }
            return Promise.resolve();
        });

        const response = await supertest(app.server)
            .put('/cust-123')
            .set('Authorization', 'Bearer valid')
            .send({
                customer: { firstName: 'John', surname: 'Doe', governmentId: '123' },
                policies: []
            });
        
        expect(response.status).toBe(404);
    });

    it('inserts tracks when policy has investmentTracks', async () => {
        let whereCallCount = 0;
        mockTx.where.mockImplementation(() => {
            whereCallCount++;
            if (whereCallCount === 1) { // check ownership
                const chainable: any = Promise.resolve([{ id: 'cust-123' }]);
                chainable.limit = vi.fn(() => Promise.resolve([{ id: 'cust-123' }]));
                return chainable;
            } else if (whereCallCount === 2) { // update customer
                const chainable: any = Promise.resolve();
                chainable.returning = vi.fn(() => Promise.resolve([{ id: 'updated-123' }]));
                return chainable;
            } else if (whereCallCount === 3) { // select policies
                return Promise.resolve([]);
            }
            return Promise.resolve();
        });

        mockTx.insert.mockReturnThis();
        mockTx.returning.mockResolvedValue([{ id: 'new-pol-1' }]);

        const response = await supertest(app.server)
            .put('/cust-123')
            .set('Authorization', 'Bearer valid')
            .send({
                customer: { firstName: 'John', surname: 'Doe', governmentId: '123' },
                policies: [
                    {
                        company: 'מגדל',
                        insuranceType: 'pension',
                        details: {
                            investmentTracks: [
                                { fundId: 'f1', weight: 50, trackName: 'S1;P 500' },
                                { trackName: 'Missing Fund ID' } // Should be skipped
                            ]
                        }
                    }
                ]
            });

        expect(response.status).toBe(200);
        expect(mockTx.insert).toHaveBeenCalled();
        expect(mockTx.values).toHaveBeenCalledWith(expect.arrayContaining([
            expect.objectContaining({ fundId: 'f1', trackName: 'S&P 500', sharePercentage: '0.5' })
        ]));
    });

    it('preserves initial accumulation if accumulation did not change', async () => {
        let whereCallCount = 0;
        mockTx.where.mockImplementation(() => {
            whereCallCount++;
            if (whereCallCount === 1) { // check ownership
                const chainable: any = Promise.resolve([{ id: 'cust-123' }]);
                chainable.limit = vi.fn(() => Promise.resolve([{ id: 'cust-123' }]));
                return chainable;
            } else if (whereCallCount === 2) { // update customer
                const chainable: any = Promise.resolve();
                chainable.returning = vi.fn(() => Promise.resolve([{ id: 'updated-123' }]));
                return chainable;
            } else if (whereCallCount === 3) { // select policies
                return Promise.resolve([
                    {
                        id: 'pol-1',
                        company: 'מגדל',
                        insuranceType: 'pension',
                        initialAccumulation: '1000',
                        currentAccumulation: '1100',
                        lastCalculatedDate: '2023-05-01',
                        details: { accumulation: '1100', monthlyDeposit: '100' }
                    }
                ]);
            } else if (whereCallCount === 4) { // 4: update policies
                const chainable: any = Promise.resolve();
                chainable.returning = vi.fn(() => Promise.resolve([{ id: 'pol-1' }]));
                return chainable;
            }
            return Promise.resolve();
        });

        const response = await supertest(app.server)
            .put('/cust-123')
            .set('Authorization', 'Bearer valid')
            .send({
                customer: { firstName: 'John', surname: 'Doe', governmentId: '123' },
                policies: [
                    {
                        id: 'pol-1',
                        company: 'מגדל',
                        insuranceType: 'pension',
                        details: { accumulation: '1100', monthlyDeposit: '200' } // Deposits changed
                    }
                ]
            });

        expect(response.status).toBe(200);
        expect(mockTx.set).toHaveBeenCalledWith(expect.objectContaining({
            initialAccumulation: '1000',
            currentAccumulation: '1100',
            lastCalculatedDate: expect.any(String) // Should update due to deposit change
        }));
    });

    it('deletes policies that are not in incoming payload', async () => {
         let whereCallCount = 0;
         mockTx.where.mockImplementation(() => {
             whereCallCount++;
             if (whereCallCount === 1) { // check ownership
                 const chainable: any = Promise.resolve([{ id: 'cust-123' }]);
                 chainable.limit = vi.fn(() => Promise.resolve([{ id: 'cust-123' }]));
                 return chainable;
             } else if (whereCallCount === 2) { // update customer
                 const chainable: any = Promise.resolve();
                 chainable.returning = vi.fn(() => Promise.resolve([{ id: 'updated-123' }]));
                 return chainable;
             } else if (whereCallCount === 3) { // select policies
                 return Promise.resolve([{ id: 'pol-to-delete' }]);
             }
             return Promise.resolve();
         });

        const response = await supertest(app.server)
            .put('/cust-123')
            .set('Authorization', 'Bearer valid')
            .send({
                customer: { firstName: 'John', surname: 'Doe', governmentId: '123' },
                policies: [] // Empty means delete existing
            });

        expect(response.status).toBe(200);
        expect(mockTx.delete).toHaveBeenCalled();

    });
});
