import { and, eq } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { StatusCodes } from 'http-status-codes';
import z from 'zod';
import { db } from '../../db/connection.js';
import { customers, policies, policyTracks } from '../../db/schema.js';
import { AppError } from '../../errors/AppError.js';
import { commonErrorResponses, SuccessStatusSchema } from '../../errors/errorSchema.js';
import { createCustomerSchema, scrubPolicies } from './schemas.js';


export default async function createCustomerRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.post(
        '/',
        {
            preHandler: [fastify.authenticate],
            schema: {
                body: createCustomerSchema,
                response: {
                    200: SuccessStatusSchema.extend({ customerId: z.string() }),
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            if (!db) {
                throw new AppError('Database not ready', StatusCodes.SERVICE_UNAVAILABLE);
            }

            const authPayload = request.user as { userId?: string; id?: string };
            const userId = authPayload.userId || authPayload.id;

            if (!userId) {
                throw new AppError('Unauthorized: Missing user ID', StatusCodes.UNAUTHORIZED);
            }

            const { customer, policies: incomingPolicies } = request.body;

            // 1. Data Transformation: Name Concatenation
            const fullName = `${customer.firstName.trim()} ${customer.surname.trim()}`;

            // 2. Data Scrubbing (The "Zero-Bloat" Rule)
            const scrubbedPolicies = scrubPolicies(incomingPolicies);

            // 3. Database Transaction
            const customerId = await db.transaction(async (tx: any) => {
                // 4. Customer Find-or-Create Logic
                let existingCustomer = await tx
                    .select()
                    .from(customers)
                    .where(
                        and(
                            eq(customers.userId, userId),
                            eq(customers.governmentId, customer.governmentId),
                        ),
                    )
                    .limit(1);

                let targetCustomerId: string;

                if (existingCustomer.length > 0) {
                    throw new AppError(
                        'לקוח עם תעודת זהות זו כבר קיים במערכת',
                        StatusCodes.CONFLICT,
                    );
                }

                const inserted = await tx
                    .insert(customers)
                    .values({
                        userId: userId,
                        name: fullName,
                        governmentId: customer.governmentId,
                        issueDate: customer.issueDate || undefined,
                        familyMembers: request.body.familyMembers || [],
                        creationType: customer.creationType,
                    })
                    .returning({ id: customers.id });
                targetCustomerId = inserted[0].id;

                // 5. Policy Bulk Insertion
                if (scrubbedPolicies.length > 0) {
                    const todayStr = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
                    const policiesToInsert = scrubbedPolicies.map((p) => {
                        const det = p.details as Record<string, any>;
                        const accumulation = det?.accumulation
                            ? parseFloat(det.accumulation)
                            : null;

                        return {
                            customerId: targetCustomerId,
                            company: p.company,
                            insuranceType: p.insuranceType,
                            issueDate: p.issueDate,
                            details: p.details,
                            fixedCommissionRate: p.fixedCommissionRate,
                            // Auto-populate accumulation tracking fields
                            systemEntryDate: todayStr,
                            ...(accumulation && !isNaN(accumulation)
                                ? {
                                      initialAccumulation: String(accumulation),
                                      currentAccumulation: String(accumulation),
                                      lastCalculatedDate: todayStr,
                                  }
                                : {}),
                        };
                    });

                    const insertedPolicies = await tx
                        .insert(policies)
                        .values(policiesToInsert)
                        .returning({ id: policies.id, details: policies.details, company: policies.company });

                    // 6. policy_tracks insertion — extracted from details.investmentTracks
                    const tracksToInsert: {
                        policyId: string;
                        fundId: number;
                        sharePercentage: string;
                        trackName: string;
                    }[] = [];

                    for (const inserted of insertedPolicies) {
                        const det = inserted.details as Record<string, any>;
                        const investmentTracks: { trackName: string; weight: number; fundId?: number }[] =
                            det?.investmentTracks || [];

                        for (const track of investmentTracks) {
                            const fundId = track.fundId;
                            
                            if (!fundId) {
                                // No fund ID mapped yet — skip, yield will be 0 for this track
                                console.warn(
                                    `[policyTracks] Track "${track.trackName}" could not be resolved to a fundId — skipping yield lookup.`,
                                );
                                continue;
                            }
                            tracksToInsert.push({
                                policyId: inserted.id,
                                fundId: fundId,
                                sharePercentage: String((track.weight || 0) / 100),
                                trackName: track.trackName?.replace(/S1;P/gi, 'S&P'),
                            });
                        }
                    }

                    if (tracksToInsert.length > 0) {
                        await tx.insert(policyTracks).values(tracksToInsert);
                    }
                }

                return targetCustomerId;
            });

            return { status: 'success' as const, customerId };
        },
    );
}
