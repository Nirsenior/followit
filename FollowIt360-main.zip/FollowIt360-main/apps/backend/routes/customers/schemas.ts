import z from 'zod';
import { companyEnum, insuranceTypeEnum } from '../../db/schema.js';

export const policySchema = z.object({
    id: z.string().optional(),
    company: z.enum(companyEnum.enumValues as [string, ...string[]]),
    insuranceType: z.enum(insuranceTypeEnum.enumValues as [string, ...string[]]),
    issueDate: z.string().optional(),
    isAgentAppointmentOnly: z.boolean().optional(),
    details: z.any().optional().default({}),
    fixedCommissionRate: z.string().optional(),
    systemEntryDate: z.string().optional(),
    initialAccumulation: z.string().optional(),
    lastCalculatedDate: z.string().optional(),
    currentAccumulation: z.string().optional(),
});

export const createCustomerSchema = z.object({
    customer: z.object({
        firstName: z.string().min(1),
        surname: z.string().min(1),
        governmentId: z.string().min(1),
        issueDate: z.string().optional(),
        creationType: z.enum(['existing', 'new_production']).optional().default('existing'),
    }),
    policies: z.array(policySchema),
    familyMembers: z.array(z.any()).optional().default([]), // Adding unstructured JSON for now to safely catch the frontend schema
});

/**
 * Scrubs zero/empty values from policy details to prevent bloated records.
 * Preserves the isAgentAppointmentOnly flag in details if set.
 */
export function scrubPolicies(incomingPolicies: z.infer<typeof createCustomerSchema>['policies']) {
    return incomingPolicies.map((policy) => {
        const scrubbedDetails: Record<string, any> = {};
        if (policy.details) {
            for (const [key, value] of Object.entries(policy.details)) {
                if (
                    value !== 0 &&
                    value !== '0' &&
                    value !== '' &&
                    value !== null &&
                    value !== undefined
                ) {
                    scrubbedDetails[key] = value;
                }
            }
        }
        if (policy.isAgentAppointmentOnly) {
            scrubbedDetails.isAgentAppointmentOnly = true;
        }

        return {
            id: (policy as any).id,
            company: policy.company,
            insuranceType: policy.insuranceType,
            issueDate: policy.issueDate || undefined,
            details: scrubbedDetails,
            fixedCommissionRate: policy.fixedCommissionRate,
            systemEntryDate: (policy as any).systemEntryDate,
            initialAccumulation: (policy as any).initialAccumulation,
            lastCalculatedDate: (policy as any).lastCalculatedDate,
            currentAccumulation: (policy as any).currentAccumulation,
        };
    });
}
