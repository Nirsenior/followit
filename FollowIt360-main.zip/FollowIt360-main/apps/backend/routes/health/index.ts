import { FastifyInstance } from 'fastify';
import checkHealthRoute from './checkHealth.js';

export default async function healthRoutes(fastify: FastifyInstance) {
    await fastify.register(checkHealthRoute);
}
