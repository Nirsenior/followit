import Fastify from 'fastify';
import supertest from 'supertest';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import healthRoutes from './index.js';

let mockDb: any;

vi.mock('../../db/connection.js', () => ({
    get db() {
        return mockDb;
    }
}));

describe('GET /health', () => {
    let app: ReturnType<typeof Fastify>;

    beforeAll(async () => {
        app = Fastify();
        await app.register(healthRoutes);
        await app.ready();
    });

    afterAll(async () => {
        await app.close();
    });

    it('returns 200 OK and payload structure with mocked database', async () => {
        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            limit: vi.fn().mockResolvedValue([{ id: 1, status: 'mock_ok' }])
        };
        const response = await supertest(app.server).get('/health');
        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('status', 'ok');
        expect(response.body).toHaveProperty('check');
        expect(response.body.check).toEqual([{ id: 1, status: 'mock_ok' }]);
    });

    it('throws AppError if database is not ready', async () => {
        mockDb = undefined;
        const response = await supertest(app.server).get('/health');
        expect(response.status).toBe(503);
        expect(response.body.message).toBe('Database is connecting in background');
    });
});
