import { FastifyInstance } from 'fastify';
import { StatusCodes } from 'http-status-codes';
import { db } from '../../db/connection.js';
import { healthCheck } from '../../db/schema.js';
import { AppError } from '../../errors/AppError.js';

export default async function checkHealthRoute(fastify: FastifyInstance) {
    fastify.get('/health', async (request, reply) => {
        if (!db) {
            throw new AppError(
                'Database is connecting in background',
                StatusCodes.SERVICE_UNAVAILABLE,
            );
        }

        const result = await db.select().from(healthCheck).limit(1);
        return { status: 'ok', database: process.env.DB_NAME, check: result };
    });
}
