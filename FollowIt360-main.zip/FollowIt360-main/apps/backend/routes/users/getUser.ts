import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { StatusCodes } from 'http-status-codes';
import z from 'zod';
import { db } from '../../db/connection.js';
import { users } from '../../db/schema.js';
import { AppError } from '../../errors/AppError.js';
import { commonErrorResponses } from '../../errors/errorSchema.js';

const UserSchema = z.object({
    id: z.string(),
    name: z.string(),
    email: z.string().email(),
    phone: z.string().nullable().optional(),
});

export default async function getUserRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.get(
        '/user',
        {
            schema: {
                response: {
                    200: UserSchema,
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            if (!db) {
                throw new AppError('Database not ready', StatusCodes.SERVICE_UNAVAILABLE);
            }

            const dbUsers = await db.select().from(users).limit(1);
            if (dbUsers.length > 0) {
                return {
                    id: dbUsers[0].id,
                    name: dbUsers[0].name,
                    email: dbUsers[0].email,
                    phone: dbUsers[0].phone ?? null,
                };
            }

            throw new AppError('No users found in database', StatusCodes.NOT_FOUND);
        },
    );
}
