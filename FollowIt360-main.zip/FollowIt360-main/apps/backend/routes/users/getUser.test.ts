import Fastify from 'fastify';
import supertest from 'supertest';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { serializerCompiler, validatorCompiler, ZodTypeProvider } from 'fastify-type-provider-zod';
import userRoutes from './index.js';

let mockDb: any;

vi.mock('../../db/connection.js', () => ({
    get db() {
        return mockDb;
    }
}));

describe('GET /user', () => {
    let app: any;

    beforeAll(async () => {
        app = Fastify().withTypeProvider<ZodTypeProvider>();
        app.setValidatorCompiler(validatorCompiler);
        app.setSerializerCompiler(serializerCompiler);

        app.decorate('authenticate', async () => {});

        await app.register(userRoutes);
        await app.ready();
    });

    afterAll(async () => {
        await app.close();
    });

    it('returns 200 OK and the first user if users exist in the database', async () => {
        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            limit: vi.fn().mockResolvedValue([{ id: 'user-123', name: 'John Doe', email: 'john@example.com', phone: null }])
        };
        const response = await supertest(app.server).get('/user');
        expect(response.status).toBe(200);
        expect(response.body).toEqual({
            id: 'user-123',
            name: 'John Doe',
            email: 'john@example.com',
            phone: null
        });
    });

    it('returns 404 NOT FOUND if database is empty', async () => {
        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            limit: vi.fn().mockResolvedValue([])
        };
        const response = await supertest(app.server).get('/user');
        expect(response.status).toBe(404);
        expect(response.body.message).toBe('No users found in database');
    });

    it('throws AppError if database is not ready', async () => {
        mockDb = undefined;
        const response = await supertest(app.server).get('/user');
        expect(response.status).toBe(503);
        expect(response.body.message).toBe('Database not ready');
    });
});
