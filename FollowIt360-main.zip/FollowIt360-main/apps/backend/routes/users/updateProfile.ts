import { eq } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { StatusCodes } from 'http-status-codes';
import z from 'zod';
import { db } from '../../db/connection.js';
import { users } from '../../db/schema.js';
import { AppError } from '../../errors/AppError.js';
import { commonErrorResponses, SuccessStatusSchema } from '../../errors/errorSchema.js';

const UpdateProfileSchema = z.object({
    name: z.string().min(1, 'Name is required'),
    email: z.string().email('Invalid email address'),
    phone: z.string().optional().nullable(),
});

export default async function updateProfileRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.put(
        '/api/users/profile',
        {
            preHandler: [fastify.authenticate],
            schema: {
                body: UpdateProfileSchema,
                response: {
                    200: SuccessStatusSchema,
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            if (!db) {
                throw new AppError('Database not ready', StatusCodes.SERVICE_UNAVAILABLE);
            }

            const payload = request.user as { userId: string };
            const { name, email, phone } = request.body;

            // Check if email is already taken by another user
            const existingUserWithEmail = await db
                .select()
                .from(users)
                .where(eq(users.email, email))
                .limit(1);

            if (existingUserWithEmail.length > 0 && existingUserWithEmail[0].id !== payload.userId) {
                throw new AppError('Email is already in use by another account', StatusCodes.CONFLICT);
            }

            await db
                .update(users)
                .set({
                    name,
                    email,
                    phone: phone || null,
                })
                .where(eq(users.id, payload.userId));

            return { status: 'success' as const };
        },
    );
}
