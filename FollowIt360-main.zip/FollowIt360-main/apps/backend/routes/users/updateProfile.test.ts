import Fastify from 'fastify';
import supertest from 'supertest';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { serializerCompiler, validatorCompiler, ZodTypeProvider } from 'fastify-type-provider-zod';
import userRoutes from './index.js';

let mockDb: any;

vi.mock('../../db/connection.js', () => ({
    get db() {
        return mockDb;
    }
}));

describe('PUT /api/users/profile', () => {
    let app: any;

    beforeAll(async () => {
        app = Fastify().withTypeProvider<ZodTypeProvider>();
        app.setValidatorCompiler(validatorCompiler);
        app.setSerializerCompiler(serializerCompiler);

        // Mock authenticate decorator
        app.decorate('authenticate', async (request: any, reply: any) => {
            const authHeader = request.headers['authorization'];
            if (authHeader === 'Bearer valid-token') {
                request.user = { userId: 'user-123' };
            } else {
                reply.status(401).send({ status: 'error', message: 'Unauthorized' });
            }
        });

        await app.register(userRoutes);
        await app.ready();
    });

    afterAll(async () => {
        await app.close();
    });

    it('returns 200 OK and updates profile if body is valid and email is not taken', async () => {
        mockDb = {
            select: vi.fn().mockReturnValue({
                from: vi.fn().mockReturnValue({
                    where: vi.fn().mockReturnValue({
                        limit: vi.fn().mockResolvedValue([]) // No existing user with this email
                    })
                })
            }),
            update: vi.fn().mockReturnValue({
                set: vi.fn().mockReturnValue({
                    where: vi.fn().mockResolvedValue({ status: 'success' })
                })
            })
        };

        const response = await supertest(app.server)
            .put('/api/users/profile')
            .set('Authorization', 'Bearer valid-token')
            .send({
                name: 'Jane Doe',
                email: 'jane@example.com',
                phone: '050-1234567'
            });

        expect(response.status).toBe(200);
        expect(response.body).toEqual({ status: 'success' });
        expect(mockDb.update).toHaveBeenCalled();
    });

    it('returns 409 Conflict if email is taken by another user', async () => {
        mockDb = {
            select: vi.fn().mockReturnValue({
                from: vi.fn().mockReturnValue({
                    where: vi.fn().mockReturnValue({
                        limit: vi.fn().mockResolvedValue([{ id: 'other-user', email: 'jane@example.com' }])
                    })
                })
            })
        };

        const response = await supertest(app.server)
            .put('/api/users/profile')
            .set('Authorization', 'Bearer valid-token')
            .send({
                name: 'Jane Doe',
                email: 'jane@example.com',
                phone: '050-1234567'
            });

        expect(response.status).toBe(409);
        expect(response.body.message).toBe('Email is already in use by another account');
    });

    it('returns 401 Unauthorized if token is missing', async () => {
        const response = await supertest(app.server)
            .put('/api/users/profile')
            .send({
                name: 'Jane Doe',
                email: 'jane@example.com',
                phone: '050-1234567'
            });

        expect(response.status).toBe(401);
        expect(response.body.message).toBe('Unauthorized');
    });
});
