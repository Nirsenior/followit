import { FastifyInstance } from 'fastify';
import getUserRoute from './getUser.js';
import updateProfileRoute from './updateProfile.js';

export default async function userRoutes(fastify: FastifyInstance) {
    await fastify.register(getUserRoute);
    await fastify.register(updateProfileRoute);
}
