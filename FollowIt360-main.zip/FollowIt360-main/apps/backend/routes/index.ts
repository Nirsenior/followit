import agreementsRoutes from './agreements/index.js';
import authRoutes from './auth/index.js';
import customersRoutes from './customers/index.js';
import healthRoutes from './health/index.js';
import leadsRoutes from './leads/index.js';
import userRoutes from './users/index.js';
import yieldsRoute from './yields/index.js';

export { agreementsRoutes, authRoutes, customersRoutes, healthRoutes, leadsRoutes, userRoutes, yieldsRoute };
