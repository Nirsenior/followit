import Fastify from 'fastify';
import supertest from 'supertest';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { serializerCompiler, validatorCompiler, ZodTypeProvider } from 'fastify-type-provider-zod';
import postVisitRoute from './postVisit.js';

let mockDb: any;

vi.mock('../../db/connection.js', () => ({
    get db() {
        return mockDb;
    }
}));

describe('POST /visit', () => {
    let app: any;

    beforeAll(async () => {
        app = Fastify().withTypeProvider<ZodTypeProvider>();
        app.setValidatorCompiler(validatorCompiler);
        app.setSerializerCompiler(serializerCompiler);

        await app.register(postVisitRoute);
        await app.ready();
    });

    afterAll(async () => {
        await app.close();
    });

    it('successfully records a page visit', async () => {
        mockDb = {
            insert: vi.fn().mockReturnValue({
                values: vi.fn().mockReturnValue({
                    onConflictDoUpdate: vi.fn().mockResolvedValue({})
                })
            })
        };

        const response = await supertest(app.server)
            .post('/visit')
            .send({ path: '/dashboard' });
        
        expect(response.status).toBe(200);
        expect(response.body).toEqual({ status: 'success' });
        expect(mockDb.insert).toHaveBeenCalled();
    });

    it('returns 200 success even if the database fails', async () => {
        mockDb = {
            insert: vi.fn().mockReturnValue({
                values: vi.fn().mockReturnValue({
                    onConflictDoUpdate: vi.fn().mockRejectedValue(new Error('DB Error'))
                })
            })
        };

        const response = await supertest(app.server)
            .post('/visit')
            .send({ path: '/journal' });
        
        expect(response.status).toBe(200);
        expect(response.body).toEqual({ status: 'success' });
    });

});
