import { FastifyInstance } from 'fastify';
import postVisitRoute from './postVisit.js';

export default async function analyticsRoutes(fastify: FastifyInstance) {
    await fastify.register(postVisitRoute);
}
