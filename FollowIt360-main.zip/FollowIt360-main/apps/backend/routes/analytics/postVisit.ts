import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';
import { db } from '../../db/connection.js';
import { dailyPageVisits } from '../../db/schema.js';
import { commonErrorResponses } from '../../errors/errorSchema.js';
import { sql } from 'drizzle-orm';

export default async function postVisitRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.post(
        '/visit',
        {
            schema: {
                body: z.object({
                    path: z.string(),
                }),
                response: {
                    200: z.object({
                        status: z.string(),
                    }),
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            const { path } = request.body;
            
            // Get today's date formatted as YYYY-MM-DD
            const today = new Date().toISOString().split('T')[0];

            try {
                // UPSERT logic: insert new row, or increment visitCount if it exists
                await db.insert(dailyPageVisits)
                    .values({
                        date: today,
                        path: path,
                        visitCount: 1,
                    })
                    .onConflictDoUpdate({
                        target: [dailyPageVisits.date, dailyPageVisits.path],
                        set: { visitCount: sql`${dailyPageVisits.visitCount} + 1` }
                    });
            } catch (error) {
                fastify.log.error(error);
                // We do not throw an error because analytics should fail silently without affecting the user
            }

            return { status: 'success' };
        },
    );
}
