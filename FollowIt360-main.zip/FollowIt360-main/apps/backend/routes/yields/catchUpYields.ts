import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { StatusCodes } from 'http-status-codes';
import z from 'zod';
import { db } from '../../db/connection.js';
import { AppError } from '../../errors/AppError.js';
import { commonErrorResponses } from '../../errors/errorSchema.js';
import { runSmartCatchUp } from '../../services/yieldCalculationService.js';

export default async function catchUpYieldsRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.post(
        '/catch-up',
        {
            schema: {
                response: {
                    200: z.object({
                        status: z.string(),
                        resourcesProcessed: z.number().optional(),
                        policiesProcessed: z.number().optional(),
                        totalMonths: z.number().optional(),
                        elapsedSeconds: z.string().optional(),
                    }),
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            const cronSecret = process.env.CRON_SECRET;
            if (!cronSecret) {
                request.log.error('CRON_SECRET is not configured on the server');
                throw new AppError('Server misconfiguration', StatusCodes.INTERNAL_SERVER_ERROR);
            }

            const providedSecret = request.headers['x-cron-secret'];
            if (providedSecret !== cronSecret) {
                request.log.warn('Unauthorized attempt to trigger yield catch-up');
                throw new AppError('Unauthorized', StatusCodes.UNAUTHORIZED);
            }

            if (!db) {
                throw new AppError('Database not ready', StatusCodes.SERVICE_UNAVAILABLE);
            }

            const start = Date.now();
            request.log.info('[CatchUpYields Route] 🕐 Starting smart yield catch-up...');
            try {
                const result = await runSmartCatchUp(request.log);
                const elapsed = ((Date.now() - start) / 1000).toFixed(1);

                request.log.info(
                    { ...result, elapsedSeconds: elapsed },
                    '[CatchUpYields Route] ✅ Smart yield catch-up complete',
                );

                return {
                    status: 'success',
                    resourcesProcessed: result.resourcesProcessed,
                    policiesProcessed: result.policiesProcessed,
                    totalMonths: result.totalMonths,
                    elapsedSeconds: elapsed,
                };
            } catch (error) {
                request.log.error({ err: error }, '[CatchUpYields Route] ❌ Yield catch-up failed');
                throw new AppError('Internal Server Error', StatusCodes.INTERNAL_SERVER_ERROR);
            }
        },
    );
}
