import { InsuranceType } from '@repo/types';
import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import z from 'zod';
import { commonErrorResponses } from '../../errors/errorSchema.js';
import { fetchTracksForCompany } from '../../services/gemelNetService.js';

/**
 * GET /api/yields/tracks
 *
 * Fetches distinct investment tracks for a given company and insurance type.
 */
export default async function getTracksRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.get(
        '/tracks',
        {
            preHandler: [fastify.authenticate],
            schema: {
                querystring: z.object({
                    insuranceType: z.string(),
                    company: z.string(),
                }),
                response: {
                    200: z.array(
                        z.object({
                            trackName: z.string(),
                            fundId: z.number(),
                        })
                    ),
                    ...commonErrorResponses,
                },
            },
        },
        async (request) => {
            const { insuranceType, company } = request.query;
            request.log.info({ insuranceType, company }, '[Yields Route] 📥 Fetching tracks');
            
            const tracks = await fetchTracksForCompany(insuranceType as InsuranceType, company, request.log);
            return tracks;
        },
    );
}
