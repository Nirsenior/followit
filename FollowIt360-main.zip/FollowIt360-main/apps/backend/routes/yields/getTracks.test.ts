import Fastify from 'fastify';
import supertest from 'supertest';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { serializerCompiler, validatorCompiler, ZodTypeProvider } from 'fastify-type-provider-zod';
import * as gemelNetService from '../../services/gemelNetService.js';
import getTracksRoute from './getTracks.js';

vi.mock('../../services/gemelNetService.js', async () => {
    const actual = await vi.importActual('../../services/gemelNetService.js');
    return {
        ...actual,
        fetchTracksForCompany: vi.fn(),
    };
});

describe('GET /api/yields/tracks', () => {
    let app: ReturnType<typeof Fastify>;

    beforeAll(async () => {
        app = Fastify().withTypeProvider<ZodTypeProvider>();
        app.setValidatorCompiler(validatorCompiler);
        app.setSerializerCompiler(serializerCompiler);
        // Mock the authenticate decorator
        app.decorate('authenticate', async () => {});
        await app.register(getTracksRoute, { prefix: '/api/yields' });
        await app.ready();
    });

    afterAll(async () => {
        await app.close();
    });

    beforeEach(() => {
        vi.clearAllMocks();
    });

    it('should return tracks for valid insuranceType and company', async () => {
        const mockTracks = [
            { trackName: 'Fund A', fundId: 101 },
            { trackName: 'Fund B', fundId: 102 },
        ];
        vi.mocked(gemelNetService.fetchTracksForCompany).mockResolvedValue(mockTracks);

        const response = await supertest(app.server)
            .get('/api/yields/tracks')
            .query({ insuranceType: 'pension', company: 'הראל' });

        expect(response.status).toBe(200);
        expect(response.body).toEqual(mockTracks);
        expect(gemelNetService.fetchTracksForCompany).toHaveBeenCalledWith('pension', 'הראל', expect.anything());
    });

    it('should return 500 (validation error) if insuranceType is missing', async () => {
        const response = await supertest(app.server)
            .get('/api/yields/tracks')
            .query({ company: 'הראל' });

        expect(response.status).toBe(500);
    });

    it('should return 500 (validation error) if company is missing', async () => {
        const response = await supertest(app.server)
            .get('/api/yields/tracks')
            .query({ insuranceType: 'pension' });

        expect(response.status).toBe(500);
    });
});
