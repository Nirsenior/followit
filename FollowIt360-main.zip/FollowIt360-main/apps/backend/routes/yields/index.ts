import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { StatusCodes } from 'http-status-codes';
import z from 'zod';
import { db } from '../../db/connection.js';
import { AppError } from '../../errors/AppError.js';
import { commonErrorResponses } from '../../errors/errorSchema.js';
import { currentReportPeriod, getWeightedYieldForPolicy } from '../../services/gemelNetService.js';
import catchUpYieldsRoute from './catchUpYields.js';
import getTracksRoute from './getTracks.js';

/**
 * GET /api/yields/:policyId/:period
 *
 * Returns the weighted monthly yield (as a decimal) for a specific policy
 * and report period (YYYYMM). If :period is omitted or 'current', uses
 * the current month.
 *
 * Response: { policyId, period, weightedYield }
 */
export default async function yieldsRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    await server.register(catchUpYieldsRoute);
    await server.register(getTracksRoute);

    server.get(
        '/:policyId/:period',
        {
            preHandler: [fastify.authenticate],
            schema: {
                params: z.object({
                    policyId: z.string().uuid(),
                    period: z
                        .string()
                        .regex(/^\d{6}$/)
                        .optional(),
                }),
                response: {
                    200: z.object({
                        policyId: z.string(),
                        period: z.string(),
                        weightedYield: z.number(),
                    }),
                    ...commonErrorResponses,
                },
            },
        },
        async (request) => {
            request.log.info({ policyId: request.params.policyId }, '[Yields Route] 📥 Incoming request');
            if (!db) throw new AppError('Database not ready', StatusCodes.SERVICE_UNAVAILABLE);
            const { policyId, period } = request.params;
            const weightedYield = await getWeightedYieldForPolicy(policyId, period, request.log);
            return { policyId, period: period || 'latest', weightedYield: weightedYield ?? 0 };
        },
    );

    /**
     * GET /api/yields/:policyId
     * Convenience — uses current period automatically.
     */
    server.get(
        '/:policyId',
        {
            preHandler: [fastify.authenticate],
            schema: {
                params: z.object({
                    policyId: z.string().uuid(),
                }),
                response: {
                    200: z.object({
                        policyId: z.string(),
                        period: z.string(),
                        weightedYield: z.number(),
                    }),
                    ...commonErrorResponses,
                },
            },
        },
        async (request) => {
            request.log.info({ policyId: request.params.policyId }, '[Yields Route] 📥 Incoming request');
            if (!db) throw new AppError('Database not ready', StatusCodes.SERVICE_UNAVAILABLE);
            const { policyId } = request.params;
            const weightedYield = await getWeightedYieldForPolicy(policyId, undefined, request.log);
            return { policyId, period: 'latest', weightedYield: weightedYield ?? 0 };
        },
    );
}
