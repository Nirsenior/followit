import { LoginRequest, loginRequestSchema } from '@repo/types';
import bcrypt from 'bcryptjs';
import { and, eq } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { StatusCodes } from 'http-status-codes';
import z from 'zod';
import { db } from '../../db/connection.js';
import { agreements, userRoles, users } from '../../db/schema.js';
import { AppError } from '../../errors/AppError.js';
import { commonErrorResponses } from '../../errors/errorSchema.js';

export default async function loginRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.post(
        '/login',
        {
            config: {
                rateLimit: {
                    max: 10,
                    timeWindow: '1 minute',
                },
            },
            schema: {
                body: loginRequestSchema,
                response: {
                    200: z.object({
                        userId: z.string(),
                        name: z.string(),
                        email: z.string(),
                        phone: z.string().nullable().optional(),
                        isAdmin: z.boolean().optional(),
                        agreements: z.array(
                            z.object({
                                company: z.string(),
                                rates: z.any(),
                            }),
                        ),
                    }),
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            const proto = request.headers['x-forwarded-proto'] || request.protocol;
            if (proto !== 'https' && process.env.NODE_ENV === 'production') {
                throw new AppError('HTTPS is required', StatusCodes.BAD_REQUEST);
            }

            if (!db) {
                throw new AppError('Database not ready', StatusCodes.SERVICE_UNAVAILABLE);
            }

            const { email, password } = request.body as LoginRequest;

            const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);

            if (!user) {
                throw new AppError('Invalid email or password', StatusCodes.UNAUTHORIZED);
            }

            // OAuth-only users have no password — direct them to Google sign-in
            if (!user.password) {
                throw new AppError(
                    "This account uses Google sign-in. Please click 'Continue with Google'",
                    StatusCodes.UNAUTHORIZED,
                );
            }

            const isPasswordValid = await bcrypt.compare(password, user.password);

            if (!isPasswordValid) {
                throw new AppError('Invalid email or password', StatusCodes.UNAUTHORIZED);
            }

            const token = fastify.jwt.sign({ userId: user.id });

            const [userAgreements, adminRole] = await Promise.all([
                db
                    .select({
                        company: agreements.company,
                        rates: agreements.rates,
                    })
                    .from(agreements)
                    .where(eq(agreements.userId, user.id)),
                db.select().from(userRoles).where(and(eq(userRoles.userId, user.id), eq(userRoles.role, 'ADMIN'))).limit(1),
            ]);

            const isSecure =
                request.protocol === 'https' ||
                request.headers['x-forwarded-proto'] === 'https' ||
                process.env.NODE_ENV === 'production';
            reply.setCookie('__session', token, {
                httpOnly: true,
                secure: isSecure,
                sameSite: isSecure ? 'none' : 'lax',
                path: '/',
                maxAge: 30 * 24 * 60 * 60, // 30 days
            });

            return {
                userId: user.id,
                name: user.name,
                email: user.email,
                phone: user.phone,
                isAdmin: adminRole.length > 0,
                agreements: userAgreements,
            };
        },
    );
}
