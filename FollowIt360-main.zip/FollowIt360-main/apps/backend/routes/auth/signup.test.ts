import Fastify from 'fastify';
import supertest from 'supertest';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { serializerCompiler, validatorCompiler, ZodTypeProvider } from 'fastify-type-provider-zod';
import signupRoute from './signup.js';
import rateLimit from '@fastify/rate-limit';

let mockDb: any;
let mockBcryptHash = vi.fn();

vi.mock('../../db/connection.js', () => ({
    get db() {
        return mockDb;
    }
}));

vi.mock('bcryptjs', () => ({
    default: {
        hash: (...args: any[]) => mockBcryptHash(...args)
    }
}));

describe('POST /auth/signup', () => {
    let app: any;

    beforeAll(async () => {
        app = Fastify().withTypeProvider<ZodTypeProvider>();
        app.setValidatorCompiler(validatorCompiler);
        app.setSerializerCompiler(serializerCompiler);

        await app.register(import('@fastify/cookie'));
        await app.register(import('@fastify/jwt'), { secret: 'test-secret' });
        await app.register(rateLimit, { max: 100, timeWindow: '1 minute' });
        
        await app.register(signupRoute);
        await app.ready();
    });

    afterAll(async () => {
        await app.close();
    });

    it('returns 200 OK, creates user and sets session cookie', async () => {
        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            where: vi.fn().mockReturnThis(),
            limit: vi.fn().mockResolvedValue([]), // No existing user
            insert: vi.fn().mockReturnThis(),
            values: vi.fn().mockReturnThis(),
            returning: vi.fn().mockResolvedValue([{ id: 'new-user-123', email: 'new@example.com' }])
        };
        mockBcryptHash.mockResolvedValue('hashed-password');

        const response = await supertest(app.server)
            .post('/signup')
            .send({ name: 'New User', email: 'new@example.com', password: 'password123' });
        
        expect(response.status).toBe(200);
        expect(response.body).toEqual({ userId: 'new-user-123', email: 'new@example.com' });
        expect(response.headers['set-cookie']).toBeDefined();
    });

    it('returns 409 Conflict if email already exists', async () => {
        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            where: vi.fn().mockReturnThis(),
            limit: vi.fn().mockResolvedValue([{ id: 'existing' }]) // Simulates user exists
        };

        const response = await supertest(app.server)
            .post('/signup')
            .send({ name: 'Existing User', email: 'existing@example.com', password: 'password123' });
        
        expect(response.status).toBe(409);
        expect(response.body.message).toBe('Email already exists');
    });

    it('throws AppError if database is not ready', async () => {
        mockDb = undefined;
        const response = await supertest(app.server)
            .post('/signup')
            .send({ name: 'Test', email: 'test@example.com', password: 'password123' });
            
        expect(response.status).toBe(503);
        expect(response.body.message).toBe('Database not ready');
    });
});
