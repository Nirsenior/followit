import { SignupRequest, signupRequestSchema } from '@repo/types';
import bcrypt from 'bcryptjs';
import { eq } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { StatusCodes } from 'http-status-codes';
import z from 'zod';
import { db } from '../../db/connection.js';
import { users } from '../../db/schema.js';
import { AppError } from '../../errors/AppError.js';
import { commonErrorResponses } from '../../errors/errorSchema.js';

export default async function signupRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.post(
        '/signup',
        {
            config: {
                rateLimit: {
                    max: 5,
                    timeWindow: '1 minute',
                },
            },
            schema: {
                body: signupRequestSchema,
                response: {
                    200: z.object({ userId: z.string(), email: z.string() }),
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            // ... (existing signup logic) ...
            const proto = request.headers['x-forwarded-proto'] || request.protocol;
            if (proto !== 'https' && process.env.NODE_ENV === 'production') {
                throw new AppError('HTTPS is required', StatusCodes.BAD_REQUEST);
            }

            if (!db) {
                throw new AppError('Database not ready', StatusCodes.SERVICE_UNAVAILABLE);
            }

            const { name, email, password } = request.body as SignupRequest;

            const existingUsers = await db
                .select()
                .from(users)
                .where(eq(users.email, email))
                .limit(1);
            if (existingUsers.length > 0) {
                throw new AppError('Email already exists', StatusCodes.CONFLICT);
            }

            const hashedPassword = await bcrypt.hash(password, 10);

            const [newUser] = await db
                .insert(users)
                .values({
                    name,
                    email,
                    password: hashedPassword,
                })
                .returning({ id: users.id, email: users.email });

            const token = fastify.jwt.sign({ userId: newUser.id });

            const isSecure =
                request.protocol === 'https' ||
                request.headers['x-forwarded-proto'] === 'https' ||
                process.env.NODE_ENV === 'production';
            reply.setCookie('__session', token, {
                httpOnly: true,
                secure: isSecure,
                sameSite: isSecure ? 'none' : 'lax',
                path: '/',
                maxAge: 30 * 24 * 60 * 60, // 30 days
            });

            return { userId: newUser.id, email: newUser.email };
        },
    );
}
