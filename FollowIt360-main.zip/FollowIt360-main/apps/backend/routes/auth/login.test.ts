import Fastify from 'fastify';
import supertest from 'supertest';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { serializerCompiler, validatorCompiler, ZodTypeProvider } from 'fastify-type-provider-zod';
import loginRoute from './login.js';
import rateLimit from '@fastify/rate-limit';

let mockDb: any;
let mockBcryptCompare = vi.fn();

vi.mock('../../db/connection.js', () => ({
    get db() {
        return mockDb;
    }
}));

vi.mock('bcryptjs', () => ({
    default: {
        compare: (...args: any[]) => mockBcryptCompare(...args)
    }
}));

describe('POST /auth/login', () => {
    let app: any;

    beforeAll(async () => {
        app = Fastify().withTypeProvider<ZodTypeProvider>();
        app.setValidatorCompiler(validatorCompiler);
        app.setSerializerCompiler(serializerCompiler);

        await app.register(import('@fastify/cookie'));
        await app.register(import('@fastify/jwt'), { secret: 'test-secret' });
        await app.register(rateLimit, { max: 100, timeWindow: '1 minute' }); // Requires rate limiting config
        
        await app.register(loginRoute);
        await app.ready();
    });

    afterAll(async () => {
        await app.close();
    });

    it('returns 200 OK, sets cookie and returns user if credentials are valid', async () => {
        const agreementResult = [{ company: 'MIGDAL', rates: { pension: { ongoing: '0.5%' } } }];
        const userResult = [{ id: 'user-123', name: 'John Doe', email: 'john@example.com', password: 'hashed', phone: null }];

        mockDb = {
            select: vi.fn().mockReturnValue({
                from: vi.fn().mockReturnValue({
                    where: vi.fn()
                        .mockImplementationOnce(() => ({
                            limit: vi.fn().mockResolvedValue(userResult)
                        }))
                        .mockResolvedValueOnce(agreementResult)
                        .mockImplementationOnce(() => ({
                            limit: vi.fn().mockResolvedValue([])
                        }))
                })
            })
        };
        mockBcryptCompare.mockResolvedValue(true);

        const response = await supertest(app.server)
            .post('/login')
            .send({ email: 'john@example.com', password: 'password123' });
        
        expect(response.status).toBe(200);
        expect(response.body).toEqual({
            userId: 'user-123',
            name: 'John Doe',
            email: 'john@example.com',
            phone: null,
            isAdmin: false,
            agreements: agreementResult
        });
        expect(response.headers['set-cookie']).toBeDefined();
        const sessionCookie = response.headers['set-cookie'].find((str: string) => str.includes('__session='));
        expect(sessionCookie).toBeTruthy();
    });

    it('returns 401 if user is not found', async () => {
        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            where: vi.fn().mockReturnThis(),
            limit: vi.fn().mockResolvedValue([])
        };

        const response = await supertest(app.server)
            .post('/login')
            .send({ email: 'missing@example.com', password: 'password123' });
        
        expect(response.status).toBe(401);
        expect(response.body.message).toBe('Invalid email or password');
    });

    it('returns 401 asking for Google login if user has no password', async () => {
        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            where: vi.fn().mockReturnThis(),
            limit: vi.fn().mockResolvedValue([{ id: 'user-123', name: 'Google User', email: 'google@example.com', password: null }])
        };

        const response = await supertest(app.server)
            .post('/login')
            .send({ email: 'google@example.com', password: 'password123' });
        
        expect(response.status).toBe(401);
        expect(response.body.message).toContain('This account uses Google sign-in');
    });

    it('returns 401 if password does not match', async () => {
        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            where: vi.fn().mockReturnThis(),
            limit: vi.fn().mockResolvedValue([{ id: 'user-123', name: 'John Doe', email: 'john@example.com', password: 'hashed' }])
        };
        mockBcryptCompare.mockResolvedValue(false);

        const response = await supertest(app.server)
            .post('/login')
            .send({ email: 'john@example.com', password: 'wrongpassword' });
        
        expect(response.status).toBe(401);
        expect(response.body.message).toBe('Invalid email or password');
    });

    it('throws AppError if database is not ready', async () => {
        mockDb = undefined;
        const response = await supertest(app.server)
            .post('/login')
            .send({ email: 'john@example.com', password: 'password123' });
            
        expect(response.status).toBe(503);
        expect(response.body.message).toBe('Database not ready');
    });
});
