import Fastify from 'fastify';
import supertest from 'supertest';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { serializerCompiler, validatorCompiler, ZodTypeProvider } from 'fastify-type-provider-zod';
import logoutRoute from './logout.js';

describe('POST /auth/logout', () => {
    let app: any;

    beforeAll(async () => {
        app = Fastify().withTypeProvider<ZodTypeProvider>();
        app.setValidatorCompiler(validatorCompiler);
        app.setSerializerCompiler(serializerCompiler);
        await app.register(import('@fastify/cookie'));
        await app.register(logoutRoute);
        await app.ready();
    });

    afterAll(async () => {
        await app.close();
    });

    it('returns 200 OK and clears the session cookie', async () => {
        const response = await supertest(app.server).post('/logout');
        
        expect(response.status).toBe(200);
        expect(response.body).toEqual({ status: 'success' });
        
        // Verify cookie is cleared
        const setCookieHeader = response.headers['set-cookie'];
        expect(setCookieHeader).toBeDefined();
        // The cookie string should have Max-Age or Expires set to past/0, and empty value.
        // Fastify reply.clearCookie('__session', { path: '/' }) sets it.
        const sessionCookie = setCookieHeader.find((str: string) => str.includes('__session=;'));
        expect(sessionCookie).toBeDefined();
        expect(sessionCookie).toMatch(/Max-Age=0|Expires=/i);
    });
});
