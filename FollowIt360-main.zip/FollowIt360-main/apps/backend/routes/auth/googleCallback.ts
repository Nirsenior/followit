import { eq } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import { db } from '../../db/connection.js';
import { users } from '../../db/schema.js';

export default async function googleCallbackRoute(fastify: FastifyInstance) {
    // --- Google OAuth Callback ---
    fastify.get('/google/callback', async (request, reply) => {
        fastify.log.info({
            msg: 'Google OAuth callback received',
            url: request.url,
            headers: request.headers,
            cookies: request.cookies,
            actualRequestHostname: request.hostname,
            protocol: request.protocol,
            ip: request.ip,
        });

        if (!db) {
            return reply.status(503).send({ status: 'error', message: 'Database not ready' });
        }

        try {
            // 1. Exchange the authorization code for an access token
            const tokenData = await (
                fastify as any
            ).googleOAuth2.getAccessTokenFromAuthorizationCodeFlow(request, reply);
            const accessToken = tokenData.token.access_token;

            // 2. Fetch the Google user profile
            const profileRes = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
                headers: { Authorization: `Bearer ${accessToken}` },
            });
            const profile = (await profileRes.json()) as {
                id: string;
                email: string;
                name: string;
            };

            const { id: googleId, email, name } = profile;

            // 3. Upsert: find by googleId OR email
            let user: typeof users.$inferSelect | undefined;
            const [byGoogleId] = await db
                .select()
                .from(users)
                .where(eq(users.googleId, googleId))
                .limit(1);
            if (byGoogleId) {
                user = byGoogleId;
            } else {
                const [byEmail] = await db
                    .select()
                    .from(users)
                    .where(eq(users.email, email))
                    .limit(1);
                if (byEmail) {
                    // Existing email/password user – attach googleId
                    const [updated] = await db
                        .update(users)
                        .set({ googleId })
                        .where(eq(users.id, byEmail.id))
                        .returning();
                    user = updated;
                }
            }

            const isNew = !user;
            if (!user) {
                // Brand new user – create record
                const [created] = await db
                    .insert(users)
                    .values({ name, email, googleId })
                    .returning();
                user = created;
            }

            // 4. Issue JWT session cookie
            const token = fastify.jwt.sign({ userId: user!.id });
            reply.setCookie('__session', token, {
                httpOnly: true,
                secure: true,
                sameSite: 'none',
                path: '/',
                maxAge: 30 * 24 * 60 * 60,
            });

            // 5. Redirect to the appropriate frontend page
            const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:5173';
            return reply.redirect(isNew ? `${frontendUrl}/onboarding` : `${frontendUrl}/dashboard`);
        } catch (err: any) {
            fastify.log.error({
                msg: 'Google OAuth callback failed',
                error: err?.message,
                stack: err?.stack,
                details: err?.data || err?.response?.data, // Common in OAuth libraries
            });
            const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:5173';
            return reply.redirect(`${frontendUrl}/?error=auth_failed`);
        }
    });
}
