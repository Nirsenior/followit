import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { commonErrorResponses, SuccessStatusSchema } from '../../errors/errorSchema.js';

export default async function logoutRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.post(
        '/logout',
        {
            schema: {
                response: {
                    200: SuccessStatusSchema,
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            const isSecure =
                request.protocol === 'https' ||
                request.headers['x-forwarded-proto'] === 'https' ||
                process.env.NODE_ENV === 'production';
            reply.clearCookie('__session', {
                path: '/',
                secure: isSecure,
                sameSite: isSecure ? 'none' : 'lax',
            });
            return { status: 'success' as const };
        },
    );
}
