import Fastify from 'fastify';
import supertest from 'supertest';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { serializerCompiler, validatorCompiler, ZodTypeProvider } from 'fastify-type-provider-zod';
import meRoute from './me.js';

let mockDb: any;

vi.mock('../../db/connection.js', () => ({
    get db() {
        return mockDb;
    }
}));

describe('GET /auth/me', () => {
    let app: any;

    beforeAll(async () => {
        app = Fastify().withTypeProvider<ZodTypeProvider>();
        app.setValidatorCompiler(validatorCompiler);
        app.setSerializerCompiler(serializerCompiler);

        // Mock authenticate decorator
        app.decorate('authenticate', async (request: any, reply: any) => {
            const authHeader = request.headers['authorization'];
            if (authHeader === 'Bearer valid-token') {
                request.user = { userId: 'user-123' };
            } else if (authHeader === 'Bearer invalid-user') {
                request.user = { userId: 'missing-user' };
            } else {
                reply.status(401).send({ status: 'error', message: 'Unauthorized' });
            }
        });

        await app.register(meRoute);
        await app.ready();
    });

    afterAll(async () => {
        await app.close();
    });

    it('returns 200 OK and user details when passing a valid token', async () => {
        const agreementResult = [{ company: 'Harel', rates: { pension: { scope: '1%' } } }];
        const userResult = [{ id: 'user-123', name: 'Auth User', email: 'auth@example.com', phone: null }];

        mockDb = {
            select: vi.fn().mockReturnValue({
                from: vi.fn().mockReturnValue({
                    where: vi.fn()
                        .mockImplementationOnce(() => ({
                            limit: vi.fn().mockResolvedValue(userResult)
                        }))
                        .mockResolvedValueOnce(agreementResult)
                        .mockImplementationOnce(() => ({
                            limit: vi.fn().mockResolvedValue([])
                        }))
                })
            })
        };

        const response = await supertest(app.server)
            .get('/me')
            .set('Authorization', 'Bearer valid-token');
        
        expect(response.status).toBe(200);
        expect(response.body).toEqual({
            userId: 'user-123',
            name: 'Auth User',
            email: 'auth@example.com',
            phone: null,
            isAdmin: false,
            agreements: agreementResult
        });
    });

    it('returns 401 Unauthorized when missing token', async () => {
        const response = await supertest(app.server).get('/me');
        expect(response.status).toBe(401);
        expect(response.body.message).toBe('Unauthorized');
    });

    it('returns 401 Unauthorized when the token user is deleted/not found', async () => {
        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            where: vi.fn().mockReturnThis(),
            limit: vi.fn().mockResolvedValue([])
        };
        const response = await supertest(app.server)
            .get('/me')
            .set('Authorization', 'Bearer invalid-user');
        
        expect(response.status).toBe(401);
        expect(response.body.message).toBe('User not found');
    });
});
