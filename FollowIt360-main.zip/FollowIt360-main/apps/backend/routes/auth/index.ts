import { FastifyInstance } from 'fastify';
import googleCallbackRoute from './googleCallback.js';
import loginRoute from './login.js';
import logoutRoute from './logout.js';
import meRoute from './me.js';
import signupRoute from './signup.js';

export default async function authRoutes(fastify: FastifyInstance) {
    await fastify.register(signupRoute);
    await fastify.register(loginRoute);
    await fastify.register(logoutRoute);
    await fastify.register(meRoute);
    await fastify.register(googleCallbackRoute);
}
