import { and, eq } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { StatusCodes } from 'http-status-codes';
import z from 'zod';
import { db } from '../../db/connection.js';
import { agreements, userRoles, users } from '../../db/schema.js';
import { AppError } from '../../errors/AppError.js';
import { commonErrorResponses } from '../../errors/errorSchema.js';

export default async function meRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.get(
        '/me',
        {
            preHandler: [fastify.authenticate],
            schema: {
                response: {
                    200: z.object({
                        userId: z.string(),
                        name: z.string(),
                        email: z.string(),
                        phone: z.string().nullable().optional(),
                        isAdmin: z.boolean().optional(),
                        agreements: z.array(
                            z.object({
                                company: z.string(),
                                rates: z.any(),
                            }),
                        ),
                    }),
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            const payload = request.user as { userId: string };

            const [user, userAgreements, adminRole] = await Promise.all([
                db.select().from(users).where(eq(users.id, payload.userId)).limit(1),
                db
                    .select({
                        company: agreements.company,
                        rates: agreements.rates,
                    })
                    .from(agreements)
                    .where(eq(agreements.userId, payload.userId)),
                db.select().from(userRoles).where(and(eq(userRoles.userId, payload.userId), eq(userRoles.role, 'ADMIN'))).limit(1),
            ]);

            if (!user[0]) {
                throw new AppError('User not found', StatusCodes.UNAUTHORIZED);
            }

            const userData = user[0];
            return {
                userId: userData.id,
                name: userData.name,
                email: userData.email,
                phone: userData.phone,
                isAdmin: adminRole.length > 0,
                agreements: userAgreements,
            };
        },
    );
}
