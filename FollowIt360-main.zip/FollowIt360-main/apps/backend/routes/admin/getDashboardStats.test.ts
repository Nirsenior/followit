import Fastify from 'fastify';
import { serializerCompiler, validatorCompiler, ZodTypeProvider } from 'fastify-type-provider-zod';
import supertest from 'supertest';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import getDashboardStatsRoute from './getDashboardStats.js';

let mockDb: any;

vi.mock('../../db/connection.js', () => ({
    get db() {
        return mockDb;
    },
}));

vi.mock('../../middlewares/admin.js', () => ({
    requireAdmin: async (request: any, reply: any) => {
        if (request.headers['x-admin'] !== 'true') {
            reply.status(403).send({ status: 'error', message: 'Forbidden' });
        }
    },
}));

describe('GET /dashboard-stats', () => {
    let app: any;

    beforeAll(async () => {
        app = Fastify().withTypeProvider<ZodTypeProvider>();
        app.setValidatorCompiler(validatorCompiler);
        app.setSerializerCompiler(serializerCompiler);

        app.decorate('authenticate', async (request: any, reply: any) => {
            const authHeader = request.headers['authorization'];
            if (authHeader === 'Bearer valid-token') {
                request.user = { userId: 'user-123' };
            } else {
                reply.status(401).send({ status: 'error', message: 'Unauthorized' });
            }
        });

        await app.register(getDashboardStatsRoute);
        await app.ready();
    });

    afterAll(async () => {
        await app.close();
    });

    it('returns dashboard stats for an admin', async () => {
        mockDb = {
            select: vi.fn().mockReturnValue({
                from: vi.fn().mockReturnValue({
                    where: vi.fn().mockResolvedValue([{ totalVisits: 45 }]),
                }),
            }),
        };

        const response = await supertest(app.server)
            .get('/dashboard-stats')
            .set('Authorization', 'Bearer valid-token')
            .set('x-admin', 'true');

        expect(response.status).toBe(200);
        expect(response.body).toEqual({
            monthlyEntries: 45,
            totalSubscribedUsers: 0,
            totalMonthlyIncome: 0,
            monthlyCancels: {
                today: 0,
                thisMonth: 0,
            },
        });
    });

    it('returns 403 Forbidden for non-admin user', async () => {
        const response = await supertest(app.server)
            .get('/dashboard-stats')
            .set('Authorization', 'Bearer valid-token')
            .set('x-admin', 'false');

        expect(response.status).toBe(403);
    });
});
