import { desc, sql } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';
import { db } from '../../db/connection.js';
import { policies } from '../../db/schema.js';
import { commonErrorResponses } from '../../errors/errorSchema.js';
import { requireAdmin } from '../../middlewares/admin.js';

export default async function getInsuranceStatsRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.get(
        '/insurance-stats',
        {
            preHandler: [fastify.authenticate, requireAdmin],
            schema: {
                response: {
                    200: z.object({
                        mostUsedCompanies: z.array(
                            z.object({
                                company: z.string(),
                                count: z.number(),
                            }),
                        ),
                        mostUsedTypes: z.array(
                            z.object({
                                type: z.string(),
                                count: z.number(),
                            }),
                        ),
                    }),
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            // Group by company
            const companies = await db
                .select({
                    company: policies.company,
                    count: sql<number>`CAST(COUNT(*) AS INTEGER)`,
                })
                .from(policies)
                .groupBy(policies.company)
                .orderBy(desc(sql`COUNT(*)`))
                .limit(5);

            // Group by insurance type
            const types = await db
                .select({
                    type: policies.insuranceType,
                    count: sql<number>`CAST(COUNT(*) AS INTEGER)`,
                })
                .from(policies)
                .groupBy(policies.insuranceType)
                .orderBy(desc(sql`COUNT(*)`))
                .limit(5);

            return {
                mostUsedCompanies: companies.map(
                    (c: { company: string | null; count: number }) => ({
                        company: c.company || '',
                        count: c.count,
                    }),
                ),
                mostUsedTypes: types.map((t: { type: string | null; count: number }) => ({
                    type: t.type || '',
                    count: t.count,
                })),
            };
        },
    );
}
