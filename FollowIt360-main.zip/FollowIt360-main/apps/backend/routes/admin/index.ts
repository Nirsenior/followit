import { FastifyInstance } from 'fastify';
import getDashboardStatsRoute from './getDashboardStats.js';
import getInsuranceStatsRoute from './getInsuranceStats.js';
import getUsersRoute from './getUsers.js';
import promoteToAdminRoute from './promoteToAdmin.js';
import demoteFromAdminRoute from './demoteFromAdmin.js';

export default async function adminRoutes(fastify: FastifyInstance) {
    await fastify.register(getDashboardStatsRoute);
    await fastify.register(getInsuranceStatsRoute);
    await fastify.register(getUsersRoute);
    await fastify.register(promoteToAdminRoute);
    await fastify.register(demoteFromAdminRoute);
}
