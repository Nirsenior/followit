import Fastify from 'fastify';
import supertest from 'supertest';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { serializerCompiler, validatorCompiler, ZodTypeProvider } from 'fastify-type-provider-zod';
import getInsuranceStatsRoute from './getInsuranceStats.js';

let mockDb: any;

vi.mock('../../db/connection.js', () => ({
    get db() {
        return mockDb;
    }
}));

vi.mock('../../middlewares/admin.js', () => ({
    requireAdmin: async (request: any, reply: any) => {
        if (request.headers['x-admin'] !== 'true') {
            reply.status(403).send({ status: 'error', message: 'Forbidden' });
        }
    }
}));

describe('GET /insurance-stats', () => {
    let app: any;

    beforeAll(async () => {
        app = Fastify().withTypeProvider<ZodTypeProvider>();
        app.setValidatorCompiler(validatorCompiler);
        app.setSerializerCompiler(serializerCompiler);

        app.decorate('authenticate', async (request: any, reply: any) => {
            const authHeader = request.headers['authorization'];
            if (authHeader === 'Bearer valid-token') {
                request.user = { userId: 'user-123' };
            } else {
                reply.status(401).send({ status: 'error', message: 'Unauthorized' });
            }
        });

        await app.register(getInsuranceStatsRoute);
        await app.ready();
    });

    afterAll(async () => {
        await app.close();
    });

    it('returns grouped insurance stats for an admin', async () => {
        // Group by company then by type mock
        mockDb = {
            select: vi.fn().mockReturnValue({
                from: vi.fn().mockReturnValue({
                    groupBy: vi.fn().mockReturnValue({
                        orderBy: vi.fn().mockReturnValue({
                            limit: vi.fn()
                                .mockResolvedValueOnce([{ company: 'Harel', count: 10 }])
                                .mockResolvedValueOnce([{ type: 'health', count: 5 }])
                        })
                    })
                })
            })
        };

        const response = await supertest(app.server)
            .get('/insurance-stats')
            .set('Authorization', 'Bearer valid-token')
            .set('x-admin', 'true');
        
        expect(response.status).toBe(200);
        expect(response.body).toEqual({
            mostUsedCompanies: [{ company: 'Harel', count: 10 }],
            mostUsedTypes: [{ type: 'health', count: 5 }]
        });
    });

    it('returns 403 Forbidden for non-admin user', async () => {
        const response = await supertest(app.server)
            .get('/insurance-stats')
            .set('Authorization', 'Bearer valid-token')
            .set('x-admin', 'false');
        
        expect(response.status).toBe(403);
    });
});
