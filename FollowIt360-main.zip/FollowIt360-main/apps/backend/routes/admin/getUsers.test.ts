import Fastify from 'fastify';
import { serializerCompiler, validatorCompiler, ZodTypeProvider } from 'fastify-type-provider-zod';
import supertest from 'supertest';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import getUsersRoute from './getUsers.js';

let mockDb: any;

vi.mock('../../db/connection.js', () => ({
    get db() {
        return mockDb;
    },
}));

vi.mock('../../middlewares/admin.js', () => ({
    requireAdmin: async (request: any, reply: any) => {
        if (request.headers['x-admin'] !== 'true') {
            reply.status(403).send({ status: 'error', message: 'Forbidden' });
        }
    },
}));

describe('GET /users', () => {
    let app: any;

    beforeAll(async () => {
        app = Fastify().withTypeProvider<ZodTypeProvider>();
        app.setValidatorCompiler(validatorCompiler);
        app.setSerializerCompiler(serializerCompiler);

        app.decorate('authenticate', async (request: any, reply: any) => {
            const authHeader = request.headers['authorization'];
            if (authHeader === 'Bearer valid-token') {
                request.user = { userId: 'admin-123' };
            } else {
                reply.status(401).send({ status: 'error', message: 'Unauthorized' });
            }
        });

        await app.register(getUsersRoute);
        await app.ready();
    });

    afterAll(async () => {
        await app.close();
    });

    it('returns 401 Unauthorized for unauthorized user', async () => {
        const response = await supertest(app.server).get('/users');

        expect(response.status).toBe(401);
    });

    it('returns 403 Forbidden for non-admin user', async () => {
        const response = await supertest(app.server)
            .get('/users')
            .set('Authorization', 'Bearer valid-token')
            .set('x-admin', 'false');

        expect(response.status).toBe(403);
    });

    it('returns 200 OK with paginated list of users', async () => {
        // Mock DB implementation to return data and total count
        const mockUsersData = [
            {
                id: 'user-1',
                name: 'Israel Israeli',
                email: 'israel@example.com',
                phone: null,
                customerCount: 3,
                isAdmin: false,
            },
            {
                id: 'user-2',
                name: 'Jane Doe',
                email: 'jane@example.com',
                phone: null,
                customerCount: 0,
                isAdmin: false,
            },
        ];

        mockDb = {
            select: vi.fn().mockImplementation((fields) => {
                const isCount = fields && fields.count !== undefined;
                const chain = {
                    from: vi.fn().mockReturnThis(),
                    leftJoin: vi.fn().mockReturnThis(),
                    groupBy: vi.fn().mockReturnThis(),
                    where: vi.fn().mockReturnThis(),
                    orderBy: vi.fn().mockReturnThis(),
                    limit: vi.fn().mockReturnThis(),
                    offset: vi.fn().mockReturnThis(),
                    then: vi.fn().mockImplementation((resolve) => {
                        if (isCount) {
                            resolve([{ count: 2 }]);
                        } else {
                            resolve(mockUsersData);
                        }
                    }),
                };
                return chain;
            }),
        };

        const response = await supertest(app.server)
            .get('/users')
            .query({ page: 1, limit: 10, search: 'israel' })
            .set('Authorization', 'Bearer valid-token')
            .set('x-admin', 'true');

        expect(response.status).toBe(200);
        expect(response.body).toEqual({
            users: [
                {
                    id: 'user-1',
                    name: 'Israel Israeli',
                    email: 'israel@example.com',
                    phone: null,
                    isSubscribed: false,
                    isAdmin: false,
                    customerCount: 3,
                },
                {
                    id: 'user-2',
                    name: 'Jane Doe',
                    email: 'jane@example.com',
                    phone: null,
                    isSubscribed: false,
                    isAdmin: false,
                    customerCount: 0,
                },
            ],
            total: 2,
            page: 1,
            limit: 10,
        });
    });

    it('supports sorting by isSubscribed', async () => {
        const response = await supertest(app.server)
            .get('/users')
            .query({ page: 1, limit: 10, sortBy: 'isSubscribed', sortOrder: 'desc' })
            .set('Authorization', 'Bearer valid-token')
            .set('x-admin', 'true');

        expect(response.status).toBe(200);
    });
});
