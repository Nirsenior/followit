import { asc, desc, eq, ilike, or, sql } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';
import { db } from '../../db/connection.js';
import { customers, userRoles, users } from '../../db/schema.js';
import { commonErrorResponses } from '../../errors/errorSchema.js';
import { requireAdmin } from '../../middlewares/admin.js';

export default async function getUsersRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.get(
        '/users',
        {
            preHandler: [fastify.authenticate, requireAdmin],
            schema: {
                querystring: z.object({
                    page: z.preprocess((val) => Number(val || 1), z.number().min(1)).default(1),
                    limit: z
                        .preprocess((val) => Number(val || 10), z.number().min(1).max(100))
                        .default(10),
                    search: z.string().optional(),
                    sortBy: z.enum(['name', 'customerCount', 'isSubscribed']).default('name'),
                    sortOrder: z.enum(['asc', 'desc']).default('asc'),
                }),
                response: {
                    200: z.object({
                        users: z.array(
                            z.object({
                                id: z.string(),
                                name: z.string(),
                                email: z.string(),
                                phone: z.string().nullable(),
                                isSubscribed: z.boolean(),
                                isAdmin: z.boolean(),
                                customerCount: z.number(),
                            }),
                        ),
                        total: z.number(),
                        page: z.number(),
                        limit: z.number(),
                    }),
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            const { page, limit, search, sortBy, sortOrder } = request.query;

            // Build search condition
            let whereClause = undefined;
            if (search && search.trim() !== '') {
                whereClause = or(
                    ilike(users.name, `%${search}%`),
                    ilike(users.email, `%${search}%`),
                );
            }

            // Get total count
            let total = 0;
            try {
                const countQuery = db
                    .select({
                        count: sql<number>`CAST(COUNT(DISTINCT ${users.id}) AS INTEGER)`,
                    })
                    .from(users);

                if (whereClause) {
                    countQuery.where(whereClause);
                }

                const [countResult] = await countQuery;
                total = countResult?.count || 0;
            } catch (err) {
                // In testing or other edge cases, fallback
                total = 0;
            }

            // Determine sort order
            let orderByClause;
            if (sortBy === 'customerCount') {
                orderByClause =
                    sortOrder === 'desc'
                        ? desc(sql`COUNT(${customers.id})`)
                        : asc(sql`COUNT(${customers.id})`);
            } else if (sortBy === 'isSubscribed') {
                orderByClause = sortOrder === 'desc' ? desc(sql`false`) : asc(sql`false`);
            } else {
                orderByClause = sortOrder === 'desc' ? desc(users.name) : asc(users.name);
            }

            // Build users query — left-join customers (for count) and user_roles (for isAdmin)
            const usersQuery = db
                .select({
                    id: users.id,
                    name: users.name,
                    email: users.email,
                    phone: users.phone,
                    customerCount: sql<number>`CAST(COUNT(DISTINCT ${customers.id}) AS INTEGER)`,
                    isAdmin: sql<boolean>`BOOL_OR(${userRoles.role} = 'ADMIN')`,
                })
                .from(users)
                .leftJoin(customers, eq(users.id, customers.userId))
                .leftJoin(userRoles, eq(users.id, userRoles.userId));

            if (whereClause) {
                usersQuery.where(whereClause);
            }

            usersQuery
                .groupBy(users.id)
                .orderBy(orderByClause)
                .limit(limit)
                .offset((page - 1) * limit);

            const dbUsers = await usersQuery;

            // Map and return results
            const usersList = dbUsers.map(
                (u: { id: string; name: string; email: string; phone: string | null | undefined; customerCount: number | null; isAdmin: boolean | null }) => ({
                    id: u.id,
                    name: u.name,
                    email: u.email,
                    phone: u.phone ?? null,
                    isSubscribed: false, // Keep false placeholder for now
                    isAdmin: u.isAdmin ?? false,
                    customerCount: u.customerCount || 0,
                }),
            );

            return {
                users: usersList,
                total,
                page,
                limit,
            };
        },
    );
}
