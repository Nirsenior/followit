import { sql } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';
import { db } from '../../db/connection.js';
import { dailyPageVisits } from '../../db/schema.js';
import { commonErrorResponses } from '../../errors/errorSchema.js';
import { requireAdmin } from '../../middlewares/admin.js';

export default async function getDashboardStatsRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.get(
        '/dashboard-stats',
        {
            preHandler: [fastify.authenticate, requireAdmin],
            schema: {
                response: {
                    200: z.object({
                        monthlyEntries: z.number(),
                        totalSubscribedUsers: z.number(),
                        totalMonthlyIncome: z.number(),
                        monthlyCancels: z.object({
                            today: z.number(),
                            thisMonth: z.number(),
                        }),
                    }),
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            // Get the first day of the current month
            const today = new Date();
            const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1)
                .toISOString()
                .split('T')[0];

            // Summarize monthly entries to the '/' page from daily_page_visits
            const [visitStats] = await db
                .select({
                    totalVisits: sql<number>`SUM(${dailyPageVisits.visitCount})`,
                })
                .from(dailyPageVisits)
                .where(
                    sql`${dailyPageVisits.date} >= ${firstDayOfMonth}::date AND ${dailyPageVisits.path} = '/'`,
                );

            const monthlyEntries = Number(visitStats?.totalVisits || 0);

            // Mocks for PayMe data as per the user's request
            return {
                monthlyEntries,
                totalSubscribedUsers: 0, // Mocked until PayMe integration
                totalMonthlyIncome: 0, // Mocked until PayMe integration
                monthlyCancels: {
                    today: 0,
                    thisMonth: 0,
                }, // Mocked until PayMe integration
            };
        },
    );
}
