import { and, eq } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { StatusCodes } from 'http-status-codes';
import { z } from 'zod';
import { db } from '../../db/connection.js';
import { userRoles, users } from '../../db/schema.js';
import { AppError } from '../../errors/AppError.js';
import { commonErrorResponses } from '../../errors/errorSchema.js';
import { requireAdmin } from '../../middlewares/admin.js';

export default async function demoteFromAdminRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.delete(
        '/users/:userId/roles',
        {
            preHandler: [fastify.authenticate, requireAdmin],
            schema: {
                params: z.object({
                    userId: z.string().uuid(),
                }),
                body: z.object({
                    role: z.literal('ADMIN'),
                }),
                response: {
                    200: z.object({
                        success: z.boolean(),
                        message: z.string(),
                    }),
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            const { userId } = request.params;
            const { role } = request.body;

            // Fetch the user and their matching role in a single query
            const [userWithRole] = await db
                .select({
                    userId: users.id,
                    roleUserId: userRoles.userId,
                })
                .from(users)
                .leftJoin(
                    userRoles,
                    and(eq(userRoles.userId, users.id), eq(userRoles.role, role))
                )
                .where(eq(users.id, userId))
                .limit(1);

            if (!userWithRole) {
                throw new AppError('User not found', StatusCodes.NOT_FOUND);
            }

            if (!userWithRole.roleUserId) {
                return {
                    success: true,
                    message: 'User does not have this role',
                };
            }

            await db
                .delete(userRoles)
                .where(and(eq(userRoles.userId, userId), eq(userRoles.role, role)));

            return {
                success: true,
                message: `Role ${role} removed successfully`,
            };
        },
    );
}
