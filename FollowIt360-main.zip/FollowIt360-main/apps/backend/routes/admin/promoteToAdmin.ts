import { and, eq } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { StatusCodes } from 'http-status-codes';
import { z } from 'zod';
import { db } from '../../db/connection.js';
import { userRoles, users } from '../../db/schema.js';
import { AppError } from '../../errors/AppError.js';
import { commonErrorResponses } from '../../errors/errorSchema.js';
import { requireAdmin } from '../../middlewares/admin.js';

export default async function promoteToAdminRoute(fastify: FastifyInstance) {
    const server = fastify.withTypeProvider<ZodTypeProvider>();

    server.post(
        '/users/:userId/roles',
        {
            preHandler: [fastify.authenticate, requireAdmin],
            schema: {
                params: z.object({
                    userId: z.string().uuid(),
                }),
                body: z.object({
                    role: z.literal('ADMIN'),
                }),
                response: {
                    200: z.object({
                        success: z.boolean(),
                        message: z.string(),
                    }),
                    ...commonErrorResponses,
                },
            },
        },
        async (request, reply) => {
            const { userId } = request.params;
            const { role } = request.body;

            // Verify the target user exists
            const [targetUser] = await db
                .select({ id: users.id })
                .from(users)
                .where(eq(users.id, userId))
                .limit(1);

            if (!targetUser) {
                throw new AppError('User not found', StatusCodes.NOT_FOUND);
            }

            // Check if the role already exists to avoid duplicate key error
            const [existingRole] = await db
                .select()
                .from(userRoles)
                .where(and(eq(userRoles.userId, userId), eq(userRoles.role, role)))
                .limit(1);

            if (existingRole) {
                return {
                    success: true,
                    message: 'User already has this role',
                };
            }

            await db.insert(userRoles).values({ userId, role });

            return {
                success: true,
                message: `Role ${role} granted successfully`,
            };
        },
    );
}
