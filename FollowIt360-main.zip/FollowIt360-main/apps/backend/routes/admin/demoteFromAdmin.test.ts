import Fastify from 'fastify';
import { serializerCompiler, validatorCompiler, ZodTypeProvider } from 'fastify-type-provider-zod';
import supertest from 'supertest';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { errorHandler } from '../../errors/errorHandler.js';
import demoteFromAdminRoute from './demoteFromAdmin.js';

let mockDb: any;

vi.mock('../../db/connection.js', () => ({
    get db() {
        return mockDb;
    },
}));

vi.mock('../../middlewares/admin.js', () => ({
    requireAdmin: async (request: any, reply: any) => {
        if (request.headers['x-admin'] !== 'true') {
            reply.status(403).send({ status: 'error', message: 'Forbidden' });
        }
    },
}));

describe('DELETE /users/:userId/roles', () => {
    let app: any;

    beforeAll(async () => {
        app = Fastify().withTypeProvider<ZodTypeProvider>();
        app.setValidatorCompiler(validatorCompiler);
        app.setSerializerCompiler(serializerCompiler);
        app.setErrorHandler(errorHandler);

        app.decorate('authenticate', async (request: any, reply: any) => {
            if (request.headers['authorization'] === 'Bearer valid-token') {
                request.user = { userId: 'admin-123' };
            } else {
                reply.status(401).send({ status: 'error', message: 'Unauthorized' });
            }
        });

        await app.register(demoteFromAdminRoute);
        await app.ready();
    });

    afterAll(async () => {
        await app.close();
    });

    beforeEach(() => {
        vi.clearAllMocks();
        mockDb = undefined;
    });

    // RFC-4122 compliant UUID (version 4, variant bits 0x8)
    const validUserId = 'a1b2c3d4-e5f6-4a7b-8c9d-e0f1a2b3c4d5';
    const validBody = { role: 'ADMIN' };
    const authHeaders = {
        Authorization: 'Bearer valid-token',
        'x-admin': 'true',
    };

    it('returns 401 when no auth token is provided', async () => {
        const res = await supertest(app.server)
            .delete(`/users/${validUserId}/roles`)
            .send(validBody);

        expect(res.status).toBe(401);
    });

    it('returns 403 when authenticated user is not an admin', async () => {
        const res = await supertest(app.server)
            .delete(`/users/${validUserId}/roles`)
            .set('Authorization', 'Bearer valid-token')
            .set('x-admin', 'false')
            .send(validBody);

        expect(res.status).toBe(403);
    });

    it('returns 400 when userId param is not a valid UUID', async () => {
        const res = await supertest(app.server)
            .delete('/users/not-a-valid-uuid/roles')
            .set(authHeaders)
            .send(validBody);

        expect(res.status).toBe(400);
    });

    it('returns 400 when body role is not ADMIN', async () => {
        const res = await supertest(app.server)
            .delete(`/users/${validUserId}/roles`)
            .set(authHeaders)
            .send({ role: 'USER' });

        expect(res.status).toBe(400);
    });

    it('returns 404 when the target user does not exist', async () => {
        mockDb = {
            select: vi.fn().mockReturnValue({
                from: vi.fn().mockReturnValue({
                    leftJoin: vi.fn().mockReturnValue({
                        where: vi.fn().mockReturnValue({
                            limit: vi.fn().mockResolvedValue([]),
                        }),
                    }),
                }),
            }),
        };

        const res = await supertest(app.server)
            .delete(`/users/${validUserId}/roles`)
            .set(authHeaders)
            .send(validBody);

        expect(res.status).toBe(404);
    });

    it('returns 200 and success=true when removing the ADMIN role', async () => {
        const mockDelete = vi.fn().mockReturnValue({
            where: vi.fn().mockResolvedValue(undefined),
        });

        mockDb = {
            select: vi.fn().mockImplementation(() => ({
                from: vi.fn().mockReturnValue({
                    leftJoin: vi.fn().mockReturnValue({
                        where: vi.fn().mockReturnValue({
                            limit: vi.fn().mockResolvedValue([{ userId: validUserId, roleUserId: validUserId }]),
                        }),
                    }),
                }),
            })),
            delete: mockDelete,
        };

        const res = await supertest(app.server)
            .delete(`/users/${validUserId}/roles`)
            .set(authHeaders)
            .send(validBody);

        expect(res.status).toBe(200);
        expect(res.body).toEqual({ success: true, message: 'Role ADMIN removed successfully' });
        expect(mockDelete).toHaveBeenCalledTimes(1);
    });

    it('returns 200 without deleting when user does not have the ADMIN role', async () => {
        const mockDelete = vi.fn();

        mockDb = {
            select: vi.fn().mockImplementation(() => ({
                from: vi.fn().mockReturnValue({
                    leftJoin: vi.fn().mockReturnValue({
                        where: vi.fn().mockReturnValue({
                            limit: vi.fn().mockResolvedValue([{ userId: validUserId, roleUserId: null }]),
                        }),
                    }),
                }),
            })),
            delete: mockDelete,
        };

        const res = await supertest(app.server)
            .delete(`/users/${validUserId}/roles`)
            .set(authHeaders)
            .send(validBody);

        expect(res.status).toBe(200);
        expect(res.body).toEqual({ success: true, message: 'User does not have this role' });
        expect(mockDelete).not.toHaveBeenCalled();
    });
});
