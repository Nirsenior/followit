import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
    service: 'gmail', // You can change this to your SMTP provider
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS, // App password if using Gmail
    },
});

export const emailService = {
    async sendPortfolioValuationLead(data: {
        agentName: string;
        phone: string;
        email: string;
        portfolioValue: number;
    }) {
        const toEmail = process.env.COMPANY_LEADS_EMAIL || 'followit360@gmail.com';
        const formattedValue = new Intl.NumberFormat('he-IL', {
            style: 'currency',
            currency: 'ILS',
            maximumFractionDigits: 0,
        }).format(data.portfolioValue);

        const mailOptions = {
            from: process.env.SMTP_USER,
            to: toEmail,
            subject: `🚨 [ליד חשוב] הסוכן ${data.agentName} מעוניין למכור את התיק שלו!`,
            html: `
                <div dir="rtl" style="font-family: Arial, sans-serif; color: #333; line-height: 1.6;">
                    <h2 style="color: #d32f2f;">🚨 ליד חדש - סוכן מעוניין למכור את התיק!</h2>
                    <p>הסוכן <strong>${data.agentName}</strong> לחץ על כפתור מכירת התיק בדשבורד.</p>
                    
                    <div style="background-color: #f5f5f5; padding: 15px; border-radius: 8px; margin: 20px 0;">
                        <ul style="list-style: none; padding: 0; margin: 0;">
                            <li style="margin-bottom: 10px;"><strong>שם הסוכן:</strong> ${data.agentName}</li>
                            <li style="margin-bottom: 10px;"><strong>טלפון:</strong> <a href="tel:${data.phone}">${data.phone}</a></li>
                            <li style="margin-bottom: 10px;"><strong>אימייל:</strong> <a href="mailto:${data.email}">${data.email}</a></li>
                            <li style="margin-bottom: 10px; font-size: 1.2em;"><strong>שווי תיק מוערך:</strong> <span style="color: #2e7d32; font-weight: bold;">${formattedValue}</span></li>
                        </ul>
                    </div>
                    
                    <p>נא ליצור קשר בהקדם!</p>
                </div>
            `,
            priority: 'high' as const,
            headers: {
                'X-Priority': '1 (Highest)',
                'X-MSMail-Priority': 'High',
                Importance: 'High',
            },
        };

        try {
            const info = await transporter.sendMail(mailOptions);
            return { success: true, messageId: info.messageId };
        } catch (error) {
            console.error('Error sending email:', error);
            throw error;
        }
    },
};
