import { describe, expect, it, vi, beforeEach } from 'vitest';
import {
    getWeightedYieldForPolicy,
    probeLatestPeriodForResource,
    currentReportPeriod,
    formatReportPeriod,
    INSURANCE_TYPE_TO_RESOURCE
} from './gemelNetService.js';

// Mock DB
let mockDb: any;
vi.mock('../db/connection.js', () => ({
    get db() {
        return mockDb;
    }
}));

// Mock fetch
global.fetch = vi.fn();

describe('gemelNetService', () => {
    const mockLogger = { info: vi.fn(), warn: vi.fn(), error: vi.fn() };

    beforeEach(() => {
        vi.clearAllMocks();
    });

    describe('probeLatestPeriodForResource', () => {
        it('fetches and returns the latest period for a resource', async () => {
            (global.fetch as any).mockResolvedValueOnce({
                ok: true,
                json: async () => ({
                    success: true,
                    result: {
                        records: [{ REPORT_PERIOD: '202503' }]
                    }
                })
            });

            const result = await probeLatestPeriodForResource('res-123', mockLogger);
            expect(result).toBe('202503');
            expect(global.fetch).toHaveBeenCalled();
        });

        it('returns null on fetch error', async () => {
            (global.fetch as any).mockRejectedValueOnce(new Error('Network error'));
            const result = await probeLatestPeriodForResource('res-123', mockLogger);
            expect(result).toBeNull();
        });
    });

    describe('getWeightedYieldForPolicy', () => {
        it('calculates weighted yield for policy tracks', async () => {
            // Mock DB to return tracks for policy
            const mockQueryChain = (result: any) => {
                const chain: any = Promise.resolve(result);
                chain.limit = vi.fn().mockReturnValue(chain);
                chain.where = vi.fn().mockReturnValue(chain);
                chain.from = vi.fn().mockReturnValue(chain);
                chain.select = vi.fn().mockReturnValue(chain);
                return chain;
            };

            let whereCall = 0;
            mockDb = {
                select: vi.fn().mockReturnValue({
                    from: vi.fn().mockReturnValue({
                        where: vi.fn().mockImplementation(() => {
                            whereCall++;
                            if (whereCall === 1) { // policy_tracks
                                return Promise.resolve([
                                    { fundId: 1001, sharePercentage: '0.4' },
                                    { fundId: 1002, sharePercentage: '0.6' }
                                ]);
                            } else if (whereCall === 2) { // policies
                                const chain: any = Promise.resolve([{ insuranceType: 'gemel' }]);
                                chain.limit = vi.fn().mockReturnValue(chain);
                                return chain;
                            } else { // fundYieldCache
                                const chain: any = Promise.resolve([]);
                                chain.limit = vi.fn().mockReturnValue(chain);
                                return chain;
                            }
                        })
                    })
                }),
                query: {
                    policies: {
                        findFirst: vi.fn().mockResolvedValue({
                            id: 'pol-1',
                            insuranceType: 'gemel'
                        })
                    }
                }
            };

            // Mock fetch to return yields for funds
            (global.fetch as any)
                .mockResolvedValueOnce({
                    ok: true,
                    text: async () => JSON.stringify({
                        success: true,
                        result: {
                            records: [
                                { FUND_ID: 1001, REPORT_PERIOD: '202503', MONTHLY_YIELD: '1.5' }
                            ]
                        }
                    })
                })
                .mockResolvedValueOnce({
                    ok: true,
                    text: async () => JSON.stringify({
                        success: true,
                        result: {
                            records: [
                                { FUND_ID: 1002, REPORT_PERIOD: '202503', MONTHLY_YIELD: '0.5' }
                            ]
                        }
                    })
                });

            const result = await getWeightedYieldForPolicy('pol-1', '202503', mockLogger);
            // 0.4 * 0.015 + 0.6 * 0.005 = 0.006 + 0.003 = 0.009
            expect(result).toBeCloseTo(0.009);
        });

        it('returns 0 if no tracks found', async () => {
            mockDb = {
                select: vi.fn().mockReturnValue({
                    from: vi.fn().mockReturnValue({
                        where: vi.fn().mockImplementation(() => {
                            const chain: any = Promise.resolve([]);
                            chain.limit = vi.fn().mockReturnValue(chain);
                            return chain;
                        })
                    })
                })
            };

            const result = await getWeightedYieldForPolicy('pol-1', '202503', mockLogger);
            expect(result).toBe(0);
        });
    });

    describe('currentReportPeriod', () => {
        it('returns previous month in YYYYMM format', () => {
            const period = currentReportPeriod();
            expect(period).toMatch(/^\d{6}$/); // e.g. 202504
        });
    });
});
