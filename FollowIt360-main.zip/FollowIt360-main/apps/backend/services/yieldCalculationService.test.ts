import { describe, expect, it, vi, beforeEach } from 'vitest';
import {
    compoundMonthlyYields,
    getGapMonths,
    catchUpPolicy,
    catchUpAllPolicies,
    runSmartCatchUp
} from './yieldCalculationService.js';

// ─────────────────────────────────────────────────
// 1. Pure Function: compoundMonthlyYields
// ─────────────────────────────────────────────────
describe('compoundMonthlyYields', () => {
    it('compounds a 3-month catch-up with weighted yields', () => {
        // Month 1: 1.7%, Month 2: 0.96%, Month 3: 0.02%
        // These are the weighted yields from the plan scenario:
        //   M1: (0.015*0.6) + (0.020*0.4) = 0.017
        //   M2: (0.008*0.6) + (0.012*0.4) = 0.0096
        //   M3: (-0.003*0.6) + (0.005*0.4) = 0.0002
        const initial = 100_000;
        const yields = [0.017, 0.0096, 0.0002];

        const result = compoundMonthlyYields(initial, yields);

        // Manual calculation:
        // After M1: 100000 * 1.017   = 101700.00
        // After M2: 101700 * 1.0096  = 102676.32
        // After M3: 102676.32 * 1.0002 = 102696.855264 → rounded to 102696.86
        expect(result).toBeCloseTo(102696.86, 2);
    });

    it('returns initial balance when yields array is empty', () => {
        expect(compoundMonthlyYields(100_000, [])).toBe(100_000);
    });

    it('returns initial balance when all yields are zero', () => {
        expect(compoundMonthlyYields(50_000, [0, 0, 0])).toBe(50_000);
    });

    it('reduces balance with negative yields', () => {
        // -2% for 2 months
        const result = compoundMonthlyYields(100_000, [-0.02, -0.02]);
        // 100000 * 0.98 * 0.98 = 96040
        expect(result).toBeCloseTo(96040, 2);
    });

    it('handles a single month yield', () => {
        const result = compoundMonthlyYields(200_000, [0.015]);
        // 200000 * 1.015 = 203000
        expect(result).toBe(203_000);
    });

    it('handles very small yields without precision loss', () => {
        const result = compoundMonthlyYields(1_000_000, [0.0001]);
        // 1000000 * 1.0001 = 1000100
        expect(result).toBe(1_000_100);
    });
});

// ─────────────────────────────────────────────────
// 2. Utility: getGapMonths
// ─────────────────────────────────────────────────
describe('getGapMonths', () => {
    it('returns empty array when start equals end', () => {
        expect(getGapMonths('202401', '202401')).toEqual([]);
    });

    it('returns empty array when start is after end', () => {
        expect(getGapMonths('202405', '202401')).toEqual([]);
    });

    it('returns single month gap', () => {
        expect(getGapMonths('202401', '202402')).toEqual(['202402']);
    });

    it('returns multiple months within same year', () => {
        expect(getGapMonths('202401', '202404')).toEqual([
            '202402',
            '202403',
            '202404',
        ]);
    });

    it('spans year boundary correctly', () => {
        expect(getGapMonths('202411', '202502')).toEqual([
            '202412',
            '202501',
            '202502',
        ]);
    });

    it('handles full year gap', () => {
        const months = getGapMonths('202312', '202412');
        expect(months).toHaveLength(12);
        expect(months[0]).toBe('202401');
        expect(months[11]).toBe('202412');
    });
});

// ─────────────────────────────────────────────────
// 3. Integration: catchUpPolicy
// ─────────────────────────────────────────────────

// We mock the DB and gemelNetService to test the orchestration logic
let mockDb: any;

vi.mock('../db/connection.js', () => ({
    get db() {
        return mockDb;
    },
}));

// Mock getWeightedYieldForPolicy from gemelNetService
const mockGetWeightedYield = vi.fn();
const mockProbeLatestPeriodForResource = vi.fn();
const mockPrewarmYieldCache = vi.fn();

vi.mock('./gemelNetService.js', () => ({
    getWeightedYieldForPolicy: (...args: any[]) => mockGetWeightedYield(...args),
    probeLatestPeriodForResource: (...args: any[]) => mockProbeLatestPeriodForResource(...args),
    prewarmYieldCache: (...args: any[]) => mockPrewarmYieldCache(...args),
    formatReportPeriod: (y: number, m: number) => `${y}${String(m).padStart(2, '0')}`,
    currentReportPeriod: () => '202504', // pretend "now" is May 2025 (current = April)
    INSURANCE_TYPE_TO_RESOURCE: {
        gemel: ['resource1'],
        hishtalmut: ['resource1'],
        pension: ['resource2'],
    }
}));

describe('catchUpPolicy', () => {
    const mockLogger = {
        info: vi.fn(),
        warn: vi.fn(),
        error: vi.fn(),
    };

    beforeEach(() => {
        vi.clearAllMocks();
        mockGetWeightedYield.mockReset();
    });

    it('compounds 3 months of weighted yields and updates the database', async () => {
        // Policy entered in Jan 2025 with 100,000 accumulation
        // lastCalculatedDate = 2025-01-31 (meaning Jan is already done)
        // Current period = 202504 (April), so gap = Feb, Mar, Apr
        // But we process up to current-1 = Mar, so gap = Feb, Mar
        // Actually let's set lastCalculatedDate so that gap is 3 months
        const policyId = 'policy-uuid-1';

        // Mock: read policy from DB
        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            where: vi.fn().mockReturnThis(),
            limit: vi.fn().mockResolvedValue([
                {
                    id: policyId,
                    initialAccumulation: '100000',
                    currentAccumulation: '100000',
                    systemEntryDate: '2025-01-01',
                    lastCalculatedDate: '2025-01-01', // means Jan not yet processed
                },
            ]),
            update: vi.fn().mockReturnThis(),
            set: vi.fn().mockReturnThis(),
        };

        // Mock: yields for Feb, Mar, Apr (3 months)
        // weighted yields: 0.017, 0.0096, 0.0002
        mockGetWeightedYield
            .mockResolvedValueOnce(0.017)   // 202501
            .mockResolvedValueOnce(0.0096)  // 202502
            .mockResolvedValueOnce(0.0002); // 202503

        const result = await catchUpPolicy(policyId, mockLogger);

        // Verify compounding: 100000 * 1.017 * 1.0096 * 1.0002 ≈ 102696.86
        expect(result.currentAccumulation).toBeCloseTo(102696.86, 2);
        expect(result.monthsProcessed).toBe(3);

        // Verify DB update was called
        expect(mockDb.update).toHaveBeenCalled();
    });

    it('stops compounding when yield returns 0 (missing data)', async () => {
        const policyId = 'policy-uuid-2';

        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            where: vi.fn().mockReturnThis(),
            limit: vi.fn().mockResolvedValue([
                {
                    id: policyId,
                    initialAccumulation: '100000',
                    currentAccumulation: '100000',
                    systemEntryDate: '2025-01-01',
                    lastCalculatedDate: '2025-01-01',
                },
            ]),
            update: vi.fn().mockReturnThis(),
            set: vi.fn().mockReturnThis(),
        };

        // Month 1 returns yield, month 2 returns null (data not published)
        mockGetWeightedYield
            .mockResolvedValueOnce(0.01)  // 202501
            .mockResolvedValueOnce(null); // 202502 — stop here

        const result = await catchUpPolicy(policyId, mockLogger);

        // Only 1 month should be compounded
        expect(result.monthsProcessed).toBe(1);
        expect(result.currentAccumulation).toBeCloseTo(101000, 2);
    });

    it('returns early with 0 months if policy has no initialAccumulation', async () => {
        const policyId = 'policy-uuid-3';

        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            where: vi.fn().mockReturnThis(),
            limit: vi.fn().mockResolvedValue([
                {
                    id: policyId,
                    initialAccumulation: null,
                    currentAccumulation: null,
                    systemEntryDate: null,
                    lastCalculatedDate: null,
                },
            ]),
        };

        const result = await catchUpPolicy(policyId, mockLogger);

        expect(result.monthsProcessed).toBe(0);
        expect(result.currentAccumulation).toBe(0);
    });

    it('returns early if policy not found', async () => {
        const policyId = 'nonexistent';

        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            where: vi.fn().mockReturnThis(),
            limit: vi.fn().mockResolvedValue([]),
        };

        const result = await catchUpPolicy(policyId, mockLogger);

        expect(result.monthsProcessed).toBe(0);
        expect(result.currentAccumulation).toBe(0);
    });

    it('returns early if there are no gap months to process', async () => {
        const policyId = 'policy-uuid-4';

        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            where: vi.fn().mockReturnThis(),
            limit: vi.fn().mockResolvedValue([
                {
                    id: policyId,
                    initialAccumulation: '100000',
                    currentAccumulation: '100000',
                    systemEntryDate: '2025-04-01',
                    // lastCalculatedDate is the same as current-1 — nothing to process
                    lastCalculatedDate: '2025-04-01',
                },
            ]),
        };

        const result = await catchUpPolicy(policyId, mockLogger);

        expect(result.monthsProcessed).toBe(0);
        expect(result.currentAccumulation).toBe(100000);
    });
});

describe('catchUpAllPolicies', () => {
    const mockLogger = { info: vi.fn(), warn: vi.fn(), error: vi.fn() };

    beforeEach(() => {
        vi.clearAllMocks();
    });

    it('catches up all trackable policies', async () => {
        const mockQueryChain = (result: any) => {
            const chain: any = Promise.resolve(result);
            chain.limit = vi.fn().mockReturnValue(chain);
            chain.where = vi.fn().mockReturnValue(chain);
            return chain;
        };

        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            where: vi.fn().mockImplementation(() => {
                if (mockDb.where.mock.calls.length === 1) {
                    return mockQueryChain([{ id: 'pol-1' }, { id: 'pol-2' }]);
                }
                return mockQueryChain([
                    {
                        id: 'pol-1',
                        initialAccumulation: '10000',
                        currentAccumulation: '10000',
                        systemEntryDate: '2025-01-01',
                        lastCalculatedDate: '2025-01-01'
                    }
                ]);
            }),
            update: vi.fn().mockReturnThis(),
            set: vi.fn().mockReturnThis(),
        };

        mockGetWeightedYield.mockResolvedValue(0.01);

        const result = await catchUpAllPolicies(mockLogger);
        // It processes 2 policies, each has a gap (since mock always returns the same limit mocked policy)
        // Actually limit returns the same array for each catchUpPolicy call.
        // The mock logic above is simplistic, so let's just assert it processes them.
        expect(result.policiesProcessed).toBeGreaterThan(0);
        expect(result.totalMonths).toBeGreaterThan(0);
    });

    it('returns zeroes if DB fails', async () => {
        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnThis(),
            where: vi.fn().mockRejectedValue(new Error('DB error')),
        };
        const result = await catchUpAllPolicies(mockLogger);
        expect(result.policiesProcessed).toBe(0);
        expect(result.totalMonths).toBe(0);
    });
});

describe('runSmartCatchUp', () => {
    const mockLogger = { info: vi.fn(), warn: vi.fn(), error: vi.fn() };

    beforeEach(() => {
        vi.clearAllMocks();
    });

    const mockQueryChain = (result: any) => {
        const chain: any = Promise.resolve(result);
        chain.limit = vi.fn().mockReturnValue(chain);
        chain.where = vi.fn().mockReturnValue(chain);
        chain.from = vi.fn().mockReturnValue(chain);
        chain.set = vi.fn().mockReturnValue(chain);
        chain.catch = vi.fn().mockReturnValue(chain);
        return chain;
    };

    it('processes resources with new data', async () => {
        let fromCallCount = 0;
        let whereCallCount = 0;

        mockDb = {
            select: vi.fn().mockReturnThis(),
            update: vi.fn().mockReturnValue(mockQueryChain([])),
            from: vi.fn().mockImplementation(() => {
                fromCallCount++;
                if (fromCallCount === 1) {
                    // gemelResourceState
                    return mockQueryChain([{ resourceId: 'resource1', resourceName: 'Test Res', lastProcessedPeriod: '202501' }]);
                }
                const chain: any = Promise.resolve([]);
                chain.where = vi.fn().mockImplementation(() => {
                    whereCallCount++;
                    if (whereCallCount === 1) {
                        // policies
                        return mockQueryChain([{ id: 'pol-1', insuranceType: 'gemel' }]);
                    } else if (whereCallCount === 2) {
                        // tracks
                        return mockQueryChain([{ fundId: 123 }]);
                    } else {
                        // catchUpPolicy
                        return mockQueryChain([
                            {
                                id: 'pol-1',
                                initialAccumulation: '10000',
                                currentAccumulation: '10000',
                                systemEntryDate: '2025-01-01',
                                lastCalculatedDate: '2025-01-01'
                            }
                        ]);
                    }
                });
                return chain;
            })
        };

        mockProbeLatestPeriodForResource.mockResolvedValue('202503');
        mockPrewarmYieldCache.mockResolvedValue(true);
        mockGetWeightedYield.mockResolvedValue(0.01);

        const result = await runSmartCatchUp(mockLogger);
        
        expect(result.resourcesProcessed).toBe(1);
        expect(result.policiesProcessed).toBe(1);
        expect(result.totalMonths).toBe(3);
    });

    it('skips processing if no new data', async () => {
        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnValue(mockQueryChain([
                { resourceId: 'resource1', resourceName: 'Test Res', lastProcessedPeriod: '202503' }
            ])),
            update: vi.fn().mockReturnValue(mockQueryChain([]))
        };

        mockProbeLatestPeriodForResource.mockResolvedValue('202503');

        const result = await runSmartCatchUp(mockLogger);
        expect(result.resourcesProcessed).toBe(0);
        expect(result.policiesProcessed).toBe(0);
    });

    it('skips resource if probe fails', async () => {
        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockReturnValue(mockQueryChain([
                { resourceId: 'resource1', resourceName: 'Test Res', lastProcessedPeriod: '202501' }
            ])),
            update: vi.fn().mockReturnValue(mockQueryChain([]))
        };

        mockProbeLatestPeriodForResource.mockResolvedValue(null);

        const result = await runSmartCatchUp(mockLogger);
        expect(result.resourcesProcessed).toBe(0);
    });

    it('handles first run (lastProcessedPeriod is null)', async () => {
        let fromCallCount = 0;
        mockDb = {
            select: vi.fn().mockReturnThis(),
            from: vi.fn().mockImplementation(() => {
                fromCallCount++;
                if (fromCallCount === 1) {
                    return mockQueryChain([{ resourceId: 'resource1', resourceName: 'Test Res', lastProcessedPeriod: null }]);
                }
                const chain: any = Promise.resolve([]);
                chain.where = vi.fn().mockReturnValue(mockQueryChain([])); // No policies
                return chain;
            }),
            update: vi.fn().mockReturnValue(mockQueryChain([]))
        };

        mockProbeLatestPeriodForResource.mockResolvedValue('202503');

        const result = await runSmartCatchUp(mockLogger);
        expect(result.resourcesProcessed).toBe(0);
    });

    it('handles DB error when querying trackable policies', async () => {
        let fromCallCount = 0;
        mockDb = {
            select: vi.fn().mockReturnThis(),
            update: vi.fn().mockReturnValue(mockQueryChain([])),
            from: vi.fn().mockImplementation(() => {
                fromCallCount++;
                if (fromCallCount === 1) {
                    return mockQueryChain([{ resourceId: 'resource1', resourceName: 'Test Res', lastProcessedPeriod: '202501' }]);
                }
                const chain: any = Promise.resolve([]);
                chain.where = vi.fn().mockRejectedValue(new Error('DB error on policies'));
                return chain;
            })
        };

        mockProbeLatestPeriodForResource.mockResolvedValue('202503');

        const result = await runSmartCatchUp(mockLogger);
        expect(result.resourcesProcessed).toBe(0);
        expect(mockLogger.error).toHaveBeenCalledWith(expect.anything(), expect.stringContaining('Failed to query policies'));
    });

    it('handles DB error when querying policy_tracks', async () => {
        let fromCallCount = 0;
        let whereCallCount = 0;

        mockDb = {
            select: vi.fn().mockReturnThis(),
            update: vi.fn().mockReturnValue(mockQueryChain([])),
            from: vi.fn().mockImplementation(() => {
                fromCallCount++;
                if (fromCallCount === 1) {
                    return mockQueryChain([{ resourceId: 'resource1', resourceName: 'Test Res', lastProcessedPeriod: '202501' }]);
                }
                const chain: any = Promise.resolve([]);
                chain.where = vi.fn().mockImplementation(() => {
                    whereCallCount++;
                    if (whereCallCount === 1) {
                        return mockQueryChain([{ id: 'pol-1', insuranceType: 'gemel' }]);
                    } else if (whereCallCount === 2) {
                        return Promise.reject(new Error('DB error on tracks'));
                    }
                    return mockQueryChain([]);
                });
                return chain;
            })
        };

        mockProbeLatestPeriodForResource.mockResolvedValue('202503');
        mockPrewarmYieldCache.mockResolvedValue(true);

        const result = await runSmartCatchUp(mockLogger);
        expect(mockLogger.warn).toHaveBeenCalledWith(expect.anything(), expect.stringContaining('Could not read policy_tracks'));
    });

    it('handles DB error when updating gemel_resource_state at the end', async () => {
        let fromCallCount = 0;
        let whereCallCount = 0;
        let updateCallCount = 0;

        const updateChain: any = Promise.resolve([]);
        updateChain.set = vi.fn().mockReturnThis();
        updateChain.where = vi.fn().mockReturnThis();
        updateChain.catch = vi.fn().mockImplementation((cb: any) => {
             updateCallCount++;
             if (updateCallCount === 2) { // The last update
                 cb(new Error('Update error'));
             }
             return Promise.resolve();
        });

        mockDb = {
            select: vi.fn().mockReturnThis(),
            update: vi.fn().mockReturnValue(updateChain),
            from: vi.fn().mockImplementation(() => {
                fromCallCount++;
                if (fromCallCount === 1) {
                    return mockQueryChain([{ resourceId: 'resource1', resourceName: 'Test Res', lastProcessedPeriod: '202501' }]);
                }
                const chain: any = Promise.resolve([]);
                chain.where = vi.fn().mockImplementation(() => {
                    whereCallCount++;
                    if (whereCallCount === 1) {
                        return mockQueryChain([{ id: 'pol-1', insuranceType: 'gemel' }]);
                    } else if (whereCallCount === 2) {
                        return mockQueryChain([{ fundId: 123 }]);
                    }
                    return mockQueryChain([]);
                });
                return chain;
            })
        };

        mockProbeLatestPeriodForResource.mockResolvedValue('202503');
        mockPrewarmYieldCache.mockResolvedValue(true);

        await runSmartCatchUp(mockLogger);
        expect(mockLogger.warn).toHaveBeenCalledWith(expect.anything(), expect.stringContaining('Failed to update state for'));
    });
});
