/**
 * @fileoverview Yield Calculation Engine — Policy Catch-Up & Compounding
 *
 * ⚠️  COMPOUNDING RULES (do not alter without review):
 *
 * 1. FORMULA: `balance = (balance + monthlyDeposit) * (1 + yieldDecimal)`
 *    Deposit is added BEFORE yield is applied for the month. Order matters.
 *
 * 2. PERIOD ANCHOR: `currentReportPeriod()` returns the previous calendar month
 *    (the last officially published period). The catch-up gap is:
 *    (lastCalculatedDate, currentReportPeriod()] — exclusive start, inclusive end.
 *
 * 3. HALT ON NULL: If `getWeightedYieldForPolicy()` returns null for any month,
 *    stop the loop immediately. Do NOT skip the month or use 0 as a substitute.
 *    Null means "official data not yet published" — not "zero yield".
 *
 * 4. NO ESTIMATION: Never synthesize or estimate a yield. Only use data returned
 *    directly by the Government API for the exact requested period.
 *
 * Pure functions (`compoundMonthlyYields`, `getGapMonths`) are fully testable
 * without DB or API — add unit tests for any changes to these functions.
 *
 * Reference: /commission_calculation_report.md
 * See also: gemelNetService.ts for API integration rules
 */
import { eq, isNotNull, inArray } from 'drizzle-orm';
import { db } from '../db/connection.js';
import { policies, policyTracks, gemelResourceState } from '../db/schema.js';

import {
    currentReportPeriod,
    formatReportPeriod,
    getWeightedYieldForPolicy,
    probeLatestPeriodForResource,
    prewarmYieldCache,
    INSURANCE_TYPE_TO_RESOURCE,
} from './gemelNetService.js';

// ─────────────────────────────────────────────────
// Pure Functions (no DB, no API — fully testable)
// ─────────────────────────────────────────────────

/**
 * Compounds an initial balance through a series of monthly yields.
 *
 * @param initialBalance - Starting balance (e.g. 100000)
 * @param monthlyYields  - Array of decimal yields per month (e.g. [0.017, 0.0096, 0.0002])
 * @returns Final compounded balance, rounded to 2 decimal places
 */
export function compoundMonthlyYields(
    initialBalance: number,
    monthlyYields: number[],
    monthlyDeposit: number = 0,
): number {
    let balance = initialBalance;
    for (const yld of monthlyYields) {
        balance = (balance + monthlyDeposit) * (1 + yld);
    }
    return Math.round(balance * 100) / 100;
}

/**
 * Generates an array of YYYYMM period strings for the gap between two periods.
 * The start period is EXCLUDED (it's already been processed).
 * The end period is INCLUDED.
 *
 * @param fromPeriod - The last processed period (exclusive), e.g. '202401'
 * @param toPeriod   - The target period (inclusive), e.g. '202404'
 * @returns Array of period strings, e.g. ['202402', '202403', '202404']
 */
export function getGapMonths(fromPeriod: string, toPeriod: string): string[] {
    let year = parseInt(fromPeriod.slice(0, 4), 10);
    let month = parseInt(fromPeriod.slice(4, 6), 10);

    const endYear = parseInt(toPeriod.slice(0, 4), 10);
    const endMonth = parseInt(toPeriod.slice(4, 6), 10);

    const result: string[] = [];

    // Advance one month past fromPeriod (exclusive start)
    month++;
    if (month > 12) {
        month = 1;
        year++;
    }

    // Iterate until we pass the end period
    while (year < endYear || (year === endYear && month <= endMonth)) {
        result.push(formatReportPeriod(year, month));
        month++;
        if (month > 12) {
            month = 1;
            year++;
        }
    }

    return result;
}

// ─────────────────────────────────────────────────
// Orchestration (DB + API)
// ─────────────────────────────────────────────────

export interface CatchUpResult {
    currentAccumulation: number;
    monthsProcessed: number;
    lastCalculatedDate: string | null;
}

/**
 * Converts a date (YYYY-MM-DD or Date) to a YYYYMM report period string.
 */
function dateToPeriod(d: string | Date): string {
    const dateStr = typeof d === 'string' ? d : d.toISOString().slice(0, 10);
    const [y, m] = dateStr.split('-');
    return `${y}${m}`;
}

/**
 * Converts a YYYYMM period to a YYYY-MM-DD date string (last day of month).
 */
function periodToDate(period: string): string {
    const year = parseInt(period.slice(0, 4), 10);
    const month = parseInt(period.slice(4, 6), 10);
    // Last day of the month
    const lastDay = new Date(year, month, 0).getDate();
    return `${year}-${String(month).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;
}

/**
 * Catches up a single policy's accumulation from lastCalculatedDate to current month - 1.
 *
 * 1. Reads policy tracking fields from the database
 * 2. Computes gap months from lastCalculatedDate (or systemEntryDate) to now - 1
 * 3. For each gap month, fetches weighted yield via gemelNetService
 * 4. Compounds: balance = balance * (1 + weightedYield) + monthlyDeposit
 * 5. Stops if a month returns yield=null (data not yet published)
 * 6. Updates currentAccumulation and lastCalculatedDate in DB
 */
export async function catchUpPolicy(policyId: string, log?: any): Promise<CatchUpResult> {
    const logger = log || console;

    if (!db) {
        logger.warn('[CatchUp] DB not ready, skipping');
        return { currentAccumulation: 0, monthsProcessed: 0, lastCalculatedDate: null };
    }

    // 1. Read policy
    const rows = await db.select().from(policies).where(eq(policies.id, policyId)).limit(1);

    if (!rows.length) {
        logger.warn(`[CatchUp] Policy ${policyId} not found`);
        return { currentAccumulation: 0, monthsProcessed: 0, lastCalculatedDate: null };
    }

    const policy = rows[0];
    const initialAccum = policy.initialAccumulation
        ? parseFloat(policy.initialAccumulation as string)
        : null;

    if (initialAccum === null || initialAccum === undefined) {
        logger.info(`[CatchUp] Policy ${policyId} has no initialAccumulation — skipping`);
        return { currentAccumulation: 0, monthsProcessed: 0, lastCalculatedDate: null };
    }

    // ⚠️  PENSION NOTE: catch-up runs for pension policies too (to keep currentAccumulation
    // up to date for display in the journal), but the result ONLY affects the סכום צבירה column.
    // The commission columns (נפרעים, היקף) for pension are NEVER derived from currentAccumulation —
    // they are calculated solely from input fields (monthlyDeposit × rate, mobility × rate).
    // Do NOT use policy.currentAccumulation as a base for pension commission calculations.

    const policyDetails = policy.details as Record<string, any>;
    const monthlyDeposit = policyDetails?.monthlyDeposit
        ? parseFloat(policyDetails.monthlyDeposit as string)
        : 0;

    // 2. Determine the anchor period
    const anchorDate = policy.lastCalculatedDate || policy.systemEntryDate;
    if (!anchorDate) {
        logger.warn(`[CatchUp] Policy ${policyId} has no anchor date — skipping`);
        return {
            currentAccumulation: initialAccum,
            monthsProcessed: 0,
            lastCalculatedDate: null,
        };
    }

    const anchorPeriod = dateToPeriod(anchorDate);
    const current = currentReportPeriod(); // This is already current month - 1

    // 3. Compute gap months
    const gapMonths = getGapMonths(anchorPeriod, current);

    if (gapMonths.length === 0) {
        const currentAccum = policy.currentAccumulation
            ? parseFloat(policy.currentAccumulation as string)
            : initialAccum;
        return {
            currentAccumulation: currentAccum,
            monthsProcessed: 0,
            lastCalculatedDate: anchorDate as string,
        };
    }

    // 4. Fetch yields and compound
    let balance = policy.currentAccumulation
        ? parseFloat(policy.currentAccumulation as string)
        : initialAccum;
    let monthsProcessed = 0;
    let lastProcessedPeriod = anchorPeriod;

    logger.info(
        `[CatchUp] Policy ${policyId} | Balance: ${balance} | Gap: ${gapMonths.length} months (${gapMonths[0]}→${gapMonths[gapMonths.length - 1]}) | Deposit: ${monthlyDeposit}`,
    );

    for (const month of gapMonths) {
        const weightedYield = await getWeightedYieldForPolicy(policyId, month, logger);

        // Stop if no data available (yield = null means API officially returned nothing and no pivot was done)
        if (weightedYield === null) {
            logger.info(
                `[CatchUp] Policy ${policyId} | Month ${month} returned yield=null (Not Published Yet) — pausing catch-up`,
            );
            break;
        }

        balance = compoundMonthlyYields(balance, [weightedYield], monthlyDeposit);
        monthsProcessed++;
        lastProcessedPeriod = month;

        logger.info(
            `[CatchUp]   └─ Month ${month} | Yield: ${(weightedYield * 100).toFixed(4)}% | Balance: ${balance.toFixed(2)}`,
        );
    }

    // 5. Update DB
    if (monthsProcessed > 0) {
        const newLastCalcDate = periodToDate(lastProcessedPeriod);
        try {
            await db
                .update(policies)
                .set({
                    currentAccumulation: String(balance),
                    lastCalculatedDate: newLastCalcDate,
                })
                .where(eq(policies.id, policyId));

            logger.info(
                `[CatchUp] ✅ Policy ${policyId} | Updated: balance=${balance.toFixed(2)}, lastCalc=${newLastCalcDate}`,
            );
        } catch (err) {
            logger.error({ err }, `[CatchUp] ❌ Failed to update policy ${policyId}`);
        }
    }

    return {
        currentAccumulation: Math.round(balance * 100) / 100,
        monthsProcessed,
        lastCalculatedDate:
            monthsProcessed > 0 ? periodToDate(lastProcessedPeriod) : (anchorDate as string),
    };
}

/**
 * @deprecated Use `runSmartCatchUp()` instead, which skips work when no new
 * government data has been published and pre-warms the yield cache to minimize
 * API calls. This function remains available for emergency full-reprocessing.
 *
 * Batch: catches up ALL policies that have a non-null initialAccumulation.
 */
export async function catchUpAllPolicies(
    log?: any,
): Promise<{ policiesProcessed: number; totalMonths: number }> {
    const logger = log || console;

    if (!db) {
        logger.warn('[CatchUp] DB not ready, skipping batch catch-up');
        return { policiesProcessed: 0, totalMonths: 0 };
    }

    // Find all policies with tracking data
    let trackablePolicies: any[] = [];
    try {
        trackablePolicies = await db
            .select({ id: policies.id })
            .from(policies)
            .where(isNotNull(policies.initialAccumulation));
    } catch (err) {
        logger.error({ err }, '[CatchUp] Failed to query policies');
        return { policiesProcessed: 0, totalMonths: 0 };
    }

    logger.info(`[CatchUp] 🔄 Starting batch catch-up for ${trackablePolicies.length} policies`);

    let totalMonths = 0;
    let policiesProcessed = 0;

    for (const p of trackablePolicies) {
        const result = await catchUpPolicy(p.id, logger);
        if (result.monthsProcessed > 0) {
            policiesProcessed++;
            totalMonths += result.monthsProcessed;
        }
    }

    logger.info(
        `[CatchUp] ✅ Batch complete | Policies: ${policiesProcessed} | Months: ${totalMonths}`,
    );

    return { policiesProcessed, totalMonths };
}

// ─────────────────────────────────────────────────────────────────────────────
// Smart Cron Orchestrator
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Inverts INSURANCE_TYPE_TO_RESOURCE to get all insurance types for a given resource ID.
 * e.g. GEMEL_RESOURCE_ID → ['gemel', 'hishtalmut', 'gemel_invest']
 */
function getInsuranceTypesForResource(resourceId: string): string[] {
    return Object.entries(INSURANCE_TYPE_TO_RESOURCE)
        .filter(([, resourceIds]: [string, string[]]) => (resourceIds as string[]).includes(resourceId))
        .map(([type]) => type);
}

/**
 * Returns the last N YYYYMM periods ending at (and including) the given period.
 * Used as a safe fallback lookback when last_processed_period is NULL.
 */
function getLast6Months(latestPeriod: string): string[] {
    const endYear = parseInt(latestPeriod.slice(0, 4), 10);
    const endMonth = parseInt(latestPeriod.slice(4, 6), 10);
    const periods: string[] = [];

    for (let i = 5; i >= 0; i--) {
        let m = endMonth - i;
        let y = endYear;
        if (m <= 0) { m += 12; y--; }
        periods.push(formatReportPeriod(y, m));
    }
    return periods;
}

/**
 * Smart nightly catch-up orchestrator.
 *
 * For each of the 3 government API resources:
 *  1. Probe the API for the latest published period (1 cheap call)
 *  2. Fast-exit if the period hasn't changed since our last run
 *  3. Otherwise:
 *     a. Pre-warm fund_yield_cache for all needed (fund_id, period) pairs
 *        in batches of 5 / 300ms — reduces live API calls in the catch-up loop
 *        from O(policies × tracks × months) to O(unique_funds × gap_months)
 *     b. Run catchUpPolicy() for every trackable policy of this resource type
 *        — all yield lookups are now cache HITs (pure DB work)
 *     c. Update gemel_resource_state to record the new processed period
 *
 * First-run behaviour (lastProcessedPeriod = NULL):
 *  - Fast-exit is skipped (always treat as new data)
 *  - Pre-warm lookback defaults to the last 6 months
 */
export async function runSmartCatchUp(
    log?: any,
): Promise<{ resourcesProcessed: number; policiesProcessed: number; totalMonths: number }> {
    const logger = log || console;

    if (!db) {
        logger.warn('[SmartCatchUp] DB not ready, skipping');
        return { resourcesProcessed: 0, policiesProcessed: 0, totalMonths: 0 };
    }

    // Load all 3 resource state rows
    let resourceRows: any[] = [];
    try {
        resourceRows = await db.select().from(gemelResourceState);
    } catch (err) {
        logger.error({ err }, '[SmartCatchUp] Failed to read gemel_resource_state — skipping run');
        return { resourcesProcessed: 0, policiesProcessed: 0, totalMonths: 0 };
    }

    let resourcesProcessed = 0;
    let totalPoliciesProcessed = 0;
    let totalMonthsProcessed = 0;

    for (const row of resourceRows) {
        const { resourceId, resourceName, lastProcessedPeriod } = row;
        logger.info(`[SmartCatchUp] 🔍 Checking resource: ${resourceName} (${resourceId})`);

        // ── Step 1: Probe API ──
        const latestPeriod = await probeLatestPeriodForResource(resourceId, logger);

        // Always update lastProbedAt
        await db
            .update(gemelResourceState)
            .set({ lastProbedAt: new Date() })
            .where(eq(gemelResourceState.resourceId, resourceId))
            .catch((err: any) => logger.warn({ err }, '[SmartCatchUp] Failed to update lastProbedAt'));

        if (!latestPeriod) {
            logger.warn(`[SmartCatchUp] ⚠️ Could not probe ${resourceName} — skipping`);
            continue;
        }

        // ── Step 2: Fast-exit check ──
        const isFirstRun = !lastProcessedPeriod;
        const hasNewData = isFirstRun || latestPeriod > lastProcessedPeriod;

        if (!hasNewData) {
            logger.info(
                `[SmartCatchUp] ⏭️  ${resourceName}: latest=${latestPeriod}, lastProcessed=${lastProcessedPeriod} — no new data, skipping`,
            );
            continue;
        }

        logger.info(
            `[SmartCatchUp] 🆕 ${resourceName}: new period detected ${lastProcessedPeriod ?? 'never'} → ${latestPeriod}`,
        );

        // ── Step 3a: Determine gap months ──
        const gapMonths = isFirstRun
            ? getLast6Months(latestPeriod)
            : getGapMonths(lastProcessedPeriod as string, latestPeriod);

        logger.info(
            `[SmartCatchUp] 📅 ${resourceName}: gap months = [${gapMonths.join(', ')}]`,
        );

        // ── Step 3b: Find all trackable policies for this resource ──
        const insuranceTypes = getInsuranceTypesForResource(resourceId);
        if (!insuranceTypes.length) {
            logger.warn(`[SmartCatchUp] No insurance types mapped to ${resourceName} — skipping`);
            continue;
        }

        let trackablePolicies: Array<{ id: string; insuranceType: string }> = [];
        try {
            trackablePolicies = await db
                .select({ id: policies.id, insuranceType: policies.insuranceType })
                .from(policies)
                .where(
                    // Only financial policies with a non-null initialAccumulation
                    // that belong to the insurance types served by this resource
                    isNotNull(policies.initialAccumulation),
                );
            // Filter by insurance type in-memory (simpler than pgEnum IN clause)
            trackablePolicies = trackablePolicies.filter((p) =>
                insuranceTypes.includes(p.insuranceType),
            );
        } catch (err) {
            logger.error({ err }, `[SmartCatchUp] Failed to query policies for ${resourceName}`);
            continue;
        }

        logger.info(
            `[SmartCatchUp] 📋 ${resourceName}: ${trackablePolicies.length} trackable policies`,
        );

        if (!trackablePolicies.length) {
            // No policies for this resource — still update the state so we don't reprobe tomorrow
            await db
                .update(gemelResourceState)
                .set({ lastProcessedPeriod: latestPeriod, lastProcessedAt: new Date() })
                .where(eq(gemelResourceState.resourceId, resourceId))
                .catch((err: any) => logger.warn({ err }, '[SmartCatchUp] Failed to update state'));
            continue;
        }

        // ── Step 3c: Collect unique fund IDs for the pre-warm ──
        const policyIds = trackablePolicies.map((p) => p.id);
        let uniqueFundIds: number[] = [];
        try {
            const trackRows = await db
                .select({ fundId: policyTracks.fundId })
                .from(policyTracks)
                .where(inArray(policyTracks.policyId, policyIds));
            uniqueFundIds = Array.from(new Set<number>(trackRows.map((t: { fundId: number }) => t.fundId)));
        } catch (err) {
            logger.warn({ err }, `[SmartCatchUp] Could not read policy_tracks — pre-warm skipped`);
        }

        // ── Step 3d: Pre-warm the cache ──
        // Use the first insurance type of this resource as a hint for the API resource selection
        const primaryInsuranceType = insuranceTypes[0] as any;
        if (uniqueFundIds.length) {
            logger.info(
                `[SmartCatchUp] 🔥 Pre-warming cache: ${uniqueFundIds.length} unique funds × ${gapMonths.length} months`,
            );
            await prewarmYieldCache(uniqueFundIds, gapMonths, primaryInsuranceType, logger);
        }

        // ── Step 3e: Catch-up phase (all yield lookups are now cache HITs) ──
        let policiesProcessed = 0;
        let monthsProcessed = 0;

        for (const policy of trackablePolicies) {
            const result = await catchUpPolicy(policy.id, logger);
            if (result.monthsProcessed > 0) {
                policiesProcessed++;
                monthsProcessed += result.monthsProcessed;
            }
        }

        totalPoliciesProcessed += policiesProcessed;
        totalMonthsProcessed += monthsProcessed;

        // ── Step 3f: Update resource state ──
        await db
            .update(gemelResourceState)
            .set({ lastProcessedPeriod: latestPeriod, lastProcessedAt: new Date() })
            .where(eq(gemelResourceState.resourceId, resourceId))
            .catch((err: any) =>
                logger.warn({ err }, `[SmartCatchUp] Failed to update state for ${resourceName}`),
            );

        resourcesProcessed++;
        logger.info(
            `[SmartCatchUp] ✅ ${resourceName} complete | Policies: ${policiesProcessed} | Months: ${monthsProcessed}`,
        );
    }

    logger.info(
        `[SmartCatchUp] 🏁 Run complete | Resources: ${resourcesProcessed} | Policies: ${totalPoliciesProcessed} | Months: ${totalMonthsProcessed}`,
    );

    return {
        resourcesProcessed,
        policiesProcessed: totalPoliciesProcessed,
        totalMonths: totalMonthsProcessed,
    };
}
