/**
 * @fileoverview GemelNet Government API Integration — Fund Yield Fetching
 *
 * ⚠️  STRICT NO-ASSUMPTIONS POLICY (enforced since conv 357465ea):
 *
 * 1. NO AUTO-PIVOT: If a specific YYYYMM period is requested and the API returns
 *    no data OR returns a different period — return `null`. Do NOT fall back to
 *    an adjacent month or any estimation.
 *
 * 2. PERIOD MATCH REQUIRED: After fetching, always verify `actualPeriod === activePeriod`.
 *    If they differ, treat it as "not published yet" and return null.
 *
 * 3. HALT ON NULL: If any track for a policy returns yield=null, the entire
 *    catch-up for that policy month must halt (return null upstream).
 *    Do not average with available tracks or skip the null track.
 *
 * 4. CACHE FALLBACK (latest mode only): Cache fallback is ONLY used when
 *    requesting the "latest" available yield (not a specific period).
 *
 * Reference: /commission_calculation_report.md, /journal_columns_guide.md
 * Data source: https://data.gov.il — Official Israeli government fund data
 */
import { GEMELNET_COMPANY_MAP, POLIS_COMPANY_MAP, InsuranceType } from '@repo/types';
import { and, desc, eq, inArray } from 'drizzle-orm';
import { db } from '../db/connection.js';
import { fundYieldCache, gemelResourceState, policies, policyTracks } from '../db/schema.js';

const GEMEL_NET_URL = 'https://data.gov.il/api/3/action/datastore_search';
const GEMEL_RESOURCE_ID = 'a30dcbea-a1d2-482c-ae29-8f781f5025fb';
const PENSION_RESOURCE_ID = '6d47d6b5-cb08-488b-b333-f1e717b1e1bd'; // Includes comprehensive pension funds
const POLIS_RESOURCE_ID = 'c6c62cc7-fe02-4b18-8f3e-813abfbb4647'; // Long Term Savings (Polisot Hisachon)

export const INSURANCE_TYPE_TO_RESOURCE: Record<string, string[]> = {
    pension: [PENSION_RESOURCE_ID],
    gemel: [GEMEL_RESOURCE_ID],
    hishtalmut: [GEMEL_RESOURCE_ID],
    gemel_invest: [GEMEL_RESOURCE_ID],
    long_term_savings: [POLIS_RESOURCE_ID],
};

const ALL_RESOURCES = [PENSION_RESOURCE_ID, GEMEL_RESOURCE_ID, POLIS_RESOURCE_ID];

/**
 * Formats a Date (or year+month) into the YYYYMM string expected by the API.
 */
export function formatReportPeriod(year: number, month: number): string {
    return `${year}${String(month).padStart(2, '0')}`;
}

/**
 * Returns the current report period string (current month).
 */
export function currentReportPeriod(): string {
    const now = new Date();
    let year = now.getFullYear();
    // now.getMonth() is 0-indexed (April is 3). So if we want the PREVIOUS month calendar-wise,
    // it perfectly aligns with now.getMonth() unless it's January (0), then we need December (12).
    let month = now.getMonth();

    if (month === 0) {
        month = 12;
        year -= 1;
    }

    return formatReportPeriod(year, month);
}

interface GemelNetRecord {
    FUND_ID: string | number;
    REPORT_PERIOD: string | number;
    /** Monthly gross nominal yield as a percentage, e.g. 1.23 means 1.23% */
    TSUA_NOMINALIT_BRUTO_HODSHIT: string | number | null;
}

interface GemelNetResponse {
    success: boolean;
    result: {
        records: GemelNetRecord[];
    };
}

/**
 * Fetches the monthly gross nominal yield for a specific fund + period from the Government API.
 * Returns the yield as a decimal (e.g. 0.0123 for 1.23%), or null if not available.
 */
async function fetchFromApi(
    fundId: number,
    reportPeriod?: string,
    insuranceType?: InsuranceType,
    log?: any,
): Promise<{
    yieldDecimal: number;
    actualPeriod: string;
    success: boolean;
    error?: string;
} | null> {
    const logger = log || console;
    const tryFetch = async (
        resourceId: string,
    ): Promise<
        { yieldDecimal: number; actualPeriod: string; success: boolean } | 'not_found' | 'error'
    > => {
        const bodyObj: any = {
            resource_id: resourceId,
            filters: { FUND_ID: String(fundId) },
            limit: 1,
        };

        if (reportPeriod && reportPeriod !== 'latest') {
            bodyObj.filters.REPORT_PERIOD = reportPeriod;
            logger.info(
                `[GemelNet Debug] 🎯 Mode: Specific Period (${reportPeriod}) | Fund: ${fundId} | Resource: ${resourceId}`,
            );
        } else {
            // "Latest" mode: sort descending to get the most recent entry
            bodyObj.sort = 'REPORT_PERIOD desc';
            logger.info(
                `[GemelNet Debug] 🚀 Mode: Absolute Latest (ignoring time) | Fund: ${fundId} | Resource: ${resourceId}`,
            );
        }

        try {
            const res = await fetch(GEMEL_NET_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(bodyObj),
                signal: AbortSignal.timeout(10_000),
            });

            if (!res.ok) {
                logger.info(`[GemelNet Debug] ⚠️ HTTP Error ${res.status} for ${resourceId}`);
                return 'error';
            }

            const rawText = await res.text();
            const data = JSON.parse(rawText) as GemelNetResponse & {
                result: { records: Array<Record<string, any>> };
            };

            if (!data.success) {
                logger.info(`[GemelNet Debug] ⚠️ API returned success=false for ${resourceId}`);
                return 'error';
            }

            if (!data.result?.records?.length) {
                return 'not_found';
            }

            const firstRecord = data.result.records[0];
            const raw = firstRecord.TSUA_NOMINALIT_BRUTO_HODSHIT ?? firstRecord.MONTHLY_YIELD;

            if (raw === null || raw === undefined || raw === '') return 'not_found';

            const p = parseFloat(String(raw));
            if (isNaN(p)) return 'not_found';

            return {
                yieldDecimal: p / 100,
                actualPeriod: String(firstRecord.REPORT_PERIOD),
                success: true,
            };
        } catch (error) {
            logger.error({ error, resourceId }, `[GemelNet Debug] ❌ Fetch Error [${resourceId}]`);
            return 'error';
        }
    };

    const sources =
        insuranceType && INSURANCE_TYPE_TO_RESOURCE[insuranceType]
            ? INSURANCE_TYPE_TO_RESOURCE[insuranceType]
            : ALL_RESOURCES;

    for (const sourceId of sources) {
        const result = await tryFetch(sourceId);
        if (result === 'error') continue; // Try next source if this one errored
        if (result === 'not_found') continue; // Try next source if not found

        // Success!
        logger.info(
            `[GemelNet API] ✅ Success | Fund ${fundId} | Found in ${sourceId} | Period: ${result.actualPeriod} | Yield: ${(result.yieldDecimal * 100).toFixed(4)}%`,
        );
        return { ...result, success: true };
    }

    return null;
}

/**
/**
 * Reads the most recent yield for a fund from the cache (any period), used as a fallback.
 */
async function getLatestCachedYield(fundId: number): Promise<number | null> {
    if (!db) return null;
    try {
        const rows = await db
            .select()
            .from(fundYieldCache)
            .where(eq(fundYieldCache.fundId, fundId))
            .orderBy(desc(fundYieldCache.reportPeriod))
            .limit(1);
        if (!rows.length) return null;
        return parseFloat(rows[0].monthlyYield as string);
    } catch {
        return null;
    }
}

/**
 * Writes (or upserts) a yield value to the cache.
 */
async function writeCacheEntry(
    fundId: number,
    reportPeriod: string,
    monthlyYield: number,
    log?: any,
): Promise<void> {
    const logger = log || console;
    if (!db) return;
    try {
        await db
            .insert(fundYieldCache)
            .values({
                fundId,
                reportPeriod,
                monthlyYield: String(monthlyYield),
            })
            .onConflictDoUpdate({
                target: [fundYieldCache.fundId, fundYieldCache.reportPeriod],
                set: {
                    monthlyYield: String(monthlyYield),
                    fetchedAt: new Date(),
                },
            });
    } catch (err) {
        logger.warn({ err }, '[GemelNet] writeCacheEntry failed');
    }
}

/**
 * Main yield-fetching function.
 *
 * 1. Checks the local cache first.
 * 2. If not cached, fetches from the Government API.
 * 3. If the API has no data for the requested period (not yet published),
 *    falls back to the most recently cached yield for that fund.
 * 4. Stores the result back in cache.
 *
 * @returns monthly yield as a decimal (e.g. 0.0123 = 1.23%), or 0 if unavailable.
 */
export async function fetchYieldForFund(
    fundId: number,
    reportPeriod?: string,
    insuranceType?: InsuranceType,
    log?: any,
): Promise<number | null> {
    const activePeriod = reportPeriod || 'latest';
    const logger = log || console;
    logger.info(
        `[GemelNet Heartbeat] 💓 Fetching yield for Fund: ${fundId} | Period: ${activePeriod}`,
    );
    if (!db) {
        logger.warn('[GemelNet] DB not ready, returning null yield');
        return null;
    }

    // 1. Check cache (only if a specific period was requested)
    if (reportPeriod && reportPeriod !== 'latest') {
        let cached: any[] = [];
        try {
            cached = await db
                .select()
                .from(fundYieldCache)
                .where(
                    and(
                        eq(fundYieldCache.fundId, fundId),
                        eq(fundYieldCache.reportPeriod, reportPeriod),
                    ),
                )
                .limit(1);
        } catch {
            logger.warn('[GemelNet] fund_yield_cache not available yet (migration pending?)');
        }

        if (cached.length > 0) {
            const cachedYield = parseFloat(cached[0].monthlyYield as string);
            console.info(
                `[GemelNet Cache] 💾 HIT — Fund ${fundId} | Period ${reportPeriod} | Yield: ${(cachedYield * 100).toFixed(4)}%`,
            );
            return cachedYield;
        }
    }

    // 2. Fetch from API
    const current = currentReportPeriod();
    const isLatestRequested = !reportPeriod || reportPeriod === 'latest';

    logger.info(
        `[GemelNet API] 🔍 Evaluating Fetch — Req: "${activePeriod}" | Curr: "${current}" | isLatest: ${isLatestRequested}`,
    );

    let apiResult = await fetchFromApi(
        fundId,
        isLatestRequested ? 'latest' : activePeriod,
        insuranceType,
        logger,
    );

    // No auto-pivot: If specific period failed, we return null to signal missing data (No assumptions)
    if (apiResult === null && !isLatestRequested && activePeriod !== 'latest') {
        logger.info(
            `[GemelNet API] 🛑 Specific period ${activePeriod} not published yet for fund ${fundId}. Stopping (No Assumptions).`,
        );
        return null;
    }

    if (apiResult && apiResult.success) {
        const { yieldDecimal, actualPeriod } = apiResult;

        if (!isLatestRequested && actualPeriod !== activePeriod) {
            logger.info(
                `[GemelNet API] 🛑 Requested ${activePeriod} but API returned ${actualPeriod}. Treating as not published yet. (No Assumptions)`,
            );
            return null;
        }

        if (isLatestRequested) {
            console.info(
                `[GemelNet API] 🚀 Using LATEST available data — Fund ${fundId} | Got: ${actualPeriod} | Original Requested: ${activePeriod}`,
            );
        }

        // Store in cache (only if it matched exactly, which is guaranteed here for specific periods)
        await writeCacheEntry(fundId, actualPeriod, yieldDecimal, logger);

        return yieldDecimal;
    }

    const fallback = await getLatestCachedYield(fundId);
    if (fallback !== null) {
        logger.warn(
            `[GemelNet] ⚠️ No API data for fund ${fundId} period ${activePeriod}. Using cached fallback yield: ${(fallback * 100).toFixed(4)}%`,
        );
        return fallback;
    }

    // 4. Absolutely no data — return null
    logger.warn(`[GemelNet] ❌ No yield data at all for fund ${fundId}. Returning null.`);
    return null;
}

/**
 * Calculates the weighted monthly yield for a single policy by reading
 * its policy_tracks and fetching each track's yield from the cache/API.
 *
 * @returns blended yield as a decimal (e.g. 0.0098 = 0.98%)
 */
export async function getWeightedYieldForPolicy(
    policyId: string,
    reportPeriod?: string,
    log?: any,
): Promise<number | null> {
    const logger = log || console;
    if (!db) return 0;

    let tracks: any[] = [];
    try {
        tracks = await db.select().from(policyTracks).where(eq(policyTracks.policyId, policyId));
    } catch {
        // policy_tracks table doesn't exist yet — return 0 until migration runs
        logger.warn(
            '[GemelNet] policy_tracks not available yet (migration pending?). Returning 0 yield.',
        );
        return 0;
    }

    // Fetch policy details to get insurance type
    const policyRows = await db
        .select({ insuranceType: policies.insuranceType })
        .from(policies)
        .where(eq(policies.id, policyId))
        .limit(1);
    const policy = policyRows[0];

    if (!tracks.length) {
        // No tracks assigned — yield = 0 (accumulation driven by deposits only)
        return 0;
    }

    let weightedYield = 0;
    logger.info(
        `[GemelNet] 📊 Policy ${policyId} | ${tracks.length} track(s) | Period ${reportPeriod || 'latest'}`,
    );
    for (const track of tracks) {
        const share = parseFloat(track.sharePercentage as string); // 0..1
        const yld = await fetchYieldForFund(
            track.fundId,
            reportPeriod,
            policy?.insuranceType,
            logger,
        );

        if (yld === null) {
            logger.info(
                `[GemelNet]   └─ Track "${track.trackName}" | Fund ${track.fundId} | Yield is NULL. Halting weighted calculation.`,
            );
            return null; // Strict "No Assumptions": If one track is missing, we can't accurately compound the month
        }

        const contribution = share * yld;
        logger.info(
            `[GemelNet]   └─ Track "${track.trackName}" | Fund ${track.fundId} | Share ${(share * 100).toFixed(1)}% | Yield ${(yld * 100).toFixed(4)}% | Contribution ${(contribution * 100).toFixed(4)}%`,
        );
        weightedYield += contribution;
    }
    logger.info(
        `[GemelNet] 🏁 Policy ${policyId} | Weighted Yield: ${(weightedYield * 100).toFixed(4)}%`,
    );
    return weightedYield;
}

/**
 * Fetches all active investment tracks for a given company and insurance type.
 * Deduplicates by FUND_ID and returns a clean array.
 */
export async function fetchTracksForCompany(
    insuranceType: InsuranceType,
    company: string,
    log?: any,
): Promise<Array<{ trackName: string; fundId: number }>> {
    const logger = log || console;
    const resources = INSURANCE_TYPE_TO_RESOURCE[insuranceType] || ALL_RESOURCES;
    let mappedCompany = '';
    const filters: any = {};

    if (insuranceType === 'long_term_savings') {
        mappedCompany = POLIS_COMPANY_MAP[company] || company;
        filters.PARENT_COMPANY_NAME = mappedCompany;
    } else {
        mappedCompany = GEMELNET_COMPANY_MAP[company] || company;
        filters.MANAGING_CORPORATION = mappedCompany;
    }

    if (insuranceType === 'gemel') filters.FUND_CLASSIFICATION = 'תגמולים ואישית לפיצויים';
    if (insuranceType === 'hishtalmut') filters.FUND_CLASSIFICATION = 'קרנות השתלמות';
    if (insuranceType === 'gemel_invest') filters.FUND_CLASSIFICATION = 'קופת גמל להשקעה';
    
    // We query the latest available month to avoid getting thousands of rows
    // Note: If no rows match, we might fall back to general query, but querying latest should be fine
    
    logger.info(`[GemelNet Tracks] 🔍 Fetching tracks for Company: ${company} (${mappedCompany}) | Type: ${insuranceType} | Filters: ${JSON.stringify(filters)}`);
    
    let allFunds = new Map<number, string>();
    
    for (const resourceId of resources) {
        try {
            const bodyObj: any = {
                resource_id: resourceId,
                filters,
                fields: 'FUND_ID,FUND_NAME',
                limit: 1000,
                sort: 'REPORT_PERIOD desc',
            };
            
            const res = await fetch(GEMEL_NET_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(bodyObj),
                signal: AbortSignal.timeout(10_000),
            });
            
            if (!res.ok) {
                logger.warn(`[GemelNet Tracks] ⚠️ HTTP Error ${res.status} for ${resourceId}`);
                continue;
            }
            
            const data = await res.json() as any;
            if (!data.success || !data.result?.records?.length) {
                continue;
            }
            
            const records = data.result.records;
            
            // Deduplicate by FUND_ID
            for (const record of records) {
                const fundId = parseInt(String(record.FUND_ID), 10);
                const fundName = record.FUND_NAME?.replace(/S1;P/gi, 'S&P');
                
                if (!isNaN(fundId) && fundName && !allFunds.has(fundId)) {
                    allFunds.set(fundId, fundName);
                }
            }
            
        } catch (error) {
            logger.error({ error, resourceId }, `[GemelNet Tracks] ❌ Fetch Error`);
        }
    }
    
    const result = Array.from(allFunds.entries()).map(([fundId, trackName]) => ({ trackName, fundId }));
    
    logger.info(`[GemelNet Tracks] ✅ Found ${result.length} tracks for ${company}`);
    return result;
}

// ─────────────────────────────────────────────────────────────────────────────
// Smart Cron Helpers — resource version check + cache pre-warm
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Probes a single government API resource for its latest published REPORT_PERIOD.
 * Makes exactly ONE cheap API call (no fund filter, limit=1, sort desc).
 * Used as a fast gatekeeper by the nightly cron before doing any heavy work.
 *
 * @param resourceId - The government API resource UUID (e.g. GEMEL_RESOURCE_ID)
 * @returns Latest YYYYMM period string, or null on failure / empty resource
 */
export async function probeLatestPeriodForResource(
    resourceId: string,
    log?: any,
): Promise<string | null> {
    const logger = log || console;
    try {
        const body = {
            resource_id: resourceId,
            limit: 1,
            sort: 'REPORT_PERIOD desc',
            fields: 'REPORT_PERIOD',
        };

        const res = await fetch(GEMEL_NET_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
            signal: AbortSignal.timeout(10_000),
        });

        if (!res.ok) {
            logger.warn(`[GemelNet Probe] ⚠️ HTTP ${res.status} for resource ${resourceId}`);
            return null;
        }

        const data = await res.json() as any;
        if (!data.success || !data.result?.records?.length) {
            logger.warn(`[GemelNet Probe] ⚠️ No records found for resource ${resourceId}`);
            return null;
        }

        const period = String(data.result.records[0].REPORT_PERIOD);
        logger.info(`[GemelNet Probe] ✅ Resource ${resourceId} → latest period: ${period}`);
        return period;
    } catch (err) {
        logger.error({ err }, `[GemelNet Probe] ❌ Failed to probe resource ${resourceId}`);
        return null;
    }
}

/**
 * Pre-warms the fund_yield_cache for a set of (fund_id, period) pairs.
 *
 * Strategy:
 *  1. Build the full cartesian product: fundIds × gapMonths
 *  2. Check fund_yield_cache for already-cached pairs (one DB query)
 *  3. Fetch only the missing pairs from the API, in batches of 5 with 300ms delay
 *  4. writeCacheEntry() inside fetchYieldForFund() persists each result
 *
 * After this function completes, every subsequent catchUpPolicy() call will
 * find cache HITs for all yield lookups — zero live API calls during the per-policy loop.
 *
 * @param fundIds       - Unique fund IDs needed across all policies for this resource
 * @param gapMonths     - YYYYMM period strings to pre-warm (e.g. ['202503', '202504'])
 * @param insuranceType - Used to target the correct API resource
 */
export async function prewarmYieldCache(
    fundIds: number[],
    gapMonths: string[],
    insuranceType: InsuranceType,
    log?: any,
): Promise<void> {
    const logger = log || console;

    if (!fundIds.length || !gapMonths.length) return;

    // 1. Build full set of needed pairs
    const needed: Array<{ fundId: number; period: string }> = [];
    for (const fundId of fundIds) {
        for (const period of gapMonths) {
            needed.push({ fundId, period });
        }
    }

    logger.info(
        `[Prewarm] 🔥 Starting cache pre-warm | ${fundIds.length} funds × ${gapMonths.length} periods = ${needed.length} pairs`,
    );

    // 2. Check which pairs are already cached.
    // Fetch all fund_yield_cache rows for the relevant fund IDs, then filter in-memory.
    // (Drizzle doesn't natively support tuple-IN; the result set is small — bounded by
    //  unique fund IDs across all tracks, typically < 200 rows.)
    let alreadyCached = new Set<string>();
    if (db) {
        try {
            const relevantRows = await db
                .select({ fundId: fundYieldCache.fundId, reportPeriod: fundYieldCache.reportPeriod })
                .from(fundYieldCache)
                .where(inArray(fundYieldCache.fundId, fundIds));

            alreadyCached = new Set(relevantRows.map((r: { fundId: number; reportPeriod: string }) => `${r.fundId}:${r.reportPeriod}`));
        } catch (err) {
            logger.warn({ err }, '[Prewarm] ⚠️ Could not check cache — will fetch all pairs from API');
        }
    }

    // 3. Filter to only missing pairs
    const missing = needed.filter(({ fundId, period }) => !alreadyCached.has(`${fundId}:${period}`));

    logger.info(
        `[Prewarm] 📊 Cache check complete | ${alreadyCached.size} already cached | ${missing.length} to fetch from API`,
    );

    if (!missing.length) {
        logger.info('[Prewarm] ✅ All pairs already cached — nothing to fetch');
        return;
    }

    // 4. Fetch missing pairs in batches of 5 with 300ms delay between batches
    const BATCH_SIZE = 5;
    const BATCH_DELAY_MS = 300;
    let fetched = 0;
    let failed = 0;

    for (let i = 0; i < missing.length; i += BATCH_SIZE) {
        const batch = missing.slice(i, i + BATCH_SIZE);

        await Promise.all(
            batch.map(async ({ fundId, period }) => {
                try {
                    const result = await fetchYieldForFund(fundId, period, insuranceType, logger);
                    if (result !== null) {
                        fetched++;
                    } else {
                        // null means data not published yet — not an error
                        logger.info(
                            `[Prewarm]   └─ Fund ${fundId} | Period ${period} → not published yet (null)`,
                        );
                    }
                } catch (err) {
                    failed++;
                    logger.warn({ err }, `[Prewarm] ⚠️ Failed to fetch fund ${fundId} period ${period}`);
                }
            }),
        );

        if (i + BATCH_SIZE < missing.length) {
            await new Promise((resolve) => setTimeout(resolve, BATCH_DELAY_MS));
        }
    }

    logger.info(
        `[Prewarm] ✅ Pre-warm complete | Fetched: ${fetched} | Failed: ${failed} | Skipped (not published): ${missing.length - fetched - failed}`,
    );
}
