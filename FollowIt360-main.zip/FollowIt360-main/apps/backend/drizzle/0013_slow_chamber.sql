CREATE TABLE "daily_page_visits" (
	"date" date NOT NULL,
	"path" text NOT NULL,
	"visit_count" integer DEFAULT 0 NOT NULL,
	CONSTRAINT "daily_page_visits_date_path_pk" PRIMARY KEY("date","path")
);
--> statement-breakpoint
CREATE TABLE "user_roles" (
	"user_id" uuid NOT NULL,
	"role" text NOT NULL,
	CONSTRAINT "user_roles_user_id_role_pk" PRIMARY KEY("user_id","role")
);
--> statement-breakpoint
ALTER TABLE "user_roles" ADD CONSTRAINT "user_roles_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;