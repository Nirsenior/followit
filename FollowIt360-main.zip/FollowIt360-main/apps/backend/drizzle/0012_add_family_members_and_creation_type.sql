ALTER TABLE customers ADD COLUMN IF NOT EXISTS family_members jsonb DEFAULT '[]'::jsonb;
--> statement-breakpoint
ALTER TABLE customers ADD COLUMN IF NOT EXISTS creation_type text DEFAULT 'existing';