CREATE TABLE "gemel_resource_state" (
    "resource_id"            varchar(36)  PRIMARY KEY NOT NULL,
    "resource_name"          text         NOT NULL,
    "last_processed_period"  varchar(6),
    "last_probed_at"         timestamp,
    "last_processed_at"      timestamp
);
--> statement-breakpoint

-- Seed one row per government API resource.
-- last_processed_period intentionally NULL: the smart cron interprets NULL as
-- "never processed" and will perform a full catch-up with a 6-month pre-warm lookback
-- on its first run.
INSERT INTO "gemel_resource_state" ("resource_id", "resource_name") VALUES
    ('a30dcbea-a1d2-482c-ae29-8f781f5025fb', 'gemel'),
    ('6d47d6b5-cb08-488b-b333-f1e717b1e1bd', 'pension'),
    ('c6c62cc7-fe02-4b18-8f3e-813abfbb4647', 'polis');
