ALTER TABLE "policies" ADD COLUMN "system_entry_date" date;--> statement-breakpoint
ALTER TABLE "policies" ADD COLUMN "initial_accumulation" numeric(14, 2);--> statement-breakpoint
ALTER TABLE "policies" ADD COLUMN "last_calculated_date" date;--> statement-breakpoint
ALTER TABLE "policies" ADD COLUMN "current_accumulation" numeric(14, 2);