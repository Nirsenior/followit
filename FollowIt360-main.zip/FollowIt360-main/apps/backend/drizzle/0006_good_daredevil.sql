CREATE TYPE "public"."insuranceType_enum" AS ENUM('health', 'life', 'critical_illness', 'pension', 'gemel', 'hishtalmut', 'gemel_invest', 'long_term_savings', 'elementary', 'abroad');--> statement-breakpoint
CREATE TABLE "customers" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid NOT NULL,
	"name" text NOT NULL,
	"birthdate" date,
	"government_id" text NOT NULL,
	CONSTRAINT "customers_user_id_gov_idx" UNIQUE("user_id","government_id")
);
--> statement-breakpoint
CREATE TABLE "policies" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"customer_id" uuid NOT NULL,
	"company" "company_enum" NOT NULL,
	"insurance_type" "insuranceType_enum" NOT NULL,
	"issue_date" date,
	"details" jsonb DEFAULT '{}'::jsonb NOT NULL
) WITH (fillfactor = 85);
--> statement-breakpoint
ALTER TABLE "customers" ADD CONSTRAINT "customers_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "policies" ADD CONSTRAINT "policies_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "customers_user_id_idx" ON "customers" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "policies_details_gin_idx" ON "policies" USING gin ("details" jsonb_path_ops);