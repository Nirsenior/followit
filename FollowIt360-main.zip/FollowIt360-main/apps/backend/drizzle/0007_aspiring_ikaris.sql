DO $$ 
BEGIN 
    IF EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'customers' 
        AND column_name = 'birthdate'
        AND table_schema = 'public'
    ) THEN 
        ALTER TABLE "customers" RENAME COLUMN "birthdate" TO "issue_date";
    END IF;
END $$;
--> statement-breakpoint
ALTER TABLE "agreements" ALTER COLUMN "company" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "policies" ALTER COLUMN "company" SET DATA TYPE text;--> statement-breakpoint
DROP TYPE IF EXISTS "public"."company_enum";--> statement-breakpoint
CREATE TYPE "public"."company_enum" AS ENUM('הראל', 'מגדל', 'מנורה', 'הפניקס', 'כלל', 'איילון', 'שומרה', 'שלמה חברה לביטוח', 'הכשרה', 'פספורטקארד', 'אלטשולר שחם', 'אינפיניטי', 'מור', 'פסגות', 'אנליסט', 'IBI', 'ילין לפידות', 'מיטב', 'GLOBAL');--> statement-breakpoint
UPDATE "agreements" SET "company" = 'שלמה חברה לביטוח' WHERE "company" = 'שלמה';--> statement-breakpoint
UPDATE "policies" SET "company" = 'שלמה חברה לביטוח' WHERE "company" = 'שלמה';--> statement-breakpoint
ALTER TABLE "agreements" ALTER COLUMN "company" SET DATA TYPE "public"."company_enum" USING "company"::"public"."company_enum";--> statement-breakpoint
ALTER TABLE "policies" ALTER COLUMN "company" SET DATA TYPE "public"."company_enum" USING "company"::"public"."company_enum";