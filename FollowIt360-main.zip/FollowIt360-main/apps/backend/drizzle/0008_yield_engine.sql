CREATE TABLE IF NOT EXISTS "fund_yield_cache" (
	"id" serial PRIMARY KEY NOT NULL,
	"fund_id" integer NOT NULL,
	"report_period" varchar(6) NOT NULL,
	"monthly_yield" numeric(10, 6) NOT NULL,
	"is_estimated" boolean DEFAULT true NOT NULL,
	"fetched_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "fund_yield_cache_fund_period_unq" UNIQUE("fund_id","report_period")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "policy_tracks" (
	"id" serial PRIMARY KEY NOT NULL,
	"policy_id" uuid NOT NULL,
	"fund_id" integer NOT NULL,
	"share_percentage" numeric(5, 4) NOT NULL,
	"track_name" text
);
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "policy_tracks" ADD CONSTRAINT "policy_tracks_policy_id_policies_id_fk" FOREIGN KEY ("policy_id") REFERENCES "public"."policies"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "fund_yield_cache_fund_id_idx" ON "fund_yield_cache" USING btree ("fund_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "policy_tracks_policy_id_idx" ON "policy_tracks" USING btree ("policy_id");