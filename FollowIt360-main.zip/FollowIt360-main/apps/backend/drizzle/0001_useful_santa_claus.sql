CREATE TYPE "public"."company_enum" AS ENUM('הראל', 'מגדל', 'מנורה', 'הפניקס', 'כלל', 'איילון', 'שומרה', 'שלמה', 'הכשרה', 'פספורטקארד', 'אלטשולר שחם', 'אינפיניטי', 'מור', 'פסגות');--> statement-breakpoint
CREATE TABLE "agreements" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" integer NOT NULL,
	"company" "company_enum" NOT NULL,
	"rates" jsonb DEFAULT '{}'::jsonb NOT NULL,
	CONSTRAINT "agreements_user_id_company_unique" UNIQUE("user_id","company")
);
--> statement-breakpoint
ALTER TABLE "agreements" ADD CONSTRAINT "agreements_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;