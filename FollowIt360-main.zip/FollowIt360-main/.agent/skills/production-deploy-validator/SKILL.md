---
name: production-deploy-validator
description: This skill should be used when the user asks to "prepare the system to production", "validate production deployment", "check GCP production readiness", "run production pre-flight checks", "verify secrets in production", or "validate production DB and resources".
version: 0.1.0
---

# Production Deploy Validator

This skill outlines the procedures for checking the production readiness of the Follow-It system before executing deployments. Use it to ensure all environments, cloud resources, secrets, database configurations, and network settings are validated correctly.

## Instructions

1. **Verify stack configuration locally** by running the automated script.
   Use the local validation script in `scripts/validate-env-and-repo.js` to perform static analysis of the repository. Run:
   ```bash
   node .agent/skills/production-deploy-validator/scripts/validate-env-and-repo.js
   ```
2. **Consult the production readiness checklist** in `references/checklist.md` to ensure all structural items (build, testing, DNS) are checked.
3. **Run GCP verification commands** in `references/gcp-checks.md` to query GCP directly and verify active cloud resources, secrets, VPC network settings, scheduler jobs, and resource alerts.
4. **Set up resource and billing alerts** as detailed in `references/gcp-checks.md` to monitor CPU usage, database storage, and project billing thresholds.

## Additional Resources

### Reference Files

- **`references/checklist.md`** - Full production readiness checklist for stack, cloud, database, and security validation.
- **`references/gcp-checks.md`** - A complete list of `gcloud` copy-pasteable commands to verify cloud setup and guides to configure billing, CPU, and DB storage alerts.

### Scripts

- **`scripts/validate-env-and-repo.js`** - Node.js script to check for hardcoded secrets, misconfigured URLs, and CORS rules in the repository.
