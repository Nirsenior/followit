# Production Readiness Checklist

This document contains a structured, comprehensive checklist for verifying that the application stack, GCP cloud resources, secrets, database settings, and build systems are ready for a production release.

## 1. Application & Stack Configuration
- [ ] **Build Check:** Execute local build of backend and frontend. Ensure zero TypeScript/bundling compilation errors:
  - `npm run build` in root workspace.
- [ ] **TypeScript Config:** Validate that standard Node ESM options parse correctly and target packages resolve.
- [ ] **CORS Verification:** Inspect `apps/backend/index.ts` to ensure that:
  - Development allows all origins.
  - Production allows requests from `followit360.com` and matching Cloud Run service subdomains.
- [ ] **Environment Validation:** Verify that no hardcoded backend development URLs (e.g. `localhost:8080`) are left in frontend production configurations.
  - Build args for frontend in CI/CD pipeline specify `VITE_API_URL` correctly.

## 2. Cloud Infrastructure & Networks
- [ ] **VPC Network:** Validate the existence of VPC networks `follow-it-vpc-staging` and `follow-it-vpc-prod` in their respective projects.
- [ ] **Serverless VPC Access:** Confirm VPC Connectors are configured:
  - Staging: `connector-subnet-staging` with IP range `10.1.2.0/24`.
  - Production: `connector-subnet-prod` with IP range `10.1.1.0/24`.
- [ ] **Private Service Connect (PSC) in Staging:** Verify the PSC Endpoint `sql-psc-endpoint` exists in staging network with IP `10.1.2.2` mapping to the SQL service attachment.
- [ ] **Direct Private IP in Prod:** Confirm that the production VPC peers directly with Google Managed Services (Private Service Access peering) over `google-managed-services-prod` address range.
- [ ] **DNS Mapping:** Check that the Cloud DNS records are correctly mapped:
  - Staging: Private zone `sql.goog.` maps `e1cfa342fb4d.2q1z4vmhb3e66.me-west1.sql.goog.` to the PSC endpoint IP `10.1.2.2`.
  - Production: Custom domains `followit360.com` and `www.followit360.com` point to the Firebase Hosting configurations.

## 3. Secrets Management
- [ ] **Manually Configured Secrets:** Verify that the following secrets are created manually in Google Secret Manager for **both projects**:
  - `JWT_SECRET` (stores token signing keys)
  - `GOOGLE_CLIENT_ID` (client ID for Google OAuth authentication)
  - `GOOGLE_CLIENT_SECRET` (secret for Google OAuth authentication)
  - `CRON_SECRET` (token to authenticate Cloud Scheduler cron triggers)
  - `SMTP_PASS` (password/app-password for SMTP mail agent)
- [ ] **Access Control:** Confirm that the application Service Accounts (`followit360-app-sa@<project-id>.iam.gserviceaccount.com`) are granted the **Secret Manager Secret Accessor** role (`roles/secretmanager.secretAccessor`) on these secrets.

## 4. Database Setup
- [ ] **Database Engine Version:** Confirm that the SQL instance is configured with Postgres 15.
- [ ] **Database Separation:** Verify that the single instance hosts two separate databases:
  - `follow_it_staging` (staging database)
  - `follow_it_prod` (production database)
- [ ] **IAM Database Authentication:** Verify that Cloud SQL database flags have `cloudsql.iam_authentication` set to `on`.
- [ ] **Service Account Users:** Ensure IAM service account users are created inside the database:
  - Staging SA: `followit360-app-sa@followit360-stg.iam`
  - Prod SA: `followit360-app-sa@followit360-prod.iam`
- [ ] **Database Migration System:** Ensure that migrations run smoothly and automatically on application startup using Drizzle. Run `db:generate` locally to verify Drizzle has generated all necessary SQL scripts for schemas.

## 5. Automation & Schedulers
- [ ] **Cron Triggers:** Validate that Cloud Scheduler job `yield-catch-up-job` exists in both projects.
- [ ] **Cron Payload Security:** Verify that the Scheduler jobs are configured to include the `"x-cron-secret"` header matching the secret manager `CRON_SECRET` value.
- [ ] **Cron Endpoints:** Ensure target URLs map to `https://www.followit360.com/api/yields/catch-up` (prod) and `https://staging.followit360.com/api/yields/catch-up` (staging).
