# Google Cloud Resource Verification & Alerting Guide

This reference document outlines specific `gcloud` CLI commands to verify GCP deployment readiness, database settings, and networking configurations. It also includes instructions for setting up CPU, database storage, and billing alerts.

To run these checks, ensure the `gcloud` CLI is installed, and authenticate by running:
```bash
gcloud auth login
```

---

## 1. Secrets Manager Validation

Verify that all required application secrets exist in Google Secret Manager.

### Check secrets listing in Production:
```bash
gcloud secrets list --project=followit360-prod
```
Ensure the output contains:
* `JWT_SECRET`
* `GOOGLE_CLIENT_ID`
* `GOOGLE_CLIENT_SECRET`
* `CRON_SECRET`
* `SMTP_PASS`

### Check secrets listing in Staging:
```bash
gcloud secrets list --project=followit360-stg
```

### Check Service Account Permissions on Secrets:
Verify that the application service account has permissions to access secret payloads.
```bash
# Verify for JWT_SECRET
gcloud secrets get-iam-policy JWT_SECRET --project=followit360-prod
```
Ensure that `roles/secretmanager.secretAccessor` is granted to:
`serviceAccount:followit360-app-sa@followit360-prod.iam.gserviceaccount.com`
`serviceAccount:followit360-app-sa@followit360-stg.iam.gserviceaccount.com`

---

## 2. Cloud SQL Database Validation

Confirm instance and network setup for PostgreSQL 15.

### Describe the Cloud SQL Instance (located in Prod):
```bash
gcloud sql instances describe follow-it-cluster --project=followit360-prod
```
* **Verify:** `databaseVersion` is `POSTGRES_15`
* **Verify IP Configuration:** Under `ipConfiguration`, ensure `ipv4Enabled` is `false` (no public IP) and that the private network settings correspond to VPC connectivity.
* **Verify IAM Auth:** Under `databaseFlags`, ensure the flag `cloudsql.iam_authentication` is `on`.

### List IAM Users inside the DB Instance:
```bash
gcloud sql users list --instance=follow-it-cluster --project=followit360-prod
```
Verify the following IAM users are listed with type `CLOUD_IAM_SERVICE_ACCOUNT`:
* `followit360-app-sa@followit360-stg.iam`
* `followit360-app-sa@followit360-prod.iam`

---

## 3. Network & Connectivity Validation

### Staging VPC & Private Service Connect (PSC):
Confirm that the Forwarding Rule for PSC SQL target is correctly configured in staging.
```bash
gcloud compute forwarding-rules list --project=followit360-stg
```
Check that `sql-psc-rule` points to the Cloud SQL instance service attachment and lists IP address `10.1.2.2`.

### Staging Cloud DNS Records:
Verify that the private zone resolves the PSC endpoint properly.
```bash
gcloud dns record-sets list --zone=sql-psc-zone --project=followit360-stg
```
Ensure that `e1cfa342fb4d.2q1z4vmhb3e66.me-west1.sql.goog.` resolves to the A record `10.1.2.2`.

### VPC Peering in Production (Private Service Access):
Confirm that Private Service Connection is established in the production network.
```bash
gcloud compute addresses list --global --project=followit360-prod
```
Ensure `google-managed-services-prod` exists and is reserved for VPC Peering.

---

## 4. Cloud Run Services Validation

Describe the backend and frontend configurations.

### Verify Backend Environment Variables & Secrets:
```bash
gcloud run services describe backend --region=me-west1 --project=followit360-prod
```
Verify:
* Environment variables `DB_NAME` (`follow_it_prod`), `DB_IP_TYPE` (`PRIVATE`), `DB_USER` (`followit360-app-sa@followit360-prod.iam`) are set.
* Secrets `JWT_SECRET`, `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `CRON_SECRET`, `SMTP_PASS` are correctly mapped to their latest versions.
* VPC Connector points to `connector-subnet-prod` and VPC egress is set to `private-ranges-only`.

### Verify Staging Backend Environment:
```bash
gcloud run services describe backend --region=me-west1 --project=followit360-stg
```
Verify:
* `DB_IP_TYPE` is set to `PSC`.
* `DB_PSC_TARGET` is set to `10.1.2.2`.

---

## 5. Cloud Scheduler Job Validation

Confirm the nightly batch tasks configurations.
```bash
gcloud scheduler jobs list --project=followit360-prod
gcloud scheduler jobs list --project=followit360-stg
```
* **Verify:** Job `yield-catch-up-job` exists and is scheduled for `0 2 * * *`.
* **Verify Header:** Inspect the job headers to ensure `x-cron-secret` is correctly defined.

---

## 6. Resource Alerts & Billing Budgets Setup Guide

Setup monitoring alerts to prevent outages and budget overruns.

### A. Set Up Google Cloud Billing Budgets & Alerts
Avoid billing surprises by establishing alerts at percentage thresholds.

1. Navigate to the Google Cloud Console **Billing** page.
2. Select **Budgets & alerts** from the left navigation menu.
3. Click **Create Budget**:
   - **Scope:** Select both `followit360-prod` and `followit360-stg` projects.
   - **Amount:** Select **Specified Amount** and enter your monthly limit (e.g. `$50` or `$100` budget).
   - **Actions / Thresholds:** Configure threshold alerts at:
     - **50% of budget** (triggers email notification to billing administrators)
     - **90% of budget** (triggers warning notification)
     - **100% of budget** (indicates budget fully consumed)
   - **Pub/Sub Notifications (Optional):** Attach a Pub/Sub topic if you wish to trigger automated functions (such as scaling down resources or disabling services) when budget limits are breached.
4. Click **Finish**.

### B. Configure Cloud Run CPU Utilization Alerts
Monitor server instances when computing loads exceed safe capacities.

Create an alerting policy in Cloud Monitoring:
```bash
# Create a CPU Alert Policy using gcloud CLI
gcloud alpha monitoring policies create \
  --project=followit360-prod \
  --display-name="High Cloud Run Backend CPU Alert" \
  --enabled \
  --conditions="type=threshold,name='CPU exceeds 80% for 5 mins',filter='resource.type=\"cloud_run_revision\" AND resource.labels.service_name=\"backend\" AND metric.type=\"run.googleapis.com/container/cpu/utilizations\"',comparison=COMPARISON_GT,threshold-value=0.8,duration=300s,trigger-count=1" \
  --notification-channels="[NOTIFICATION_CHANNEL_ID]"
```
*Note: Replace `[NOTIFICATION_CHANNEL_ID]` with your configured monitoring email channel or Slack webhook ID (which can be listed using `gcloud beta monitoring channels list`).*

### C. Configure Cloud SQL Storage Auto-Increase & Alerts
Database disk space exhaustion will crash the database. Prevent this by combining auto-increase and space alerts.

#### 1. Enable Storage Auto-Increase (Recommended & Free):
Storage auto-increase scales database storage capacity dynamically when utilization is high. It only bills for the active storage used, which is highly cost-effective compared to over-provisioning.
```bash
gcloud sql instances patch follow-it-cluster \
  --project=followit360-prod \
  --storage-auto-increase
```

#### 2. Create Storage Utilization Warning Alerts (exceeds 85%):
Generate a warning notification when disk utilization grows rapidly.
```bash
gcloud alpha monitoring policies create \
  --project=followit360-prod \
  --display-name="Cloud SQL Disk Utilization Warning" \
  --enabled \
  --conditions="type=threshold,name='Disk usage exceeds 85%',filter='resource.type=\"cloudsql_database\" AND resource.labels.database_id=\"followit360-prod:follow-it-cluster\" AND metric.type=\"cloudsql.googleapis.com/database/disk/utilization\"',comparison=COMPARISON_GT,threshold-value=0.85,duration=600s" \
  --notification-channels="[NOTIFICATION_CHANNEL_ID]"
```
