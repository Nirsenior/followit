import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '../../../../');

let errorCount = 0;
let warningCount = 0;

function logError(message) {
    console.error(`\x1b[31m[ERROR] ${message}\x1b[0m`);
    errorCount++;
}

function logWarning(message) {
    console.warn(`\x1b[33m[WARNING] ${message}\x1b[0m`);
    warningCount++;
}

function logSuccess(message) {
    console.log(`\x1b[32m[SUCCESS] ${message}\x1b[0m`);
}

// 1. Scan for hardcoded credentials / keys
function scanForSecrets() {
    console.log('\n--- Scanning for hardcoded secrets ---');
    const scanPaths = [
        path.join(rootDir, 'apps/backend'),
        path.join(rootDir, 'apps/frontend/src')
    ];

    const secretRegexes = [
        /const\s+\w*(secret|key|password|token)\w*\s*=\s*['"`][a-zA-Z0-9_\-]{16,}['"`]/gi,
        /password:\s*['"`][a-zA-Z0-9_\-]{8,}['"`]/gi,
        /clientSecret:\s*['"`][a-zA-Z0-9_\-]{16,}['"`]/gi,
        /JWT_SECRET\s*=\s*['"`][a-zA-Z0-9_\-]{16,}['"`]/gi
    ];

    function checkFile(filePath) {
        // Skip .env, test files, configs, and build files
        const baseName = path.basename(filePath);
        if (baseName.includes('.env') ||
            baseName.includes('test.') ||
            baseName.includes('config.') ||
            baseName === 'package.json' ||
            baseName === 'package-lock.json' ||
            filePath.includes('dist') ||
            filePath.includes('node_modules') ||
            filePath.includes('.turbo') ||
            filePath.includes('validate-env-and-repo.js')) {
            return;
        }

        try {
            const content = fs.readFileSync(filePath, 'utf8');
            secretRegexes.forEach((regex, idx) => {
                let match;
                while ((match = regex.exec(content)) !== null) {
                    // Make sure it's not process.env
                    if (match[0].includes('process.env')) continue;
                    logError(`Potential hardcoded secret found in ${path.relative(rootDir, filePath)}: "${match[0].trim()}"`);
                }
            });
        } catch (e) {
            // Ignore unreadable files
        }
    }

    function walkDir(dir) {
        if (!fs.existsSync(dir)) return;
        const list = fs.readdirSync(dir);
        list.forEach(file => {
            const fullPath = path.join(dir, file);
            const stat = fs.statSync(fullPath);
            if (stat && stat.isDirectory()) {
                walkDir(fullPath);
            } else {
                checkFile(fullPath);
            }
        });
    }

    scanPaths.forEach(walkDir);
    if (errorCount === 0) {
        logSuccess('No hardcoded secrets detected in application source code.');
    }
}

// 2. Validate CORS configurations
function validateCORS() {
    console.log('\n--- Checking CORS configurations ---');
    const indexPath = path.join(rootDir, 'apps/backend/index.ts');
    if (!fs.existsSync(indexPath)) {
        logWarning('backend/index.ts not found. Skipping CORS validation.');
        return;
    }

    const content = fs.readFileSync(indexPath, 'utf8');
    if (content.includes("origin: '*'") && content.includes("NODE_ENV === 'production'")) {
        logError('Wildcard CORS origin is enabled in production environment.');
    } else if (content.includes('followit360') && content.includes("NODE_ENV === 'production'")) {
        logSuccess('CORS limits allowed origins in production (detected followit360 domain checks).');
    } else {
        logWarning('Ensure CORS configuration restricts origins to followit360.com in production.');
    }
}

// 3. Verify Database IP/PSC configs are dynamic
function validateDbConnection() {
    console.log('\n--- Checking database connection properties ---');
    const connPath = path.join(rootDir, 'apps/backend/db/connection.ts');
    if (!fs.existsSync(connPath)) {
        logError('db/connection.ts not found. Critical file missing.');
        return;
    }

    const content = fs.readFileSync(connPath, 'utf8');
    const usesPscTarget = content.includes('DB_PSC_TARGET');
    const usesIpTypeEnv = content.includes('DB_IP_TYPE');

    if (!usesIpTypeEnv || !usesPscTarget) {
        logError('db/connection.ts has hardcoded database connection settings. Needs process.env.DB_IP_TYPE and process.env.DB_PSC_TARGET.');
    } else {
        logSuccess('Database connection configurations are dynamically set using environment variables.');
    }
}

// 4. Verify deployment configuration consistency
function validateDeployConfig() {
    console.log('\n--- Checking CI/CD deploy configuration ---');
    const deployYmlPath = path.join(rootDir, '.github/workflows/deploy.yml');
    if (!fs.existsSync(deployYmlPath)) {
        logWarning('.github/workflows/deploy.yml not found. Skipping workflow validation.');
        return;
    }

    const content = fs.readFileSync(deployYmlPath, 'utf8');

    // Expected environment variables on Cloud Run
    const expectedVars = [
        'DB_NAME',
        'DB_USER',
        'INSTANCE_CONNECTION_NAME',
        'BASE_URL',
        'FRONTEND_URL',
        'DB_IP_TYPE',
        'DB_PSC_TARGET'
    ];

    const expectedSecrets = [
        'JWT_SECRET',
        'GOOGLE_CLIENT_ID',
        'GOOGLE_CLIENT_SECRET',
        'CRON_SECRET',
        'SMTP_PASS'
    ];

    expectedVars.forEach(v => {
        if (!content.includes(v)) {
            logError(`CI/CD deploy.yml is missing expected environment variable: ${v}`);
        }
    });

    expectedSecrets.forEach(s => {
        if (!content.includes(s)) {
            logError(`CI/CD deploy.yml is missing expected secret mapping: ${s}`);
        }
    });

    if (content.includes('ui-test')) {
        logWarning('CI/CD deploy.yml still contains triggers for the "ui-test" branch.');
    }

    if (errorCount === 0) {
        logSuccess('CI/CD deployment workflow variables and secret mappings are correct.');
    }
}

// Run scans
scanForSecrets();
validateCORS();
validateDbConnection();
validateDeployConfig();

console.log('\n--- Scan Summary ---');
console.log(`Errors: ${errorCount}`);
console.log(`Warnings: ${warningCount}`);

if (errorCount > 0) {
    console.log('\n\x1b[31mVerification FAILED. Please resolve errors before publishing.\x1b[0m');
    process.exit(1);
} else {
    console.log('\n\x1b[32mVerification PASSED. Code is ready for production.\x1b[0m');
    process.exit(0);
}
