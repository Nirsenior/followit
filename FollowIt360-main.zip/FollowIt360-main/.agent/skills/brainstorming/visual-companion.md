# Visual Companion

The Visual Companion is a browser-based tool for showing mockups, diagrams, and visual options during brainstorming. It works by running a local Node.js server that serves a dynamic HTML page.

## How it works

1. **Server:** A local Node.js server (`server.cjs`) runs on port 3000. It serves an HTML page (`frame-template.html`) and provides a WebSocket for real-time updates.
2. **Client:** The HTML page connects to the WebSocket and listens for updates. When it receives new content, it updates the page.
3. **Control:** You control the content of the page by sending messages to the server using the `scripts/helper.js` script.

## Using the Visual Companion

### 1. Start the server

Before you can use the Visual Companion, you need to start the server. Run the following command in your terminal:

```bash
bash skills/brainstorming/scripts/start-server.sh
```

This will start the server in the background. You only need to do this once per session.

### 2. Open the page

Once the server is running, open the following URL in your web browser:

`http://localhost:3000`

### 3. Update the content

To update the content of the page, use the `scripts/helper.js` script. You can send HTML, CSS, and JavaScript to the page.

Example:

```bash
node skills/brainstorming/scripts/helper.js update --html "<h1>Hello World</h1>" --css "h1 { color: red; }"
```

### 4. Stop the server

When you're finished, you can stop the server by running:

```bash
bash skills/brainstorming/scripts/stop-server.sh
```

## Best Practices

- **Keep it simple:** The Visual Companion is for quick mockups and diagrams, not full applications.
- **Use it for visuals:** Only use the browser for content that is inherently visual. Use the terminal for everything else.
- **Iterate quickly:** Use the companion to show options and get feedback, then move on.
- **Don't over-engineer:** Avoid complex JavaScript or external dependencies unless absolutely necessary.
