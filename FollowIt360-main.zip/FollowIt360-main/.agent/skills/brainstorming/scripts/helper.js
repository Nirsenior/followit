const http = require('http');

const args = process.argv.slice(2);
const command = args[0];

if (command === 'update') {
    const params = {};
    for (let i = 1; i < args.length; i += 2) {
        const key = args[i].replace(/^--/, '');
        params[key] = args[i + 1];
    }

    const data = JSON.stringify({
        type: 'update',
        ...params
    });

    const req = http.request({
        hostname: 'localhost',
        port: 3000,
        path: '/update',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': data.length
        }
    }, (res) => {
        res.on('data', () => {});
        res.on('end', () => {
            console.log('Update sent');
        });
    });

    req.on('error', (e) => {
        console.error(`Problem with request: ${e.message}`);
    });

    req.write(data);
    req.end();
} else {
    console.log('Usage: node helper.js update --html "..." --css "..." --js "..."');
}
