# Design Specification: Admin User Management

This document details the architectural design for the Admin User Management feature inside Follow-It. The goal is to provide system administrators with a highly performant, paginated, filterable, and sortable display of all registered users (insurance agents) and their aggregated customer metrics.

---

## 1. Architectural Overview

The feature uses a server-side paginated table. The frontend requests batches of user data from the backend by providing limits, offsets, column sorting parameters, and filtering values.

```mermaid
sequenceDiagram
    participant FE as Frontend (AdminDashboard)
    participant BE as Backend API (Fastify)
    participant DB as Postgres Database (Drizzle)

    FE->>BE: GET /api/admin/users?page=1&limit=25&search=Moshe&sortBy=customerCount&sortOrder=desc
    BE->>DB: Query users left-joined with customer counts + filters
    DB-->>BE: Returns subset of users and total count
    BE-->>FE: Returns { users: User[], totalCount: 42, totalPages: 2 }
```

---

## 2. Component Design & APIs

### Backend Endpoint: `GET /api/admin/users`
A new administrative route will be added to the backend under `/api/admin/users.ts`.

* **Authorization:** Requires the existing `requireAdmin` middleware.
* **Query Parameters:**
  - `page` (number, default: 1)
  - `limit` (number, default: 10)
  - `sortBy` (string: `'name' | 'email' | 'customerCount' | 'createdAt' | 'phone' | 'isSubscribed'`)
  - `sortOrder` (string: `'asc' | 'desc'`)
  - `search` (string, filters name and email)
  - `filterPhone` (string)
  - `filterIsSubscribed` (string: `'true' | 'false' | ''`)

* **Database Query Details (Drizzle ORM):**
  - Left-joins the `users` table with the `customers` table, grouped by `users.id` to aggregate a count of each user's customers.
  - Applies selective where-clauses for query string filters.
  - Computes limits and offsets.
  - Returns a payload structure:
    ```json
    {
      "users": [
        {
          "id": "uuid",
          "name": "Full Name",
          "email": "user@example.com",
          "customerCount": 14,
          "phone": "050-1234567",
          "isSubscribed": true,
          "createdAt": "2026-05-01T12:00:00.000Z"
        }
      ],
      "totalCount": 120,
      "totalPages": 5,
      "currentPage": 1
    }
    ```

### Frontend Layout: `AdminDashboard.tsx`
* **KPI Header:** Compress the existing 4 large KPI cards into a single row of compact cards to reduce vertical space consumption by 50%.
* **Collapsible Charts Section:** Place the "Common Insurance Companies" and "Common Policy Types" cards in a collapsible container or secondary tab, allowing the Admin User Table to occupy the main viewport.
* **Virtualized Paginated Table:**
  - Use server-side state for tracking pagination, sorting, and filters.
  - Show input fields in the table header of each column (Name, Email, Phone, Subscription) for filtering.
  - Render clean loading, empty, and error states.

---

## 3. TDD Strategy (Test-Driven Development)

1. Write backend test file `apps/backend/routes/admin/getUsers.test.ts` first.
2. Define tests covering:
   - Successful paginated responses.
   - Searching by user name or email.
   - Sorting by user name, email, and customer counts.
   - Access rejection for non-admin users.
3. Once the tests are written and fail appropriately, implement the endpoint code inside `apps/backend/routes/admin/getUsers.ts` until all tests pass successfully.

---

## 4. Deferred Steps: Phone and Subscription DB Updates

As per explicit requirements, database changes to natively support permanent `phone` and `isSubscribed` columns will be deferred to the **very last step of the plan**.

* **Phase 1 (Development):** Use mocked/derived values for `phone` and `isSubscribed` on the backend returned from `/api/admin/users` (e.g. realistic Hebrew phone numbers and random boolean values) to design, build, and test the entire functional table in the frontend and backend.
* **Phase 2 (Final Step):** Modify `schema.ts`, generate and apply migrations to add the columns to the DB, update the API to read directly from those columns, and ask the user for specific instructions on how they want to populate/manage this data going forward.
