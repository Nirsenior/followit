# Design Specification: Commission Rate Effectivity (Retroactive vs. From Now On)

This document details the architectural design for handling retroactive vs. future ("from now on") commission rate adjustments inside Follow-It. The goal is to allow agents to update their ongoing renewal commission ("נפרעים") rates and choose whether the change applies retroactively to existing policies or strictly to future sales.

---

## 1. Architectural Overview

The system uses a **server-side bulk transaction model** to execute effectivity decisions. 

Instead of modifying all policies on the client and sending huge bulk policy updates over HTTP, the frontend registers the user's choices inside the `EffectivityModal` and saves them in local memory. When the user clicks the final "Save" button, the frontend sends both the new agreements and a list of `effectivityDecisions` to the server. The server then executes the bulk adjustments in a single database transaction.

```mermaid
sequenceDiagram
    participant FE as Frontend (ProfileSettings)
    participant BE as Backend API (Fastify)
    participant DB as Postgres Database (Drizzle)

    FE->>BE: POST /api/agreements { userId, agreements, effectivityDecisions }
    Note over BE: Starts DB Transaction
    BE->>DB: Save updated agreements
    loop For each effectivityDecision
        alt isRetroactive is false (From Now On)
            BE->>DB: Lock the oldValue as fixedCommissionRate on existing matching policies
        else isRetroactive is true (Retroactive)
            BE->>DB: Clear fixedCommissionRate on existing matching policies
        end
        BE->>DB: Update nested family member policies inside customers JSONB
    end
    Note over BE: Commits DB Transaction
    BE-->>FE: Returns success { status: 'success' }
```

---

## 2. Technical Design & Database Schema

### 2.1 Database Schema Changes
To natively support rate overrides on a per-policy level, we add a new `fixedCommissionRate` column to the `policies` table in the database schema.

**File: [schema.ts](file:///c:/Users/WINDOWS%2011/Desktop/Follow-It/apps/backend/db/schema.ts)**
```typescript
export const policies = pgTable(
    'policies',
    {
        id: uuid('id').primaryKey().defaultRandom(),
        customerId: uuid('customer_id')
            .references(() => customers.id, { onDelete: 'cascade' })
            .notNull(),
        company: companyEnum('company').notNull(),
        insuranceType: insuranceTypeEnum('insurance_type').notNull(),
        issueDate: date('issue_date'),
        details: jsonb('details').notNull().default({}),
        
        // --- ADDED FOR RATE EFFECTIVITY LOCKS ---
        fixedCommissionRate: numeric('fixed_commission_rate', { precision: 5, scale: 2 }),

        // --- Accumulation Tracking ---
        systemEntryDate: date('system_entry_date'),
        initialAccumulation: numeric('initial_accumulation', { precision: 14, scale: 2 }),
        lastCalculatedDate: date('last_calculated_date'),
        currentAccumulation: numeric('current_accumulation', { precision: 14, scale: 2 }),
    }
);
```

---

## 3. API Endpoint Updates

### 3.1 `POST /api/agreements`
We update the request payload to optionally accept an array of `effectivityDecisions` representing the changes that need to be made to existing policies.

* **Route File**: [saveAgreements.ts](file:///c:/Users/WINDOWS%2011/Desktop/Follow-It/apps/backend/routes/agreements/saveAgreements.ts)
* **Zod Schemas**:
```typescript
const effectivityDecisionSchema = z.object({
    company: z.string(), // "GLOBAL" or specific company name
    type: z.enum(insuranceTypeEnum.enumValues),
    oldValue: z.string(),
    newValue: z.string(),
    isRetroactive: z.boolean(),
});

const saveAgreementsRequestSchema = z.object({
    userId: z.string().uuid('Invalid User ID format'),
    agreements: z.array(agreementItemSchema),
    effectivityDecisions: z.array(effectivityDecisionSchema).optional().default([]),
});
```

* **Handler Implementation (Transactional safety)**:
```typescript
await db.transaction(async (tx) => {
    // 1. Insert/update the user's master agreements
    await tx.insert(agreements).values(agreementsToInsert).onConflictDoUpdate(...);

    // 2. Process effectivity decisions if provided
    if (effectivityDecisions.length > 0) {
        const userCustomers = await tx
            .select({ id: customers.id, familyMembers: customers.familyMembers })
            .from(customers)
            .where(eq(customers.userId, userId));

        if (userCustomers.length > 0) {
            const customerIds = userCustomers.map((c) => c.id);

            for (const decision of effectivityDecisions) {
                const companyCondition = decision.company !== 'GLOBAL' 
                    ? eq(policies.company, decision.company as any) 
                    : undefined;

                if (decision.isRetroactive) {
                    // RETROACTIVE: Wipe custom rate locks, falling back to new master agreement rate
                    await tx.update(policies)
                        .set({ fixedCommissionRate: null })
                        .where(
                            and(
                                inArray(policies.customerId, customerIds),
                                eq(policies.insuranceType, decision.type),
                                companyCondition
                            )
                        );
                } else {
                    // FROM NOW ON: Freeze the old rate on existing policies that don't have a lock yet
                    await tx.update(policies)
                        .set({ fixedCommissionRate: decision.oldValue })
                        .where(
                            and(
                                inArray(policies.customerId, customerIds),
                                eq(policies.insuranceType, decision.type),
                                companyCondition,
                                isNull(policies.fixedCommissionRate)
                            )
                        );
                }

                // Update family members' policies stored in JSONB column inside customers table
                for (const customer of userCustomers) {
                    let familyMembersUpdated = false;
                    const familyMembers = (customer.familyMembers as any[]) || [];

                    const updatedFamilyMembers = familyMembers.map((fm) => {
                        const updatedPolicies = (fm.policies as any[] || []).map((policy) => {
                            const isMatch = policy.type === decision.type && 
                                (decision.company === 'GLOBAL' || policy.company === decision.company);

                            if (isMatch) {
                                familyMembersUpdated = true;
                                if (decision.isRetroactive) {
                                    const { fixedCommissionRate, ...rest } = policy;
                                    return rest;
                                } else {
                                    if (!policy.fixedCommissionRate) {
                                        return { ...policy, fixedCommissionRate: decision.oldValue };
                                    }
                                }
                            }
                            return policy;
                        });
                        return { ...fm, policies: updatedPolicies };
                    });

                    if (familyMembersUpdated) {
                        await tx.update(customers)
                            .set({ familyMembers: updatedFamilyMembers })
                            .where(eq(customers.id, customer.id));
                    }
                }
            }
        }
    }
});
```

### 3.2 `GET /api/customers`
Update the API response structure in [getCustomers.ts](file:///c:/Users/WINDOWS%2011/Desktop/Follow-It/apps/backend/routes/customers/getCustomers.ts) to map the database column to the frontend model:
```typescript
fixedCommissionRate: p.fixedCommissionRate || undefined
```

### 3.3 Customer Schema Updates (`policySchema`)
Update [schemas.ts](file:///c:/Users/WINDOWS%2011/Desktop/Follow-It/apps/backend/routes/customers/schemas.ts) to accept `fixedCommissionRate` in Zod and include it during updates:
```typescript
export const policySchema = z.object({
    id: z.string().optional(),
    company: z.enum(companyEnum.enumValues as [string, ...string[]]),
    insuranceType: z.enum(insuranceTypeEnum.enumValues as [string, ...string[]]),
    issueDate: z.string().optional(),
    isAgentAppointmentOnly: z.boolean().optional(),
    details: z.any().optional().default({}),
    fixedCommissionRate: z.string().optional(), // <-- ADDED
    systemEntryDate: z.string().optional(),
    initialAccumulation: z.string().optional(),
    lastCalculatedDate: z.string().optional(),
    currentAccumulation: z.string().optional(),
});
```

---

## 4. Frontend State & UI Integration

### 4.1 State Management in `ProfileSettings.tsx`
* Add local state tracking for effectivity choices:
```typescript
interface EffectivityDecision {
    company: string;
    type: InsuranceType;
    oldValue: string;
    newValue: string;
    isRetroactive: boolean;
}

const [effectivityDecisions, setEffectivityDecisions] = useState<EffectivityDecision[]>([]);
```

* Update `applyChange(isRetroactive)`:
```typescript
const applyChange = (isRetroactive: boolean) => {
    if (!pendingChange) return;
    const { company, type, oldValue, newValue } = pendingChange;

    // Save decision in state to send to backend on Save
    setEffectivityDecisions((prev) => {
        const filtered = prev.filter((d) => !(d.company === company && d.type === type));
        return [...filtered, { company, type, oldValue, newValue, isRetroactive }];
    });

    // Update queryClient locally as before so that it takes effect immediately in UI
    ...
    setPendingChange(null);
};
```

* Update `handleSave`:
```typescript
await fetch(`${baseUrl}/api/agreements`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify({
        userId: profile.id,
        agreements: agreementsPayload,
        effectivityDecisions, // <-- SEND TO SERVER
    }),
});
```

---

## 5. Test-Driven Development (TDD) Strategy

### 5.1 Backend Tests
We will write a comprehensive test suite first under `apps/backend/routes/agreements/saveAgreements.test.ts` to test:
1. **Standard Save**: Saving agreements with an empty decisions array doesn't affect existing policies.
2. **From Now On (Non-Retroactive)**: Sending `isRetroactive: false` locks the `oldValue` on matching user policies, while ignoring unmatched companies or types.
3. **Retroactive**: Sending `isRetroactive: true` clears the lock (`fixedCommissionRate = null`) on existing matching policies.
4. **Nested JSONB**: Verifies that policies stored inside `familyMembers` arrays in the `customers` table are correctly locked or cleared based on effectivity decisions.

### 5.2 Frontend Tests
- Verify that `ProfileSettings` collects and structures the decisions array correctly inside `handleSave`.
