# FollowIt360

Insurance & financial policy management platform for Israeli insurance agents.

## What It Does

- Manage clients and their insurance/financial policies (pension, health, gemel, hishtalmut, long-term savings, elementary)
- Track commissions (scope / ongoing) per policy type, per company agreement
- Calculate compound accumulation for financial policies using live Government API yield data (data.gov.il)
- Customer journal view with aggregated monthly payments, accumulation, and commissions

## Tech Stack

| Layer        | Technology                                  |
| ------------ | ------------------------------------------- |
| Monorepo     | Turborepo                                   |
| Backend      | Node.js + Express + TypeScript              |
| Frontend     | React + Vite + TypeScript                   |
| Database     | PostgreSQL via Drizzle ORM                  |
| Auth         | Google OAuth2 + JWT                         |
| Hosting      | Google Cloud Run (backend + frontend)       |
| Infra        | Terraform + Google Cloud SQL                |
| CI/CD        | GitHub Actions → Cloud Run (staging + prod) |
| Shared Types | `packages/types`                            |

## Project Structure

```
apps/
  backend/          Express API server
    routes/         REST endpoints
    services/       Business logic (gemelNetService, yieldCalculationService)
    db/             Drizzle schema + migrations
  frontend/         React SPA
    pages/          CustomerJournal, Dashboard, etc.
packages/
  types/            Shared TypeScript interfaces (Policy, Customer, etc.)
  eslint-config/    Shared lint config
infra/              Terraform (Cloud SQL, Cloud Run, VPC)
```

## Key Business Docs

- [`commission_calculation_report.md`](./commission_calculation_report.md) — Commission formula reference (Hebrew)
- [`journal_columns_guide.md`](./journal_columns_guide.md) — Customer journal column definitions (Hebrew)

## Dev Commands

```bash
# Install all dependencies
npm install

# Run everything in dev mode
npm run dev

# Run backend only
cd apps/backend && npm run dev

# Run frontend only
cd apps/frontend && npm run dev

# Build all
npm run build

# Run tests
npm run test

# Format all files
npx prettier --write .
```

## Environment

Backend requires a `.env` file in `apps/backend/`. Key variables:

- `DATABASE_URL` — PostgreSQL connection string
- `JWT_SECRET` — JWT signing secret
- `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` — OAuth2 credentials
- `CRON_SECRET` — Secret for the Cloud Scheduler yield cron endpoint

## Environments

| Branch    | Environment | URL                             |
| --------- | ----------- | ------------------------------- |
| `main`    | Production  | https://followit360.com         |
| `develop` | Staging     | https://staging.followit360.com |

## Deployment & Production Validation

The repository includes a custom suite of tools to validate production readiness and verify cloud infrastructure before committing to production:

### 1. Run Pre-flight Checks (Local Repo Validation)
To check for hardcoded secrets, database IP configurations, CORS restrictions, and CI/CD environment mappings:
```bash
node .agent/skills/production-deploy-validator/scripts/validate-env-and-repo.js
```

### 2. CI/CD Validation
The deployment pipeline (`.github/workflows/deploy.yml`) is configured with the following safeguards:
- Installs dependencies and automatically compiles monorepo packages (such as `@repo/types`).
- Executes all unit and integration tests (`npm run test`).
- **If any test or compilation fails, the deployment is blocked immediately.**

### 3. Monitoring & Alerting (GCP)
Alerting policies are deployed on the `follow-it-cluster` database and Cloud Run instances:
- **Cloud Run CPU Alert:** Triggers if CPU utilization exceeds 80% for 5 minutes (configured for both staging and production).
- **Cloud SQL CPU Alert:** Triggers if Database CPU utilization exceeds 80% for 5 minutes.
- **Cloud SQL Disk Warning:** Triggers if database disk storage utilization exceeds 85% for 10 minutes.
- **Billing Budget Alert:** Active on the billing account at 50%, 90%, and 100% of the monthly 100 ILS budget.

### 4. Artifact Registry Cleanup Policies
To keep GCP storage costs to a minimum, a cleanup policy is set on the Artifact Registry repository (`app-images`) in both `followit360-stg` and `followit360-prod` to retain only the **3 most recent versions** of the backend/frontend images.

