export default [
  {
    extends: 'vitest.config.mts',
    test: {
      name: 'frontend',
      include: ['apps/frontend/**/*.test.{ts,tsx,js,jsx}'],
      environment: 'happy-dom',
    }
  },
  {
    extends: 'vitest.config.mts',
    test: {
      name: 'backend',
      include: ['apps/backend/**/*.test.{ts,tsx,js,jsx}'],
      environment: 'node',
    }
  }
];
