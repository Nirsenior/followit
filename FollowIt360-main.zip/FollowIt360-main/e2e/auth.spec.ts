import { test, expect } from '@playwright/test';

test.describe('Authentication Flows', () => {
  test('TC-AUTH-01: Valid User Login', async ({ page }) => {
    // Mock the backend API response for login
    await page.route('**/api/auth/login', async (route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          userId: 'test-user-123',
          name: 'Test Agent',
          email: 'agent@pro.co.il',
          agreements: []
        }),
      });
    });

    // Navigate to the login page
    await page.goto('/login');

    const emailInput = page.getByPlaceholder('agent@pro.co.il');

    // Fill the login form
    await expect(emailInput).toBeVisible();
    await emailInput.fill('agent@pro.co.il');
    await page.getByPlaceholder('••••••••').fill('password123');

    // Submit the form
    await page.getByRole('button', { name: 'כניסה מאובטחת' }).click();

    // Verify successful login logic - expecting redirection to Dashboard
    // Dashboard should have some specific text or URL.
    await expect(page).toHaveURL(/.*dashboard/i);
  });

  test('TC-AUTH-02: User Signup', async ({ page }) => {
    // Mock the backend API response for signup
    await page.route('**/api/auth/signup', async (route) => {
      await route.fulfill({
        status: 201,
        contentType: 'application/json',
        body: JSON.stringify({
          id: 'new-user-123',
          firstName: 'New',
          lastName: 'User',
          email: 'new@pro.co.il'
        }),
      });
    });

    await page.goto('/signup');

    // Fill signup form based on exact labels or placeholders from SignupPage.tsx
    // The inputs don't have unique placeholders mostly, but they are attached to the form.
    // Instead of using placehoder, let's just use input types or names if available, or just generic fill.
    // In React Hook Form, inputs have `name` attributes matching the register key: firstName, lastName, email, password
    await page.locator('input[name="firstName"]').fill('New');
    await page.locator('input[name="lastName"]').fill('User');
    await page.locator('input[name="email"]').fill('new@pro.co.il');
    await page.locator('input[name="password"]').fill('password123');

    // Submit form
    await page.getByRole('button', { name: /צור חשבון/i }).click();

    // After signup, we expect to be redirected to dashboard
    await expect(page).toHaveURL(/.*dashboard/i);
  });
});
