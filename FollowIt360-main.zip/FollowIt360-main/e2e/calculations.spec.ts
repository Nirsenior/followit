import { test, expect } from '@playwright/test';

test.describe('Customer Journal Calculations', () => {
  test.beforeEach(async ({ page }) => {
    // Mock session restore
    await page.route('**/api/auth/me', async (route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ 
          userId: 'test-user', 
          name: 'Test User', 
          email: 'test@pro.co.il',
          agreements: [{ company: 'Migdal', rates: {} }]
        })
      });
    });
    
    // Mock the customer API to return a customer with policies and yields
    // useCustomers typically fetches all customers from /api/customers
    await page.route('**/api/customers', async (route) => {
      // Ignore requests for Vite source code (e.g., /src/api/customers.ts)
      if (route.request().url().includes('.ts') || route.request().url().includes('.tsx')) {
        return route.continue();
      }
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify([
          {
            id: '123456789',
            dbId: 'calc-mock-id',
            firstName: 'John',
            lastName: 'Doe',
            issueDate: new Date().toISOString(),
            policies: [
              {
                id: 'pol-1',
                type: 'pension',
                company: 'Migdal',
                status: 'active',
                isAgentAppointmentOnly: false,
                monthlyCost: 0,
                issueDate: new Date().toISOString(),
                systemEntryDate: new Date().toISOString(),
                details: {
                  accumulation: 100000,
                  monthlyDeposit: 1000,
                  subType: 'מקיפה',
                }
              },
              {
                id: 'pol-2',
                type: 'health',
                company: 'Migdal',
                status: 'active',
                isAgentAppointmentOnly: false,
                monthlyCost: 1000,
                issueDate: new Date().toISOString(),
                systemEntryDate: new Date().toISOString(),
                details: {}
              }
            ]
          }
        ])
      });
    });

  });

  test('TC-CALC-01: View Financial Calculations', async ({ page }) => {
    page.on('console', msg => console.log('PAGE LOG:', msg.text()));
    page.on('pageerror', err => console.log('PAGE ERROR:', err.message));
    
    // Go to dashboard to view the customer
    await page.goto('/dashboard');
    await page.waitForTimeout(2000); // Wait a bit to let any queries finish

    // Verify the page loaded the dashboard
    await expect(page.getByText('דשבורד').first()).toBeVisible({ timeout: 5000 });

    // Verify the pension accumulation is displayed correctly
    await expect(page.getByText('₪100,000').first()).toBeVisible();

    // Verify the monthly premium is displayed correctly
    await expect(page.getByText('₪1,000').first()).toBeVisible();

  });
});
