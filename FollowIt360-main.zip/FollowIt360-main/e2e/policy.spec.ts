import { test, expect } from '@playwright/test';

test.describe('Policy Configurator & Yield Fetching', () => {
  test.beforeEach(async ({ page }) => {
    // Mock login and inject state or just bypass auth
    await page.route('**/api/auth/login', async (route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ userId: 'test-user', name: 'Test User' })
      });
    });
    // Attempt standard login first
    await page.goto('/login');
    const emailInput = page.getByPlaceholder('agent@pro.co.il');
    await expect(emailInput).toBeVisible();
    await emailInput.fill('agent@test.com');
    await page.getByPlaceholder('••••••••').fill('password');
    await page.getByRole('button', { name: 'כניסה מאובטחת' }).click();
    await expect(page).toHaveURL(/.*dashboard/i);
  });

  test('TC-POL-01: Add Financial Policy with MyGemel Track', async ({ page }) => {
    // Mock the backend API response for fetching yield tracks
    await page.route('**/api/yields/tracks*', async (route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          tracks: [
            { id: '123', name: 'Mock Track General', trackId: 100 },
            { id: '456', name: 'Mock Track Equity', trackId: 101 },
          ]
        }),
      });
    });

    // Mock customer update/create API to succeed
    await page.route('**/api/customers*', async (route) => {
        await route.fulfill({
            status: 200,
            contentType: 'application/json',
            body: JSON.stringify({ message: 'Success' })
        });
    });

    // We need to navigate to the customer journal or add policy screen
    // Since we don't have a specific customer, let's assume we can navigate to add customer or directly to a journal if mock data allows.
    // If there is a button 'לקוח חדש' (New Customer), we click it.
    await page.goto('/dashboard');
    const newCustomerBtn = page.getByText(/לקוח חדש|הוסף לקוח/i).first();
    if (await newCustomerBtn.isVisible()) {
        await newCustomerBtn.click();
    } else {
        // Fallback: navigate directly to a journal with a fake ID
        await page.goto('/customer/new-customer-id');
    }

    // Now look for 'הוספת פוליסה' (Add Policy)
    const addPolicyBtn = page.getByRole('button', { name: /הוספת פוליסה/i }).first();
    if (await addPolicyBtn.isVisible()) {
        await addPolicyBtn.click();
    }

    // Assume there is a dropdown or field for Product Type
    const productTypeSelect = page.locator('select[name="productType"], select').first();
    if (await productTypeSelect.isVisible()) {
        await productTypeSelect.selectOption({ label: 'קרן פנסיה' }); // Or whatever is available
    }

    // Wait for tracks to load from the mocked API
    // We should see "Mock Track General"
    const trackDropdown = page.locator('select').nth(1); // Usually the next select is the track, or maybe it's an autocomplete
    if (await trackDropdown.isVisible()) {
        // If it's a select
        await expect(trackDropdown).toContainText('Mock Track General');
    } else {
        // If it's a text input with autocomplete
        const trackInput = page.getByPlaceholder(/מסלול/i).first();
        if (await trackInput.isVisible()) {
            await trackInput.click();
            await expect(page.getByText('Mock Track General').first()).toBeVisible();
            await page.getByText('Mock Track General').first().click();
        }
    }

    // Submit policy
    const submitBtn = page.getByRole('button', { name: /שמור פוליסה/i }).first();
    if (await submitBtn.isVisible()) {
        await submitBtn.click();
    }
    
    // Expect success
    // Wait for the policy to appear in the list or some success toast
    await expect(page.locator('body')).not.toContainText('שגיאה');
  });
});
